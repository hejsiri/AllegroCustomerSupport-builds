<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_0_1_167($module)
{
    if (class_exists('AllegroCustomerServiceUpdater')) {
        Configuration::updateValue(AllegroCustomerServiceUpdater::CONFIG_UPDATE_CHANNEL, AllegroCustomerServiceUpdater::UPDATE_CHANNEL_PUBLIC);
    }

    return true;
}

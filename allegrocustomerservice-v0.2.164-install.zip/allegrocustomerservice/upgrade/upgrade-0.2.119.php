<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_0_2_119($module)
{
    $modulePath = rtrim(method_exists($module, 'getLocalPath') ? $module->getLocalPath() : dirname(__DIR__), '/');
    $paths = [
        '.gitignore',
        'RELEASE_AUTOMATION.md',
        'REPOSITORY_REMOTES.md',
        'scripts',
        'tools',
        'config/.gitkeep',
        'config/git-remotes.conf',
        'config/release-build.conf',
        'config/release-build.conf.example',
    ];

    foreach ($paths as $path) {
        allegrocustomerservice_remove_obsolete_path_0_2_119($modulePath . '/' . $path);
    }

    $configDir = $modulePath . '/config';
    if (is_dir($configDir) && allegrocustomerservice_is_empty_dir_0_2_119($configDir)) {
        @rmdir($configDir);
    }

    return true;
}

function allegrocustomerservice_remove_obsolete_path_0_2_119($path)
{
    if ($path === '' || !file_exists($path)) {
        return;
    }

    if (is_file($path) || is_link($path)) {
        @unlink($path);

        return;
    }

    if (!is_dir($path)) {
        return;
    }

    $iterator = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator($path, FilesystemIterator::SKIP_DOTS),
        RecursiveIteratorIterator::CHILD_FIRST
    );

    foreach ($iterator as $item) {
        if ($item->isDir()) {
            @rmdir($item->getPathname());
        } else {
            @unlink($item->getPathname());
        }
    }

    @rmdir($path);
}

function allegrocustomerservice_is_empty_dir_0_2_119($path)
{
    $items = scandir($path);
    if ($items === false) {
        return false;
    }

    foreach ($items as $item) {
        if ($item !== '.' && $item !== '..') {
            return false;
        }
    }

    return true;
}

<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_0_2_144($module)
{
    Configuration::deleteByName('AAR_RETURN_THUMB_CACHE');

    return true;
}

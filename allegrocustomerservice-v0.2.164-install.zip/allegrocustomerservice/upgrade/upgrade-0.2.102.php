<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_0_2_102($module)
{
    return true;
}

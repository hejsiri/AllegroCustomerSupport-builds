<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_0_2_141($module)
{
    Configuration::deleteByName('AAR_RETURN_THUMB_CACHE');

    return true;
}

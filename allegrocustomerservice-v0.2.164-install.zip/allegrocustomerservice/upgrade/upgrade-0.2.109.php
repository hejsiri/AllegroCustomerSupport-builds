<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_0_2_109($module)
{
    $ok = true;

    if (method_exists($module, 'installTabs')) {
        $ok = $ok && (bool) $module->installTabs();
    }

    foreach (['actionAdminControllerSetMedia', 'displayBackOfficeHeader', 'displayAdminOrderSide', 'displayAdminOrderMain'] as $hookName) {
        if (method_exists($module, 'registerHook')) {
            $module->registerHook($hookName);
        }
    }

    return $ok;
}

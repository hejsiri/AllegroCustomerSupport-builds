<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_0_2_126($module)
{
    return true;
}

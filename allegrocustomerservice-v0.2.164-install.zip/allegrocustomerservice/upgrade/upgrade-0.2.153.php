<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_0_2_153($module)
{
    Configuration::deleteByName('AAR_THREAD_REPLY_STATE_CACHE');

    return true;
}

<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_0_2_110($module)
{
    if (method_exists($module, 'installTabs') && !$module->installTabs()) {
        return false;
    }

    foreach (['actionAdminControllerSetMedia', 'displayBackOfficeHeader', 'displayAdminOrderSide', 'displayAdminOrderMain'] as $hookName) {
        if (method_exists($module, 'registerHook')) {
            $module->registerHook($hookName);
        }
    }

    return true;
}

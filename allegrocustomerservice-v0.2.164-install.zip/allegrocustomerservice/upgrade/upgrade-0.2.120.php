<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_0_2_120($module)
{
    $modulePath = rtrim(method_exists($module, 'getLocalPath') ? $module->getLocalPath() : dirname(__DIR__), '/');
    $paths = [
        'allegroautoresponder.php',
    ];

    foreach ($paths as $path) {
        $fullPath = $modulePath . '/' . $path;
        if (is_file($fullPath) || is_link($fullPath)) {
            @unlink($fullPath);
        }
    }

    return true;
}

<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_0_2_121($module)
{
    // Force regeneration with the improved linked-order thumbnail resolver.
    Configuration::deleteByName('AAR_ISSUE_THUMB_CACHE');

    return true;
}

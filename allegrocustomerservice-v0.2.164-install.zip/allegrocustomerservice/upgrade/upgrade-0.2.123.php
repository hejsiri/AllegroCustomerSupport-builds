<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_0_2_123($module)
{
    Configuration::deleteByName('AAR_ISSUE_THUMB_CACHE');

    return true;
}

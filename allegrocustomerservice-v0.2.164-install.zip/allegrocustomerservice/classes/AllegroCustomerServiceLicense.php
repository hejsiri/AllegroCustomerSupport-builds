<?php

if (!defined('_PS_VERSION_')) {
    exit;
}

if (!class_exists('AllegroCustomerServiceLicense', false)) {
class AllegroCustomerServiceLicense
{
    private const LICENSE_FILE = 'license.php';
    private const PUBLIC_KEY_FILE = 'keys/license_public.pem';

    private $modulePath;
    private $context;
    private $module;
    private $status = null;

    public function __construct(string $modulePath, $context, Module $module)
    {
        $this->modulePath = rtrim($modulePath, '/') . '/';
        $this->context = $context;
        $this->module = $module;
    }

    public function getStatus(): array
    {
        if ($this->status !== null) {
            return $this->status;
        }

        $licenseKey = $this->loadLicenseKey();
        if ($licenseKey === null || $licenseKey === '') {
            return $this->status = $this->buildStatus(false, 'missing', 'Moduł wymaga prawidłowego klucza licencyjnego w pliku license.php.');
        }

        $parts = explode('.', $licenseKey, 2);
        if (count($parts) !== 2) {
            return $this->status = $this->buildStatus(false, 'invalid_format', 'Klucz licencyjny jest nieprawidłowy.');
        }

        $payloadEncoded = trim($parts[0]);
        $signatureEncoded = trim($parts[1]);
        $payloadJson = $this->base64UrlDecode($payloadEncoded);
        $signature = $this->base64UrlDecode($signatureEncoded);

        if ($payloadJson === '' || $signature === '') {
            return $this->status = $this->buildStatus(false, 'invalid_format', 'Klucz licencyjny jest nieprawidłowy.');
        }

        $payload = json_decode($payloadJson, true);
        if (!is_array($payload)) {
            return $this->status = $this->buildStatus(false, 'invalid_payload', 'Klucz licencyjny jest nieprawidłowy.');
        }

        $publicKeyPath = $this->modulePath . self::PUBLIC_KEY_FILE;
        if (!is_file($publicKeyPath)) {
            return $this->status = $this->buildStatus(false, 'public_key_missing', 'Nie udało się odczytać pliku licencji lub klucza publicznego weryfikacji.');
        }

        $publicKey = (string) file_get_contents($publicKeyPath);
        $verification = openssl_verify($payloadEncoded, $signature, $publicKey, OPENSSL_ALGO_SHA256);
        if ($verification !== 1) {
            return $this->status = $this->buildStatus(false, 'signature_invalid', 'Klucz licencyjny jest nieprawidłowy.');
        }

        $licensedModule = (string) ($payload['module'] ?? '');
        if ($licensedModule !== '' && $licensedModule !== $this->module->name) {
            return $this->status = $this->buildStatus(false, 'module_mismatch', 'Klucz licencyjny jest nieprawidłowy.');
        }

        $currentDomain = $this->normalizeDomain($this->getCurrentDomain());
        $licensedDomain = $this->normalizeDomain((string) ($payload['domain'] ?? ''));
        if ($currentDomain === '' || !$this->domainMatches($licensedDomain, $currentDomain)) {
            return $this->status = $this->buildStatus(false, 'domain_mismatch', 'Licencja nie jest ważna dla tej domeny sklepu.');
        }

        $expiresAt = (string) ($payload['expires_at'] ?? '');
        if (!$this->isExpiryValid($expiresAt)) {
            return $this->status = $this->buildStatus(false, 'expired', 'Licencja wygasła.');
        }

        return $this->status = $this->buildStatus(true, 'valid', '', [
            'domain' => $licensedDomain,
            'expires_at' => $expiresAt,
            'payload' => $payload,
        ]);
    }

    public function assertValid(): void
    {
        $status = $this->getStatus();
        if (!$status['valid']) {
            throw new PrestaShopException((string) $status['message']);
        }
    }

    private function buildStatus(bool $valid, string $code, string $message, array $details = []): array
    {
        return [
            'valid' => $valid,
            'code' => $code,
            'message' => $message,
            'details' => $details,
        ];
    }

    private function loadLicenseKey(): ?string
    {
        $licensePath = $this->modulePath . self::LICENSE_FILE;
        if (!is_file($licensePath)) {
            return null;
        }

        try {
            $value = require $licensePath;
        } catch (Throwable $e) {
            return '';
        }

        if (is_string($value)) {
            return trim($value);
        }

        if (is_array($value)) {
            foreach (['key', 'license_key'] as $field) {
                if (!empty($value[$field]) && is_string($value[$field])) {
                    return trim($value[$field]);
                }
            }
        }

        return '';
    }

    private function getCurrentDomain(): string
    {
        $baseUrl = '';
        if (isset($this->context->shop) && method_exists($this->context->shop, 'getBaseURL')) {
            $baseUrl = (string) $this->context->shop->getBaseURL(true);
        }

        $host = (string) parse_url($baseUrl, PHP_URL_HOST);
        if ($host !== '') {
            return $host;
        }

        return (string) ($_SERVER['HTTP_HOST'] ?? $_SERVER['SERVER_NAME'] ?? '');
    }

    private function normalizeDomain(string $domain): string
    {
        $domain = trim(strtolower($domain));
        if ($domain === '') {
            return '';
        }

        if (strpos($domain, '://') !== false) {
            $domain = (string) parse_url($domain, PHP_URL_HOST);
        }

        $domain = preg_replace('~:\d+$~', '', $domain);
        $domain = rtrim((string) $domain, '.');

        if (strpos($domain, 'www.') === 0) {
            $domain = substr($domain, 4);
        }

        return $domain;
    }

    private function domainMatches(string $licensedDomain, string $currentDomain): bool
    {
        if ($licensedDomain === '' || $currentDomain === '') {
            return false;
        }

        if ($licensedDomain === $currentDomain) {
            return true;
        }

        if (strpos($licensedDomain, '*.') === 0) {
            $suffix = substr($licensedDomain, 1);

            return substr($currentDomain, -strlen($suffix)) === $suffix;
        }

        return substr($currentDomain, -strlen('.' . $licensedDomain)) === '.' . $licensedDomain;
    }

    private function isExpiryValid(string $expiresAt): bool
    {
        if ($expiresAt === '') {
            return false;
        }

        try {
            if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $expiresAt)) {
                $expiry = new DateTimeImmutable($expiresAt . ' 23:59:59', new DateTimeZone('UTC'));
            } else {
                $expiry = new DateTimeImmutable($expiresAt);
            }
        } catch (Throwable $e) {
            return false;
        }

        $now = new DateTimeImmutable('now', new DateTimeZone('UTC'));

        return $expiry >= $now;
    }

    private function base64UrlDecode(string $value): string
    {
        $value = strtr($value, '-_', '+/');
        $remainder = strlen($value) % 4;
        if ($remainder > 0) {
            $value .= str_repeat('=', 4 - $remainder);
        }

        $decoded = base64_decode($value, true);

        return $decoded === false ? '' : $decoded;
    }
}
}

<?php
namespace PrestaShop\Module\AllegroCustomerService\Service;

use Configuration;
use Tools;

if (!class_exists(__NAMESPACE__ . '\\AllegroApiClient', false)) {
class AllegroApiClient
{
    private const API_URL = 'https://api.allegro.pl';
    private const ACCEPT = 'application/vnd.allegro.public.v1+json';
    private const ACCEPT_BETA = 'application/vnd.allegro.beta.v1+json';
    private const CONNECT_TIMEOUT = 10;
    private const REQUEST_TIMEOUT = 20;

    /** @var TokenManager */
    private $tokenManager;

    public function __construct(TokenManager $tokenManager)
    {
        $this->tokenManager = $tokenManager;
    }

    public function getThreads(int $limit = 20, int $offset = 0): array
    {
        return $this->request('GET', '/messaging/threads?limit=' . max(1, min(20, $limit)) . '&offset=' . max(0, $offset));
    }

    public function getThread(string $threadId): array
    {
        return $this->request('GET', '/messaging/threads/' . rawurlencode($threadId));
    }

    public function getThreadMessages(string $threadId, int $limit = 20, int $offset = 0): array
    {
        return $this->request('GET', '/messaging/threads/' . rawurlencode($threadId) . '/messages?limit=' . max(1, min(20, $limit)) . '&offset=' . max(0, $offset));
    }

    public function getIssues(int $limit = 20, int $offset = 0, array $filters = []): array
    {
        $params = [
            'limit' => max(1, min(100, $limit)),
            'offset' => max(0, $offset),
        ];

        foreach ($filters as $name => $value) {
            if (!is_scalar($value)) {
                continue;
            }

            $value = trim((string) $value);
            if ($value === '') {
                continue;
            }

            $params[$name] = $value;
        }

        return $this->request('GET', '/sale/issues?' . http_build_query($params), null, self::ACCEPT_BETA);
    }

    public function getIssue(string $issueId): array
    {
        return $this->request('GET', '/sale/issues/' . rawurlencode($issueId), null, self::ACCEPT_BETA);
    }

    public function getCustomerReturns(int $limit = 100, int $offset = 0, array $filters = []): array
    {
        $params = [
            'limit' => max(1, min(1000, $limit)),
            'offset' => max(0, $offset),
        ];

        foreach ($filters as $name => $value) {
            if (!is_scalar($value)) {
                continue;
            }

            $value = trim((string) $value);
            if ($value === '') {
                continue;
            }

            $params[$name] = $value;
        }

        return $this->request('GET', '/order/customer-returns?' . http_build_query($params), null, self::ACCEPT_BETA);
    }

    public function getCustomerReturn(string $customerReturnId): array
    {
        return $this->request('GET', '/order/customer-returns/' . rawurlencode($customerReturnId), null, self::ACCEPT_BETA);
    }

    public function getCarrierTracking(string $carrierId, array $waybills): array
    {
        $carrierId = trim($carrierId);
        $waybills = array_values(array_unique(array_filter(array_map(static function ($waybill): string {
            return trim((string) $waybill);
        }, $waybills))));

        if ($carrierId === '' || !$waybills) {
            return [];
        }

        $params = [];
        foreach (array_slice($waybills, 0, 20) as $waybill) {
            $params[] = 'waybill=' . rawurlencode($waybill);
        }

        return $this->request('GET', '/order/carriers/' . rawurlencode($carrierId) . '/tracking?' . implode('&', $params));
    }

    public function rejectCustomerReturn(string $customerReturnId, string $code, string $reason = ''): array
    {
        $payload = [
            'rejection' => [
                'code' => $code,
            ],
        ];

        $reason = trim($reason);
        if ($reason !== '') {
            $payload['rejection']['reason'] = $reason;
        }

        return $this->request(
            'POST',
            '/order/customer-returns/' . rawurlencode($customerReturnId) . '/rejection',
            $payload,
            self::ACCEPT_BETA
        );
    }

    public function createPaymentRefund(array $payload): array
    {
        return $this->request('POST', '/payments/refunds', $payload);
    }

    public function getProductOffer(string $offerId): array
    {
        return $this->request('GET', '/sale/product-offers/' . rawurlencode($offerId));
    }

    public function getProduct(string $productId): array
    {
        return $this->request('GET', '/sale/products/' . rawurlencode($productId));
    }

    public function getCheckoutForm(string $checkoutFormId): array
    {
        return $this->request('GET', '/order/checkout-forms/' . rawurlencode($checkoutFormId));
    }

    public function getIssueChat(string $issueId, int $limit = 20, int $offset = 0): array
    {
        return $this->request(
            'GET',
            '/sale/issues/' . rawurlencode($issueId) . '/chat?limit=' . max(1, min(100, $limit)) . '&offset=' . max(0, $offset),
            null,
            self::ACCEPT_BETA
        );
    }

    public function sendIssueMessage(string $issueId, string $text, string $type = 'REGULAR', array $attachments = []): array
    {
        return $this->request('POST', '/sale/issues/' . rawurlencode($issueId) . '/message', [
            'text' => $text,
            'attachments' => $attachments,
            'type' => $type,
        ], self::ACCEPT_BETA);
    }

    public function sendMessage(string $recipientLogin, string $text, ?string $orderId = null, array $attachments = []): array
    {
        $orderId = $this->normalizeOptionalString($orderId);
        $payload = [
            'recipient' => [
                'login' => $recipientLogin,
            ],
            'text' => $text,
            'attachments' => $attachments,
        ];

        if ($orderId !== '') {
            $payload['order'] = [
                'id' => $orderId,
            ];
        }

        return $this->request('POST', '/messaging/messages', $payload);
    }

    public function sendMessageToThread(string $threadId, string $text, array $attachments = []): array
    {
        return $this->request('POST', '/messaging/threads/' . rawurlencode($threadId) . '/messages', [
            'text' => $text,
            'attachments' => $attachments,
        ]);
    }

    private function normalizeOptionalString(?string $value): string
    {
        $value = trim((string) $value);
        if ($value === '' || mb_strtolower($value) === 'null') {
            return '';
        }

        return $value;
    }

    public function markThreadRead(string $threadId): array
    {
        return $this->request('PUT', '/messaging/threads/' . rawurlencode($threadId) . '/read', [
            'read' => true,
        ]);
    }

    public function getAuthorizationUrl(): string
    {
        return '';
    }

    public function request(string $method, string $path, ?array $payload = null, ?string $accept = null, ?string $contentType = null): array
    {
        $token = $this->tokenManager->getValidAccessToken();
        $url = self::API_URL . $path;
        $accept = $accept ?: self::ACCEPT;
        $contentType = $contentType ?: $accept;

        $headers = [
            'Authorization: Bearer ' . $token,
            'Accept: ' . $accept,
            'Content-Type: ' . $contentType,
            'User-Agent: PrestaShop-AllegroCustomerSupport/0.1',
        ];

        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $method);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, self::CONNECT_TIMEOUT);
        curl_setopt($ch, CURLOPT_TIMEOUT, self::REQUEST_TIMEOUT);

        if ($payload !== null) {
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
        }

        $raw = curl_exec($ch);
        $status = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);

        if ($raw === false) {
            $error = curl_error($ch);
            curl_close($ch);
            throw new \RuntimeException('cURL error: ' . $error);
        }

        curl_close($ch);

        $decoded = json_decode($raw, true);
        if ($status >= 400) {
            if ($status === 403) {
                throw new \RuntimeException('Allegro API access denied for ' . $method . ' ' . $path . '. Sprawdź uprawnienia aplikacji i ponownie połącz konto Allegro. Response: ' . $raw);
            }

            throw new \RuntimeException('Allegro API error (' . $status . '): ' . $raw);
        }

        return is_array($decoded) ? $decoded : [];
    }
}
}

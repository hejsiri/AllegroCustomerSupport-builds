<?php

if (!class_exists('AllegroCustomerServiceReturnThumbnailModuleFrontController', false)) {
class AllegroCustomerServiceReturnThumbnailModuleFrontController extends ModuleFrontController
{
    public $display_header = false;
    public $display_footer = false;

    public function initContent()
    {
        parent::initContent();

        $token = trim((string) Tools::getValue('token'));
        $expected = trim((string) Configuration::get(AllegroCustomerService::CONFIG_PREFIX . 'CRON_TOKEN'));
        if ($expected === '' || !hash_equals($expected, $token)) {
            http_response_code(403);
            exit;
        }

        $returnId = trim((string) Tools::getValue('return_id'));
        if ($returnId === '') {
            http_response_code(400);
            exit;
        }

        try {
            $url = $this->module->resolveCustomerReturnThumbnailById($returnId);
            if ($url === '') {
                http_response_code(404);
                exit;
            }

            Tools::redirectLink($url);
        } catch (Throwable $e) {
            PrestaShopLogger::addLog('[AAR] Return thumbnail lookup failed for ' . $returnId . ': ' . $e->getMessage(), 2);
            http_response_code(404);
            exit;
        }
    }
}
}

<?php
if (!class_exists('AllegroCustomerServiceCronModuleFrontController', false)) {
class AllegroCustomerServiceCronModuleFrontController extends ModuleFrontController
{
    public $display_header = false;
    public $display_footer = false;

    public function initContent()
    {
        parent::initContent();

        header('Content-Type: application/json');

        $token = (string) Tools::getValue('token');
        $expected = (string) Configuration::get(AllegroCustomerService::CONFIG_PREFIX . 'CRON_TOKEN');

        if (!$expected || !hash_equals($expected, $token)) {
            http_response_code(403);
            die(json_encode(['ok' => false, 'message' => 'Invalid token']));
        }

        if (!(bool) Configuration::get(AllegroCustomerService::CONFIG_PREFIX . 'ENABLED')) {
            die(json_encode(['ok' => true, 'message' => 'Module disabled']));
        }

        try {
            if (!class_exists('AllegroCustomerServiceLicense', false)) {
                require_once dirname(__DIR__, 2) . '/classes/AllegroCustomerServiceLicense.php';
            }
            $license = new AllegroCustomerServiceLicense($this->module->getLocalPath(), $this->context, $this->module);
            $license->assertValid();

            $tokenManager = new \PrestaShop\Module\AllegroCustomerService\Service\TokenManager();
            $apiClient = new \PrestaShop\Module\AllegroCustomerService\Service\AllegroApiClient($tokenManager);
            $ruleEngine = new \PrestaShop\Module\AllegroCustomerService\Service\RuleEngine();
            $logger = new \PrestaShop\Module\AllegroCustomerService\Service\Logger();
            $responder = new \PrestaShop\Module\AllegroCustomerService\Service\Responder($apiClient, $logger, (bool) Configuration::get(AllegroCustomerService::CONFIG_PREFIX . 'TEST_MODE'));
            $scanner = new \PrestaShop\Module\AllegroCustomerService\Service\MessageScanner($apiClient, $ruleEngine, $responder, $logger);
            $summary = $scanner->scan((int) Configuration::get(AllegroCustomerService::CONFIG_PREFIX . 'POLL_LIMIT'));

            die(json_encode(array_merge(['ok' => true], $summary)));
        } catch (Throwable $e) {
            http_response_code(500);
            PrestaShopLogger::addLog('[AAR] Cron error: ' . $e->getMessage(), 3);
            die(json_encode(['ok' => false, 'message' => $e->getMessage()]));
        }
    }
}
}

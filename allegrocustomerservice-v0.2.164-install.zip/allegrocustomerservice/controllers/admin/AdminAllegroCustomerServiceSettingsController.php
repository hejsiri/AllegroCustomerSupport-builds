<?php

if (!class_exists('AdminAllegroCustomerServiceSettingsController', false)) {
class AdminAllegroCustomerServiceSettingsController extends ModuleAdminController
{
    public function __construct()
    {
        $this->bootstrap = true;
        parent::__construct();
    }

    public function initContent()
    {
        parent::initContent();

        $this->content .= $this->module->getContent();
        $this->context->smarty->assign('content', $this->content);
    }
}
}

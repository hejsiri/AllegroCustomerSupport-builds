<?php

declare(strict_types=1);

$root = dirname(__DIR__);

function aarLicenseUsage(): string
{
    return implode(PHP_EOL, [
        'Usage:',
        '  php scripts/generate_license.php --module=allegrocustomerservice --domain=example.com --expires=2027-12-31 --customer="Client" --output=license.php',
        '',
        'Options:',
        '  --module       Technical PrestaShop module name, e.g. allegrocustomerservice or cargostockmanager.',
        '  --domain       Licensed domain. Plain domains also cover subdomains; use *.example.com for wildcard.',
        '  --expires      Expiry date in YYYY-MM-DD format.',
        '  --customer     Optional customer name saved in the signed payload.',
        '  --private-key  Path to RSA private key. Defaults to LICENSE_PRIVATE_KEY, config/license_private.pem,',
        '                 config/update_private.pem, or the local CargoStockManager tools key when present.',
        '  --output       Output file. Use - to print to STDOUT. Default: license.php in current directory.',
        '  --key-only     Print or save only the license key instead of a PHP license.php file.',
        '  --help         Show this help.',
        '',
    ]);
}

function aarLicenseBase64UrlEncode(string $value): string
{
    return rtrim(strtr(base64_encode($value), '+/', '-_'), '=');
}

function aarLicenseBuildKey(string $privateKeyPath, string $module, string $domain, string $expires, string $customer = ''): string
{
    $privateKeyPath = trim($privateKeyPath);
    $module = trim($module);
    $domain = trim($domain);
    $expires = trim($expires);
    $customer = trim($customer);

    if ($module === '' || $domain === '' || $expires === '') {
        throw new InvalidArgumentException('module, domain and expires are required.');
    }

    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $expires)) {
        throw new InvalidArgumentException('expires must use YYYY-MM-DD format.');
    }

    if ($privateKeyPath === '' || !is_file($privateKeyPath)) {
        throw new RuntimeException('Private key not found. Pass --private-key or set LICENSE_PRIVATE_KEY.');
    }

    $payload = [
        'module' => $module,
        'domain' => $domain,
        'expires_at' => $expires,
        'issued_at' => gmdate('c'),
    ];

    if ($customer !== '') {
        $payload['customer'] = $customer;
    }

    $payloadJson = json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    if (!is_string($payloadJson) || $payloadJson === '') {
        throw new RuntimeException('Could not encode license payload.');
    }

    $payloadEncoded = aarLicenseBase64UrlEncode($payloadJson);
    $privateKey = (string) file_get_contents($privateKeyPath);
    if (!openssl_sign($payloadEncoded, $signature, $privateKey, OPENSSL_ALGO_SHA256)) {
        throw new RuntimeException('Could not sign license payload.');
    }

    return $payloadEncoded . '.' . aarLicenseBase64UrlEncode($signature);
}

function aarLicenseBuildPhp(string $licenseKey): string
{
    return "<?php\n\nreturn [\n    'key' => '" . addslashes($licenseKey) . "',\n];\n";
}

function aarLicenseDefaultPrivateKey(string $root): string
{
    $envPath = trim((string) getenv('LICENSE_PRIVATE_KEY'));
    $candidates = [
        $envPath,
        $root . '/config/license_private.pem',
        $root . '/config/update_private.pem',
        '/Users/paweltucki/Sites/localhost/CARGO_STOCK_MANAGER/cargostockmanager-tools/keys/license_private.pem',
    ];

    foreach ($candidates as $candidate) {
        if ($candidate !== '' && is_file($candidate)) {
            return $candidate;
        }
    }

    return '';
}

$options = getopt('', [
    'module:',
    'domain:',
    'expires:',
    'customer::',
    'private-key::',
    'output::',
    'key-only',
    'help',
]);

if (isset($options['help'])) {
    fwrite(STDOUT, aarLicenseUsage());
    exit(0);
}

$module = trim((string) ($options['module'] ?? 'allegrocustomerservice'));
$domain = trim((string) ($options['domain'] ?? ''));
$expires = trim((string) ($options['expires'] ?? ''));
$customer = trim((string) ($options['customer'] ?? ''));
$privateKey = trim((string) ($options['private-key'] ?? ''));
$output = trim((string) ($options['output'] ?? 'license.php'));
$keyOnly = array_key_exists('key-only', $options);

if ($privateKey === '') {
    $privateKey = aarLicenseDefaultPrivateKey($root);
}

if ($domain === '' || $expires === '' || $module === '') {
    fwrite(STDERR, aarLicenseUsage());
    exit(1);
}

try {
    $licenseKey = aarLicenseBuildKey($privateKey, $module, $domain, $expires, $customer);
    $contents = $keyOnly ? $licenseKey . PHP_EOL : aarLicenseBuildPhp($licenseKey);

    if ($output === '-') {
        fwrite(STDOUT, $contents);
    } else {
        $outputDir = dirname($output);
        if ($outputDir !== '.' && !is_dir($outputDir) && !mkdir($outputDir, 0775, true) && !is_dir($outputDir)) {
            throw new RuntimeException('Could not create output directory: ' . $outputDir);
        }
        if (file_put_contents($output, $contents) === false) {
            throw new RuntimeException('Could not write output file: ' . $output);
        }

        fwrite(STDOUT, 'License written: ' . $output . PHP_EOL);
    }
} catch (Throwable $e) {
    fwrite(STDERR, $e->getMessage() . PHP_EOL);
    exit(1);
}

<?php

if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_prestino_build_12($module)
{
    return Configuration::updateValue('AAR_PRESTINO_BUILD', 12);
}

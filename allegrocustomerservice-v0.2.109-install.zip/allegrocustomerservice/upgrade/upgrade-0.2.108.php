<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_0_2_108($module)
{
    if (method_exists($module, 'repairLegacyInstallationState')) {
        return (bool) $module->repairLegacyInstallationState();
    }

    return true;
}

<?php

if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_allegro_customer_service_prestino_34($module)
{
    return Configuration::updateValue('AAR_PRESTINO_BUILD', 34);
}

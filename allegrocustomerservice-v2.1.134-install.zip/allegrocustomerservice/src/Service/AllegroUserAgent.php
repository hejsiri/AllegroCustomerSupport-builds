<?php
/**
 * Copyright (c) 2026 Prestino. All rights reserved.
 *
 * This file is proprietary software. Copying, modification, distribution,
 * or use outside the terms of a valid Prestino license is prohibited.
 *
 * @author Prestino
 * @copyright 2026 Prestino
 * @license Proprietary
 */

namespace PrestaShop\Module\AllegroCustomerService\Service;

if (!defined('_PS_VERSION_')) {
    exit;
}

final class AllegroUserAgent
{
    public const VERSION = '2.1.134';
    private const APPLICATION_NAME = 'Prestino-Obsługa-Klienta-Allegro';
    private const DOCUMENTATION_URL = 'https://www.prestino.pl/22-allegro-customer-service.html';

    public static function value(?string $version = null): string
    {
        $version = trim((string) ($version ?? self::VERSION));
        if (preg_match('/^\d+\.\d+\.\d+$/', $version) !== 1) {
            $version = self::VERSION;
        }

        return self::APPLICATION_NAME . '/' . $version . ' (+' . self::DOCUMENTATION_URL . ')';
    }

    public static function header(): string
    {
        return 'User-Agent: ' . self::value();
    }

}

<?php
/**
 * Copyright (c) 2026 Prestino. All rights reserved.
 *
 * This file is proprietary software. Copying, modification, distribution,
 * or use outside the terms of a valid Prestino license is prohibited.
 *
 * @author Prestino
 * @copyright 2026 Prestino
 * @license Proprietary
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

if (!class_exists('PrestaShop\\Module\\AllegroCustomerService\\Service\\AllegroUserAgent', false)) {
    require_once __DIR__ . '/src/Service/AllegroUserAgent.php';
}
if (!class_exists('PrestaShop\\Module\\AllegroCustomerService\\Service\\AllegroApiClient', false)) {
    require_once __DIR__ . '/src/Service/AllegroApiClient.php';
}
if (!class_exists('PrestaShop\\Module\\AllegroCustomerService\\Service\\TokenManager', false)) {
    require_once __DIR__ . '/src/Service/TokenManager.php';
}
if (!class_exists('PrestaShop\\Module\\AllegroCustomerService\\Service\\RuleEngine', false)) {
    require_once __DIR__ . '/src/Service/RuleEngine.php';
}
if (!class_exists('PrestaShop\\Module\\AllegroCustomerService\\Service\\MessageScanner', false)) {
    require_once __DIR__ . '/src/Service/MessageScanner.php';
}
if (!class_exists('PrestaShop\\Module\\AllegroCustomerService\\Service\\Responder', false)) {
    require_once __DIR__ . '/src/Service/Responder.php';
}
if (!class_exists('PrestaShop\\Module\\AllegroCustomerService\\Service\\Logger', false)) {
    require_once __DIR__ . '/src/Service/Logger.php';
}
if (!class_exists('AllegroCustomerServiceUpdater', false)) {
    require_once __DIR__ . '/classes/AllegroCustomerServiceUpdater.php';
}
if (!class_exists('AllegroCustomerServiceLicense', false)) {
    require_once __DIR__ . '/classes/AllegroCustomerServiceLicense.php';
}

use PrestaShop\Module\AllegroCustomerService\Service\AllegroApiClient;
use PrestaShop\Module\AllegroCustomerService\Service\AllegroUserAgent;
use PrestaShop\Module\AllegroCustomerService\Service\Logger;
use PrestaShop\Module\AllegroCustomerService\Service\MessageScanner;
use PrestaShop\Module\AllegroCustomerService\Service\Responder;
use PrestaShop\Module\AllegroCustomerService\Service\RuleEngine;
use PrestaShop\Module\AllegroCustomerService\Service\TokenManager;

class AllegroCustomerService extends Module
{
    private const TECHNICAL_MODULE_NAME = 'allegrocustomerservice';
    public const PRESTINO_BUILD = 47;
    public const CONFIG_PREFIX = 'AAR_';
    private const ISSUE_THUMB_CACHE_CONFIG = 'AAR_ISSUE_THUMB_CACHE';
    private const RETURN_THUMB_CACHE_CONFIG = 'AAR_RETURN_THUMB_CACHE';
    private const THREAD_REPLY_STATE_CACHE_CONFIG = 'AAR_THREAD_REPLY_STATE_CACHE';
    private const FILTERED_THREAD_API_PAGES_PER_BATCH = 4;
    private const FILTERED_THREAD_API_MAX_PAGES = 20;
    private const MENU_UNREAD_BADGE_CACHE_CONFIG = 'AAR_MENU_UNREAD_BADGE_CACHE';
    private const MENU_RETURNS_BADGE_CACHE_CONFIG = 'AAR_MENU_RETURNS_BADGE_CACHE';
    private const QUICK_REPLIES_CONFIG = 'AAR_QUICK_REPLIES';
    private const CLAIM_REJECTION_TEMPLATE_MIGRATION_CONFIG = 'AAR_CLAIM_REJECTION_TEMPLATE_MIGRATED';
    private const MENU_UNREAD_BADGE_CACHE_TTL = 120;
    private const ADMIN_PARENT_CLASS = 'AdminAllegroCustomerService';
    private const ADMIN_TAB_CLASSES = [
        'AdminAllegroCustomerService',
        'AdminAllegroCustomerServiceMessages',
        'AdminAllegroCustomerServiceDisputes',
        'AdminAllegroCustomerServiceComplaints',
        'AdminAllegroCustomerServiceReturns',
        'AdminAllegroCustomerServiceSettings',
    ];
    private $licenseService;
    private $htmlFragments = [];
    private $htmlFragmentsLoaded = false;

    public function __construct()
    {
        $this->name = 'allegrocustomerservice';
        $this->tab = 'administration';
        $this->version = AllegroUserAgent::VERSION;
        $this->author = 'Prestino';
        $this->need_instance = 0;
        $this->bootstrap = true;
        $this->ps_versions_compliancy = [
            'min' => '8.0.0',
            'max' => _PS_VERSION_,
        ];

        parent::__construct();

        $this->displayName = $this->trans('Obsługa Klienta Allegro', [], 'Modules.Allegrocustomerservice.Admin');
        $this->description = $this->trans('Allegro customer service for PrestaShop: messages, disputes, complaints, returns, automatic replies, CRON tasks and logs.', [], 'Modules.Allegrocustomerservice.Admin');

        if (Module::isInstalled($this->name)) {
            $this->runPostUpdateMigrations();
        }
    }

    protected function getTechnicalModuleName(): string
    {
        return self::TECHNICAL_MODULE_NAME;
    }

    public function getModuleContext()
    {
        return $this->context;
    }

    public function install()
    {
        return parent::install()
            && $this->installDatabase()
            && $this->installTabs()
            && $this->registerHook('actionAdminControllerSetMedia')
            && $this->registerHook('displayBackOfficeHeader')
            && $this->registerHook('displayAdminOrderSide')
            && $this->registerHook('displayAdminOrderMain')
            && Configuration::updateValue(self::CONFIG_PREFIX . 'ENABLED', 0)
            && Configuration::updateValue(self::CONFIG_PREFIX . 'CRON_TOKEN', bin2hex(random_bytes(16)))
            && Configuration::updateValue(self::CONFIG_PREFIX . 'POLL_LIMIT', 20)
            && Configuration::updateValue(self::CONFIG_PREFIX . 'COOLDOWN_MINUTES', 60)
            && Configuration::updateValue(self::CONFIG_PREFIX . 'TEST_MODE', 1)
            && Configuration::updateValue(self::CONFIG_PREFIX . 'CLIENT_ID', '')
            && Configuration::updateValue(self::CONFIG_PREFIX . 'CLIENT_SECRET', '')
            && Configuration::updateValue(self::CONFIG_PREFIX . 'AUTH_BACKEND_URL', '')
            && Configuration::updateValue(self::CONFIG_PREFIX . 'AUTH_BACKEND_KEY', '')
            && Configuration::updateValue(self::CONFIG_PREFIX . 'REDIRECT_URI', '')
            && Configuration::updateValue(self::CONFIG_PREFIX . 'OAUTH_STATE', '')
            && Configuration::updateValue(self::QUICK_REPLIES_CONFIG, '')
            && Configuration::updateValue('AAR_PRESTINO_BUILD', self::PRESTINO_BUILD)
            && $this->seedDefaultRules()
            && $this->installClaimRejectionQuickReply()
            && Configuration::updateValue(self::CLAIM_REJECTION_TEMPLATE_MIGRATION_CONFIG, 1);
    }

    public function uninstall()
    {
        return Configuration::deleteByName(self::CONFIG_PREFIX . 'ENABLED')
            && Configuration::deleteByName(self::CONFIG_PREFIX . 'CRON_TOKEN')
            && Configuration::deleteByName(self::CONFIG_PREFIX . 'POLL_LIMIT')
            && Configuration::deleteByName(self::CONFIG_PREFIX . 'COOLDOWN_MINUTES')
            && Configuration::deleteByName(self::CONFIG_PREFIX . 'TEST_MODE')
            && Configuration::deleteByName(self::CONFIG_PREFIX . 'CLIENT_ID')
            && Configuration::deleteByName(self::CONFIG_PREFIX . 'CLIENT_SECRET')
            && Configuration::deleteByName(self::CONFIG_PREFIX . 'AUTH_BACKEND_URL')
            && Configuration::deleteByName(self::CONFIG_PREFIX . 'AUTH_BACKEND_KEY')
            && Configuration::deleteByName(self::CONFIG_PREFIX . 'REDIRECT_URI')
            && Configuration::deleteByName(self::CONFIG_PREFIX . 'OAUTH_STATE')
            && Configuration::deleteByName(self::QUICK_REPLIES_CONFIG)
            && Configuration::deleteByName(self::CLAIM_REJECTION_TEMPLATE_MIGRATION_CONFIG)
            && Configuration::deleteByName(AllegroCustomerServiceUpdater::CONFIG_UPDATE_CHANNEL)
            && Configuration::deleteByName('AAR_RUNTIME_VERSION')
            && Configuration::deleteByName('AAR_PRESTINO_BUILD')
            && Configuration::deleteByName(self::MENU_UNREAD_BADGE_CACHE_CONFIG)
            && Configuration::deleteByName(self::MENU_RETURNS_BADGE_CACHE_CONFIG)
            && $this->uninstallTabs()
            && $this->uninstallDatabase()
            && parent::uninstall();
    }

    public function installTabs(): bool
    {
        $sellParentId = $this->getTabIdByClassName('SELL');
        if ($sellParentId <= 0) {
            $sellParentId = 0;
        }
        $parentId = $this->installTab(self::ADMIN_PARENT_CLASS, $sellParentId, [
            'pl' => 'Obsługa Klienta Allegro',
            'en' => 'AllegroCustomerSupport',
        ], 'headset_mic');

        if (!$parentId) {
            return false;
        }

        $tabs = [
            'AdminAllegroCustomerServiceMessages' => [
                'pl' => 'Wiadomości',
                'en' => 'Messages',
            ],
            'AdminAllegroCustomerServiceDisputes' => [
                'pl' => 'Dyskusje',
                'en' => 'Disputes',
            ],
            'AdminAllegroCustomerServiceComplaints' => [
                'pl' => 'Reklamacje',
                'en' => 'Complaints',
            ],
            'AdminAllegroCustomerServiceReturns' => [
                'pl' => 'Zwroty towarów',
                'en' => 'Returns',
            ],
            'AdminAllegroCustomerServiceSettings' => [
                'pl' => 'Ustawienia',
                'en' => 'Settings',
            ],
        ];

        foreach ($tabs as $className => $names) {
            if (!$this->installTab($className, $parentId, $names, '', true)) {
                return false;
            }
        }

        return $this->reorderAdminChildTabs((int) $parentId);
    }

    public function uninstallTabs(): bool
    {
        foreach (array_reverse(self::ADMIN_TAB_CLASSES) as $className) {
            $idTab = $this->getTabIdByClassName($className);
            if ($idTab <= 0) {
                continue;
            }

            $tab = new Tab($idTab);
            if (!$tab->delete()) {
                return false;
            }
        }

        return true;
    }

    public function resolveAdminControllerName(string $controller): string
    {
        return $controller;
    }

    public function getAdminLinkFor(string $controller, array $params = []): string
    {
        return $this->context->link->getAdminLink($this->resolveAdminControllerName($controller), true, [], $params);
    }

    private function installTab(string $className, int $parentId, array $names, string $icon = '', bool $active = true)
    {
        $existingId = $this->getTabIdByClassName($className);
        if ($existingId > 0) {
            $tab = new Tab($existingId);
            $tab->id_parent = $parentId;
            $tab->module = $this->name;
            $tab->active = $active;
            if (property_exists($tab, 'enabled')) {
                $tab->enabled = true;
            }
            $tab->name = $this->buildTabNames($names);
            if (property_exists($tab, 'icon')) {
                $tab->icon = $icon;
            }

            if (!$tab->update()) {
                return false;
            }

            return $this->grantAdminTabAccess($existingId) ? $existingId : false;
        }

        $tab = new Tab();
        $tab->active = $active;
        if (property_exists($tab, 'enabled')) {
            $tab->enabled = true;
        }
        $tab->class_name = $className;
        $tab->id_parent = $parentId;
        $tab->module = $this->name;
        $tab->name = $this->buildTabNames($names);
        if (property_exists($tab, 'icon')) {
            $tab->icon = $icon;
        }

        return $tab->add() ? (int) $tab->id : false;
    }

    private function grantAdminTabAccess(int $idTab): bool
    {
        if ($idTab <= 0 || !class_exists('Tab') || !method_exists('Tab', 'initAccess')) {
            return true;
        }

        try {
            Tab::initAccess($idTab);
            if (class_exists('Profile') && method_exists('Profile', 'resetCacheAccesses')) {
                Profile::resetCacheAccesses();
            }
        } catch (Throwable $e) {
            PrestaShopLogger::addLog('[AAR] Admin tab access repair error for tab #' . (int) $idTab . ': ' . $e->getMessage(), 2);

            return false;
        }

        return true;
    }

    private function getTabIdByClassName(string $className): int
    {
        return (int) Db::getInstance()->getValue(
            'SELECT `id_tab` FROM `' . _DB_PREFIX_ . 'tab` WHERE `class_name` = \'' . pSQL($className) . '\''
        );
    }

    private function buildTabNames(array $names): array
    {
        $languages = Language::getLanguages(false);
        $tabNames = [];

        foreach ($languages as $language) {
            $iso = (string) ($language['iso_code'] ?? '');
            $tabNames[(int) $language['id_lang']] = $names[$iso] ?? $names['en'] ?? reset($names);
        }

        return $tabNames;
    }

    private function reorderAdminChildTabs(int $parentId): bool
    {
        if ($parentId <= 0) {
            return false;
        }

        $position = 0;
        foreach (self::ADMIN_TAB_CLASSES as $className) {
            if ($className === self::ADMIN_PARENT_CLASS) {
                continue;
            }

            $tabId = $this->getTabIdByClassName($className);
            if ($tabId <= 0) {
                continue;
            }

            $tab = new Tab($tabId);
            $tab->id_parent = $parentId;
            if (property_exists($tab, 'position')) {
                $tab->position = $position;
            }

            if (!$tab->update()) {
                return false;
            }

            ++$position;
        }

        return true;
    }

    protected function installDatabase()
    {
        $sql = file_get_contents(__DIR__ . '/sql/install.sql');
        $sql = str_replace('PREFIX_', _DB_PREFIX_, $sql);
        foreach (array_filter(array_map('trim', explode(';', $sql))) as $query) {
            if (!Db::getInstance()->execute($query)) {
                return false;
            }
        }

        return true;
    }

    protected function uninstallDatabase()
    {
        $tables = [
            _DB_PREFIX_ . 'allegro_ar_account',
            _DB_PREFIX_ . 'allegro_ar_rule',
            _DB_PREFIX_ . 'allegro_ar_thread',
            _DB_PREFIX_ . 'allegro_ar_log',
        ];

        foreach ($tables as $table) {
            Db::getInstance()->execute('DROP TABLE IF EXISTS `' . pSQL($table) . '`');
        }

        return true;
    }

    public function seedDefaultRules(): bool
    {
        $existingNames = Db::getInstance()->executeS('SELECT name FROM `' . _DB_PREFIX_ . 'allegro_ar_rule`');
        $existingMap = [];
        foreach ($existingNames as $row) {
            $name = trim((string) ($row['name'] ?? ''));
            if ($name === '') {
                continue;
            }

            $existingMap[mb_strtolower($name)] = true;
        }

        $now = date('Y-m-d H:i:s');

        foreach ($this->getDefaultRuleSeeds() as $rule) {
            $ruleName = trim((string) ($rule['name'] ?? ''));
            if ($ruleName === '' || isset($existingMap[mb_strtolower($ruleName)])) {
                continue;
            }

            $data = [
                'name' => pSQL($ruleName),
                'enabled' => (int) ($rule['enabled'] ?? 1),
                'priority' => (int) ($rule['priority'] ?? 100),
                'match_type' => pSQL((string) ($rule['match_type'] ?? 'contains')),
                'keywords' => pSQL((string) ($rule['keywords'] ?? ''), true),
                'response_template' => pSQL((string) ($rule['response_template'] ?? ''), true),
                'only_first_message' => (int) ($rule['only_first_message'] ?? 0),
                'cooldown_minutes' => (int) ($rule['cooldown_minutes'] ?? 180),
                'date_add' => $now,
                'date_upd' => $now,
            ];

            if (!Db::getInstance()->insert('allegro_ar_rule', $data)) {
                return false;
            }

            $existingMap[mb_strtolower($ruleName)] = true;
        }

        return true;
    }

    protected function getDefaultRuleSeeds(): array
    {
        return [
            [
                'name' => 'Status przesylki',
                'priority' => 10,
                'match_type' => 'contains',
                'keywords' => "gdzie paczka\nstatus przesylki\ngdzie jest przesylka\ngdzie moje zamowienie\nkiedy paczka dojdzie\nczy przesylka zostala wyslana",
                'response_template' => "Czesc {buyer_login},\n\ndziekujemy za wiadomosc. Sprawdzimy status przesylki i wrocimy do Ciebie z informacja tak szybko, jak to mozliwe.\n\nPozdrawiamy,\n{shop_name}",
                'only_first_message' => 0,
                'cooldown_minutes' => 180,
            ],
            [
                'name' => 'Termin wysylki',
                'priority' => 20,
                'match_type' => 'contains',
                'keywords' => "kiedy wysylka\nkiedy bedzie wyslane\nkiedy wyślecie\nna kiedy wysylka\njaki czas realizacji\nkiedy nadacie",
                'response_template' => "Czesc {buyer_login},\n\ndziekujemy za kontakt. Sprawdzimy termin realizacji i wrocimy do Ciebie z odpowiedzia tak szybko, jak to mozliwe.\n\nPozdrawiamy,\n{shop_name}",
                'only_first_message' => 0,
                'cooldown_minutes' => 180,
            ],
            [
                'name' => 'Faktura lub paragon',
                'priority' => 30,
                'match_type' => 'contains',
                'keywords' => "faktura\nparagon\ndokument zakupu\nrachunek\nfv\nfakture",
                'response_template' => "Czesc {buyer_login},\n\ndziekujemy za wiadomosc. Sprawdzimy temat dokumentu zakupu i wracamy z informacja tak szybko, jak to mozliwe.\n\nPozdrawiamy,\n{shop_name}",
                'only_first_message' => 0,
                'cooldown_minutes' => 240,
            ],
            [
                'name' => 'Zwrot produktu',
                'priority' => 40,
                'match_type' => 'contains',
                'keywords' => "zwrot\nchce zwrocic\nodstapienie od umowy\nodeslac produkt\njak zwrocic",
                'response_template' => "Czesc {buyer_login},\n\ndziekujemy za wiadomosc. Przekazemy Ci instrukcje dotyczace zwrotu i dalszych krokow tak szybko, jak to mozliwe.\n\nPozdrawiamy,\n{shop_name}",
                'only_first_message' => 1,
                'cooldown_minutes' => 720,
            ],
            [
                'name' => 'Reklamacja lub uszkodzenie',
                'priority' => 50,
                'match_type' => 'contains',
                'keywords' => "reklamacja\nuszkodzony produkt\nprodukt uszkodzony\nwada produktu\nnie dziala\nnie działa\nbrakuje elementu",
                'response_template' => "Czesc {buyer_login},\n\ndziekujemy za wiadomosc. Sprawdzimy zgloszenie i wrocimy do Ciebie z informacja o dalszych krokach tak szybko, jak to mozliwe.\n\nPozdrawiamy,\n{shop_name}",
                'only_first_message' => 1,
                'cooldown_minutes' => 720,
            ],
            [
                'name' => 'Zmiana lub anulowanie zamowienia',
                'priority' => 60,
                'match_type' => 'contains',
                'keywords' => "anulowac zamowienie\nanulacja zamowienia\nzmiana adresu\nzmienic adres\nzmiana zamowienia\nchce anulowac",
                'response_template' => "Czesc {buyer_login},\n\ndziekujemy za kontakt. Sprawdzimy, czy zmiana lub anulowanie zamowienia jest jeszcze mozliwe, i wrocimy do Ciebie z informacja tak szybko, jak to mozliwe.\n\nPozdrawiamy,\n{shop_name}",
                'only_first_message' => 1,
                'cooldown_minutes' => 360,
            ],
            [
                'name' => 'Dostepnosc produktu',
                'priority' => 70,
                'match_type' => 'contains',
                'keywords' => "dostepny\nczy dostepne\nstan magazynowy\nkiedy bedzie dostepne\nkiedy bedzie na stanie\nczy macie na stanie",
                'response_template' => "Czesc {buyer_login},\n\ndziekujemy za wiadomosc. Sprawdzimy dostepnosc produktu i wrocimy do Ciebie z odpowiedzia tak szybko, jak to mozliwe.\n\nPozdrawiamy,\n{shop_name}",
                'only_first_message' => 0,
                'cooldown_minutes' => 240,
            ],
            [
                'name' => 'Parametry i zgodnosc produktu',
                'priority' => 80,
                'match_type' => 'contains',
                'keywords' => "czy pasuje\nczy bedzie pasowac\njakie wymiary\njakie parametry\nspecyfikacja\nkompatybilnosc",
                'response_template' => "Czesc {buyer_login},\n\ndziekujemy za pytanie. Sprawdzimy parametry lub zgodnosc produktu i wrocimy do Ciebie z odpowiedzia tak szybko, jak to mozliwe.\n\nPozdrawiamy,\n{shop_name}",
                'only_first_message' => 0,
                'cooldown_minutes' => 240,
            ],
            [
                'name' => 'Platnosc i zaksięgowanie',
                'priority' => 90,
                'match_type' => 'contains',
                'keywords' => "platnosc\npłatność\nczy wplata dotarla\nczy platnosc zostala zaksięgowana\noplacone\nopłacone\nprzelew",
                'response_template' => "Czesc {buyer_login},\n\ndziekujemy za wiadomosc. Sprawdzimy status platnosci i wrocimy do Ciebie z informacja tak szybko, jak to mozliwe.\n\nPozdrawiamy,\n{shop_name}",
                'only_first_message' => 0,
                'cooldown_minutes' => 180,
            ],
            [
                'name' => 'Prosba o kontakt',
                'priority' => 100,
                'match_type' => 'contains',
                'keywords' => "prosze o kontakt\nproszę o kontakt\nczy mozecie odpisac\nczy możecie odpisać\nczekam na odpowiedz\nbrak odpowiedzi",
                'response_template' => "Czesc {buyer_login},\n\ndziekujemy za kontakt. Wrocimy do Ciebie z odpowiedzia tak szybko, jak to mozliwe.\n\nPozdrawiamy,\n{shop_name}",
                'only_first_message' => 0,
                'cooldown_minutes' => 180,
            ],
        ];
    }

    public function getContent()
    {
        if ((int) Tools::getValue('ajax') === 1) {
            $this->handleAjaxRequest();
        }

        $output = '';
        $this->handleSettingsActions($output);

        $deviceAuthUrl = $this->getAdminLinkFor('AdminAllegroCustomerServiceSettings');
        $prestinoCssPath = $this->getLocalPath() . 'views/css/prestino-license.css';
        $prestinoJsPath = $this->getLocalPath() . 'views/js/prestino-license.js';
        $prestinoConfig = $this->getPrestinoBrowserConfiguration();

        $trustedPanels = [
            $this->htmlFragment('71f2979a09205307aa84') => $this->renderLicenseStatusPanel(),
            $this->htmlFragment('98f96509656c0ad763a7') => $this->renderUpdatePanel(),
            $this->htmlFragment('bd53d5e40752c33b7ee0') => $this->renderSettingsForm(),
            $this->htmlFragment('5ebdedc494efc273c4cd') => $this->renderQuickRepliesSettingsPanel(),
            $this->htmlFragment('9e699b951b181018037e') => $this->renderRuleForm($this->getEditedRule()),
            $this->htmlFragment('8ef41bf45ff4384053c9') => $this->renderRulesTable(),
            $this->htmlFragment('6eac8c921802f22d4506') => $this->renderLogsTable(),
        ];

        $this->context->smarty->assign([
            'prestino_license_css_url' => $this->_path . 'views/css/prestino-license.css?v=' . (is_file($prestinoCssPath) ? filemtime($prestinoCssPath) : $this->version),
            'prestino_license_js_url' => $this->_path . 'views/js/prestino-license.js?v=' . (is_file($prestinoJsPath) ? filemtime($prestinoJsPath) : $this->version),
            'prestino_browser_config_base64' => base64_encode((string) json_encode($prestinoConfig, JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT)),
            'cron_url' => $this->getCronUrl(),
            'oauth_url' => $this->getOauthCallbackUrl(),
            'device_auth_url' => $deviceAuthUrl,
            'device_auth_url_base64' => base64_encode((string) json_encode($deviceAuthUrl)),
            'device_auth_enabled' => $this->hasAllegroAuthBackend(),
            'connected_account' => $this->getConnectedAccount(),
        ]);

        $page = $this->display($this->getModuleEntryFile(), 'views/templates/admin/configure.tpl');

        return $output . strtr($page, $trustedPanels);
    }

    protected function getModuleEntryFile(): string
    {
        $entryFile = $this->getLocalPath() . $this->getTechnicalModuleName() . '.php';

        return is_file($entryFile) ? $entryFile : __FILE__;
    }

    protected function htmlFragment(string $id): string
    {
        if (!$this->htmlFragmentsLoaded) {
            $rendered = $this->display(
                $this->getModuleEntryFile(),
                'views/templates/admin/html-fragments.tpl'
            );
            $matches = [];
            preg_match_all(
                '/@@AAR_FRAGMENT:([a-f0-9]{20})@@(.*?)@@AAR_FRAGMENT_END@@/s',
                $rendered,
                $matches,
                PREG_SET_ORDER
            );

            foreach ($matches as $match) {
                $this->htmlFragments[(string) $match[1]] = (string) $match[2];
            }

            $this->htmlFragmentsLoaded = true;
        }

        if (!array_key_exists($id, $this->htmlFragments)) {
            throw new RuntimeException('Missing Smarty HTML fragment: ' . $id);
        }

        return $this->htmlFragments[$id];
    }

    protected function getCronUrl(): string
    {
        $query = http_build_query([
            'token' => (string) Configuration::get(self::CONFIG_PREFIX . 'CRON_TOKEN'),
        ]);

        return rtrim(Tools::getShopDomainSsl(true) . __PS_BASE_URI__, '/')
            . '/modules/' . rawurlencode($this->name) . '/cron.php?' . $query;
    }

    protected function getLicenseService(): AllegroCustomerServiceLicense
    {
        if (!$this->licenseService instanceof AllegroCustomerServiceLicense) {
            $this->licenseService = new AllegroCustomerServiceLicense($this->getLocalPath(), $this->context, $this);
        }

        return $this->licenseService;
    }

    protected function getLicenseStatus(): array
    {
        return $this->getLicenseService()->getStatus();
    }

    protected function assertLicenseValid(): void
    {
        $this->getLicenseService()->assertValid();
    }

    protected function renderLicenseGateIfInvalid(): string
    {
        $status = $this->getLicenseStatus();
        if (!empty($status['valid'])) {
            return '';
        }

        return $this->htmlFragment('389bc1a93a22a94284fa') . $this->renderLicenseAlert($status) . $this->htmlFragment('aac32651b10f567c461b');
    }

    protected function renderLicenseAlert(array $status): string
    {
        $message = trim((string) ($status['message'] ?? 'Moduł wymaga prawidłowego klucza licencyjnego w pliku license.php.'));
        if ($message === '') {
            $message = 'Moduł wymaga prawidłowego klucza licencyjnego w pliku license.php.';
        }

        return $this->htmlFragment('5d67e76860c75451f93a') . Tools::safeOutput($message) . $this->htmlFragment('aac32651b10f567c461b');
    }

    public function renderLicenseStatusPanel(?array $status = null): string
    {
        $status = is_array($status) ? $status : $this->getLicenseStatus();
        if (empty($status['valid'])) {
            $message = trim((string) ($status['message'] ?? 'Moduł wymaga prawidłowej licencji Prestino.'));

            return $this->htmlFragment('b095e92ffb26d02dae5f')
                . Tools::safeOutput($message !== '' ? $message : 'Moduł wymaga prawidłowej licencji Prestino.') . $this->htmlFragment('aac32651b10f567c461b');
        }

        $details = is_array($status['details'] ?? null) ? $status['details'] : [];
        if ((string) ($details['plan'] ?? '') === 'trial') {
            $expiresAt = trim((string) ($details['expires_at'] ?? ''));
            $message = $expiresAt !== ''
                ? 'Licencja testowa jest ważna do ' . $expiresAt . '.'
                : 'Licencja testowa jest aktywna.';

            return $this->htmlFragment('904931f3134670ead633')
                . Tools::safeOutput($message) . $this->htmlFragment('aac32651b10f567c461b');
        }

        $updatesUntil = trim((string) ($details['updates_until'] ?? ''));
        $maintenance = !empty($details['updates_active'])
            ? 'Aktualizacje dostępne do ' . $updatesUntil . '.'
            : 'Okres aktualizacji wygasł' . ($updatesUntil !== '' ? ' ' . $updatesUntil : '') . '.';

        return $this->htmlFragment('1bd22b865dbe5cfd8406')
            . Tools::safeOutput($maintenance . ' Moduł pozostaje aktywny bezterminowo.') . $this->htmlFragment('aac32651b10f567c461b');
    }

    protected function renderLicenseAlertIfInvalid(): string
    {
        $status = $this->getLicenseStatus();
        if (!empty($status['valid'])) {
            return '';
        }

        return $this->renderLicenseAlert($status);
    }

    protected function handleAjaxRequest(): void
    {
        $action = (string) Tools::getValue('action');

        try {
            if (in_array($action, ['startDeviceAuthorization', 'pollDeviceAuthorization', 'CheckForUpdates', 'InstallUpdate'], true)) {
                $this->assertLicenseValid();
            }

            if ($action === 'startDeviceAuthorization') {
                $result = (new TokenManager())->startDeviceAuthorization();

                $this->jsonResponse([
                    'success' => true,
                    'verificationUriComplete' => (string) ($result['verification_uri_complete'] ?? ''),
                    'userCode' => (string) ($result['user_code'] ?? ''),
                    'deviceCode' => (string) ($result['device_code'] ?? ''),
                    'interval' => max(3, (int) ($result['interval'] ?? 5)),
                ]);
            }

            if ($action === 'pollDeviceAuthorization') {
                $deviceCode = (string) Tools::getValue('device_code');
                if ($deviceCode === '') {
                    throw new RuntimeException('Missing device code.');
                }

                $result = (new TokenManager())->pollDeviceAuthorization($deviceCode);
                $this->jsonResponse([
                    'success' => true,
                    'authorized' => (bool) ($result['authorized'] ?? false),
                    'pending' => (bool) ($result['pending'] ?? false),
                    'error' => (string) ($result['error'] ?? ''),
                    'account' => $result['account'] ?? null,
                ]);
            }

            if ($action === 'CheckForUpdates') {
                $channel = trim((string) Tools::getValue('channel', ''));
                $updater = $this->getUpdater();
                $channelOverride = $channel !== '' ? $channel : null;
                $status = $updater->checkForUpdates($channelOverride);
                $changelog = $updater->getChangelogForUpdate($channelOverride);

                $this->jsonResponse([
                    'ok' => true,
                    'status' => $status,
                    'changelog' => $changelog,
                ]);
            }

            if ($action === 'InstallUpdate') {
                $channel = trim((string) Tools::getValue('channel', ''));
                $result = $this->getUpdater()->installAvailableUpdate($channel !== '' ? $channel : null);

                $this->jsonResponse([
                    'ok' => true,
                    'version' => (string) ($result['version'] ?? ''),
                    'message' => 'Moduł został zaktualizowany. Odśwież stronę panelu.',
                ]);
            }

            $this->jsonResponse([
                'success' => false,
                'message' => 'Unknown AJAX action.',
            ], 400);
        } catch (Throwable $e) {
            PrestaShopLogger::addLog('[AAR] AJAX error: ' . $e->getMessage(), 3);
            $this->jsonResponse([
                'ok' => false,
                'success' => false,
                'message' => $e->getMessage(),
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    protected function jsonResponse(array $payload, int $status = 200): void
    {
        if (function_exists('http_response_code')) {
            http_response_code($status);
        }

        header('Content-Type: application/json; charset=utf-8');
        exit(json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE));
    }

    public function getMessagesContent(): string
    {
        $output = '';
        $licenseGate = $this->renderLicenseGateIfInvalid();
        if ($licenseGate !== '') {
            return $licenseGate;
        }

        if ((int) Tools::getValue('aar_refresh') === 1) {
            $output .= $this->displayConfirmation($this->trans('Wiadomości zostały odświeżone z Allegro.', [], 'Modules.Allegrocustomerservice.Admin'));
        }

        if (Tools::isSubmit('submitAarSendMessage')) {
            $result = $this->sendManualMessage();
            $output .= $result
                ? $this->displayConfirmation($this->trans('Wiadomość została wysłana.', [], 'Modules.Allegrocustomerservice.Admin'))
                : $this->displayError($this->trans('Nie udało się wysłać wiadomości. Sprawdź logi i uprawnienia Allegro.', [], 'Modules.Allegrocustomerservice.Admin'));
        }

        return $output . $this->renderInboxPanel();
    }

    public function getDisputesContent(): string
    {
        return $this->getIssuesContent('DISPUTE', 'Dyskusje', 'Dyskusje zostały odświeżone z Allegro.');
    }

    public function getComplaintsContent(): string
    {
        return $this->getIssuesContent('CLAIM', 'Reklamacje', 'Reklamacje zostały odświeżone z Allegro.');
    }

    public function getReturnsContent(): string
    {
        $output = '';
        $licenseGate = $this->renderLicenseGateIfInvalid();
        if ($licenseGate !== '') {
            return $licenseGate;
        }

        if ((int) Tools::getValue('aar_refresh') === 1) {
            Configuration::deleteByName(self::MENU_RETURNS_BADGE_CACHE_CONFIG);
            $output .= $this->displayConfirmation($this->trans('Zwroty zostały odświeżone z Allegro.', [], 'Modules.Allegrocustomerservice.Admin'));
        }

        if (Tools::isSubmit('submitAarRefundReturn')) {
            try {
                $this->refundCustomerReturnFromRequest();
                Configuration::deleteByName(self::MENU_RETURNS_BADGE_CACHE_CONFIG);
                $output .= $this->displayConfirmation($this->trans('Zwrot pieniędzy został zlecony w Allegro.', [], 'Modules.Allegrocustomerservice.Admin'));
            } catch (Throwable $e) {
                $output .= $this->displayError($this->trans('Nie udało się zlecić zwrotu pieniędzy.', [], 'Modules.Allegrocustomerservice.Admin') . ' ' . Tools::safeOutput($e->getMessage()));
            }
        }

        if (Tools::isSubmit('submitAarRejectReturn')) {
            try {
                $this->rejectCustomerReturnFromRequest();
                Configuration::deleteByName(self::MENU_RETURNS_BADGE_CACHE_CONFIG);
                $output .= $this->displayConfirmation($this->trans('Odmowa zwrotu została wysłana do Allegro.', [], 'Modules.Allegrocustomerservice.Admin'));
            } catch (Throwable $e) {
                $output .= $this->displayError($this->trans('Nie udało się odmówić zwrotu.', [], 'Modules.Allegrocustomerservice.Admin') . ' ' . Tools::safeOutput($e->getMessage()));
            }
        }

        return $output . $this->renderReturnsToolbar() . $this->renderReturnsPanel();
    }

    protected function getIssuesContent(string $issueType, string $sectionTitle, string $refreshMessage): string
    {
        $output = '';
        $licenseGate = $this->renderLicenseGateIfInvalid();
        if ($licenseGate !== '') {
            return $licenseGate;
        }

        if ((int) Tools::getValue('aar_refresh') === 1) {
            $output .= $this->displayConfirmation($this->trans($refreshMessage, [], 'Modules.Allegrocustomerservice.Admin'));
        }

        if (Tools::isSubmit('submitAarSendIssueMessage')) {
            $result = $this->sendIssueMessage($issueType);
            $output .= $result
                ? $this->displayConfirmation($this->trans('Wiadomość została wysłana.', [], 'Modules.Allegrocustomerservice.Admin'))
                : $this->displayError($this->trans('Nie udało się wysłać wiadomości. Sprawdź logi i uprawnienia Allegro.', [], 'Modules.Allegrocustomerservice.Admin'));
        }

        if (Tools::isSubmit('submitAarSetClaimReturn')) {
            try {
                $this->setClaimReturnRequirementFromRequest();
                $output .= $this->displayConfirmation($this->trans('Decyzja o odesłaniu towaru została przekazana do Allegro.', [], 'Modules.Allegrocustomerservice.Admin'));
            } catch (Throwable $e) {
                $output .= $this->displayError($this->trans('Nie udało się zapisać decyzji o odesłaniu towaru.', [], 'Modules.Allegrocustomerservice.Admin') . ' ' . Tools::safeOutput($e->getMessage()));
            }
        }

        if (Tools::isSubmit('submitAarChangeClaimStatus')) {
            try {
                $status = $this->changeClaimStatusFromRequest();
                $message = strpos($status, 'REJECTED_') === 0
                    ? 'Reklamacja została odrzucona w Allegro.'
                    : 'Reklamacja została uznana w Allegro.';
                $output .= $this->displayConfirmation($this->trans($message, [], 'Modules.Allegrocustomerservice.Admin'));
            } catch (Throwable $e) {
                $output .= $this->displayError($this->trans('Nie udało się zapisać decyzji reklamacyjnej.', [], 'Modules.Allegrocustomerservice.Admin') . ' ' . Tools::safeOutput($e->getMessage()));
            }
        }

        return $output . $this->renderIssuesToolbar($issueType) . $this->renderIssuesPanel($issueType, $sectionTitle);
    }

    protected function handleSettingsActions(string &$output): void
    {
        $licenseStatus = $this->getLicenseStatus();
        $licenseValid = (bool) ($licenseStatus['valid'] ?? false);
        $hasProtectedPost = Tools::isSubmit('submitAarSettings')
            || Tools::isSubmit('submitAarSaveQuickReplies')
            || Tools::isSubmit('submitAarSaveUpdateSettings')
            || Tools::isSubmit('submitAarCheckUpdate')
            || Tools::isSubmit('submitAarInstallUpdate')
            || Tools::isSubmit('submitAarDisconnectAccount')
            || Tools::isSubmit('submitAarAddRule')
            || Tools::isSubmit('submitAarSaveRule')
            || Tools::isSubmit('submitAarRunTest')
            || Tools::isSubmit('submitAarInstallDefaultRules')
            || Tools::getIsset('delete_rule');
        if (!$licenseValid && $hasProtectedPost) {
            $output .= $this->renderLicenseAlert($licenseStatus);

            return;
        }

        if (Tools::isSubmit('submitAarSettings')) {
            $this->saveSettings();
            $output .= $this->displayConfirmation($this->trans('Ustawienia zapisane.', [], 'Modules.Allegrocustomerservice.Admin'));
        }

        if (Tools::isSubmit('submitAarSaveQuickReplies')) {
            $this->saveQuickRepliesFromRequest();
            $output .= $this->displayConfirmation($this->trans('Gotowe odpowiedzi zostały zapisane.', [], 'Modules.Allegrocustomerservice.Admin'));
        }

        if (Tools::isSubmit('submitAarSaveUpdateSettings')) {
            try {
                $this->getUpdater()->saveConfiguredChannel((string) Tools::getValue('aar_update_channel', AllegroCustomerServiceUpdater::UPDATE_CHANNEL_PUBLIC));
                $output .= $this->displayConfirmation($this->trans('Ustawienia aktualizacji zapisane.', [], 'Modules.Allegrocustomerservice.Admin'));
            } catch (Throwable $e) {
                $output .= $this->displayError($e->getMessage());
            }
        }

        if (Tools::isSubmit('submitAarCheckUpdate')) {
            try {
                $status = $this->getUpdater()->checkForUpdates();
                if (empty($status['configured'])) {
                    $output .= $this->displayWarning($this->trans('Aktualizacje nie są skonfigurowane.', [], 'Modules.Allegrocustomerservice.Admin'));
                } elseif (!empty($status['available'])) {
                    $output .= $this->displayConfirmation($this->trans('Dostępna jest aktualizacja modułu.', [], 'Modules.Allegrocustomerservice.Admin') . ' ' . Tools::safeOutput((string) $status['version']));
                } else {
                    $output .= $this->displayConfirmation($this->trans('Masz najnowszą wersję modułu.', [], 'Modules.Allegrocustomerservice.Admin'));
                }
            } catch (Throwable $e) {
                $output .= $this->displayError($e->getMessage());
            }
        }

        if (Tools::isSubmit('submitAarInstallUpdate')) {
            try {
                $result = $this->getUpdater()->installAvailableUpdate();
                $output .= $this->displayConfirmation($this->trans('Moduł został zaktualizowany. Odśwież stronę panelu.', [], 'Modules.Allegrocustomerservice.Admin') . ' ' . Tools::safeOutput((string) ($result['version'] ?? '')));
            } catch (Throwable $e) {
                $output .= $this->displayError($e->getMessage());
            }
        }

        if (Tools::isSubmit('submitAarDisconnectAccount')) {
            $this->disconnectAllegroAccount();
            $output .= $this->displayConfirmation($this->trans('Konto Allegro zostało rozłączone w module.', [], 'Modules.Allegrocustomerservice.Admin'));
        }

        if (Tools::isSubmit('submitAarAddRule')) {
            $this->createRuleFromRequest();
            $output .= $this->displayConfirmation($this->trans('Reguła została dodana.', [], 'Modules.Allegrocustomerservice.Admin'));
        }

        if (Tools::isSubmit('submitAarSaveRule')) {
            $this->updateRuleFromRequest((int) Tools::getValue('id_rule'));
            $output .= $this->displayConfirmation($this->trans('Reguła została zapisana.', [], 'Modules.Allegrocustomerservice.Admin'));
        }

        if (Tools::isSubmit('submitAarRunTest')) {
            $result = $this->runManualScan();
            $output .= $result
                ? $this->displayConfirmation($this->trans('Skan ręczny zakończony.', [], 'Modules.Allegrocustomerservice.Admin'))
                : $this->displayError($this->trans('Skan ręczny nie powiódł się. Sprawdź logi i dane API.', [], 'Modules.Allegrocustomerservice.Admin'));
        }

        if (Tools::isSubmit('submitAarInstallDefaultRules')) {
            $result = $this->seedDefaultRules();
            $output .= $result
                ? $this->displayConfirmation($this->trans('Pakiet startowych reguł został zaimportowany. Brakujące reguły zostały dodane bez nadpisywania istniejących.', [], 'Modules.Allegrocustomerservice.Admin'))
                : $this->displayError($this->trans('Nie udało się zaimportować reguł startowych.', [], 'Modules.Allegrocustomerservice.Admin'));
        }

        if (Tools::getIsset('delete_rule')) {
            $this->deleteRule((int) Tools::getValue('delete_rule'));
            $output .= $this->displayConfirmation($this->trans('Reguła została usunięta.', [], 'Modules.Allegrocustomerservice.Admin'));
        }
    }

    public function hookDisplayAdminOrderSide(array $params): string
    {
        return '';
    }

    public function hookDisplayAdminOrderMain(array $params): string
    {
        return '';
    }

    public function hookDisplayBackOfficeHeader(array $params): string
    {
        if (empty($this->getLicenseStatus()['valid'])) {
            return $this->renderAllegroMenuStateScript();
        }

        return $this->renderAllegroMenuStateScript()
            . $this->renderAllegroMenuUnreadBadge()
            . $this->renderAllegroMenuReturnsBadge();
    }

    public function hookActionAdminControllerSetMedia(array $params): void
    {
        $controller = (string) Tools::getValue('controller');
        if ($controller === '') {
            $controller = (string) Tools::getValue('_legacy_controller');
        }
        if ($controller === '' && isset($this->context->controller->controller_name)) {
            $controller = (string) $this->context->controller->controller_name;
        }
        $isModuleConfiguration = $controller === 'AdminModules'
            && (string) Tools::getValue('configure') === $this->name;
        if ($controller !== 'AdminAllegroCustomerServiceSettings' && !$isModuleConfiguration) {
            return;
        }

        $cssPath = $this->getLocalPath() . 'views/css/prestino-license.css';
        $jsPath = $this->getLocalPath() . 'views/js/prestino-license.js';
        $this->context->controller->addCSS(
            $this->_path . 'views/css/prestino-license.css?v=' . (is_file($cssPath) ? filemtime($cssPath) : $this->version)
        );
        $this->context->controller->addJS(
            $this->_path . 'views/js/prestino-license.js?v=' . (is_file($jsPath) ? filemtime($jsPath) : $this->version)
        );

        Media::addJsDef([
            'allegroCustomerServicePrestino' => $this->getPrestinoBrowserConfiguration(),
        ]);
    }

    protected function getPrestinoBrowserConfiguration(): array
    {
        return [
            'valid' => !empty($this->getLicenseStatus()['valid']),
            'licenseHtml' => $this->renderLicenseStatusPanel(),
            'updateUrl' => $this->getAdminLinkFor('AdminAllegroCustomerServiceSettings', ['ajax' => 1]),
        ];
    }

    protected function renderAllegroMenuStateScript(): string
    {
        $controller = (string) Tools::getValue('controller');
        if ($controller === '') {
            $controller = (string) Tools::getValue('_legacy_controller');
        }

        $menuControllers = self::ADMIN_TAB_CLASSES;

        if (!in_array($controller, $menuControllers, true)) {
            return '';
        }

        $config = [
            'parentController' => $this->resolveAdminControllerName(self::ADMIN_PARENT_CLASS),
            'currentController' => $controller,
            'parentLabels' => [
                'Wiadomości Allegro',
                'Obsługa Klienta Allegro',
                'Allegro Messages',
                'AllegroCustomerSupport',
            ],
            'labelsByController' => [
                'AdminAllegroCustomerServiceMessages' => ['Wiadomości', 'Messages'],
                'AdminAllegroCustomerServiceDisputes' => ['Dyskusje', 'Disputes'],
                'AdminAllegroCustomerServiceComplaints' => ['Reklamacje', 'Complaints', 'Reklamacje i dyskusje', 'Complaints and disputes'],
                'AdminAllegroCustomerServiceReturns' => ['Zwroty towarów', 'Returns', 'Zwroty'],
                'AdminAllegroCustomerServiceSettings' => ['Ustawienia', 'Settings'],
            ],
            'renameLabels' => [
                'Reklamacje i dyskusje' => 'Reklamacje',
                'Complaints and disputes' => 'Complaints',
                'Zwroty' => 'Zwroty towarów',
            ],
        ];

        return $this->htmlFragment('f299a9f61886f6ca091d') . json_encode($config) . $this->htmlFragment('9b3d9fae41578f12f055');
    }

    protected function renderAllegroMenuUnreadBadge(): string
    {
        $count = $this->getAllegroUnreadThreadsCount();
        if ($count <= 0) {
            return $this->htmlFragment('b4dd43801b7431731b7d');
        }

        $config = [
            'count' => $count,
            'label' => $this->trans('Nowe wiadomości Allegro', [], 'Modules.Allegrocustomerservice.Admin'),
            'controller' => $this->resolveAdminControllerName(self::ADMIN_PARENT_CLASS),
            'labels' => [
                'Wiadomości Allegro',
                'Obsługa Klienta Allegro',
                'Allegro Messages',
                'AllegroCustomerSupport',
            ],
        ];

        return $this->htmlFragment('fd88dc82c7734e348e42') . json_encode($config) . $this->htmlFragment('d34e9e0449a6508498ba');
    }

    protected function renderAllegroMenuReturnsBadge(): string
    {
        $count = $this->getAllegroOpenReturnsCount();
        if ($count <= 0) {
            return $this->htmlFragment('f6b5a70e04b023f390d4');
        }

        $config = [
            'count' => $count,
            'label' => $this->trans('Zwroty do obsłużenia', [], 'Modules.Allegrocustomerservice.Admin'),
            'controller' => $this->resolveAdminControllerName('AdminAllegroCustomerServiceReturns'),
            'labels' => [
                'Zwroty towarów',
                'Returns',
                'Zwroty',
            ],
        ];

        return $this->htmlFragment('f299a9f61886f6ca091d') . json_encode($config) . $this->htmlFragment('579fe501e9a2bd5d3921');
    }

    protected function getAllegroUnreadThreadsCount(): int
    {
        $cached = $this->getCachedMenuUnreadBadgeCount();
        if ($cached !== null) {
            return $cached;
        }

        try {
            $apiClient = new AllegroApiClient(new TokenManager());
            $limit = 20;
            $maxPages = 5;
            $count = 0;

            for ($page = 0; $page < $maxPages; ++$page) {
                $response = $apiClient->getThreads($limit, $page * $limit);
                $threads = $response['threads'] ?? [];
                if (!is_array($threads) || $threads === []) {
                    break;
                }

                foreach ($threads as $thread) {
                    if (is_array($thread) && isset($thread['read']) && !(bool) $thread['read']) {
                        ++$count;
                    }
                }

                if (count($threads) < $limit) {
                    break;
                }
            }

            $this->setCachedMenuUnreadBadgeCount($count);

            return $count;
        } catch (Throwable $e) {
            return $this->getCachedMenuUnreadBadgeCount(false) ?? 0;
        }
    }

    protected function getAllegroOpenReturnsCount(): int
    {
        $cached = $this->getCachedMenuReturnsBadgeCount();
        if ($cached !== null) {
            return $cached;
        }

        try {
            $apiClient = new AllegroApiClient(new TokenManager());
            $limit = 100;
            $maxPages = 5;
            $count = 0;

            for ($page = 0; $page < $maxPages; ++$page) {
                $response = $apiClient->getCustomerReturns($limit, $page * $limit);
                $returns = $response['customerReturns'] ?? [];
                if (!is_array($returns) || $returns === []) {
                    break;
                }

                foreach ($returns as $return) {
                    if ($this->isCustomerReturnPending($return)) {
                        ++$count;
                    }
                }

                if (count($returns) < $limit) {
                    break;
                }
            }

            $this->setCachedMenuReturnsBadgeCount($count);

            return $count;
        } catch (Throwable $e) {
            return $this->getCachedMenuReturnsBadgeCount(false) ?? 0;
        }
    }

    protected function getCachedMenuUnreadBadgeCount(bool $onlyFresh = true): ?int
    {
        $stored = (string) Configuration::get(self::MENU_UNREAD_BADGE_CACHE_CONFIG);
        if ($stored === '') {
            return null;
        }

        $decoded = json_decode($stored, true);
        if (!is_array($decoded) || !isset($decoded['count'], $decoded['timestamp'])) {
            return null;
        }

        if ($onlyFresh && time() - (int) $decoded['timestamp'] > self::MENU_UNREAD_BADGE_CACHE_TTL) {
            return null;
        }

        return max(0, (int) $decoded['count']);
    }

    protected function setCachedMenuUnreadBadgeCount(int $count): void
    {
        Configuration::updateValue(self::MENU_UNREAD_BADGE_CACHE_CONFIG, json_encode([
            'count' => max(0, $count),
            'timestamp' => time(),
        ]));
    }

    protected function getCachedMenuReturnsBadgeCount(bool $onlyFresh = true): ?int
    {
        $stored = (string) Configuration::get(self::MENU_RETURNS_BADGE_CACHE_CONFIG);
        if ($stored === '') {
            return null;
        }

        $decoded = json_decode($stored, true);
        if (!is_array($decoded) || !isset($decoded['count'], $decoded['timestamp'])) {
            return null;
        }

        if ($onlyFresh && time() - (int) $decoded['timestamp'] > self::MENU_UNREAD_BADGE_CACHE_TTL) {
            return null;
        }

        return max(0, (int) $decoded['count']);
    }

    protected function setCachedMenuReturnsBadgeCount(int $count): void
    {
        Configuration::updateValue(self::MENU_RETURNS_BADGE_CACHE_CONFIG, json_encode([
            'count' => max(0, $count),
            'timestamp' => time(),
        ]));
    }

    protected function isCustomerReturnPending($return): bool
    {
        if (!is_array($return)) {
            return false;
        }

        $status = mb_strtoupper(trim((string) ($return['status'] ?? '')));

        return !in_array($status, ['FINISHED', 'FINISHED_APT', 'REJECTED', 'COMMISSION_REFUNDED'], true);
    }

    protected function saveSettings()
    {
        Configuration::updateValue(self::CONFIG_PREFIX . 'ENABLED', (int) Tools::getValue(self::CONFIG_PREFIX . 'ENABLED'));
        Configuration::updateValue(self::CONFIG_PREFIX . 'POLL_LIMIT', (int) Tools::getValue(self::CONFIG_PREFIX . 'POLL_LIMIT'));
        Configuration::updateValue(self::CONFIG_PREFIX . 'COOLDOWN_MINUTES', (int) Tools::getValue(self::CONFIG_PREFIX . 'COOLDOWN_MINUTES'));
        Configuration::updateValue(self::CONFIG_PREFIX . 'TEST_MODE', (int) Tools::getValue(self::CONFIG_PREFIX . 'TEST_MODE'));
        Configuration::updateValue(self::CONFIG_PREFIX . 'REDIRECT_URI', trim((string) Tools::getValue(self::CONFIG_PREFIX . 'REDIRECT_URI')));
    }

    protected function saveQuickRepliesFromRequest(): void
    {
        $names = Tools::getValue('quick_reply_name', []);
        $texts = Tools::getValue('quick_reply_text', []);
        $enabled = Tools::getValue('quick_reply_enabled', []);

        if (!is_array($names)) {
            $names = [];
        }
        if (!is_array($texts)) {
            $texts = [];
        }
        if (!is_array($enabled)) {
            $enabled = [];
        }

        $rows = [];
        $indexes = array_values(array_unique(array_merge(array_keys($names), array_keys($texts), array_keys($enabled))));
        sort($indexes);

        foreach ($indexes as $index) {
            $name = trim((string) ($names[$index] ?? ''));
            $text = trim((string) ($texts[$index] ?? ''));
            if ($name === '' && $text === '') {
                continue;
            }
            if ($text === '') {
                continue;
            }

            $rows[] = [
                'name' => $name !== '' ? $name : 'Gotowa odpowiedź',
                'response_template' => $text,
                'enabled' => (int) ($enabled[$index] ?? 0) === 1 ? 1 : 0,
            ];
        }

        Configuration::updateValue(self::QUICK_REPLIES_CONFIG, json_encode($rows, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
    }

    public function installClaimRejectionQuickReply(): bool
    {
        $rows = $this->getQuickReplyRowsForSettings();
        $template = $this->getClaimRejectionQuickReplyTemplate();

        foreach ($rows as $row) {
            if (trim((string) ($row['name'] ?? '')) === $template['name']) {
                return true;
            }
        }

        $rows[] = $template;

        return Configuration::updateValue(
            self::QUICK_REPLIES_CONFIG,
            json_encode($rows, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)
        );
    }

    protected function runPostUpdateMigrations(): void
    {
        if ((int) Configuration::get(self::CLAIM_REJECTION_TEMPLATE_MIGRATION_CONFIG) === 1) {
            return;
        }

        if ($this->installClaimRejectionQuickReply()) {
            Configuration::updateValue(self::CLAIM_REJECTION_TEMPLATE_MIGRATION_CONFIG, 1);
        }
    }

    protected function getClaimRejectionQuickReplyTemplate(): array
    {
        return [
            'name' => 'Odpowiedź na reklamację — odmowa',
            'response_template' => "Odpowiedź na reklamację\n\nInformuję, iż w odpowiedzi na reklamację złożoną dnia {claim_submitted_date} r., doręczoną dnia {claim_received_date} r., dotyczącą produktu {offer_title}, postanawiam uznać tę reklamację za niezasadną.\nZakup został dokonany dnia {purchase_date} r. w kwocie {claim_amount}. Według złożonej reklamacji stwierdzono wadę polegającą na tym, że: {claim_reason_description}.\nW wyniku przeprowadzonej diagnozy dostarczonego towaru stwierdzamy, iż [uzupełnij wynik diagnozy].\nZłożona reklamacja nie wykazała, iż wada istniała już w momencie zakupu, dlatego postanawiam jak na wstępie.\nReklamacja została rozpatrzona z uwzględnieniem wszelkich praw wynikających z ustawy o prawach konsumenta oraz Kodeksu cywilnego. Pragnę również poinformować, iż od niniejszej odpowiedzi przysługuje prawo do odwołania się.",
            'enabled' => 1,
        ];
    }

    protected function disconnectAllegroAccount(): void
    {
        Db::getInstance()->execute('TRUNCATE TABLE `' . _DB_PREFIX_ . 'allegro_ar_account`');
        Configuration::deleteByName(self::MENU_UNREAD_BADGE_CACHE_CONFIG);
        Configuration::deleteByName(self::MENU_RETURNS_BADGE_CACHE_CONFIG);
    }

    protected function createRuleFromRequest(): void
    {
        $data = [
            'name' => pSQL((string) Tools::getValue('rule_name')),
            'enabled' => (int) Tools::getValue('rule_enabled', 0),
            'priority' => (int) Tools::getValue('rule_priority', 100),
            'match_type' => pSQL((string) Tools::getValue('rule_match_type', 'contains')),
            'keywords' => pSQL((string) Tools::getValue('rule_keywords')),
            'response_template' => pSQL((string) Tools::getValue('rule_response_template'), true),
            'only_first_message' => (int) Tools::getValue('rule_only_first_message', 0),
            'cooldown_minutes' => (int) Tools::getValue('rule_cooldown_minutes', 60),
            'date_add' => date('Y-m-d H:i:s'),
            'date_upd' => date('Y-m-d H:i:s'),
        ];

        Db::getInstance()->insert('allegro_ar_rule', $data);
    }

    protected function updateRuleFromRequest(int $idRule): void
    {
        if ($idRule <= 0) {
            return;
        }

        Db::getInstance()->update('allegro_ar_rule', [
            'name' => pSQL((string) Tools::getValue('rule_name')),
            'enabled' => (int) Tools::getValue('rule_enabled', 0),
            'priority' => (int) Tools::getValue('rule_priority', 100),
            'match_type' => pSQL((string) Tools::getValue('rule_match_type', 'contains')),
            'keywords' => pSQL((string) Tools::getValue('rule_keywords')),
            'response_template' => pSQL((string) Tools::getValue('rule_response_template'), true),
            'only_first_message' => (int) Tools::getValue('rule_only_first_message', 0),
            'cooldown_minutes' => (int) Tools::getValue('rule_cooldown_minutes', 60),
            'date_upd' => date('Y-m-d H:i:s'),
        ], 'id_rule=' . (int) $idRule);
    }

    protected function deleteRule(int $idRule)
    {
        return Db::getInstance()->delete('allegro_ar_rule', 'id_rule=' . (int) $idRule);
    }

    protected function runManualScan(): bool
    {
        try {
            $tokenManager = new TokenManager();
            $apiClient = new AllegroApiClient($tokenManager);
            $ruleEngine = new RuleEngine();
            $logger = new Logger();
            $responder = new Responder($apiClient, $logger, (bool) Configuration::get(self::CONFIG_PREFIX . 'TEST_MODE'));
            $scanner = new MessageScanner($apiClient, $ruleEngine, $responder, $logger);

            $scanner->scan((int) Configuration::get(self::CONFIG_PREFIX . 'POLL_LIMIT'));

            return true;
        } catch (Throwable $e) {
            PrestaShopLogger::addLog('[AAR] Manual scan error: ' . $e->getMessage(), 3);

            return false;
        }
    }

    protected function sendManualMessage(): bool
    {
        $threadId = trim((string) Tools::getValue('thread_id'));
        $text = trim((string) Tools::getValue('reply_text'));
        $logger = new Logger();

        if ($threadId === '' || $text === '') {
            $logger->log('manual_reply_failed', $threadId, '', '', ['text' => $text], ['error' => 'Thread ID or reply text is empty'], false);

            return false;
        }

        try {
            $apiClient = new AllegroApiClient(new TokenManager());
            $threadPayload = [];
            $threadMessages = [];

            try {
                $threadResponse = $apiClient->getThread($threadId);
                if (is_array($threadResponse)) {
                    $threadPayload = $threadResponse;
                }
            } catch (Throwable $e) {
                PrestaShopLogger::addLog('[AAR] Manual reply context thread lookup failed for ' . $threadId . ': ' . $e->getMessage(), 2);
            }

            try {
                $messagesResponse = $apiClient->getThreadMessages($threadId, 20);
                $threadMessages = is_array($messagesResponse['messages'] ?? null) ? $messagesResponse['messages'] : [];
            } catch (Throwable $e) {
                PrestaShopLogger::addLog('[AAR] Manual reply context messages lookup failed for ' . $threadId . ': ' . $e->getMessage(), 2);
            }

            $text = $this->applyQuickReplyTemplateReplacements($text, $this->buildQuickReplyReplacementsForThread($threadPayload, $threadMessages));
            if (trim($text) === '') {
                $logger->log('manual_reply_failed', $threadId, '', '', ['text' => $text], ['error' => 'Reply text is empty after variable replacement'], false);

                return false;
            }

            $response = $apiClient->sendMessageToThread($threadId, $text);

            try {
                $apiClient->markThreadRead($threadId);
                Configuration::deleteByName(self::MENU_UNREAD_BADGE_CACHE_CONFIG);
            } catch (Throwable $e) {
                $logger->log('mark_read_failed', $threadId, '', '', [], ['error' => $e->getMessage()], false);
            }

            $logger->log('manual_reply_sent', $threadId, (string) ($response['id'] ?? ''), '', ['text' => $text], $response, true);

            return true;
        } catch (Throwable $e) {
            PrestaShopLogger::addLog('[AAR] Manual reply error: ' . $e->getMessage(), 3);
            $logger->log('manual_reply_failed', $threadId, '', '', ['text' => $text], ['error' => $e->getMessage()], false);

            return false;
        }
    }

    protected function sendIssueMessage(string $issueType): bool
    {
        $issueId = trim((string) Tools::getValue('issue_id'));
        $text = trim((string) Tools::getValue('reply_text'));
        $logger = new Logger();

        if ($issueId === '' || $text === '') {
            $logger->log('issue_reply_failed', $issueId, '', '', ['text' => $text, 'type' => $issueType], ['error' => 'Issue ID or reply text is empty'], false);

            return false;
        }

        try {
            $apiClient = new AllegroApiClient(new TokenManager());
            $issuePayload = [];
            $issueMessages = [];

            try {
                $issueResponse = $apiClient->getIssue($issueId);
                if (is_array($issueResponse)) {
                    $issuePayload = $issueResponse;
                }
            } catch (Throwable $e) {
                PrestaShopLogger::addLog('[AAR] Issue reply context issue lookup failed for ' . $issueId . ': ' . $e->getMessage(), 2);
            }

            try {
                $chatResponse = $apiClient->getIssueChat($issueId, 20);
                $issueMessages = is_array($chatResponse['messages'] ?? null) ? $chatResponse['messages'] : [];
            } catch (Throwable $e) {
                PrestaShopLogger::addLog('[AAR] Issue reply context chat lookup failed for ' . $issueId . ': ' . $e->getMessage(), 2);
            }

            $text = $this->applyQuickReplyTemplateReplacements($text, $this->buildQuickReplyReplacementsForIssue($issuePayload, $issueMessages));
            if (trim($text) === '') {
                $logger->log('issue_reply_failed', $issueId, '', '', ['text' => $text, 'type' => $issueType], ['error' => 'Reply text is empty after variable replacement'], false);

                return false;
            }

            $response = $apiClient->sendIssueMessage($issueId, $text);
            $logger->log('issue_reply_sent', $issueId, (string) ($response['id'] ?? ''), '', ['text' => $text, 'type' => $issueType], $response, true);

            return true;
        } catch (Throwable $e) {
            PrestaShopLogger::addLog('[AAR] Issue reply error: ' . $e->getMessage(), 3);
            $logger->log('issue_reply_failed', $issueId, '', '', ['text' => $text, 'type' => $issueType], ['error' => $e->getMessage()], false);

            return false;
        }
    }

    protected function setClaimReturnRequirementFromRequest(): void
    {
        $issueId = trim((string) Tools::getValue('issue_id'));
        $choice = mb_strtoupper(trim((string) Tools::getValue('claim_return_choice')));
        if ($choice === 'SELLER_LABEL') {
            $text = trim((string) Tools::getValue('claim_return_label_message'));
        } elseif ($choice === 'CUSTOM') {
            $text = trim((string) Tools::getValue('claim_return_custom_message'));
        } else {
            $text = trim((string) Tools::getValue('claim_return_message'));
        }
        $confirmed = (int) Tools::getValue('claim_return_confirm') === 1;
        $definitions = [
            'NOT_REQUIRED' => [
                'type' => 'RETURN_NOT_REQUIRED',
                'default_message' => 'Reklamacja zostanie rozpatrzona bez konieczności odsyłania towaru.',
            ],
            'CUSTOM' => [
                'type' => 'RETURN_REQUIRED_CUSTOM',
                'default_message' => '',
            ],
            'SELLER_LABEL' => [
                'type' => 'RETURN_REQUIRED_SELLER_LABEL',
                'default_message' => 'W załączniku przekazuję etykietę do odesłania reklamowanego towaru.',
            ],
        ];

        if ($issueId === '') {
            throw new RuntimeException('Brakuje identyfikatora reklamacji.');
        }
        if (!isset($definitions[$choice])) {
            throw new RuntimeException('Nieznana decyzja dotycząca odesłania towaru.');
        }
        if (!$confirmed) {
            throw new RuntimeException('Potwierdź decyzję przed wysłaniem.');
        }

        if ($text === '') {
            $text = (string) $definitions[$choice]['default_message'];
        }
        if ($text === '') {
            throw new RuntimeException('Podaj kupującemu instrukcję odesłania lub odbioru towaru.');
        }
        $messageLimit = in_array($choice, ['SELLER_LABEL', 'CUSTOM'], true) ? 700 : 20000;
        if (mb_strlen($text) > $messageLimit) {
            throw new RuntimeException('Wiadomość może zawierać maksymalnie ' . $messageLimit . ' znaków.');
        }

        $type = (string) $definitions[$choice]['type'];
        $apiClient = new AllegroApiClient(new TokenManager());
        $attachments = [];
        $attachmentMeta = [];
        if ($choice === 'SELLER_LABEL') {
            $attachmentMeta = $this->uploadClaimSellerLabelFromRequest($apiClient);
            $attachments[] = ['id' => (string) $attachmentMeta['id']];
        }

        $response = $apiClient->sendIssueMessage($issueId, $text, $type, $attachments);
        (new Logger())->log('claim_return_requirement_sent', $issueId, (string) ($response['id'] ?? ''), '', [
            'choice' => $choice,
            'type' => $type,
            'text' => $text,
            'attachment' => $attachmentMeta,
        ], $response, true);
    }

    protected function uploadClaimSellerLabelFromRequest(AllegroApiClient $apiClient): array
    {
        $file = $_FILES['claim_return_label'] ?? null;
        if (!is_array($file)) {
            throw new RuntimeException('Załącz etykietę przewozową.');
        }

        $error = (int) ($file['error'] ?? UPLOAD_ERR_NO_FILE);
        if ($error !== UPLOAD_ERR_OK) {
            throw new RuntimeException($error === UPLOAD_ERR_INI_SIZE || $error === UPLOAD_ERR_FORM_SIZE ? 'Plik etykiety jest zbyt duży.' : 'Nie udało się odebrać pliku etykiety.');
        }

        $temporaryPath = (string) ($file['tmp_name'] ?? '');
        $size = (int) ($file['size'] ?? 0);
        if ($temporaryPath === '' || !is_uploaded_file($temporaryPath) || $size <= 0) {
            throw new RuntimeException('Przesłany plik etykiety jest nieprawidłowy.');
        }
        if ($size > 2097152) {
            throw new RuntimeException('Etykieta może mieć maksymalnie 2 MB.');
        }

        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        $contentType = $finfo ? (string) finfo_file($finfo, $temporaryPath) : '';
        if ($finfo) {
            finfo_close($finfo);
        }
        $allowedContentTypes = [
            'application/pdf',
            'image/png',
            'image/gif',
            'image/bmp',
            'image/tiff',
            'image/jpeg',
        ];
        if (!in_array($contentType, $allowedContentTypes, true)) {
            throw new RuntimeException('Dozwolone formaty etykiety: PDF, PNG, JPG, GIF, BMP lub TIFF.');
        }

        $fileName = trim(basename((string) ($file['name'] ?? 'etykieta')));
        if ($fileName === '') {
            $fileName = 'etykieta';
        }
        $fileName = mb_substr($fileName, 0, 200);
        $contents = file_get_contents($temporaryPath);
        if (!is_string($contents) || $contents === '') {
            throw new RuntimeException('Nie udało się odczytać pliku etykiety.');
        }

        $declaration = $apiClient->declareIssueAttachment($fileName, $size);
        $attachmentId = trim((string) ($declaration['id'] ?? ''));
        $uploadUrl = trim((string) ($declaration['uploadUrl'] ?? ''));
        if ($attachmentId === '' || $uploadUrl === '') {
            throw new RuntimeException('Allegro nie zwróciło danych potrzebnych do przesłania etykiety.');
        }

        $apiClient->uploadIssueAttachment($uploadUrl, $contents, $contentType);

        return [
            'id' => $attachmentId,
            'file_name' => $fileName,
            'size' => $size,
            'content_type' => $contentType,
        ];
    }

    protected function changeClaimStatusFromRequest(): string
    {
        $issueId = trim((string) Tools::getValue('issue_id'));
        $status = mb_strtoupper(trim((string) Tools::getValue('claim_status')));
        $message = trim((string) Tools::getValue('claim_status_message'));
        $definitions = $this->getClaimStatusActionDefinitions();

        if ($issueId === '') {
            throw new RuntimeException('Brakuje identyfikatora reklamacji.');
        }
        if (!isset($definitions[$status])) {
            throw new RuntimeException('Nieznana decyzja reklamacyjna.');
        }
        if ($message === '') {
            throw new RuntimeException('Uzasadnienie decyzji jest wymagane.');
        }
        if (mb_strlen($message) > 1500) {
            throw new RuntimeException('Uzasadnienie może zawierać maksymalnie 1500 znaków.');
        }

        $partialRefund = null;
        if ($status === 'ACCEPTED_PARTIAL_REFUND') {
            $rawAmount = str_replace(',', '.', trim((string) Tools::getValue('claim_partial_refund_amount')));
            $currency = mb_strtoupper(trim((string) Tools::getValue('claim_partial_refund_currency')));
            if ($rawAmount === '' || !is_numeric($rawAmount) || (float) $rawAmount <= 0) {
                throw new RuntimeException('Podaj prawidłową kwotę częściowego zwrotu.');
            }
            if (!preg_match('/^[A-Z]{3}$/', $currency)) {
                throw new RuntimeException('Podaj prawidłowy trzyliterowy kod waluty.');
            }
            $partialRefund = [
                'amount' => number_format((float) $rawAmount, 2, '.', ''),
                'currency' => $currency,
            ];
        }

        $apiClient = new AllegroApiClient(new TokenManager());
        $response = $apiClient->changeIssueClaimStatus($issueId, $status, $message, $partialRefund);
        (new Logger())->log('claim_status_changed', $issueId, '', '', [
            'status' => $status,
            'message' => $message,
            'partial_refund' => $partialRefund,
        ], $response, true);

        return $status;
    }

    protected function getClaimStatusActionDefinitions(): array
    {
        return [
            'ACCEPTED_REPAIR' => ['group' => 'accepted', 'label' => 'Naprawa'],
            'ACCEPTED_REFUND' => ['group' => 'accepted', 'label' => 'Zwrot płatności'],
            'ACCEPTED_EXCHANGE' => ['group' => 'accepted', 'label' => 'Wymiana na nowy towar'],
            'ACCEPTED_PARTIAL_REFUND' => ['group' => 'accepted', 'label' => 'Częściowy zwrot płatności'],
            'REJECTED_ADDITIONAL_REQUIREMENTS_NOT_COMPLETED' => ['group' => 'rejected', 'label' => 'Kupujący nie uzupełnił braków w reklamacji'],
            'REJECTED_PRODUCT_NOT_RETURNED' => ['group' => 'rejected', 'label' => 'Kupujący nie udostępnił towaru'],
            'REJECTED_PRODUCT_DAMAGED_BY_USER' => ['group' => 'rejected', 'label' => 'Uszkodzenie towaru przez kupującego'],
            'REJECTED_PRODUCT_CONFORMS_TO_CONTRACT' => ['group' => 'rejected', 'label' => 'Brak niezgodności towaru z umową sprzedaży'],
            'REJECTED_MINOR_DEFECT' => ['group' => 'rejected', 'label' => 'Nieistotna wada'],
            'REJECTED_CLAIM_WITHDRAWN_BY_BUYER' => ['group' => 'rejected', 'label' => 'Reklamacja wycofana przez kupującego'],
            'REJECTED_OTHER' => ['group' => 'rejected', 'label' => 'Inny powód'],
        ];
    }

    protected function rejectCustomerReturnFromRequest(): void
    {
        $returnId = trim((string) Tools::getValue('return_id'));
        $selectedReason = mb_strtoupper(trim((string) Tools::getValue('return_rejection_code')));
        $reason = trim((string) Tools::getValue('return_rejection_reason'));
        $definitions = $this->getCustomerReturnRejectionReasonDefinitions();
        $logger = new Logger();
        $code = '';

        if ($returnId === '') {
            throw new RuntimeException('Brakuje identyfikatora zwrotu.');
        }
        if (!isset($definitions[$selectedReason])) {
            throw new RuntimeException('Nieznany powód odmowy zwrotu.');
        }
        $code = (string) ($definitions[$selectedReason]['api_code'] ?? '');
        if ($code === '') {
            throw new RuntimeException('Brakuje mapowania powodu odmowy zwrotu.');
        }
        if ($code === 'REFUND_REJECTED' && $reason === '') {
            throw new RuntimeException('Dla odmowy zwrotu środków wymagane jest uzasadnienie.');
        }

        try {
            $apiClient = new AllegroApiClient(new TokenManager());
            $response = $apiClient->rejectCustomerReturn($returnId, $code, $reason);
            $logger->log('return_rejection_sent', $returnId, '', $code, [
                'reason' => $reason,
            ], $response, true);
        } catch (Throwable $e) {
            PrestaShopLogger::addLog('[AAR] Customer return rejection error: ' . $e->getMessage(), 3);
            $logger->log('return_rejection_failed', $returnId, '', $code, [
                'reason' => $reason,
            ], ['error' => $e->getMessage()], false);
            throw $e;
        }
    }

    protected function refundCustomerReturnFromRequest(): void
    {
        $returnId = trim((string) Tools::getValue('return_id'));
        $linePayloads = Tools::getValue('return_refund_lines');
        $deliveryAmount = $this->normalizeRefundAmount((string) Tools::getValue('return_refund_delivery_amount'));
        $deliveryCurrency = trim((string) Tools::getValue('return_refund_delivery_currency', 'PLN'));
        $refundReason = $this->normalizeCustomerReturnRefundReason((string) Tools::getValue('return_refund_reason', 'REFUND'));
        $sellerComment = trim((string) Tools::getValue('return_refund_comment'));
        $logger = new Logger();

        if ($returnId === '') {
            throw new RuntimeException('Brakuje identyfikatora zwrotu.');
        }
        $refundReasonOptions = $this->getCustomerReturnRefundReasonOptions();
        if (!isset($refundReasonOptions[$refundReason])) {
            throw new RuntimeException('Nieprawidłowy powód zwrotu pieniędzy.');
        }
        if (!is_array($linePayloads)) {
            $linePayloads = [];
        }

        $apiClient = new AllegroApiClient(new TokenManager());
        $return = $apiClient->getCustomerReturn($returnId);
        $orderId = trim((string) ($return['orderId'] ?? ''));
        if ($orderId === '') {
            throw new RuntimeException('Brakuje identyfikatora zamówienia Allegro dla zwrotu.');
        }

        $checkoutForm = $apiClient->getCheckoutForm($orderId);
        $paymentId = trim((string) ($checkoutForm['payment']['id'] ?? ''));
        if ($paymentId === '') {
            throw new RuntimeException('Brakuje identyfikatora płatności Allegro dla tego zamówienia.');
        }

        $checkoutLineItems = $this->indexCheckoutLineItemsByOfferId($checkoutForm);
        $refundLineItems = [];
        foreach ($linePayloads as $line) {
            if (!is_array($line)) {
                continue;
            }

            $offerId = trim((string) ($line['offer_id'] ?? ''));
            $amount = $this->normalizeRefundAmount((string) ($line['amount'] ?? ''));
            $currency = trim((string) ($line['currency'] ?? 'PLN'));
            if ($offerId === '' || $amount === '') {
                continue;
            }

            $checkoutLineItem = $checkoutLineItems[$offerId] ?? null;
            if (!is_array($checkoutLineItem) || trim((string) ($checkoutLineItem['id'] ?? '')) === '') {
                throw new RuntimeException('Nie udało się dopasować pozycji zamówienia do oferty ' . $offerId . '.');
            }

            $refundLineItems[] = [
                'id' => (string) $checkoutLineItem['id'],
                'type' => 'AMOUNT',
                'value' => [
                    'amount' => $amount,
                    'currency' => $currency !== '' ? $currency : 'PLN',
                ],
            ];
        }

        $payload = [
            'payment' => [
                'id' => $paymentId,
            ],
            'order' => [
                'id' => $orderId,
            ],
            'commandId' => $this->generateUuidV4(),
            'reason' => $refundReason,
        ];

        if ($refundLineItems) {
            $payload['lineItems'] = $refundLineItems;
        }
        if ($deliveryAmount !== '') {
            $payload['delivery'] = [
                'value' => [
                    'amount' => $deliveryAmount,
                    'currency' => $deliveryCurrency !== '' ? $deliveryCurrency : 'PLN',
                ],
            ];
        }
        if (!$refundLineItems && $deliveryAmount === '') {
            throw new RuntimeException('Podaj kwotę zwrotu dla produktu lub dostawy.');
        }
        if ($sellerComment !== '') {
            $payload['sellerComment'] = mb_substr($sellerComment, 0, 250);
        }

        try {
            $response = $apiClient->createPaymentRefund($payload);
            $logger->log('return_refund_sent', $returnId, (string) ($response['id'] ?? ''), $refundReason, $payload, $response, true);
        } catch (Throwable $e) {
            PrestaShopLogger::addLog('[AAR] Customer return refund error: ' . $e->getMessage(), 3);
            $logger->log('return_refund_failed', $returnId, '', $refundReason, $payload, ['error' => $e->getMessage()], false);
            throw $e;
        }
    }

    protected function renderInboxPanel(): string
    {
        if (!$this->getConnectedAccount()) {
            return $this->htmlFragment('cefba4c147d4c19fa680');
        }

        try {
            $apiClient = new AllegroApiClient(new TokenManager());
            $threadPageCount = $this->getCurrentThreadPageCount();
            $hasMoreThreads = false;
            $threads = [];
            $limit = 20;
            $messageFilterActive = trim((string) Tools::getValue('message_query')) !== ''
                || (int) Tools::getValue('message_unread') === 1
                || (int) Tools::getValue('message_without_reply') === 1;
            // Allegro does not expose a server-side "requires reply" filter. For
            // active filters scan a few API pages per lazy-load batch, while a
            // hard cap prevents a single request from walking the whole inbox.
            $apiPageCount = $messageFilterActive
                ? min(self::FILTERED_THREAD_API_MAX_PAGES, $threadPageCount * self::FILTERED_THREAD_API_PAGES_PER_BATCH)
                : $threadPageCount;
            for ($page = 0; $page < $apiPageCount; ++$page) {
                $threadsResponse = $apiClient->getThreads($limit, $page * $limit);
                $responseThreads = $threadsResponse['threads'] ?? [];
                if (count($responseThreads) >= $limit
                    && $page === $apiPageCount - 1
                    && (!$messageFilterActive || $apiPageCount < self::FILTERED_THREAD_API_MAX_PAGES)
                ) {
                    $hasMoreThreads = true;
                }

                foreach ($responseThreads as $thread) {
                    if (is_array($thread)) {
                        $threads[] = $thread;
                    }
                }
            }

            $threads = $this->enrichThreadsWithReplyState($apiClient, $threads);

            $threads = $this->filterMessageThreads($threads);

            $selectedThreadId = trim((string) Tools::getValue('thread_id'));
            if ($selectedThreadId === '') {
                $selectedThreadId = (string) ($threads[0]['id'] ?? '');
            }

            $selectedThread = $this->findThreadById($threads, $selectedThreadId);
            if (!$selectedThread && $selectedThreadId !== '') {
                $selectedThread = $apiClient->getThread($selectedThreadId);
            }

            $messages = [];
            if ($selectedThreadId !== '') {
                $messageLimit = 20;
                for ($messagePage = 0; $messagePage < 5; ++$messagePage) {
                    $messagesResponse = $apiClient->getThreadMessages($selectedThreadId, $messageLimit, $messagePage * $messageLimit);
                    foreach (($messagesResponse['messages'] ?? []) as $message) {
                        if (is_array($message)) {
                            $messages[] = $message;
                        }
                    }

                    if (count($messagesResponse['messages'] ?? []) < $messageLimit) {
                        break;
                    }
                }
                usort($messages, function (array $a, array $b): int {
                    return strtotime((string) ($a['createdAt'] ?? '')) <=> strtotime((string) ($b['createdAt'] ?? ''));
                });
            }

            return $this->renderInboxHtml($threads, $selectedThreadId, $selectedThread ?: [], $messages, $hasMoreThreads, $threadPageCount);
        } catch (Throwable $e) {
            PrestaShopLogger::addLog('[AAR] Inbox render error: ' . $e->getMessage(), 3);

            return $this->htmlFragment('75556412c0c0d3fe1a06') . Tools::safeOutput($e->getMessage()) . $this->htmlFragment('862310c6baa51befea35');
        }
    }

    protected function renderIssuesPanel(string $issueType, string $sectionTitle): string
    {
        if (!$this->getConnectedAccount()) {
            return $this->htmlFragment('cacaf39098ac06f3a603') . Tools::safeOutput($sectionTitle) . $this->htmlFragment('632dd6d19630c2ee78ac');
        }

        try {
            $apiClient = new AllegroApiClient(new TokenManager());
            $issueKind = $this->getCurrentIssueKindFilter($issueType);
            $statusFilter = $this->getCurrentIssueStatusFilter();
            $issuePageCount = $this->getCurrentIssuePageCount();
            $hasMoreIssues = false;
            $issues = $this->getFilteredIssuesForKind($apiClient, $issueKind, $statusFilter, $issuePageCount, $hasMoreIssues);
            $effectiveSectionTitle = $this->getIssueSectionTitleForKind($issueKind, $sectionTitle);

            if (!$issues) {
                return $this->htmlFragment('cacaf39098ac06f3a603') . Tools::safeOutput($effectiveSectionTitle) . $this->htmlFragment('5c401c3c836fbed23a55');
            }

            $selectedIssueId = trim((string) Tools::getValue('issue_id'));
            if ($selectedIssueId === '') {
                $selectedIssueId = (string) ($issues[0]['id'] ?? '');
            }

            $selectedIssue = $this->findIssueById($issues, $selectedIssueId);
            if (!$selectedIssue) {
                $selectedIssueId = (string) ($issues[0]['id'] ?? '');
                $selectedIssue = $this->findIssueById($issues, $selectedIssueId);
            }
            if ($selectedIssueId !== '') {
                $initialMessageFromList = is_array($selectedIssue['chat']['initialMessage'] ?? null)
                    ? $selectedIssue['chat']['initialMessage']
                    : [];
                try {
                    $issueDetails = $apiClient->getIssue($selectedIssueId);
                    if (is_array($issueDetails) && $issueDetails) {
                        $selectedIssue = array_replace_recursive(is_array($selectedIssue) ? $selectedIssue : [], $issueDetails);
                        if (!is_array($selectedIssue['chat']['initialMessage'] ?? null) && $initialMessageFromList) {
                            $selectedIssue['chat']['initialMessage'] = $initialMessageFromList;
                        }
                    }
                } catch (Throwable $e) {
                    PrestaShopLogger::addLog('[AAR] Selected issue details lookup failed for ' . $selectedIssueId . ': ' . $e->getMessage(), 2);
                }

                $selectedIssueType = mb_strtoupper(trim((string) ($selectedIssue['type'] ?? '')));
                $checkoutFormId = $this->extractIssueCheckoutFormId(is_array($selectedIssue) ? $selectedIssue : []);
                if ($selectedIssueType === 'CLAIM' && $checkoutFormId !== '') {
                    try {
                        $checkoutForm = $apiClient->getCheckoutForm($checkoutFormId);
                        if (is_array($checkoutForm) && $checkoutForm) {
                            $selectedIssue['_checkout_form'] = $checkoutForm;
                        }
                    } catch (Throwable $e) {
                        PrestaShopLogger::addLog('[AAR] Claim checkout form lookup failed for ' . $checkoutFormId . ': ' . $e->getMessage(), 2);
                    }
                }
            }

            $messages = [];
            $messagesResponse = [];
            $messageHistoryMeta = [];
            if ($selectedIssueId !== '') {
                $expectedMessageCount = max(0, (int) ($selectedIssue['chat']['messagesCount'] ?? 0));
                $messagesResponse = $apiClient->getAllIssueChat($selectedIssueId, $expectedMessageCount);
                $messages = $messagesResponse['chat'] ?? $messagesResponse['messages'] ?? [];
                $messages = $this->mergeIssueMessagesAndAttachments($selectedIssue ?: [], $messages);
                usort($messages, function (array $a, array $b): int {
                    return strtotime((string) ($a['createdAt'] ?? '')) <=> strtotime((string) ($b['createdAt'] ?? ''));
                });
                $messages = $this->deduplicateIssueMessageAttachments($messages);
                $messageHistoryMeta = is_array($messagesResponse['history'] ?? null) ? $messagesResponse['history'] : [];
                $messageHistoryMeta['rendered_count'] = count($messages);
                $messageHistoryMeta['count_mismatch'] = $expectedMessageCount > 0 && count($messages) < $expectedMessageCount;
                if (empty($messageHistoryMeta['error']) && empty($messageHistoryMeta['limit_reached'])) {
                    $messageHistoryMeta['complete'] = true;
                } else {
                    $messageHistoryMeta['complete'] = false;
                }
            }

            $this->maybeDumpIssueDebugPayload($selectedIssueId, $selectedIssue ?: [], $messagesResponse, $messages, $issues);
            $this->maybeDumpIssueOfferDebugPayload($apiClient, $selectedIssue ?: []);
            $this->maybeDumpIssueCheckoutFormDebugPayload($apiClient, $selectedIssue ?: []);

            return $this->renderIssuesHtml($issues, $selectedIssueId, $selectedIssue ?: [], $messages, $issueKind, $effectiveSectionTitle, $statusFilter, $hasMoreIssues, $issuePageCount, $messageHistoryMeta);
        } catch (Throwable $e) {
            PrestaShopLogger::addLog('[AAR] Issues render error: ' . $e->getMessage(), 3);

            return $this->htmlFragment('cacaf39098ac06f3a603') . Tools::safeOutput($sectionTitle) . $this->htmlFragment('d2c9d220fb09364e73a4') . Tools::safeOutput($e->getMessage()) . $this->htmlFragment('862310c6baa51befea35');
        }
    }

    protected function renderReturnsPanel(): string
    {
        if (!$this->getConnectedAccount()) {
            return $this->htmlFragment('3ead645154982c81131e');
        }

        try {
            $apiClient = new AllegroApiClient(new TokenManager());
            $pageCount = $this->getCurrentReturnPageCount();
            $hasMoreReturns = false;
            $returns = $this->getFilteredCustomerReturns($apiClient, $pageCount, $hasMoreReturns);

            if (!$returns) {
                return $this->htmlFragment('87feb3e4e2d9fb130d87');
            }

            $selectedReturnId = trim((string) Tools::getValue('return_id'));
            if ($selectedReturnId === '') {
                $selectedReturnId = (string) ($returns[0]['id'] ?? '');
            }

            $selectedReturn = $this->findCustomerReturnById($returns, $selectedReturnId);
            $selectedReturnListItem = is_array($selectedReturn) ? $selectedReturn : [];
            $selectedReturnRaw = $selectedReturn;
            if (!$selectedReturn) {
                $selectedReturnId = (string) ($returns[0]['id'] ?? '');
                $selectedReturn = $this->findCustomerReturnById($returns, $selectedReturnId);
                $selectedReturnListItem = is_array($selectedReturn) ? $selectedReturn : [];
                $selectedReturnRaw = $selectedReturn;
            }
            if ($selectedReturnId !== '') {
                try {
                    $details = $apiClient->getCustomerReturn($selectedReturnId);
                    if (is_array($details) && $details) {
                        $selectedReturnRaw = $details;
                        $selectedReturn = $details;
                    }
                } catch (Throwable $e) {
                    PrestaShopLogger::addLog('[AAR] Customer return details fetch failed for ' . $selectedReturnId . ': ' . $e->getMessage(), 2);
                }

                if (is_array($selectedReturn)) {
                    $selectedReturn = $this->enrichCustomerReturnWithTracking($apiClient, $selectedReturn);
                    $selectedReturn = $this->enrichCustomerReturnWithCheckoutForm($apiClient, $selectedReturn);
                    if ($selectedReturnListItem) {
                        $selectedReturn['_list_item'] = $selectedReturnListItem;
                    }
                }
            }

            $this->maybeDumpCustomerReturnDebugPayload($selectedReturnId, $selectedReturn ?: [], $returns, $selectedReturnRaw ?? []);
            $this->warmCustomerReturnListThumbnailCache($returns, $selectedReturn ?: []);

            return $this->renderReturnsHtml($returns, $selectedReturnId, $selectedReturn ?: [], $hasMoreReturns, $pageCount, $selectedReturnRaw ?? []);
        } catch (Throwable $e) {
            PrestaShopLogger::addLog('[AAR] Returns render error: ' . $e->getMessage(), 3);

            return $this->htmlFragment('906267be76758ee514b4') . Tools::safeOutput($e->getMessage()) . $this->htmlFragment('862310c6baa51befea35');
        }
    }

    protected function renderInboxHtml(array $threads, string $selectedThreadId, array $selectedThread, array $messages, bool $hasMoreThreads = false, int $threadPageCount = 1): string
    {
        $html = $this->htmlFragment('3b5b56a39639fa6a2966');
        $html .= $this->renderInboxColorStyles();
        $html .= $this->htmlFragment('80d19d6c9845e63312b1');
        $html .= $this->htmlFragment('903e00c1a53060879d98');
        $html .= $this->renderMessagesToolbar();
        $html .= $this->htmlFragment('9c1f3d8d4941f3c9b071');

        if (!$threads) {
            $html .= $this->htmlFragment('aec0e868c14c32209a48');
        }

        foreach ($threads as $thread) {
            $threadId = (string) ($thread['id'] ?? '');
            if ($threadId === '') {
                continue;
            }

            $isSelected = $threadId === $selectedThreadId;
            $login = (string) ($thread['interlocutor']['login'] ?? 'Rozmówca');
            $lastDate = (string) ($thread['lastMessageDateTime'] ?? '');
            $read = (bool) ($thread['read'] ?? true);
            $requiresReply = $this->threadRequiresSellerReply($thread);
            $lastPreview = $this->buildThreadPreview($thread);
            $avatarUrl = $this->getThreadInterlocutorAvatarUrl($thread);
            $avatarInitial = $this->getAvatarInitial($login);
            $url = $this->getAdminMessagesUrl(['thread_id' => $threadId]);

            $html .= $this->htmlFragment('3da56e3ab29e7b919153') . ($isSelected ? ' active' : '') . (!$read ? ' aar-thread-unread' : '') . ($requiresReply ? ' aar-thread-requires-reply' : '') . '" href="' . Tools::safeOutput($url) . '" data-aar-thread-id="' . Tools::safeOutput($threadId) . '">';
            $html .= $this->htmlFragment('a2d2fcd252f1e6a9e659');
            $html .= $this->htmlFragment('c0f94042584e5e06a73c');
            if ($avatarUrl !== '') {
                $html .= $this->htmlFragment('6f722b80156fb8ac7f43') . Tools::safeOutput($avatarUrl) . '" alt="" loading="lazy" onerror="this.style.display=\'none\';this.nextElementSibling.style.display=\'flex\';">';
            }
            $html .= $this->htmlFragment('e8841256670daa42a437') . ($avatarUrl !== '' ? ' style="display:none;"' : '') . '>' . Tools::safeOutput($avatarInitial) . $this->htmlFragment('411fdb22d8d9298e5d32');
            $html .= $this->htmlFragment('411fdb22d8d9298e5d32');
            $html .= $this->htmlFragment('3e821330d4ea17f4441e');
            $html .= $this->htmlFragment('09a4488603d56538c20e');
            $html .= $this->htmlFragment('6bcb3a7eedceb230324f') . Tools::safeOutput($login) . $this->htmlFragment('b2f69f8100b2a95949ee');
            if (!$read) {
                $html .= $this->htmlFragment('5b9eea029683923affeb');
            }
            if ($requiresReply) {
                $html .= $this->htmlFragment('fddbd869b27cf4dae3c3');
            }
            $html .= $this->htmlFragment('ef5ccf65c6838d586699') . Tools::safeOutput($this->formatAllegroDate($lastDate)) . $this->htmlFragment('3f0e243eb74ef9d8ab22');
            $html .= $this->htmlFragment('aac32651b10f567c461b');
            if ($lastPreview !== '') {
                $html .= $this->htmlFragment('a125842269cef80d210e') . Tools::safeOutput($lastPreview) . $this->htmlFragment('aac32651b10f567c461b');
            }
            $html .= $this->htmlFragment('411fdb22d8d9298e5d32');
            $html .= $this->htmlFragment('aac32651b10f567c461b');
            $html .= $this->htmlFragment('ecd5b806462c7dfdf078');
        }

        if ($hasMoreThreads) {
            $html .= $this->htmlFragment('ad70b9e0a22f6f75cff8');
            $html .= $this->htmlFragment('616327b278e6aa304ebe') . Tools::safeOutput($this->getAdminMessagesUrl([
                'thread_pages' => $threadPageCount + 1,
            ])) . $this->htmlFragment('4358d93eb5f182ca1f90');
            $html .= $this->htmlFragment('aac32651b10f567c461b');
        }

        $html .= $this->htmlFragment('aac32651b10f567c461b');
        $html .= $this->htmlFragment('aac32651b10f567c461b');
        $html .= $this->htmlFragment('76188d09923e295b39a8');

        if ($selectedThreadId === '') {
            $html .= $this->htmlFragment('a8fa13476adf6e5b9252');
            $html .= $this->htmlFragment('bed8cccb6be290d6dc7a');
            $html .= $this->htmlFragment('aac32651b10f567c461b');
        } else {
            $html .= $this->htmlFragment('a8fa13476adf6e5b9252');
            $recipientLogin = (string) ($selectedThread['interlocutor']['login'] ?? '');
            $allegroThreadUrl = $this->getAllegroMessageThreadUrl($selectedThreadId);
            $html .= $this->htmlFragment('20be10fabab37f35e1da');
            $html .= $this->htmlFragment('83e45be88f9fa6c65988');
            $html .= $this->htmlFragment('a0dd9b5c80c6db31455b') . Tools::safeOutput($allegroThreadUrl) . '" target="_blank" rel="noopener noreferrer" title="Otwórz ten wątek w Centrum Wiadomości Allegro">Rozmowa z ' . Tools::safeOutput($recipientLogin ?: 'klientem') . $this->htmlFragment('cbf6a5a1c16cb26c1831');
            $html .= $this->htmlFragment('aac32651b10f567c461b');
            $html .= $this->htmlFragment('aac32651b10f567c461b');

            $html .= $this->htmlFragment('3fc514f9de2c6a8185a6');
            if (!$messages) {
                $html .= $this->htmlFragment('7675a37cfe5b35a169c0');
            } else {
                $messageOfferThumbnails = [];
                foreach ($messages as $message) {
                    $isCustomer = (bool) ($message['author']['isInterlocutor'] ?? false);
                    $author = $isCustomer ? (string) ($message['author']['login'] ?? $recipientLogin ?: 'Klient') : 'Ty';
                    $text = $this->decodeAllegroText((string) ($message['text'] ?? ''));
                    $createdAt = (string) ($message['createdAt'] ?? '');
                    $offerId = (string) ($message['relatesTo']['offer']['id'] ?? '');
                    $orderId = (string) ($message['relatesTo']['order']['id'] ?? '');
                    $offerThumbnailUrl = '';
                    if ($isCustomer && $offerId !== '') {
                        if (!array_key_exists($offerId, $messageOfferThumbnails)) {
                            $messageOfferThumbnails[$offerId] = $this->resolveMessageOfferThumbnailUrl($offerId);
                        }
                        $offerThumbnailUrl = (string) $messageOfferThumbnails[$offerId];
                    }

                    $html .= $this->htmlFragment('a2912fe0649a9644d4c9') . ($isCustomer ? 'aar-message-left' : 'aar-message-right') . '">';
                    $html .= $this->htmlFragment('749fbd88e7bb20f2ac0a') . ($isCustomer ? 'aar-message-customer' : 'aar-message-shop') . '">';
                    $html .= $this->htmlFragment('0e4fb2ce9d9a198ee66e') . Tools::safeOutput($author) . $this->htmlFragment('1c1d28f3add65937d6f1') . Tools::safeOutput($this->formatAllegroDate($createdAt)) . $this->htmlFragment('b682f1d98bd2dbdf3ff4');
                    $html .= $this->htmlFragment('027c433fe4bd801fc5d0') . Tools::safeOutput($text) . $this->htmlFragment('aac32651b10f567c461b');
                    if ($offerThumbnailUrl !== '') {
                        $html .= $this->htmlFragment('fa06e02186365ec4f7a9');
                        $html .= $this->htmlFragment('6f722b80156fb8ac7f43') . Tools::safeOutput($offerThumbnailUrl) . '" alt="Miniatura oferty ' . Tools::safeOutput($offerId) . '" loading="lazy">';
                        $html .= $this->htmlFragment('df4d436c5c55b795de17') . Tools::safeOutput($offerId) . $this->htmlFragment('20d9389126097e1d3cbd');
                        $html .= $this->htmlFragment('aac32651b10f567c461b');
                    }
                    if ($orderId !== '' || $offerId !== '') {
                        $html .= $this->htmlFragment('219fd589fc1d4c98603c');
                        if ($orderId !== '') {
                            $html .= 'Zamówienie: ' . Tools::safeOutput($orderId) . ' ';
                        }
                        if ($offerId !== '' && $offerThumbnailUrl === '') {
                            $html .= 'Oferta: ' . Tools::safeOutput($offerId);
                        }
                        $html .= $this->htmlFragment('3f0e243eb74ef9d8ab22');
                    }
                    $html .= $this->htmlFragment('aac32651b10f567c461b');
                    $html .= $this->htmlFragment('aac32651b10f567c461b');
                }
            }
            $html .= $this->htmlFragment('aac32651b10f567c461b');

            $html .= $this->htmlFragment('b74c5d85cbd75cca8b08');
            $html .= $this->htmlFragment('80a4d1f37288943c32ce') . Tools::safeOutput($selectedThreadId) . '">';
            $html .= $this->htmlFragment('0f184e39d8fef1803bb4');
            $html .= $this->htmlFragment('535bb9cb52d71fb724e6');
            $html .= $this->htmlFragment('8aa80c8e7b350b1b8443');
            $html .= $this->renderReplyExpandToggle();
            $html .= $this->htmlFragment('169af330b464215def4e');
            $html .= $this->renderQuickReplySelect($this->buildQuickReplyReplacementsForThread($selectedThread, $messages));
            $html .= $this->htmlFragment('aac32651b10f567c461b');
            $html .= $this->htmlFragment('205ab5a60c10858ba5da');
            $html .= $this->htmlFragment('aac32651b10f567c461b');
            $html .= $this->htmlFragment('aac32651b10f567c461b');
            $html .= $this->htmlFragment('e0c7bb7b72eeecfc0734');
            $html .= $this->htmlFragment('aac32651b10f567c461b');
        }

        $html .= $this->htmlFragment('aac32651b10f567c461b');
        $html .= $this->htmlFragment('aac32651b10f567c461b');
        $html .= $this->htmlFragment('aac32651b10f567c461b');

        return $html;
    }

    protected function mergeIssueMessagesAndAttachments(array $issue, array $messages): array
    {
        $normalizedMessages = [];
        foreach ($messages as $message) {
            if (!is_array($message)) {
                continue;
            }

            $message['attachments'] = $this->normalizeIssueAttachmentList(
                $message['attachments'] ?? $message['attachment'] ?? []
            );
            $normalizedMessages[] = $message;
        }

        $initialMessage = is_array($issue['chat']['initialMessage'] ?? null)
            ? $issue['chat']['initialMessage']
            : [];
        $initialAttachments = $this->normalizeIssueAttachmentList(
            $initialMessage['attachments'] ?? $initialMessage['attachment'] ?? []
        );
        $formAttachments = array_merge(
            $this->normalizeIssueAttachmentList($issue['attachments'] ?? []),
            $this->normalizeIssueAttachmentList($issue['reason']['attachments'] ?? [])
        );
        $attachmentsAssignedToMessages = [];
        foreach ($normalizedMessages as $message) {
            foreach ($message['attachments'] as $attachment) {
                if (!is_array($attachment)) {
                    continue;
                }
                $key = trim((string) ($attachment['key'] ?? ''));
                if ($key !== '') {
                    $attachmentsAssignedToMessages[$key] = true;
                }
            }
        }
        $unassignedFormAttachments = array_values(array_filter($formAttachments, static function (array $attachment) use ($attachmentsAssignedToMessages): bool {
            $key = trim((string) ($attachment['key'] ?? ''));

            return $key !== '' && !isset($attachmentsAssignedToMessages[$key]);
        }));
        $initialAttachments = $this->mergeIssueAttachmentLists($initialAttachments, $unassignedFormAttachments);

        $initialId = trim((string) ($initialMessage['id'] ?? ''));
        $initialIndex = null;
        foreach ($normalizedMessages as $index => $message) {
            $messageId = trim((string) ($message['id'] ?? ''));
            if ($initialId !== '' && $messageId === $initialId) {
                $initialIndex = $index;
                break;
            }
        }

        if ($initialIndex !== null) {
            $normalizedMessages[$initialIndex]['attachments'] = $this->mergeIssueAttachmentLists(
                $normalizedMessages[$initialIndex]['attachments'] ?? [],
                $initialAttachments
            );
        } elseif ($initialMessage || $initialAttachments) {
            $initialMessage['id'] = $initialId !== '' ? $initialId : 'issue-initial-' . trim((string) ($issue['id'] ?? ''));
            $initialMessage['text'] = (string) ($initialMessage['text'] ?? '');
            $initialMessage['createdAt'] = (string) ($initialMessage['createdAt'] ?? $issue['openedDate'] ?? '');
            $initialMessage['type'] = (string) ($initialMessage['type'] ?? 'REGULAR');
            $initialMessage['author'] = is_array($initialMessage['author'] ?? null)
                ? $initialMessage['author']
                : [
                    'login' => (string) ($issue['buyer']['login'] ?? ''),
                    'role' => 'BUYER',
                ];
            $initialMessage['attachments'] = $initialAttachments;
            $normalizedMessages[] = $initialMessage;
        }

        return $normalizedMessages;
    }

    protected function normalizeIssueAttachmentList($attachments): array
    {
        if ($attachments === null || $attachments === '') {
            return [];
        }

        if (!is_array($attachments)) {
            $attachments = [$attachments];
        } elseif (isset($attachments['id']) || isset($attachments['attachmentId']) || isset($attachments['url']) || isset($attachments['fileName'])) {
            $attachments = [$attachments];
        }

        $normalized = [];
        foreach ($attachments as $attachment) {
            $item = $this->normalizeIssueAttachment($attachment);
            if ($item === null) {
                continue;
            }
            $normalized[$item['key']] = $item;
        }

        return array_values($normalized);
    }

    protected function normalizeIssueAttachment($attachment): ?array
    {
        if (is_string($attachment)) {
            $attachment = ['url' => $attachment];
        }
        if (!is_array($attachment)) {
            return null;
        }

        $attachmentId = trim((string) ($attachment['id'] ?? $attachment['attachmentId'] ?? ''));
        $url = trim((string) ($attachment['url'] ?? ''));
        if ($attachmentId === '' && $url !== '') {
            $path = (string) parse_url($url, PHP_URL_PATH);
            if (preg_match('#/sale/issues/attachments/([0-9a-f-]{36})/?$#i', $path, $matches)) {
                $attachmentId = (string) $matches[1];
            }
        }

        if (!preg_match('/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i', $attachmentId)) {
            return null;
        }

        $fileName = trim((string) ($attachment['fileName'] ?? $attachment['filename'] ?? $attachment['name'] ?? ''));
        $fileName = $this->sanitizeIssueAttachmentFileName($fileName);
        if ($fileName === '') {
            $fileName = 'zalacznik-' . substr($attachmentId, 0, 8);
        }

        $contentType = trim((string) ($attachment['contentType'] ?? $attachment['mimeType'] ?? ''));

        return [
            'key' => 'id:' . mb_strtolower($attachmentId),
            'id' => $attachmentId,
            'fileName' => $fileName,
            'contentType' => $contentType,
        ];
    }

    protected function sanitizeIssueAttachmentFileName(string $fileName): string
    {
        $fileName = str_replace(["\0", "\r", "\n", '/', '\\'], '', trim($fileName));
        if ($fileName === '' || $fileName === '.' || $fileName === '..') {
            return '';
        }

        return mb_substr($fileName, 0, 180);
    }

    protected function mergeIssueAttachmentLists(array ...$lists): array
    {
        $merged = [];
        foreach ($lists as $list) {
            foreach ($list as $attachment) {
                if (!is_array($attachment)) {
                    continue;
                }
                $key = trim((string) ($attachment['key'] ?? ''));
                if ($key === '') {
                    continue;
                }
                $merged[$key] = $attachment;
            }
        }

        return array_values($merged);
    }

    protected function deduplicateIssueMessageAttachments(array $messages): array
    {
        $seen = [];
        $seenImageNames = [];
        foreach ($messages as $index => $message) {
            $unique = [];
            foreach (($message['attachments'] ?? []) as $attachment) {
                if (!is_array($attachment)) {
                    continue;
                }
                $key = trim((string) ($attachment['key'] ?? ''));
                if ($key === '' || isset($seen[$key])) {
                    continue;
                }
                $imageNameKey = '';
                if ($this->isIssueImageAttachment($attachment)) {
                    $fileName = $this->sanitizeIssueAttachmentFileName((string) ($attachment['fileName'] ?? ''));
                    if ($fileName !== '') {
                        $imageNameKey = mb_strtolower($fileName);
                        if (isset($seenImageNames[$imageNameKey])) {
                            continue;
                        }
                    }
                }
                $seen[$key] = true;
                if ($imageNameKey !== '') {
                    $seenImageNames[$imageNameKey] = true;
                }
                $unique[] = $attachment;
            }
            $messages[$index]['attachments'] = $unique;
        }

        return $messages;
    }

    protected function renderIssueHistoryWarning(array $historyMeta): string
    {
        if (!array_key_exists('complete', $historyMeta) || !empty($historyMeta['complete'])) {
            return '';
        }

        $expected = max(0, (int) ($historyMeta['expected_count'] ?? 0));
        $rendered = max(0, (int) ($historyMeta['rendered_count'] ?? $historyMeta['fetched_count'] ?? 0));
        $message = $expected > 0
            ? 'Historia może być niepełna. Pobrano ' . $rendered . ' z ' . $expected . ' wiadomości zgłoszenia.'
            : 'Historia może być niepełna. Nie udało się pobrać wszystkich stron rozmowy.';

        if (!empty($historyMeta['limit_reached'])) {
            $message .= ' Osiągnięto limit bezpieczeństwa pobierania.';
        } elseif (trim((string) ($historyMeta['error'] ?? '')) !== '') {
            $message .= ' Odśwież widok, aby ponowić pobieranie.';
        }

        return $this->htmlFragment('fc9fe45305b3aa327d1b') . Tools::safeOutput($message) . $this->htmlFragment('aac32651b10f567c461b');
    }

    protected function renderIssueMessageAttachments(string $issueType, array $attachments): string
    {
        if (!$attachments) {
            return '';
        }

        $html = $this->htmlFragment('cab50334c7034cd74876');
        foreach ($attachments as $attachment) {
            if (!is_array($attachment)) {
                continue;
            }

            $attachmentId = trim((string) ($attachment['id'] ?? ''));
            $fileName = $this->sanitizeIssueAttachmentFileName((string) ($attachment['fileName'] ?? ''));
            if ($attachmentId === '' || $fileName === '') {
                continue;
            }

            $downloadUrl = $this->getIssueAttachmentAdminUrl($issueType, $attachmentId, $fileName, false);
            if ($this->isIssueImageAttachment($attachment)) {
                $previewUrl = $this->getIssueAttachmentAdminUrl($issueType, $attachmentId, $fileName, true);
                $html .= $this->htmlFragment('627c3ca5b6eb300e19d6') . Tools::safeOutput($fileName) . '" title="Otwórz podgląd" data-aar-issue-attachment-preview data-aar-preview-url="' . Tools::safeOutput($previewUrl) . '" data-aar-download-url="' . Tools::safeOutput($downloadUrl) . '" data-aar-preview-name="' . Tools::safeOutput($fileName) . '">';
                $html .= $this->htmlFragment('6f722b80156fb8ac7f43') . Tools::safeOutput($previewUrl) . '" alt="' . Tools::safeOutput($fileName) . '" loading="lazy" onerror="this.style.display=\'none\';this.nextElementSibling.style.display=\'flex\';">';
                $html .= $this->htmlFragment('94bbd51b2ac775994104');
                $html .= $this->htmlFragment('d8de48c79715e8f2762e');
            } else {
                $html .= $this->htmlFragment('1f3d44626d1c23654e86') . Tools::safeOutput($downloadUrl) . '">';
                $html .= $this->htmlFragment('26e5765da6e33399f653') . Tools::safeOutput($fileName) . $this->htmlFragment('99ff1f4a5980a962ed2c');
                $html .= $this->htmlFragment('ecd5b806462c7dfdf078');
            }
        }
        $html .= $this->htmlFragment('aac32651b10f567c461b');

        return $html;
    }

    protected function isIssueImageAttachment(array $attachment): bool
    {
        $contentType = mb_strtolower(trim((string) ($attachment['contentType'] ?? '')));
        if (in_array($contentType, ['image/png', 'image/gif', 'image/bmp', 'image/tiff', 'image/jpeg', 'image/jpg'], true)) {
            return true;
        }

        $extension = mb_strtolower((string) pathinfo((string) ($attachment['fileName'] ?? ''), PATHINFO_EXTENSION));

        return in_array($extension, ['png', 'gif', 'bmp', 'tif', 'tiff', 'jpg', 'jpeg'], true);
    }

    protected function getIssueAttachmentAdminUrl(string $issueType, string $attachmentId, string $fileName, bool $inline): string
    {
        $controller = mb_strtoupper($issueType) === 'DISPUTE'
            ? 'AdminAllegroCustomerServiceDisputes'
            : 'AdminAllegroCustomerServiceComplaints';

        return $this->getAdminLinkFor($controller, [
            'download_issue_attachment' => 1,
            'attachment_id' => $attachmentId,
            'attachment_name' => $fileName,
            'attachment_disposition' => $inline ? 'inline' : 'attachment',
        ]);
    }

    protected function renderIssueAttachmentPreviewModal(): string
    {
        $html = $this->htmlFragment('36fa6902daae32935922');
        $html .= $this->htmlFragment('6f9e5ef8a33410af2064');
        $html .= $this->htmlFragment('9d20f6214d62a8ec9896');
        $html .= $this->htmlFragment('c88cc0047ef45e60fdd5');
        $html .= $this->htmlFragment('bd1770902d0bb0db962c');

        return $html;
    }

    public function serveIssueAttachmentFromAdmin(): void
    {
        if (!$this->isIssueAttachmentAdminRequestAuthorized()) {
            $this->outputIssueAttachmentError(403, 'Brak dostępu do załącznika.');
        }

        $attachmentId = trim((string) Tools::getValue('attachment_id'));
        if (!preg_match('/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i', $attachmentId)) {
            $this->outputIssueAttachmentError(400, 'Nieprawidłowy identyfikator załącznika.');
        }

        $fallbackName = $this->sanitizeIssueAttachmentFileName((string) Tools::getValue('attachment_name'));
        if ($fallbackName === '') {
            $fallbackName = 'zalacznik-' . substr($attachmentId, 0, 8);
        }

        try {
            $apiClient = new AllegroApiClient(new TokenManager());
            $download = $apiClient->downloadIssueAttachment($attachmentId);
        } catch (Throwable $e) {
            PrestaShopLogger::addLog('[AAR] Issue attachment download failed for ' . $attachmentId . ': ' . $e->getMessage(), 2);
            $this->outputIssueAttachmentError(502, 'Nie udało się pobrać załącznika z Allegro.');
        }

        $body = (string) ($download['body'] ?? '');
        if ($body === '') {
            $this->outputIssueAttachmentError(502, 'Allegro zwróciło pusty załącznik.');
        }

        $contentType = mb_strtolower(trim((string) ($download['content_type'] ?? '')));
        $semicolon = strpos($contentType, ';');
        if ($semicolon !== false) {
            $contentType = trim(substr($contentType, 0, $semicolon));
        }
        $allowedContentTypes = [
            'image/png', 'image/gif', 'image/bmp', 'image/tiff', 'image/jpeg', 'image/jpg',
            'application/pdf', 'application/octet-stream',
        ];
        if (!in_array($contentType, $allowedContentTypes, true)) {
            $contentType = 'application/octet-stream';
        }
        if ($contentType === 'application/octet-stream') {
            $extension = mb_strtolower((string) pathinfo($fallbackName, PATHINFO_EXTENSION));
            $contentTypeByExtension = [
                'png' => 'image/png',
                'gif' => 'image/gif',
                'bmp' => 'image/bmp',
                'tif' => 'image/tiff',
                'tiff' => 'image/tiff',
                'jpg' => 'image/jpeg',
                'jpeg' => 'image/jpeg',
                'pdf' => 'application/pdf',
            ];
            if (isset($contentTypeByExtension[$extension])) {
                $contentType = $contentTypeByExtension[$extension];
            }
        }

        $requestedDisposition = trim((string) Tools::getValue('attachment_disposition'));
        $disposition = $requestedDisposition === 'inline' && strpos($contentType, 'image/') === 0
            ? 'inline'
            : 'attachment';
        $asciiName = preg_replace('/[^A-Za-z0-9._-]+/', '_', $fallbackName);
        $asciiName = trim((string) $asciiName, '._');
        if ($asciiName === '') {
            $asciiName = 'attachment-' . substr($attachmentId, 0, 8);
        }

        if (!headers_sent()) {
            header('Content-Type: ' . $contentType);
            header('Content-Length: ' . strlen($body));
            header('Content-Disposition: ' . $disposition . '; filename="' . $asciiName . '"; filename*=UTF-8\'\'' . rawurlencode($fallbackName));
            header('Cache-Control: private, no-store, no-cache, must-revalidate, max-age=0');
            header('Pragma: no-cache');
            header('X-Content-Type-Options: nosniff');
            header('Content-Security-Policy: default-src \'none\'; sandbox');
        }

        echo $body;
        exit;
    }

    protected function isIssueAttachmentAdminRequestAuthorized(): bool
    {
        $employee = $this->context->employee ?? null;
        $controllerObject = $this->context->controller ?? null;
        if (!$employee || (int) ($employee->id ?? 0) <= 0 || !is_object($controllerObject)) {
            return false;
        }

        $allowedControllers = array_map('mb_strtolower', [
            'AdminAllegroCustomerServiceComplaints',
            'AdminAllegroCustomerServiceDisputes',
        ]);
        $controllerCandidates = [];
        if (isset($controllerObject->controller_name)) {
            $controllerCandidates[] = (string) $controllerObject->controller_name;
        }
        $controllerCandidates[] = get_class($controllerObject);

        foreach ($controllerCandidates as $candidate) {
            $candidate = trim(str_replace('\\', '/', $candidate));
            if ($candidate === '') {
                continue;
            }
            $candidate = (string) preg_replace('#^.*/#', '', $candidate);
            $candidate = (string) preg_replace('/Controller(?:Core)?$/i', '', $candidate);
            if (in_array(mb_strtolower($candidate), $allowedControllers, true)) {
                return true;
            }
        }

        return false;
    }

    protected function outputIssueAttachmentError(int $status, string $message): void
    {
        http_response_code($status);
        if (!headers_sent()) {
            header('Content-Type: text/plain; charset=utf-8');
            header('Cache-Control: private, no-store, no-cache, must-revalidate, max-age=0');
            header('X-Content-Type-Options: nosniff');
        }
        echo $message;
        exit;
    }

    protected function renderIssuesHtml(array $issues, string $selectedIssueId, array $selectedIssue, array $messages, string $issueType, string $sectionTitle, string $statusFilter = 'all', bool $hasMoreIssues = false, int $issuePageCount = 1, array $messageHistoryMeta = []): string
    {
        $html = $this->htmlFragment('8dc8bcd6b4b7effccf44');
        $html .= $this->renderInboxColorStyles();
        $html .= $this->htmlFragment('80d19d6c9845e63312b1');
        $html .= $this->htmlFragment('903e00c1a53060879d98');
        $html .= $this->htmlFragment('9c1f3d8d4941f3c9b071');

        foreach ($issues as $issue) {
            $issueId = (string) ($issue['id'] ?? '');
            if ($issueId === '') {
                continue;
            }

            $isSelected = $issueId === $selectedIssueId;
            $subject = $this->buildIssueSubject($issue);
            $lastDate = (string) ($issue['lastMessage']['createdAt'] ?? $issue['updatedAt'] ?? $issue['createdAt'] ?? '');
            $requiresReply = $this->issueRequiresSellerReply($issue);
            $preview = $this->buildIssuePreview($issue);
            $status = (string) ($issue['currentState']['status'] ?? $issue['status'] ?? '');
            $statusLabel = $this->formatIssueListStatus($status);
            $statusClass = $this->getIssueStatusClass($status);
            $issueTypeLabel = $this->formatIssueTypeLabel((string) ($issue['type'] ?? ''));
            $issueTypeClass = $this->getIssueTypeBadgeClass((string) ($issue['type'] ?? ''));
            $thumbnailUrl = $this->resolveIssueThumbnailUrl($issue, true);
            $thumbnailImageUrl = $this->getIssueThumbnailImageUrl($issue);
            $thumbnailDebugUrl = $this->getIssueThumbnailDebugUrl($issue);
            $url = $this->getIssuesAdminUrl($issueType, ['issue_id' => $issueId]);

            $html .= $this->htmlFragment('3da56e3ab29e7b919153') . ($isSelected ? ' active' : '') . ($requiresReply ? ' aar-thread-unread' : '') . '" href="' . Tools::safeOutput($url) . '">';
            $html .= $this->htmlFragment('5482b524c3b0c8ec82ce');
            $html .= $this->htmlFragment('e9416126fc8d7aa0f4c8');
            $html .= $this->htmlFragment('66d7f4a82e158e98ae1f') . ($thumbnailDebugUrl !== '' ? ' data-aar-thumb-debug-url="' . Tools::safeOutput($thumbnailDebugUrl) . '"' : '') . '>';
            if ($thumbnailUrl !== '') {
                $html .= $this->htmlFragment('6f722b80156fb8ac7f43') . Tools::safeOutput($thumbnailUrl) . '" alt="" loading="lazy" ' . $this->getThumbnailImageFallbackAttributes($thumbnailDebugUrl) . '>';
            } elseif ($thumbnailImageUrl !== '') {
                $html .= $this->htmlFragment('6f722b80156fb8ac7f43') . Tools::safeOutput($thumbnailImageUrl) . '" alt="" loading="lazy" ' . $this->getThumbnailImageFallbackAttributes($thumbnailDebugUrl) . '>';
            }
            $html .= $this->htmlFragment('9b0a54aa00a68e4f68dc') . (($thumbnailUrl !== '' || $thumbnailImageUrl !== '') ? ' style="display:none;"' : '') . $this->htmlFragment('0fc315b339d1eab21a33');
            $html .= $this->htmlFragment('aac32651b10f567c461b');
            if ($issueTypeLabel !== '') {
                $html .= $this->htmlFragment('8685167a760ac942054a');
                $html .= $this->htmlFragment('17f1151a5c5e3ec19d62') . Tools::safeOutput($issueTypeClass) . '">' . Tools::safeOutput($issueTypeLabel) . $this->htmlFragment('411fdb22d8d9298e5d32');
                $html .= $this->htmlFragment('aac32651b10f567c461b');
            }
            $html .= $this->htmlFragment('aac32651b10f567c461b');
            $html .= $this->htmlFragment('4a361d654e46bef5dcb9');
            $html .= $this->htmlFragment('09a4488603d56538c20e');
            $html .= $this->htmlFragment('6bcb3a7eedceb230324f') . Tools::safeOutput($subject) . $this->htmlFragment('b2f69f8100b2a95949ee');
            $html .= $this->htmlFragment('ef5ccf65c6838d586699') . Tools::safeOutput($this->formatAllegroDate($lastDate)) . $this->htmlFragment('3f0e243eb74ef9d8ab22');
            $html .= $this->htmlFragment('aac32651b10f567c461b');
            if ($preview !== '') {
                $html .= $this->htmlFragment('a125842269cef80d210e') . Tools::safeOutput($preview) . $this->htmlFragment('aac32651b10f567c461b');
            }
            if ($statusLabel !== '') {
                $html .= $this->htmlFragment('ca0274419e562106044b');
                $html .= $this->htmlFragment('8a478e1112962b7150fa') . Tools::safeOutput($statusClass) . '">' . Tools::safeOutput($statusLabel) . $this->htmlFragment('411fdb22d8d9298e5d32');
                $html .= $this->htmlFragment('aac32651b10f567c461b');
            }
            $html .= $this->renderIssueListDeadline($issue, $statusClass);
            $html .= $this->htmlFragment('aac32651b10f567c461b');
            $html .= $this->htmlFragment('aac32651b10f567c461b');
            $html .= $this->htmlFragment('ecd5b806462c7dfdf078');
        }

        if ($hasMoreIssues) {
            $html .= $this->htmlFragment('ad70b9e0a22f6f75cff8');
            $html .= $this->htmlFragment('5c8e08f3b41c236e86e0') . Tools::safeOutput($this->getIssuesAdminUrl($issueType, [
                'issue_pages' => $issuePageCount + 1,
            ])) . $this->htmlFragment('4358d93eb5f182ca1f90');
            $html .= $this->htmlFragment('aac32651b10f567c461b');
        }

        $html .= $this->htmlFragment('aac32651b10f567c461b');
        $html .= $this->htmlFragment('aac32651b10f567c461b');
        $html .= $this->htmlFragment('76188d09923e295b39a8');

        if ($selectedIssueId === '') {
            $html .= $this->htmlFragment('a8fa13476adf6e5b9252');
            $html .= $this->htmlFragment('631d94406b733cdfa687');
            $html .= $this->htmlFragment('aac32651b10f567c461b');
        } else {
            $html .= $this->htmlFragment('a8fa13476adf6e5b9252');
            $html .= $this->htmlFragment('20be10fabab37f35e1da');
            $html .= $this->htmlFragment('83e45be88f9fa6c65988');
            $headerTitle = $this->buildIssueHeaderTitle($selectedIssue);
            $headerUrl = mb_strtoupper((string) ($selectedIssue['type'] ?? '')) === 'CLAIM' ? $this->getAllegroIssueUrl($selectedIssue) : '';
            if ($headerUrl !== '') {
                $html .= $this->htmlFragment('a0dd9b5c80c6db31455b') . Tools::safeOutput($headerUrl) . '" target="_blank" rel="noopener noreferrer">' . Tools::safeOutput($headerTitle) . $this->htmlFragment('dfd587e883b672c87064');
            } else {
                $html .= $this->htmlFragment('573000717bf3cb25938a') . Tools::safeOutput($headerTitle) . $this->htmlFragment('167241b96f2b077c0273');
            }
            $html .= $this->htmlFragment('53af437bbd88794d1959') . $this->renderIssueHeaderSubtitle($selectedIssue, $sectionTitle, $messages) . $this->htmlFragment('3f0e243eb74ef9d8ab22');
            $html .= $this->htmlFragment('aac32651b10f567c461b');
            $html .= $this->renderIssueHeaderBadges($selectedIssue);
            $html .= $this->htmlFragment('aac32651b10f567c461b');

            $isSelectedClaim = mb_strtoupper((string) ($selectedIssue['type'] ?? '')) === 'CLAIM';
            $html .= $this->htmlFragment('3fc514f9de2c6a8185a6');
            if ($isSelectedClaim) {
                $html .= $this->renderClaimSummaryPanel($selectedIssue, $messages);
                $html .= $this->renderClaimWorkflowPanel($selectedIssueId, $selectedIssue);
            } else {
                $html .= $this->renderIssueOrderSummaryPanel($selectedIssue, $messages);
            }
            $html .= $this->renderIssueHistoryWarning($messageHistoryMeta);
            if (!$messages) {
                $html .= $this->htmlFragment('5dfcd99fa233d2dd8fc0');
            } else {
                foreach ($messages as $message) {
                    $isCustomer = $this->isIssueCustomerMessage($message);
                    $author = $this->getIssueAuthorLabel($message, $selectedIssue);
                    $text = $this->decodeAllegroText((string) ($message['text'] ?? ''));
                    $createdAt = (string) ($message['createdAt'] ?? '');
                    $messageType = (string) ($message['type'] ?? '');
                    $attachments = is_array($message['attachments'] ?? null) ? $message['attachments'] : [];

                    $html .= $this->htmlFragment('a2912fe0649a9644d4c9') . ($isCustomer ? 'aar-message-left' : 'aar-message-right') . '">';
                    $html .= $this->htmlFragment('749fbd88e7bb20f2ac0a') . ($isCustomer ? 'aar-message-customer' : 'aar-message-shop') . '">';
                    $html .= $this->htmlFragment('0e4fb2ce9d9a198ee66e') . Tools::safeOutput($author) . $this->htmlFragment('1c1d28f3add65937d6f1') . Tools::safeOutput($this->formatAllegroDate($createdAt)) . $this->htmlFragment('b682f1d98bd2dbdf3ff4');
                    if ($text !== '') {
                        $html .= $this->htmlFragment('027c433fe4bd801fc5d0') . Tools::safeOutput($text) . $this->htmlFragment('aac32651b10f567c461b');
                    }
                    $html .= $this->renderIssueMessageAttachments((string) ($selectedIssue['type'] ?? $issueType), $attachments);
                    if ($messageType !== '') {
                        $html .= $this->htmlFragment('b4b297088fabe576640a') . Tools::safeOutput($messageType) . $this->htmlFragment('3f0e243eb74ef9d8ab22');
                    }
                    $html .= $this->htmlFragment('aac32651b10f567c461b');
                    $html .= $this->htmlFragment('aac32651b10f567c461b');
                }
            }
            $html .= $this->htmlFragment('aac32651b10f567c461b');
            $html .= $this->renderIssueAttachmentPreviewModal();

            if ($isSelectedClaim) {
                $html .= $this->renderClaimWorkflowModals($selectedIssueId, $selectedIssue);
            }

            $html .= $this->htmlFragment('b74c5d85cbd75cca8b08');
            $html .= $this->htmlFragment('3c6bfa2df1e24221dfc1') . Tools::safeOutput($selectedIssueId) . '">';
            $html .= $this->htmlFragment('0f184e39d8fef1803bb4');
            $html .= $this->htmlFragment('535bb9cb52d71fb724e6');
            $html .= $this->htmlFragment('8aa80c8e7b350b1b8443');
            $html .= $this->renderReplyExpandToggle();
            $html .= $this->htmlFragment('6882e25eb85cc4f8c54b');
            $html .= $this->renderQuickReplySelect($this->buildQuickReplyReplacementsForIssue($selectedIssue, $messages));
            $html .= $this->htmlFragment('aac32651b10f567c461b');
            $html .= $this->htmlFragment('47a019fe750e543df314');
            $html .= $this->htmlFragment('aac32651b10f567c461b');
            $html .= $this->htmlFragment('aac32651b10f567c461b');
            $html .= $this->htmlFragment('e0c7bb7b72eeecfc0734');
            $html .= $this->htmlFragment('aac32651b10f567c461b');
        }

        $html .= $this->htmlFragment('aac32651b10f567c461b');
        $html .= $this->htmlFragment('aac32651b10f567c461b');
        $html .= $this->htmlFragment('aac32651b10f567c461b');

        return $html;
    }

    protected function renderReturnsHtml(array $returns, string $selectedReturnId, array $selectedReturn, bool $hasMoreReturns = false, int $returnPageCount = 1, array $selectedReturnRaw = []): string
    {
        $html = $this->htmlFragment('fec4c8b7c880e0b7bdec');
        $html .= $this->renderInboxColorStyles();
        $html .= $this->htmlFragment('80d19d6c9845e63312b1');
        $html .= $this->htmlFragment('903e00c1a53060879d98');
        $html .= $this->htmlFragment('9c1f3d8d4941f3c9b071');

        foreach ($returns as $return) {
            if (!is_array($return)) {
                continue;
            }

            $returnId = (string) ($return['id'] ?? '');
            if ($returnId === '') {
                continue;
            }

            $isSelected = $returnId === $selectedReturnId;
            $status = (string) ($return['status'] ?? '');
            $statusClass = $this->getCustomerReturnStatusClass($status);
            $subject = $this->buildCustomerReturnSubject($return);
            $preview = $this->buildCustomerReturnPreview($return);
            $createdAt = (string) ($return['createdAt'] ?? '');
            $thumbnailUrl = $this->getCustomerReturnListThumbnailImageUrl($returnId, $return);
            $url = $this->getReturnsAdminUrl(['return_id' => $returnId]);

            $html .= $this->htmlFragment('3da56e3ab29e7b919153') . ($isSelected ? ' active' : '') . '" href="' . Tools::safeOutput($url) . '">';
            $html .= $this->htmlFragment('5482b524c3b0c8ec82ce');
            $html .= $this->htmlFragment('09adf6e802ab0cd30639');
            if ($thumbnailUrl !== '') {
                $html .= $this->htmlFragment('6f722b80156fb8ac7f43') . Tools::safeOutput($thumbnailUrl) . '" alt="" loading="lazy" ' . $this->getThumbnailImageFallbackAttributes() . '>';
            }
            $html .= $this->htmlFragment('9b0a54aa00a68e4f68dc') . ($thumbnailUrl !== '' ? ' style="display:none;"' : '') . $this->htmlFragment('0fc315b339d1eab21a33');
            $html .= $this->htmlFragment('aac32651b10f567c461b');
            $html .= $this->htmlFragment('4a361d654e46bef5dcb9');
            $html .= $this->htmlFragment('09a4488603d56538c20e');
            $html .= $this->htmlFragment('6bcb3a7eedceb230324f') . Tools::safeOutput($subject) . $this->htmlFragment('b2f69f8100b2a95949ee');
            $html .= $this->htmlFragment('ef5ccf65c6838d586699') . Tools::safeOutput($this->formatAllegroDate($createdAt)) . $this->htmlFragment('3f0e243eb74ef9d8ab22');
            $html .= $this->htmlFragment('aac32651b10f567c461b');
            if ($preview !== '') {
                $html .= $this->htmlFragment('a125842269cef80d210e') . Tools::safeOutput($preview) . $this->htmlFragment('aac32651b10f567c461b');
            }
            $html .= $this->htmlFragment('ca0274419e562106044b');
            $html .= $this->htmlFragment('83212e4aa8c1c9f0effd');
            $html .= $this->htmlFragment('8a478e1112962b7150fa') . Tools::safeOutput($statusClass) . '">' . Tools::safeOutput($this->formatCustomerReturnStatus($status)) . $this->htmlFragment('411fdb22d8d9298e5d32');
            $html .= $this->htmlFragment('aac32651b10f567c461b');
            $html .= $this->htmlFragment('aac32651b10f567c461b');
            $html .= $this->htmlFragment('aac32651b10f567c461b');
            $html .= $this->htmlFragment('ecd5b806462c7dfdf078');
        }

        if ($hasMoreReturns) {
            $html .= $this->htmlFragment('ad70b9e0a22f6f75cff8');
            $html .= $this->htmlFragment('5c8e08f3b41c236e86e0') . Tools::safeOutput($this->getReturnsAdminUrl([
                'return_pages' => $returnPageCount + 1,
            ])) . $this->htmlFragment('4358d93eb5f182ca1f90');
            $html .= $this->htmlFragment('aac32651b10f567c461b');
        }

        $html .= $this->htmlFragment('aac32651b10f567c461b');
        $html .= $this->htmlFragment('aac32651b10f567c461b');
        $html .= $this->htmlFragment('76188d09923e295b39a8');

        if ($selectedReturnId === '') {
            $html .= $this->htmlFragment('a8fa13476adf6e5b9252');
            $html .= $this->htmlFragment('ead35bb591e85c729e5c');
            $html .= $this->htmlFragment('aac32651b10f567c461b');
        } else {
            $html .= $this->htmlFragment('a8fa13476adf6e5b9252');
            $html .= $this->htmlFragment('20be10fabab37f35e1da');
            $html .= $this->htmlFragment('83e45be88f9fa6c65988');
            $headerUrl = $this->getAllegroReturnUrl($selectedReturn);
            $headerTitle = $this->buildCustomerReturnHeaderTitle($selectedReturn);
            if ($headerUrl !== '') {
                $html .= $this->htmlFragment('a0dd9b5c80c6db31455b') . Tools::safeOutput($headerUrl) . '" target="_blank" rel="noopener noreferrer">' . Tools::safeOutput($headerTitle) . $this->htmlFragment('dfd587e883b672c87064');
            } else {
                $html .= $this->htmlFragment('573000717bf3cb25938a') . Tools::safeOutput($headerTitle) . $this->htmlFragment('167241b96f2b077c0273');
            }
            $html .= $this->renderCustomerReturnHeaderMeta($selectedReturn);
            $html .= $this->htmlFragment('aac32651b10f567c461b');
            $html .= $this->renderCustomerReturnHeaderBadges($selectedReturn);
            $html .= $this->htmlFragment('aac32651b10f567c461b');

            $html .= $this->htmlFragment('3fc514f9de2c6a8185a6');
            $html .= $this->renderCustomerReturnSummaryPanel($selectedReturn);
            $html .= $this->htmlFragment('aac32651b10f567c461b');
            $html .= $this->renderCustomerReturnDecisionPanel($selectedReturnId, $selectedReturn, $this->calculateCustomerReturnTotal($selectedReturn));
            $html .= $this->renderCustomerReturnTrackingModal($selectedReturnId, $selectedReturn);
            $html .= $this->renderCustomerReturnDiagnosticsPanel($selectedReturnId, $selectedReturn, $selectedReturnRaw);
            $html .= $this->htmlFragment('aac32651b10f567c461b');
        }

        $html .= $this->htmlFragment('aac32651b10f567c461b');
        $html .= $this->htmlFragment('aac32651b10f567c461b');
        $html .= $this->htmlFragment('aac32651b10f567c461b');

        return $html;
    }

    protected function renderIssueListDeadline(array $issue, string $statusClass): string
    {
        if (mb_strtoupper((string) ($issue['type'] ?? '')) !== 'CLAIM') {
            return '';
        }

        $decisionDueDate = (string) ($issue['decisionDueDate'] ?? '');
        $timeMeta = $this->buildClaimTimeMeta($issue);
        if ($decisionDueDate === '' && trim((string) ($timeMeta['subline'] ?? '')) === '') {
            return '';
        }

        $deadlineClass = trim((string) ($timeMeta['status_class'] ?? $statusClass));
        $html = $this->htmlFragment('d0215eb3aa823aa1ff8c') . Tools::safeOutput($deadlineClass) . '">';
        $html .= $this->htmlFragment('394adc88e1c1778e7f6f');
        $html .= $this->htmlFragment('346c9f216796b8c7e533') . Tools::safeOutput((string) ($timeMeta['headline'] ?? 'Termin reklamacji')) . $this->htmlFragment('411fdb22d8d9298e5d32');
        if ($decisionDueDate !== '') {
            $html .= $this->htmlFragment('b909d90bf0d833f6168e') . Tools::safeOutput($this->formatAllegroDate($decisionDueDate)) . $this->htmlFragment('b2f69f8100b2a95949ee');
        }
        $html .= $this->htmlFragment('aac32651b10f567c461b');
        if (trim((string) ($timeMeta['subline'] ?? '')) !== '') {
            $html .= $this->htmlFragment('f0376987d932f481e68f') . Tools::safeOutput((string) $timeMeta['subline']) . $this->htmlFragment('aac32651b10f567c461b');
        }
        $html .= $this->renderClaimProgressBar('aar-thread-deadline-progress', $timeMeta);
        $html .= $this->htmlFragment('aac32651b10f567c461b');

        return $html;
    }

    protected function renderClaimSummaryPanel(array $issue, array $messages = []): string
    {
        $status = (string) ($issue['currentState']['status'] ?? '');
        $statusDueDate = (string) ($issue['currentState']['statusDueDate'] ?? '');
        $decisionDueDate = (string) ($issue['decisionDueDate'] ?? '');
        $openedDate = (string) ($issue['openedDate'] ?? '');
        $buyerLogin = (string) ($issue['buyer']['login'] ?? '');
        $buyerId = (string) ($issue['buyer']['id'] ?? '');
        $checkoutFormIds = $this->extractCheckoutFormIdsFromPayload($issue);
        foreach ($messages as $message) {
            if (is_array($message)) {
                $checkoutFormIds = array_merge($checkoutFormIds, $this->extractCheckoutFormIdsFromPayload($message));
            }
        }
        $checkoutFormIds = array_values(array_unique(array_filter(array_map('strval', $checkoutFormIds))));
        $checkoutFormId = $checkoutFormIds[0] ?? '';
        $offerId = (string) ($issue['offer']['id'] ?? '');
        $offerQuantity = (string) ($issue['offer']['quantity'] ?? '');
        $productId = (string) ($issue['product']['id'] ?? '');
        $reasonType = (string) ($issue['reason']['type'] ?? '');
        $reasonDescription = $this->resolveIssueTextValue($issue['reason']['description'] ?? null);
        $expectations = $this->formatIssueExpectations($issue['expectations'] ?? []);
        $timeMeta = $this->buildClaimTimeMeta($issue, $messages);
        $statusClass = $this->getIssueStatusClass($status);
        $linkedOrder = $this->resolvePrestashopOrderLink($issue, $messages);
        $decisionResolvedAt = (string) ($timeMeta['resolved_at'] ?? '');

        $html = $this->htmlFragment('b068c232d929bc09d011');
        $html .= $this->htmlFragment('2e907e3455a3643241c5') . Tools::safeOutput((string) ($timeMeta['status_class'] ?? $statusClass)) . '">';
        $html .= $this->htmlFragment('744f57556647a0e5899c');
        $html .= $this->htmlFragment('9e4527fb137f0b371f78');
        $html .= $this->htmlFragment('a90204ddb3c9cc647d69') . Tools::safeOutput($timeMeta['headline']) . $this->htmlFragment('b2f69f8100b2a95949ee');
        $html .= $this->htmlFragment('a19fa9bb29b6423d2150') . Tools::safeOutput($timeMeta['subline']) . $this->htmlFragment('aac32651b10f567c461b');
        $html .= $this->htmlFragment('aac32651b10f567c461b');
        $html .= $this->htmlFragment('07f64419ae27959e82d8');
        $html .= $this->htmlFragment('01b872817d1447242f45');
        $html .= $this->htmlFragment('a90204ddb3c9cc647d69') . Tools::safeOutput($this->formatAllegroDate($decisionDueDate)) . $this->htmlFragment('b2f69f8100b2a95949ee');
        $html .= $this->htmlFragment('aac32651b10f567c461b');
        $html .= $this->htmlFragment('aac32651b10f567c461b');
        $html .= $this->renderClaimProgressBar('aar-claim-progress', $timeMeta);
        $html .= $this->htmlFragment('aac32651b10f567c461b');

        $orderProductRows = $this->buildIssueOrderProductRows($checkoutFormId, $offerId, $offerQuantity, $productId, $linkedOrder);

        $html .= $this->htmlFragment('008754a00056d50396a3');
        $html .= $this->renderCheckoutBuyerDeliveryCard($checkoutFormId, $buyerLogin);
        $html .= $this->renderClaimInfoCard('Zamówienie i produkt', $orderProductRows);
        $html .= $this->renderClaimInfoCard('Powód reklamacji', [
            'Typ powodu' => $this->formatIssueReasonType($reasonType),
            'Temat' => $this->buildIssueSubject($issue),
        ], $reasonDescription);
        $timingRows = [
            'Oczekiwane rozwiązanie' => $expectations,
        ];
        $orderDate = $this->resolveOrderDateByCheckoutForm($checkoutFormId);
        $orderDateLabel = $this->formatPrestashopOrderDateWithAge($orderDate);
        if ($orderDateLabel !== '') {
            $timingRows['Data zamówienia'] = $orderDateLabel;
        }
        $timingRows['Otwarcie reklamacji'] = $this->formatIssueOpenDateSinceOrder($openedDate, $orderDate);
        $timingRows['Termin decyzji'] = $this->formatAllegroDate($decisionDueDate);
        if ($decisionResolvedAt !== '') {
            $timingRows['Rozpatrzono'] = $this->formatAllegroDate($decisionResolvedAt);
        }
        $html .= $this->renderClaimInfoCard('Oczekiwania i terminy', $timingRows);
        $html .= $this->htmlFragment('aac32651b10f567c461b');
        $html .= $this->htmlFragment('aac32651b10f567c461b');

        return $html;
    }

    protected function renderClaimWorkflowPanel(string $issueId, array $issue): string
    {
        if ($issueId === '') {
            return '';
        }

        $status = mb_strtoupper(trim((string) ($issue['currentState']['status'] ?? '')));
        $isOpen = $status === 'CLAIM_SUBMITTED';
        $returnRequired = $this->getClaimReturnRequiredState($issue);
        $returnDueDate = (string) ($issue['currentState']['statusDueDate'] ?? '');
        $decisionDueDate = (string) ($issue['decisionDueDate'] ?? $returnDueDate);
        $noReturnModalId = $this->buildClaimModalId('no-return', $issueId);
        $returnModalId = $this->buildClaimModalId('return', $issueId);
        $acceptModalId = $this->buildClaimModalId('accept', $issueId);
        $rejectModalId = $this->buildClaimModalId('reject', $issueId);

        $html = $this->htmlFragment('2d288d251aee41a717dc');
        $html .= $this->htmlFragment('ab4c1e74156977dd6195');
        $html .= $this->htmlFragment('8c60d89c6de49fdc2eff');
        $html .= $this->htmlFragment('083305ad31663b5a40a8');
        if ($returnDueDate !== '') {
            $html .= $this->htmlFragment('b55f706c7ef1117edcb6') . Tools::safeOutput($this->formatAllegroDate($returnDueDate)) . $this->htmlFragment('411fdb22d8d9298e5d32');
        }
        $html .= $this->htmlFragment('aac32651b10f567c461b');
        if ($returnRequired === true) {
            $html .= $this->htmlFragment('63322d5586e9b8f56f17');
            $html .= $this->htmlFragment('7508f1d0f9024aa4d8da');
            $html .= $this->htmlFragment('c9f973f8841179123cfb');
            $html .= $this->htmlFragment('aac32651b10f567c461b');
        } elseif ($returnRequired === false) {
            $html .= $this->htmlFragment('1680888e1cf1f0f0d8d0');
            $html .= $this->htmlFragment('7508f1d0f9024aa4d8da');
            $html .= $this->htmlFragment('86a9888b584f4bbe0a17');
            $html .= $this->htmlFragment('aac32651b10f567c461b');
        } elseif ($isOpen) {
            $html .= $this->htmlFragment('8d3cd24950086c63b466');
            $html .= $this->htmlFragment('3970af0e6180c34a4055');
            $html .= $this->htmlFragment('ef06db0162fe568a2efb') . Tools::safeOutput($noReturnModalId) . $this->htmlFragment('aaa46baa403508912e5f');
            $html .= $this->htmlFragment('ef06db0162fe568a2efb') . Tools::safeOutput($returnModalId) . $this->htmlFragment('20f7c45e7da7afb21969');
            $html .= $this->htmlFragment('aac32651b10f567c461b');
        } else {
            $html .= $this->htmlFragment('69d29400075d2120cd6a');
        }
        $html .= $this->htmlFragment('aac32651b10f567c461b');

        $html .= $this->htmlFragment('8c60d89c6de49fdc2eff');
        $html .= $this->htmlFragment('861e13aeb504efc92afe');
        if ($decisionDueDate !== '') {
            $html .= $this->htmlFragment('b55f706c7ef1117edcb6') . Tools::safeOutput($this->formatAllegroDate($decisionDueDate)) . $this->htmlFragment('411fdb22d8d9298e5d32');
        }
        $html .= $this->htmlFragment('aac32651b10f567c461b');
        if ($isOpen) {
            $html .= $this->htmlFragment('a1d9ff4d0fdbfcc9b9c2');
            $html .= $this->htmlFragment('3970af0e6180c34a4055');
            $html .= $this->htmlFragment('37f7eb0e951bd522ebcc') . Tools::safeOutput($acceptModalId) . $this->htmlFragment('00138ebb0f5babfda925');
            $html .= $this->htmlFragment('9f9ab6222b3d8c471403') . Tools::safeOutput($rejectModalId) . $this->htmlFragment('975df65329c4e521d420');
            $html .= $this->htmlFragment('aac32651b10f567c461b');
        } else {
            $html .= $this->htmlFragment('bc55c99d9719d85d39fc') . Tools::safeOutput($this->formatIssueStatus($status)) . $this->htmlFragment('75276f3cd0194a647ce8');
        }
        $html .= $this->htmlFragment('aac32651b10f567c461b');
        $html .= $this->htmlFragment('195fde57a5eb9165a3ce');

        return $html;
    }

    protected function getClaimReturnRequiredState(array $issue): ?bool
    {
        $value = $issue['currentState']['returnRequired'] ?? null;
        if (is_bool($value)) {
            return $value;
        }
        if (is_int($value)) {
            return $value === 1;
        }
        if (is_string($value)) {
            $normalized = mb_strtolower(trim($value));
            if (in_array($normalized, ['true', '1', 'yes'], true)) {
                return true;
            }
            if (in_array($normalized, ['false', '0', 'no'], true)) {
                return false;
            }
        }

        return null;
    }

    protected function buildClaimModalId(string $kind, string $issueId): string
    {
        return 'aar-claim-' . preg_replace('/[^a-zA-Z0-9_-]/', '-', $kind) . '-modal-' . preg_replace('/[^a-zA-Z0-9_-]/', '-', $issueId);
    }

    protected function renderClaimWorkflowModals(string $issueId, array $issue): string
    {
        $status = mb_strtoupper(trim((string) ($issue['currentState']['status'] ?? '')));
        if ($issueId === '' || $status !== 'CLAIM_SUBMITTED') {
            return '';
        }

        $html = '';
        if ($this->getClaimReturnRequiredState($issue) === null) {
            $html .= $this->renderClaimNoReturnModal($issueId);
            $html .= $this->renderClaimReturnRequiredModal($issueId, $issue);
        }
        $html .= $this->renderClaimStatusModal($issueId, 'accepted', $issue);
        $html .= $this->renderClaimStatusModal($issueId, 'rejected', $issue);

        return $html;
    }

    protected function renderClaimNoReturnModal(string $issueId): string
    {
        $modalId = $this->buildClaimModalId('no-return', $issueId);
        $html = $this->htmlFragment('9e5db7545417154438f8') . Tools::safeOutput($modalId) . '" tabindex="-1" role="dialog" aria-labelledby="' . Tools::safeOutput($modalId . '-title') . '">';
        $html .= $this->htmlFragment('b62c1a34c0e3ea7baef3');
        $html .= $this->htmlFragment('5b361f9289120a6411bc') . Tools::safeOutput($modalId . '-title') . $this->htmlFragment('a53cc4c7fe605e978ec8');
        $html .= $this->htmlFragment('6a8a07b8e5e1ca4ee4e1');
        $html .= $this->htmlFragment('3c6bfa2df1e24221dfc1') . Tools::safeOutput($issueId) . $this->htmlFragment('47aa17c3b21447e0b6b8');
        $html .= $this->htmlFragment('92cb39851bf2397957b1');
        $html .= $this->htmlFragment('52e61d1c5afd59cd4e58');
        $html .= $this->htmlFragment('0feb2ea8d0bc9fed1b2c');
        $html .= $this->htmlFragment('bd1770902d0bb0db962c');

        return $html;
    }

    protected function renderClaimReturnRequiredModal(string $issueId, array $issue): string
    {
        $modalId = $this->buildClaimModalId('return', $issueId);
        $smartId = $modalId . '-smart';
        $labelId = $modalId . '-label';
        $customId = $modalId . '-custom';
        $smartDelivery = $this->getClaimSmartDeliveryState($issue);
        $allegroIssueUrl = $this->getAllegroIssueUrl($issue);
        $canOpenSmartReturn = $smartDelivery === true && $allegroIssueUrl !== '';
        $html = $this->htmlFragment('a03e2f603b4d712835a9') . Tools::safeOutput($modalId) . '" tabindex="-1" role="dialog" aria-labelledby="' . Tools::safeOutput($modalId . '-title') . '">';
        $html .= $this->htmlFragment('b62c1a34c0e3ea7baef3');
        $html .= $this->htmlFragment('5b361f9289120a6411bc') . Tools::safeOutput($modalId . '-title') . $this->htmlFragment('a6eaaae63329336ba68e');
        $html .= $this->htmlFragment('aaef73e8b1369899fddd');
        $html .= $this->htmlFragment('3c6bfa2df1e24221dfc1') . Tools::safeOutput($issueId) . $this->htmlFragment('129d605fde6f2485b4dc');
        $html .= $this->htmlFragment('ee20e7bb00bfae99a813');
        $html .= $this->htmlFragment('b6b2a1f76cdcbe2a1d87');

        if ($canOpenSmartReturn) {
            $html .= $this->htmlFragment('cf2732c21bea96594af4') . Tools::safeOutput($smartId) . '">';
            $html .= $this->htmlFragment('344fe1b5977e7c06c157') . Tools::safeOutput($smartId) . '" type="radio" name="claim_return_choice" value="SMART" data-aar-smart-url="' . Tools::safeOutput($allegroIssueUrl) . '" required>';
            $html .= $this->htmlFragment('3a5b3094d41d72bff961');
            $html .= $this->htmlFragment('3fc95dda2fe9090067ea');
        } else {
            $smartUnavailableReason = $smartDelivery === false
                ? 'Dostawa tego zamówienia nie została zrealizowana w ramach SMART!.'
                : 'Nie udało się potwierdzić w danych zamówienia, czy dostawa była objęta SMART!.';
            $html .= $this->htmlFragment('9411f08f7f4099fcc9c4') . Tools::safeOutput($smartId) . '">';
            $html .= $this->htmlFragment('344fe1b5977e7c06c157') . Tools::safeOutput($smartId) . '" type="radio" disabled>';
            $html .= $this->htmlFragment('2e320230d1a94de2e500') . Tools::safeOutput($smartUnavailableReason) . $this->htmlFragment('7007cea0c7a30adb4076');
            $html .= $this->htmlFragment('3fc95dda2fe9090067ea');
        }

        $html .= $this->htmlFragment('e4c67e7231caef084086') . Tools::safeOutput($labelId) . '">';
        $html .= $this->htmlFragment('344fe1b5977e7c06c157') . Tools::safeOutput($labelId) . '" type="radio" name="claim_return_choice" value="SELLER_LABEL" required>';
        $html .= $this->htmlFragment('9bc21cd6326301b404cc');
        $html .= $this->htmlFragment('3fc95dda2fe9090067ea');
        $html .= $this->htmlFragment('2be2e6bf4cf38155f391');
        $html .= $this->htmlFragment('3cd1f8e4f20dd894fe34') . Tools::safeOutput($modalId . '-file') . $this->htmlFragment('de04b92087e663bf2edf') . Tools::safeOutput($modalId . '-file') . $this->htmlFragment('2d825a3a2237bf7c6b92');
        $html .= $this->htmlFragment('b4c7156cec58e5679b00') . Tools::safeOutput($modalId . '-label-message') . $this->htmlFragment('0031acd07775327ec8a4') . Tools::safeOutput($modalId . '-label-message') . $this->htmlFragment('3249e490dcf36e4d4e6f');
        $html .= $this->htmlFragment('aac32651b10f567c461b');

        $html .= $this->htmlFragment('e4c67e7231caef084086') . Tools::safeOutput($customId) . '">';
        $html .= $this->htmlFragment('344fe1b5977e7c06c157') . Tools::safeOutput($customId) . '" type="radio" name="claim_return_choice" value="CUSTOM" required>';
        $html .= $this->htmlFragment('12b3614bb9c6fee88365');
        $html .= $this->htmlFragment('3fc95dda2fe9090067ea');
        $html .= $this->htmlFragment('b1f8dd0034609c3ba909');
        $html .= $this->htmlFragment('b4c7156cec58e5679b00') . Tools::safeOutput($modalId . '-custom-message') . $this->htmlFragment('3643f5438abeee0b9fbb') . Tools::safeOutput($modalId . '-custom-message') . $this->htmlFragment('3249e490dcf36e4d4e6f');
        $html .= $this->htmlFragment('aac32651b10f567c461b');
        $html .= $this->htmlFragment('aac32651b10f567c461b');
        $html .= $this->htmlFragment('bb1f27fbf382688a3ec7');
        $html .= $this->htmlFragment('bd1770902d0bb0db962c');

        return $html;
    }

    protected function getClaimSmartDeliveryState(array $issue): ?bool
    {
        $checkoutForm = is_array($issue['_checkout_form'] ?? null) ? $issue['_checkout_form'] : [];
        if (!$checkoutForm) {
            $checkoutFormId = $this->extractIssueCheckoutFormId($issue);
            $checkoutForm = $this->getStoredCheckoutFormContent($checkoutFormId);
        }

        $value = $checkoutForm['delivery']['smart'] ?? null;
        if (is_bool($value)) {
            return $value;
        }
        if (is_int($value)) {
            return $value === 1;
        }
        if (is_string($value)) {
            $normalized = mb_strtolower(trim($value));
            if (in_array($normalized, ['true', '1', 'yes'], true)) {
                return true;
            }
            if (in_array($normalized, ['false', '0', 'no'], true)) {
                return false;
            }
        }

        return null;
    }

    protected function renderClaimStatusModal(string $issueId, string $group, array $issue): string
    {
        $isAccepted = $group === 'accepted';
        $modalId = $this->buildClaimModalId($isAccepted ? 'accept' : 'reject', $issueId);
        $title = $isAccepted ? 'Uznaj reklamację' : 'Odrzuć reklamację';
        $definitions = array_filter($this->getClaimStatusActionDefinitions(), static function (array $definition) use ($group): bool {
            return (string) ($definition['group'] ?? '') === $group;
        });
        $currency = $this->resolveClaimWorkflowCurrency($issue);

        $html = $this->htmlFragment('9e5db7545417154438f8') . Tools::safeOutput($modalId) . '" tabindex="-1" role="dialog" aria-labelledby="' . Tools::safeOutput($modalId . '-title') . '">';
        $html .= $this->htmlFragment('b62c1a34c0e3ea7baef3');
        $html .= $this->htmlFragment('5b361f9289120a6411bc') . Tools::safeOutput($modalId . '-title') . '">' . Tools::safeOutput($title) . $this->htmlFragment('5dea455128320f6fbab1');
        $html .= $this->htmlFragment('6a8a07b8e5e1ca4ee4e1');
        $html .= $this->htmlFragment('3c6bfa2df1e24221dfc1') . Tools::safeOutput($issueId) . '">';
        if (!$isAccepted) {
            $html .= $this->htmlFragment('422f1cb140d2aa51f505');
        }
        $html .= $this->htmlFragment('0dfd4c10121853c80a5a') . ($isAccepted ? 'Wybierz sposób rozpatrzenia reklamacji' : 'Wybierz powód odrzucenia reklamacji') . $this->htmlFragment('75276f3cd0194a647ce8');
        $html .= $this->htmlFragment('b438f972c9858f3e54b6');
        $checked = true;
        foreach ($definitions as $status => $definition) {
            $html .= $this->htmlFragment('e9a5900706ce8f4bb3f0') . Tools::safeOutput($status) . '"' . ($checked ? ' checked' : '') . $this->htmlFragment('6cd14378d6c7a129dad7') . Tools::safeOutput((string) ($definition['label'] ?? $status)) . $this->htmlFragment('776b32bc638deda8a74f');
            $checked = false;
        }
        $html .= $this->htmlFragment('aac32651b10f567c461b');
        if ($isAccepted) {
            $html .= $this->htmlFragment('27611dbd2d2e8a6b9dea') . Tools::safeOutput($currency) . $this->htmlFragment('3fc4185eb3374968b5e1');
        }
        $html .= $this->htmlFragment('7ab0b7628ec58a3da85f');
        $html .= $this->htmlFragment('5d653417ba1e49ee253f');
        $html .= $this->htmlFragment('ce403747ba3174515fae') . ($isAccepted ? 'btn-success' : 'btn-danger') . $this->htmlFragment('73220861342631e398bb');
        $html .= $this->htmlFragment('bd1770902d0bb0db962c');

        return $html;
    }

    protected function resolveClaimWorkflowCurrency(array $issue): string
    {
        foreach (($issue['expectations'] ?? []) as $expectation) {
            if (!is_array($expectation)) {
                continue;
            }
            $currency = mb_strtoupper(trim((string) ($expectation['refund']['currency'] ?? '')));
            if (preg_match('/^[A-Z]{3}$/', $currency)) {
                return $currency;
            }
        }

        return 'PLN';
    }

    protected function renderIssueOrderSummaryPanel(array $issue, array $messages = []): string
    {
        $checkoutFormIds = $this->extractCheckoutFormIdsFromPayload($issue);
        foreach ($messages as $message) {
            if (is_array($message)) {
                $checkoutFormIds = array_merge($checkoutFormIds, $this->extractCheckoutFormIdsFromPayload($message));
            }
        }

        $checkoutFormIds = array_values(array_unique(array_filter(array_map('strval', $checkoutFormIds))));
        $checkoutFormId = $checkoutFormIds[0] ?? '';
        $offerId = (string) ($issue['offer']['id'] ?? '');
        $offerQuantity = (string) ($issue['offer']['quantity'] ?? '');
        $productId = (string) ($issue['product']['id'] ?? '');
        $linkedOrder = $this->resolvePrestashopOrderLink($issue, $messages);
        $rows = $this->buildIssueOrderProductRows($checkoutFormId, $offerId, $offerQuantity, $productId, $linkedOrder);

        if (!$rows) {
            return '';
        }

        $html = $this->htmlFragment('6ffca28fc000c21f0f60');
        $html .= $this->renderClaimInfoCard('Zamówienie i produkt', $rows);
        $html .= $this->htmlFragment('aac32651b10f567c461b');

        return $html;
    }

    protected function renderCustomerReturnDecisionPanel(string $returnId, array $return, string $total = ''): string
    {
        if ($returnId === '') {
            return '';
        }

        $refundModalId = $this->buildCustomerReturnRefundModalId($returnId);
        $rejectionModalId = $this->buildCustomerReturnRejectionModalId($returnId);
        $html = $this->htmlFragment('798d468a761f0b067889');
        $html .= $this->htmlFragment('c1e5ec9cb79ffff71230');
        $html .= $this->htmlFragment('03d7d7ce5a21c86d54fa');
        $html .= $this->htmlFragment('f44ff6fed10e654e0537');
        $html .= $this->htmlFragment('48ee9a597c85fbb2a916');
        if ($this->canRefundCustomerReturn($return)) {
            $html .= $this->htmlFragment('aa838190baba9cb5b773') . Tools::safeOutput($refundModalId) . $this->htmlFragment('a81a722318fdf6762712');
        } else {
            $html .= $this->htmlFragment('b6b9a2f9adc476606a2c');
        }
        if ($this->canRejectCustomerReturn($return)) {
            $html .= $this->htmlFragment('aa838190baba9cb5b773') . Tools::safeOutput($rejectionModalId) . $this->htmlFragment('0874fd92f2325e1ce731');
        } else {
            $html .= $this->htmlFragment('5ae39f8391e09620c8b5');
        }
        $html .= $this->htmlFragment('348845d8804b5c895e2a');
        $html .= $this->htmlFragment('aac32651b10f567c461b');
        if ($total !== '') {
            $html .= $this->htmlFragment('f9c09dc18722339b27f6') . Tools::safeOutput($total) . $this->htmlFragment('0e1a4d58742cfc31cdde');
        }
        $html .= $this->htmlFragment('aac32651b10f567c461b');
        $html .= $this->htmlFragment('aac32651b10f567c461b');
        $html .= $this->renderCustomerReturnRefundModal($returnId, $return);
        $html .= $this->renderCustomerReturnRejectionModal($returnId, $return);

        return $html;
    }

    protected function canRefundCustomerReturn(array $return): bool
    {
        if (is_array($return['rejection'] ?? null)) {
            return false;
        }

        $status = mb_strtoupper(trim((string) ($return['status'] ?? '')));
        if (in_array($status, ['FINISHED', 'FINISHED_APT', 'REJECTED', 'COMMISSION_REFUNDED'], true)) {
            return false;
        }

        foreach (($return['items'] ?? []) as $item) {
            if (!is_array($item)) {
                continue;
            }

            if (trim((string) ($item['offerId'] ?? '')) !== '' && $this->calculateCustomerReturnItemAmount($item) > 0) {
                return true;
            }
        }

        return false;
    }

    protected function canRejectCustomerReturn(array $return): bool
    {
        if (is_array($return['rejection'] ?? null)) {
            return false;
        }

        $status = mb_strtoupper(trim((string) ($return['status'] ?? '')));

        return !in_array($status, ['FINISHED', 'FINISHED_APT', 'REJECTED'], true);
    }

    protected function renderCustomerReturnSummaryPanel(array $return): string
    {
        $buyerProfile = $this->getCustomerReturnBuyerProfile($return);
        $buyerName = $buyerProfile['name'];
        $buyerLogin = $buyerProfile['login'];
        $buyerEmail = $buyerProfile['email'];
        $buyerPhone = $buyerProfile['phone'];
        $deliveryMethod = $this->getCustomerReturnDeliveryMethod($return);
        $deliveryWaybill = $this->getCustomerReturnWaybill($return);
        $returnAddress = $this->getCustomerReturnAddressLines($return);
        $refundLines = $this->getCustomerReturnRefundLines($return);
        $itemsBody = $this->renderCustomerReturnItems($return);
        $total = $this->calculateCustomerReturnTotal($return);

        $html = $this->htmlFragment('2999732c77c89b69cd5b');
        if ($itemsBody !== '') {
            $html .= $this->htmlFragment('9b50c3acec6d00bb2648') . $itemsBody . $this->htmlFragment('aac32651b10f567c461b');
        }
        $html .= $this->htmlFragment('f0df5d156f15599a2781');
        $html .= $this->htmlFragment('2a94ebc16196e0ca7ada');
        $html .= $this->htmlFragment('7aaf601393c59989b35a');
        $html .= $this->renderCustomerReturnTimeline($return);
        $html .= $this->htmlFragment('195fde57a5eb9165a3ce');

        $html .= $this->htmlFragment('f6d238b312aa9654ace5');
        $html .= $this->htmlFragment('5f0bcfe10a4bbfe11bfa');
        if ($buyerName !== '') {
            $html .= $this->htmlFragment('9e4527fb137f0b371f78') . Tools::safeOutput($buyerName) . $this->htmlFragment('aac32651b10f567c461b');
        }
        if ($buyerLogin !== '') {
            $html .= $this->htmlFragment('4974c1aa3d15fb468350') . Tools::safeOutput($buyerLogin) . $this->htmlFragment('aac32651b10f567c461b');
        }
        if ($buyerEmail !== '') {
            $html .= $this->htmlFragment('7b71bf048cbfeb66f730') . Tools::safeOutput($buyerEmail) . '">' . Tools::safeOutput($buyerEmail) . $this->htmlFragment('545b719c5aa06983a1e6');
        }
        if ($buyerPhone !== '') {
            $html .= $this->htmlFragment('9625c9f6d3b5664a904a') . Tools::safeOutput($this->formatPhoneNumber($buyerPhone)) . $this->htmlFragment('aac32651b10f567c461b');
        }
        $html .= $this->htmlFragment('bfaa060997c5ca9c57be') . ($this->customerReturnHasInvoice($return) ? 'is-invoice' : 'is-no-invoice') . '">' . ($this->customerReturnHasInvoice($return) ? 'FAKTURA' : 'BEZ FAKTURY') . $this->htmlFragment('8dad793c25981e398e7a');
        $html .= $this->htmlFragment('195fde57a5eb9165a3ce');

        $html .= $this->htmlFragment('f6d238b312aa9654ace5');
        $html .= $this->htmlFragment('8f5f15192c009c3f51ba');
        if ($deliveryMethod !== '') {
            $html .= $this->htmlFragment('9e4527fb137f0b371f78') . Tools::safeOutput($deliveryMethod) . $this->htmlFragment('aac32651b10f567c461b');
        }
        if ($deliveryWaybill !== '') {
            if ($this->shouldUseCustomerReturnTrackingModal($return)) {
                $trackingModalId = $this->buildCustomerReturnTrackingModalId((string) ($return['id'] ?? ''), $deliveryWaybill);
                $html .= $this->htmlFragment('fe41e29de37559edc8d7') . Tools::safeOutput($trackingModalId) . '">' . Tools::safeOutput($deliveryWaybill) . $this->htmlFragment('fb0f2e9f534ca03a2975');
            } else {
                $trackingUrl = $this->getCustomerReturnTrackingUrl($return);
                if ($trackingUrl !== '') {
                    $html .= $this->htmlFragment('50e28d916f2722ef0109') . Tools::safeOutput($trackingUrl) . '" target="_blank" rel="noopener noreferrer">' . Tools::safeOutput($deliveryWaybill) . $this->htmlFragment('545b719c5aa06983a1e6');
                } else {
                    $html .= $this->htmlFragment('9e4527fb137f0b371f78') . Tools::safeOutput($deliveryWaybill) . $this->htmlFragment('aac32651b10f567c461b');
                }
            }
        }
        if ($returnAddress) {
            $html .= $this->htmlFragment('84a1ef8aa95210dc3fff');
            foreach ($returnAddress as $line) {
                $html .= $this->htmlFragment('9e4527fb137f0b371f78') . Tools::safeOutput($line) . $this->htmlFragment('aac32651b10f567c461b');
            }
        }
        $html .= $this->htmlFragment('195fde57a5eb9165a3ce');

        $html .= $this->htmlFragment('966507249d91544f5646');
        $html .= $this->htmlFragment('7e639e7dfcdc7a1efabd');
        if ($refundLines) {
            foreach ($refundLines as $index => $line) {
                $lineClass = $index === 0 ? ' class="aar-return-refund-account"' : '';
                $html .= $this->htmlFragment('d70b8e28e0ce87164f95') . $lineClass . '>' . Tools::safeOutput($line) . $this->htmlFragment('aac32651b10f567c461b');
            }
        } else {
            $html .= $this->htmlFragment('43f61dd14734a67ae01f');
        }
        $html .= $this->htmlFragment('195fde57a5eb9165a3ce');
        $html .= $this->htmlFragment('aac32651b10f567c461b');
        $html .= $this->htmlFragment('aac32651b10f567c461b');

        return $html;
    }

    protected function renderCustomerReturnDiagnosticsPanel(string $returnId, array $selectedReturn, array $selectedReturnRaw = []): string
    {
        if ($returnId === '') {
            return '';
        }

        $debugUrl = $this->getReturnsAdminUrl(['return_id' => $returnId, 'aar_debug_return' => 1]);
        $modalId = $this->buildCustomerReturnDebugModalId($returnId);
        $payload = [
            'selected_return_id' => $returnId,
            'api_response' => $selectedReturnRaw ?: $selectedReturn,
            'enriched_response' => $selectedReturn,
        ];

        $html = $this->htmlFragment('436f07bad56985b79346') . Tools::safeOutput($modalId) . '" tabindex="-1" role="dialog" aria-labelledby="' . Tools::safeOutput($modalId . '-title') . '">';
        $html .= $this->htmlFragment('a04acc39bbf01025ebbd');
        $html .= $this->htmlFragment('d91ec07885dee8fb2180');
        $html .= $this->htmlFragment('d53c52f4f898f8ed293c');
        $html .= $this->htmlFragment('1ffc2c2a9b34fd8df40e');
        $html .= $this->htmlFragment('eec8c139fec0bb69cdb2') . Tools::safeOutput($modalId . '-title') . $this->htmlFragment('283d51335246153e5c7b');
        $html .= $this->htmlFragment('aac32651b10f567c461b');
        $html .= $this->htmlFragment('6416b918eef22c892aee');
        $html .= $this->htmlFragment('a2a7951e7d4b8e95dadf');
        $html .= $this->htmlFragment('f858169656616e48df49');
        $html .= $this->htmlFragment('93ec083ffba5d004a38d') . Tools::safeOutput($debugUrl) . $this->htmlFragment('5a9b72848822eb5e2167');
        $html .= $this->htmlFragment('aac32651b10f567c461b');
        $html .= $this->htmlFragment('278e4ecb1e30d1398390') . Tools::safeOutput(json_encode($payload, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)) . $this->htmlFragment('485b0c2c3b23c2f8e61e');
        $html .= $this->htmlFragment('aac32651b10f567c461b');
        $html .= $this->htmlFragment('5b94a554b4af4f48d3c5');
        $html .= $this->htmlFragment('745c5e36a882adc8902a');
        $html .= $this->htmlFragment('aac32651b10f567c461b');
        $html .= $this->htmlFragment('aac32651b10f567c461b');
        $html .= $this->htmlFragment('aac32651b10f567c461b');
        $html .= $this->htmlFragment('aac32651b10f567c461b');

        return $html;
    }

    protected function renderCustomerReturnTrackingModal(string $returnId, array $return): string
    {
        $waybill = $this->getCustomerReturnWaybill($return);
        if ($returnId === '' || $waybill === '' || !$this->shouldUseCustomerReturnTrackingModal($return)) {
            return '';
        }

        $modalId = $this->buildCustomerReturnTrackingModalId($returnId, $waybill);
        $trackingEntry = $this->findCustomerReturnTrackingEntry($return, $waybill);
        $statuses = is_array($trackingEntry['trackingDetails']['statuses'] ?? null) ? $trackingEntry['trackingDetails']['statuses'] : [];
        $externalUrl = $this->getCustomerReturnTrackingUrl($return);

        $html = $this->htmlFragment('5798c622726ee17b28ff') . Tools::safeOutput($modalId) . '" tabindex="-1" role="dialog" aria-labelledby="' . Tools::safeOutput($modalId . '-title') . '">';
        $html .= $this->htmlFragment('a04acc39bbf01025ebbd');
        $html .= $this->htmlFragment('d91ec07885dee8fb2180');
        $carrierName = $this->getCustomerReturnDeliveryMethod($return);
        $html .= $this->htmlFragment('a42a4bae2f7f585c52bf');
        $html .= $this->htmlFragment('9cd32f1b7fa2efc3ba22');
        $html .= $this->htmlFragment('eec8c139fec0bb69cdb2') . Tools::safeOutput($modalId . '-title') . $this->htmlFragment('1a696990823019632780');
        $html .= $this->htmlFragment('38846a2aecf7305a8f79');
        $html .= $this->htmlFragment('a90204ddb3c9cc647d69') . Tools::safeOutput($waybill) . $this->htmlFragment('b2f69f8100b2a95949ee');
        if ($carrierName !== '') {
            $html .= $this->htmlFragment('f0a8ebd68c47ad5549c3') . Tools::safeOutput($carrierName) . $this->htmlFragment('411fdb22d8d9298e5d32');
        }
        $html .= $this->htmlFragment('aac32651b10f567c461b');
        $html .= $this->htmlFragment('aac32651b10f567c461b');
        $html .= $this->htmlFragment('1ffc2c2a9b34fd8df40e');
        $html .= $this->htmlFragment('aac32651b10f567c461b');
        $html .= $this->htmlFragment('6416b918eef22c892aee');

        if ($statuses) {
            $html .= $this->htmlFragment('b254b1ed2055c07f7ab9');
            $totalStatuses = count($statuses);
            foreach ($statuses as $index => $status) {
                if (!is_array($status)) {
                    continue;
                }

                $occurredAt = $this->formatAllegroDate((string) ($status['occurredAt'] ?? $status['createdAt'] ?? ''));
                $description = trim((string) ($status['description'] ?? ''));
                $code = trim((string) ($status['code'] ?? ''));
                $translatedDescription = $this->translateCustomerReturnTrackingDescription($code, $description);
                $classes = ['aar-return-tracking-step', 'is-completed'];
                if ($index === $totalStatuses - 1) {
                    $classes[] = 'is-active';
                }
                if ($index < $totalStatuses - 1) {
                    $classes[] = 'has-next-completed';
                }

                $html .= $this->htmlFragment('834e25fc21c57c69258d') . Tools::safeOutput(implode(' ', $classes)) . '">';
                $html .= $this->htmlFragment('e5c2c2aea0ea9f13a316');
                $html .= $this->htmlFragment('bfac32c15a71882292af') . Tools::safeOutput($translatedDescription !== '' ? $translatedDescription : $this->formatCustomerReturnTrackingCode($code)) . $this->htmlFragment('aac32651b10f567c461b');
                if ($occurredAt !== '') {
                    $html .= $this->htmlFragment('6c2a4f56779dcd1b2d3e') . Tools::safeOutput($occurredAt) . $this->htmlFragment('aac32651b10f567c461b');
                }
                if ($code !== '' && $translatedDescription !== '' && $translatedDescription !== $code) {
                    $html .= $this->htmlFragment('7a6ba052d3cbf1e697ba') . Tools::safeOutput($this->formatCustomerReturnTrackingCode($code)) . $this->htmlFragment('aac32651b10f567c461b');
                } elseif ($description !== '' && $translatedDescription === '') {
                    $html .= $this->htmlFragment('7a6ba052d3cbf1e697ba') . Tools::safeOutput($description) . $this->htmlFragment('aac32651b10f567c461b');
                }
                $html .= $this->htmlFragment('aac32651b10f567c461b');
            }
            $html .= $this->htmlFragment('aac32651b10f567c461b');
        } else {
            $html .= $this->htmlFragment('c405171c6a17c0cf7aef');
        }

        $html .= $this->htmlFragment('aac32651b10f567c461b');
        $html .= $this->htmlFragment('5b94a554b4af4f48d3c5');
        if ($externalUrl !== '') {
            $html .= $this->htmlFragment('05c074c4f3fe221a2f75') . Tools::safeOutput($externalUrl) . $this->htmlFragment('52eb511f8687c7d2d725');
        }
        $html .= $this->htmlFragment('745c5e36a882adc8902a');
        $html .= $this->htmlFragment('aac32651b10f567c461b');
        $html .= $this->htmlFragment('aac32651b10f567c461b');
        $html .= $this->htmlFragment('aac32651b10f567c461b');
        $html .= $this->htmlFragment('aac32651b10f567c461b');

        return $html;
    }

    protected function buildCustomerReturnDebugModalId(string $returnId): string
    {
        return 'aar-return-debug-' . preg_replace('/[^a-zA-Z0-9_-]/', '-', $returnId);
    }

    protected function buildCustomerReturnTrackingModalId(string $returnId, string $waybill): string
    {
        return 'aar-return-tracking-' . preg_replace('/[^a-zA-Z0-9_-]/', '-', $returnId . '-' . $waybill);
    }

    protected function renderCustomerReturnTimeline(array $return): string
    {
        $steps = $this->buildCustomerReturnTimelineSteps($return);
        if (!$steps) {
            return '';
        }

        $html = $this->htmlFragment('a3763de88a8ba0217b45');
        foreach ($steps as $step) {
            $classes = ['aar-return-timeline-step'];
            if (!empty($step['completed'])) {
                $classes[] = 'is-completed';
            }
            if (!empty($step['active'])) {
                $classes[] = 'is-active';
            }
            if (!empty($step['next_completed'])) {
                $classes[] = 'has-next-completed';
            }

            $html .= $this->htmlFragment('834e25fc21c57c69258d') . Tools::safeOutput(implode(' ', $classes)) . '">';
            $html .= $this->htmlFragment('1f76f94889e147abccb0');
            $html .= $this->htmlFragment('59b19231ae6b302f689f') . Tools::safeOutput((string) ($step['label'] ?? '')) . $this->htmlFragment('aac32651b10f567c461b');
            if (trim((string) ($step['date'] ?? '')) !== '') {
                $html .= $this->htmlFragment('ae6c506e7de94d7c2b4e') . Tools::safeOutput($this->formatAllegroDate((string) $step['date'])) . $this->htmlFragment('aac32651b10f567c461b');
            }
            $html .= $this->htmlFragment('aac32651b10f567c461b');
        }
        $html .= $this->htmlFragment('aac32651b10f567c461b');
        $returnId = trim((string) ($return['id'] ?? ''));
        if ($returnId !== '') {
            $modalId = $this->buildCustomerReturnDebugModalId($returnId);
            $html .= $this->htmlFragment('528a00dfe2e31c7e5ebd') . Tools::safeOutput($modalId) . $this->htmlFragment('561275aa984856b9bab7');
        }

        return $html;
    }

    protected function buildCustomerReturnTimelineSteps(array $return): array
    {
        $status = mb_strtoupper(trim((string) ($return['status'] ?? '')));
        $isOwnShipping = $this->isCustomerReturnOwnShipping($return);
        $statusOrder = [
            'CREATED' => 0,
            'DISPATCHED' => 1,
            'IN_TRANSIT' => 2,
            'DELIVERED' => 3,
            'WAREHOUSE_DELIVERED' => 3,
            'WAREHOUSE_VERIFICATION' => 3,
            'FINISHED' => 4,
            'FINISHED_APT' => 4,
            'COMMISSION_REFUND_CLAIMED' => 4,
            'COMMISSION_REFUNDED' => 5,
        ];
        $activeIndex = $statusOrder[$status] ?? 0;
        $isRejected = $status === 'REJECTED' || is_array($return['rejection'] ?? null);

        $dates = [
            'CREATED' => (string) ($return['createdAt'] ?? ''),
            'DISPATCHED' => $this->findCustomerReturnDate($return, ['DISPATCHED', 'SENT']),
            'IN_TRANSIT' => $this->findCustomerReturnDate($return, ['IN_TRANSIT']),
            'DELIVERED' => $this->findCustomerReturnDate($return, ['DELIVERED', 'WAREHOUSE_DELIVERED', 'WAREHOUSE_VERIFICATION']),
            'FINISHED' => $this->findCustomerReturnDate($return, ['FINISHED', 'FINISHED_APT']),
            'COMMISSION_REFUNDED' => $this->findCustomerReturnDate($return, ['COMMISSION_REFUNDED']),
        ];

        if ($dates['IN_TRANSIT'] === '') {
            $dates['IN_TRANSIT'] = $this->findCustomerReturnTrackingDate($return, ['IN_TRANSIT', 'RELEASED_FOR_DELIVERY', 'AVAILABLE_FOR_PICKUP']);
        }
        if ($dates['DISPATCHED'] === '') {
            $dates['DISPATCHED'] = $this->findCustomerReturnTrackingDispatchDate($return);
        }
        if ($dates['DELIVERED'] === '') {
            $dates['DELIVERED'] = $this->findCustomerReturnTrackingDate($return, ['DELIVERED']);
        }
        if ($dates['DELIVERED'] === '') {
            $dates['DELIVERED'] = $this->findFirstParcelDate($return, ['deliveredAt', 'receivedAt']);
        }
        if ($isRejected && is_array($return['rejection'] ?? null)) {
            $dates['FINISHED'] = (string) ($return['rejection']['createdAt'] ?? $dates['FINISHED']);
        }
        if (
            $dates['FINISHED'] === ''
            && (
                in_array($status, ['FINISHED', 'FINISHED_APT', 'COMMISSION_REFUNDED'], true)
                || is_array($return['refund'] ?? null)
            )
        ) {
            $dates['FINISHED'] = $this->findCustomerReturnDateByPathHints($return, [
                'refund',
                'refunded',
                'payment',
                'moneyback',
                'money_back',
                'finished',
                'finish',
            ], [
                'commission',
                'rebate',
                'tracking',
                'parcel',
                'waybill',
                '_checkout_form',
                'checkout_form',
            ]);
        }
        if (
            $dates['FINISHED'] === ''
            && in_array($status, ['FINISHED', 'FINISHED_APT', 'COMMISSION_REFUNDED'], true)
        ) {
            $dates['FINISHED'] = $this->findCustomerReturnDateFromListItem($return, [
                'FINISHED',
                'FINISHED_APT',
                'COMMISSION_REFUNDED',
            ], [
                'refund',
                'refunded',
                'payment',
                'moneyback',
                'money_back',
                'finished',
                'finish',
                'updated',
                'status',
                'change',
            ], [
                'commission',
                'rebate',
                'tracking',
                'parcel',
                'waybill',
                '_checkout_form',
                'checkout_form',
            ]);
        }
        if ($dates['COMMISSION_REFUNDED'] === '' && $status === 'COMMISSION_REFUNDED') {
            $dates['COMMISSION_REFUNDED'] = $this->findCustomerReturnDateByPathHints($return, [
                'commission',
                'rebate',
                'transactionrebate',
                'transaction_rebate',
                'refundclaim',
                'refund_claim',
                'commissionrefunded',
                'commission_refunded',
            ]);
        }
        if ($dates['COMMISSION_REFUNDED'] === '' && $status === 'COMMISSION_REFUNDED') {
            $dates['COMMISSION_REFUNDED'] = $this->findCustomerReturnDateFromListItem($return, [
                'COMMISSION_REFUNDED',
            ], [
                'commission',
                'rebate',
                'transactionrebate',
                'transaction_rebate',
                'refundclaim',
                'refund_claim',
                'commissionrefunded',
                'commission_refunded',
                'updated',
                'status',
                'change',
            ]);
        }

        if ($isOwnShipping) {
            $definitions = [
                ['status' => 'CREATED', 'label' => 'Zwrot zgłoszony'],
                ['status' => 'FINISHED', 'label' => $isRejected ? 'Zwrot odrzucony' : 'Zwrot wpłaty'],
                ['status' => 'COMMISSION_REFUNDED', 'label' => 'Zwrot prowizji'],
            ];
        } else {
            $definitions = [
                ['status' => 'CREATED', 'label' => 'Zwrot zgłoszony'],
                ['status' => 'DISPATCHED', 'label' => 'Nadany'],
                ['status' => 'IN_TRANSIT', 'label' => 'W drodze'],
                ['status' => 'DELIVERED', 'label' => 'Doręczony'],
                ['status' => 'FINISHED', 'label' => $isRejected ? 'Zwrot odrzucony' : 'Zwrot wpłaty'],
                ['status' => 'COMMISSION_REFUNDED', 'label' => 'Zwrot prowizji'],
            ];
        }

        $steps = [];
        foreach ($definitions as $index => $definition) {
            $stepStatus = (string) $definition['status'];
            $date = trim((string) $dates[$stepStatus]);
            $completed = $date !== '';
            if ($isRejected && $index > 4) {
                $completed = false;
            }
            if ($stepStatus === 'FINISHED' && !in_array($status, ['FINISHED', 'FINISHED_APT', 'COMMISSION_REFUNDED'], true)) {
                $completed = false;
                $date = '';
            }
            $nextDefinition = $definitions[$index + 1] ?? null;
            $nextStatus = is_array($nextDefinition) ? (string) $nextDefinition['status'] : '';
            $nextDate = $nextStatus !== '' ? trim((string) $dates[$nextStatus]) : '';
            $nextCompleted = $nextStatus !== '' && $nextDate !== '';
            $lineCompleted = $completed && $nextCompleted;
            if ($isRejected && $index + 1 > 4) {
                $lineCompleted = false;
            }

            $steps[] = [
                'label' => (string) $definition['label'],
                'date' => $date,
                'completed' => $completed,
                'next_completed' => $lineCompleted,
                'active' => $index === $activeIndex || ($isRejected && $index === 4),
            ];
        }

        return $steps;
    }

    protected function findCustomerReturnDateFromListItem(array $return, array $statuses, array $includeHints = [], array $excludeHints = []): string
    {
        $listItem = is_array($return['_list_item'] ?? null) ? $return['_list_item'] : [];
        if (!$listItem) {
            return '';
        }

        $date = $this->findCustomerReturnDate($listItem, $statuses);
        if ($date !== '') {
            return $date;
        }

        if ($includeHints) {
            $date = $this->findCustomerReturnDateByPathHints($listItem, $includeHints, $excludeHints);
            if ($date !== '') {
                return $date;
            }
        }

        foreach (['statusChangedAt', 'statusUpdatedAt', 'updatedAt'] as $fallbackField) {
            $candidate = trim((string) ($listItem[$fallbackField] ?? ''));
            if ($candidate !== '' && strtotime($candidate) !== false) {
                return $candidate;
            }
        }

        return '';
    }

    protected function isCustomerReturnOwnShipping(array $return): bool
    {
        $hasTracking = !empty($return['_tracking']);
        $hasAnyParcel = false;
        $hasCarrierOrWaybill = false;

        foreach (($return['parcels'] ?? []) as $parcel) {
            if (!is_array($parcel)) {
                continue;
            }

            $hasAnyParcel = true;
            $carrierId = trim((string) $this->firstNonEmptyString([
                $parcel['carrierId'] ?? null,
                $parcel['transportingCarrierId'] ?? null,
                $parcel['truckingCarrierId'] ?? null,
            ]));
            $waybill = trim((string) $this->firstNonEmptyString([
                $parcel['waybill'] ?? null,
                $parcel['transportingWaybill'] ?? null,
                $parcel['truckingWaybill'] ?? null,
            ]));

            if ($carrierId !== '' || $waybill !== '') {
                $hasCarrierOrWaybill = true;
                break;
            }
        }

        return $hasAnyParcel && !$hasCarrierOrWaybill && !$hasTracking;
    }

    protected function enrichCustomerReturnWithTracking(AllegroApiClient $apiClient, array $return): array
    {
        $requests = [];
        foreach (($return['parcels'] ?? []) as $parcel) {
            if (!is_array($parcel)) {
                continue;
            }

            $trackingPairs = [
                [
                    'carrier_id' => trim((string) $this->firstNonEmptyString([
                        $parcel['transportingCarrierId'] ?? null,
                        $parcel['truckingCarrierId'] ?? null,
                    ])),
                    'waybill' => trim((string) $this->firstNonEmptyString([
                        $parcel['transportingWaybill'] ?? null,
                        $parcel['truckingWaybill'] ?? null,
                    ])),
                ],
                [
                    'carrier_id' => trim((string) ($parcel['carrierId'] ?? '')),
                    'waybill' => trim((string) ($parcel['waybill'] ?? '')),
                ],
            ];

            foreach ($trackingPairs as $pair) {
                $carrierId = trim((string) $pair['carrier_id']);
                $waybill = trim((string) $pair['waybill']);
                if ($carrierId === '' || $waybill === '') {
                    continue;
                }

                $requests[$carrierId][$waybill] = true;
            }
        }

        if (!$requests) {
            return $return;
        }

        $tracking = [];
        foreach ($requests as $carrierId => $waybillMap) {
            try {
                $response = $apiClient->getCarrierTracking((string) $carrierId, array_keys($waybillMap));
                if ($response) {
                    $tracking[] = $response;
                }
            } catch (Throwable $e) {
                PrestaShopLogger::addLog('[AAR] Customer return tracking fetch failed for carrier ' . $carrierId . ': ' . $e->getMessage(), 2);
            }
        }

        if ($tracking) {
            $return['_tracking'] = $tracking;
        }

        return $return;
    }

    protected function enrichCustomerReturnWithCheckoutForm(AllegroApiClient $apiClient, array $return): array
    {
        $checkoutFormId = trim((string) ($return['orderId'] ?? ''));
        if ($checkoutFormId === '') {
            return $return;
        }

        try {
            $checkoutForm = $apiClient->getCheckoutForm($checkoutFormId);
            if (is_array($checkoutForm) && $checkoutForm) {
                $return['_checkout_form'] = $checkoutForm;

                return $return;
            }
        } catch (Throwable $e) {
            PrestaShopLogger::addLog('[AAR] Customer return checkout form fetch failed for ' . $checkoutFormId . ': ' . $e->getMessage(), 2);
        }

        $storedCheckoutForm = $this->getStoredCheckoutFormContent($checkoutFormId);
        if ($storedCheckoutForm) {
            $return['_checkout_form'] = $storedCheckoutForm;
        }

        return $return;
    }

    protected function getCustomerReturnBuyerProfile(array $return): array
    {
        $checkoutForm = is_array($return['_checkout_form'] ?? null) ? $return['_checkout_form'] : [];
        $buyer = is_array($checkoutForm['buyer'] ?? null) ? $checkoutForm['buyer'] : [];
        $deliveryAddress = is_array($checkoutForm['delivery']['address'] ?? null) ? $checkoutForm['delivery']['address'] : [];
        $invoiceAddress = is_array($checkoutForm['invoice']['address'] ?? null) ? $checkoutForm['invoice']['address'] : [];

        $name = $this->firstNonEmptyString([
            $buyer['name'] ?? null,
            $this->joinNameParts($buyer),
            $buyer['companyName'] ?? null,
            $this->joinNameParts($invoiceAddress),
            $invoiceAddress['name'] ?? null,
            $invoiceAddress['companyName'] ?? null,
            $this->joinNameParts($deliveryAddress),
            $deliveryAddress['name'] ?? null,
            $deliveryAddress['companyName'] ?? null,
            $this->getCustomerReturnBuyerName($return),
        ]);
        $login = $this->firstNonEmptyString([
            $buyer['login'] ?? null,
            $buyer['userName'] ?? null,
            $return['buyer']['login'] ?? null,
        ]);
        $email = $this->firstNonEmptyString([
            $buyer['email'] ?? null,
            $return['buyer']['email'] ?? null,
        ]);
        $phone = $this->firstNonEmptyString([
            $buyer['phoneNumber'] ?? null,
            $buyer['phone'] ?? null,
            $invoiceAddress['phoneNumber'] ?? null,
            $invoiceAddress['phone'] ?? null,
            $deliveryAddress['phoneNumber'] ?? null,
            $deliveryAddress['phone'] ?? null,
            $this->getCustomerReturnBuyerPhone($return),
        ]);

        return [
            'name' => trim((string) $name),
            'login' => trim((string) $login),
            'email' => trim((string) $email),
            'phone' => trim((string) $phone),
        ];
    }

    protected function customerReturnHasInvoice(array $return): bool
    {
        $checkoutForm = is_array($return['_checkout_form'] ?? null) ? $return['_checkout_form'] : [];
        $invoice = is_array($checkoutForm['invoice'] ?? null) ? $checkoutForm['invoice'] : [];
        if (!$invoice) {
            return false;
        }

        if (array_key_exists('required', $invoice)) {
            return (bool) $invoice['required'];
        }

        $invoiceAddress = is_array($invoice['address'] ?? null) ? $invoice['address'] : [];
        $invoiceCompany = is_array($invoice['company'] ?? null) ? $invoice['company'] : [];
        $invoiceFields = [
            $invoice['taxId'] ?? null,
            $invoice['vatNumber'] ?? null,
            $invoice['vatId'] ?? null,
            $invoice['companyName'] ?? null,
            $invoiceAddress['companyName'] ?? null,
            $invoiceAddress['taxId'] ?? null,
            $invoiceAddress['vatNumber'] ?? null,
            $invoiceAddress['vatId'] ?? null,
            $invoiceCompany['name'] ?? null,
            $invoiceCompany['taxId'] ?? null,
            $invoiceCompany['vatNumber'] ?? null,
            $invoiceAddress['street'] ?? null,
            $invoiceAddress['addressLine1'] ?? null,
            $invoiceAddress['city'] ?? null,
            $invoiceAddress['zipCode'] ?? null,
            $invoiceAddress['postCode'] ?? null,
            $this->joinNameParts($invoiceAddress),
        ];

        foreach ($invoiceFields as $field) {
            if (trim((string) $field) !== '') {
                return true;
            }
        }

        return false;
    }

    protected function findCustomerReturnTrackingDate(array $return, array $codes): string
    {
        $codes = array_map('mb_strtoupper', $codes);
        $latestMatch = '';
        foreach (($return['_tracking'] ?? []) as $trackingResponse) {
            if (!is_array($trackingResponse)) {
                continue;
            }

            foreach (($trackingResponse['waybills'] ?? []) as $waybill) {
                if (!is_array($waybill)) {
                    continue;
                }

                $statuses = $waybill['trackingDetails']['statuses'] ?? [];
                if (!is_array($statuses)) {
                    continue;
                }

                foreach ($statuses as $status) {
                    if (!is_array($status)) {
                        continue;
                    }

                    $code = mb_strtoupper(trim((string) ($status['code'] ?? '')));
                    if (!in_array($code, $codes, true)) {
                        continue;
                    }

                    $date = trim((string) ($status['occurredAt'] ?? $status['createdAt'] ?? ''));
                    if ($date === '') {
                        continue;
                    }

                    if ($latestMatch === '' || (strtotime($date) ?: 0) > (strtotime($latestMatch) ?: 0)) {
                        $latestMatch = $date;
                    }
                }
            }
        }

        return $latestMatch;
    }

    protected function findCustomerReturnTrackingDispatchDate(array $return): string
    {
        foreach (($return['_tracking'] ?? []) as $trackingResponse) {
            if (!is_array($trackingResponse)) {
                continue;
            }

            foreach (($trackingResponse['waybills'] ?? []) as $waybill) {
                if (!is_array($waybill)) {
                    continue;
                }

                $statuses = $waybill['trackingDetails']['statuses'] ?? [];
                if (!is_array($statuses)) {
                    continue;
                }

                $seenPending = false;
                foreach ($statuses as $status) {
                    if (!is_array($status)) {
                        continue;
                    }

                    $code = mb_strtoupper(trim((string) ($status['code'] ?? '')));
                    $date = trim((string) ($status['occurredAt'] ?? $status['createdAt'] ?? ''));
                    if ($code === 'PENDING') {
                        $seenPending = true;
                        continue;
                    }

                    if ($code === 'IN_TRANSIT' && $date !== '' && $seenPending) {
                        return $date;
                    }
                }
            }
        }

        return '';
    }

    protected function findCustomerReturnDate(array $return, array $statuses): string
    {
        $statuses = array_map('mb_strtoupper', $statuses);
        $dates = $this->collectCustomerReturnStatusDates($return, $statuses);
        if (!$dates) {
            return '';
        }

        usort($dates, function (string $a, string $b): int {
            return (strtotime($b) ?: 0) <=> (strtotime($a) ?: 0);
        });

        return $dates[0];
    }

    protected function collectCustomerReturnStatusDates($value, array $statuses, string $path = '', int $depth = 0): array
    {
        if ($depth > 10) {
            return [];
        }

        if (!is_array($value)) {
            return [];
        }

        $containerHints = ['timeline', 'history', 'events', 'statushistory', 'statuses', 'statuseslist'];
        $pathLower = mb_strtolower($path);
        $isStatusContainer = $pathLower === '';
        foreach ($containerHints as $hint) {
            if ($hint !== '' && strpos($pathLower, $hint) !== false) {
                $isStatusContainer = true;
                break;
            }
        }

        $statusFields = ['status', 'statusCode', 'code', 'type', 'name', 'label', 'title', 'action', 'state', 'step'];
        $dateFields = ['createdAt', 'date', 'occurredAt', 'updatedAt', 'finishedAt', 'deliveredAt', 'sentAt', 'dispatchedAt'];
        $dates = [];

        if ($isStatusContainer) {
            $currentStatus = '';
            foreach ($statusFields as $field) {
                if (!array_key_exists($field, $value)) {
                    continue;
                }

                $candidate = mb_strtoupper(trim($this->firstNonEmptyString([$value[$field] ?? null])));
                if ($candidate !== '') {
                    $currentStatus = $candidate;
                    break;
                }
            }

            if ($currentStatus !== '' && in_array($currentStatus, $statuses, true)) {
                foreach ($dateFields as $field) {
                    if (!array_key_exists($field, $value)) {
                        continue;
                    }

                    $candidate = trim((string) ($value[$field] ?? ''));
                    if ($candidate !== '' && strtotime($candidate) !== false) {
                        $dates[] = $candidate;
                    }
                }
            }
        }

        foreach ($value as $key => $child) {
            $childPath = $path === '' ? (string) $key : $path . '.' . (string) $key;
            if (is_array($child)) {
                $dates = array_merge($dates, $this->collectCustomerReturnStatusDates($child, $statuses, $childPath, $depth + 1));
            }
        }

        return $dates;
    }

    protected function findCustomerReturnDateByPathHints(array $payload, array $includeHints, array $excludeHints = []): string
    {
        $includeHints = array_map('mb_strtolower', $includeHints);
        $excludeHints = array_map('mb_strtolower', $excludeHints);
        $dates = $this->collectCustomerReturnDatesByPathHints($payload, $includeHints, $excludeHints);
        if (!$dates) {
            return '';
        }

        usort($dates, function (string $a, string $b): int {
            return (strtotime($b) ?: 0) <=> (strtotime($a) ?: 0);
        });

        return $dates[0];
    }

    protected function collectCustomerReturnDatesByPathHints($value, array $includeHints, array $excludeHints, string $path = '', int $depth = 0): array
    {
        if ($depth > 8) {
            return [];
        }

        $pathLower = mb_strtolower($path);
        foreach ($excludeHints as $hint) {
            if ($hint !== '' && strpos($pathLower, $hint) !== false) {
                return [];
            }
        }

        $hasIncludeHint = false;
        foreach ($includeHints as $hint) {
            if ($hint !== '' && strpos($pathLower, $hint) !== false) {
                $hasIncludeHint = true;
                break;
            }
        }

        if (is_scalar($value)) {
            $candidate = trim((string) $value);
            if ($hasIncludeHint && $candidate !== '' && strtotime($candidate) !== false && preg_match('/\\d{4}-\\d{2}-\\d{2}/', $candidate)) {
                return [$candidate];
            }

            return [];
        }

        if (!is_array($value)) {
            return [];
        }

        $dates = [];
        foreach ($value as $key => $child) {
            $childPath = $path === '' ? (string) $key : $path . '.' . (string) $key;
            $childPathLower = mb_strtolower($childPath);
            $looksLikeDateKey = preg_match('/(date|at|time)$/i', (string) $key) === 1;
            $childHasIncludeHint = $hasIncludeHint;
            foreach ($includeHints as $hint) {
                if ($hint !== '' && strpos($childPathLower, $hint) !== false) {
                    $childHasIncludeHint = true;
                    break;
                }
            }

            if ($childHasIncludeHint && $looksLikeDateKey && is_scalar($child)) {
                $candidate = trim((string) $child);
                if ($candidate !== '' && strtotime($candidate) !== false) {
                    $dates[] = $candidate;
                    continue;
                }
            }

            $dates = array_merge($dates, $this->collectCustomerReturnDatesByPathHints($child, $includeHints, $excludeHints, $childPath, $depth + 1));
        }

        return $dates;
    }

    protected function findFirstParcelDate(array $return, array $keys = ['createdAt', 'sentAt', 'dispatchedAt']): string
    {
        $parcels = $return['parcels'] ?? [];
        if (!is_array($parcels)) {
            return '';
        }

        foreach ($parcels as $parcel) {
            if (!is_array($parcel)) {
                continue;
            }

            foreach ($keys as $key) {
                $date = trim((string) ($parcel[$key] ?? ''));
                if ($date !== '') {
                    return $date;
                }
            }
        }

        return '';
    }

    protected function renderCustomerReturnItems(array $return): string
    {
        $items = $return['items'] ?? [];
        if (!is_array($items) || !$items) {
            return '';
        }

        $html = $this->htmlFragment('c962beffeeaafb856db8');
        foreach ($items as $item) {
            if (!is_array($item)) {
                continue;
            }

            $name = trim((string) ($item['name'] ?? 'Produkt'));
            $offerId = trim((string) ($item['offerId'] ?? ''));
            $quantity = trim((string) ($item['quantity'] ?? ''));
            $price = $this->formatMoneyValue($item['price'] ?? []);
            $reasonType = $this->formatCustomerReturnReasonType((string) ($item['reason']['type'] ?? ''));
            $comment = $this->resolveCustomerReturnReasonComment($item);
            $url = trim((string) ($item['url'] ?? ''));
            $thumbnailUrl = $this->resolveCustomerReturnItemThumbnailUrl($item, $return);

            if ($thumbnailUrl !== '') {
                $html .= $this->htmlFragment('ef24562fcccae7d70df0');
                $html .= $this->htmlFragment('758b1d91242bee152a59') . Tools::safeOutput($thumbnailUrl) . $this->htmlFragment('979f5c37282c6b5c420c');
            } else {
                $html .= $this->htmlFragment('a8a5b808eedea3034be1');
            }
            $html .= $this->htmlFragment('1271e2feed0f73eed55c');
            if ($url !== '') {
                $html .= $this->htmlFragment('2dbc18d3f996ed3f37d8') . Tools::safeOutput($url) . '" target="_blank" rel="noopener noreferrer">' . Tools::safeOutput($name) . $this->htmlFragment('ab39ff5eec6f459ac1f5');
            } else {
                $html .= $this->htmlFragment('a90204ddb3c9cc647d69') . Tools::safeOutput($name) . $this->htmlFragment('b2f69f8100b2a95949ee');
            }
            if ($offerId !== '') {
                $html .= $this->htmlFragment('e1dbd793b19311df29d5') . Tools::safeOutput($offerId) . $this->htmlFragment('aac32651b10f567c461b');
            }
            $reason = trim($reasonType . ($comment !== '' ? ': ' . $comment : ''));
            if ($reason !== '') {
                $html .= $this->htmlFragment('eab7fa7aefacc1837f33') . Tools::safeOutput($reason) . $this->htmlFragment('aac32651b10f567c461b');
            }
            $html .= $this->htmlFragment('aac32651b10f567c461b');
            $html .= $this->htmlFragment('2166c24ecf5767767fe8');
            if ($quantity !== '') {
                $html .= $this->htmlFragment('9e4527fb137f0b371f78') . Tools::safeOutput($quantity . ' ' . $this->pluralizePolish((int) $quantity, 'sztuka', 'sztuki', 'sztuk')) . $this->htmlFragment('aac32651b10f567c461b');
            }
            if ($price !== '') {
                $html .= $this->htmlFragment('a90204ddb3c9cc647d69') . Tools::safeOutput($price) . $this->htmlFragment('b2f69f8100b2a95949ee');
            }
            $html .= $this->htmlFragment('aac32651b10f567c461b');
            $html .= $this->htmlFragment('aac32651b10f567c461b');
        }
        $html .= $this->htmlFragment('aac32651b10f567c461b');

        return $html;
    }

    protected function renderCustomerReturnParcels(array $return): string
    {
        $parcels = $return['parcels'] ?? [];
        if (!is_array($parcels) || !$parcels) {
            return '';
        }

        $html = $this->htmlFragment('a0271bac8a2cdb1ac3ee');
        foreach ($parcels as $parcel) {
            if (!is_array($parcel)) {
                continue;
            }

            $waybill = $this->firstNonEmptyString([$parcel['transportingWaybill'] ?? null, $parcel['truckingWaybill'] ?? null, $parcel['waybill'] ?? null]);
            $carrier = $this->firstNonEmptyString([$parcel['transportingCarrierId'] ?? null, $parcel['truckingCarrierId'] ?? null, $parcel['carrierId'] ?? null]);
            $createdAt = $this->formatAllegroDate((string) ($parcel['createdAt'] ?? ''));
            $phone = $this->maskPhone((string) ($parcel['sender']['phoneNumber'] ?? ''));
            $parts = array_filter([
                $waybill !== '' ? 'List: ' . $waybill : '',
                $carrier !== '' ? 'Przewoźnik: ' . $carrier : '',
                $createdAt !== '' ? 'Utworzono: ' . $createdAt : '',
                $phone !== '' ? 'Telefon nadawcy: ' . $phone : '',
            ]);

            if ($parts) {
                $html .= $this->htmlFragment('1bd10b905cc8a35cd6a9') . Tools::safeOutput(implode(' • ', $parts)) . $this->htmlFragment('aac32651b10f567c461b');
            }
        }
        $html .= $this->htmlFragment('aac32651b10f567c461b');

        return $html;
    }

    protected function getCustomerReturnBuyerName(array $return): string
    {
        $buyer = is_array($return['buyer'] ?? null) ? $return['buyer'] : [];
        $name = $this->firstNonEmptyString([
            $buyer['name'] ?? null,
            $this->joinNameParts($buyer),
            $buyer['companyName'] ?? null,
        ]);

        if ($name !== '') {
            return $name;
        }

        foreach (['deliveryAddress', 'address', 'invoiceAddress'] as $key) {
            $address = is_array($buyer[$key] ?? null) ? $buyer[$key] : [];
            $name = $this->firstNonEmptyString([
                $address['name'] ?? null,
                $address['companyName'] ?? null,
                $this->joinNameParts($address),
            ]);
            if ($name !== '') {
                return $name;
            }
        }

        foreach (($return['parcels'] ?? []) as $parcel) {
            if (!is_array($parcel)) {
                continue;
            }
            $sender = is_array($parcel['sender'] ?? null) ? $parcel['sender'] : [];
            $name = $this->firstNonEmptyString([
                $sender['name'] ?? null,
                $sender['companyName'] ?? null,
                $this->joinNameParts($sender),
            ]);
            if ($name !== '') {
                return $name;
            }
        }

        $name = $this->findCustomerReturnPersonNameRecursively($return);
        if ($name !== '') {
            return $name;
        }

        return '';
    }

    protected function findCustomerReturnPersonNameRecursively(array $payload, int $depth = 0): string
    {
        if ($depth > 6) {
            return '';
        }

        foreach ($payload as $key => $value) {
            $keyLower = mb_strtolower((string) $key);
            if (in_array($keyLower, ['login', 'email', 'mail', 'username', 'userid', 'id'], true)) {
                continue;
            }

            if (is_array($value)) {
                $name = $this->firstNonEmptyString([
                    $value['name'] ?? null,
                    $value['fullName'] ?? null,
                    $value['fullname'] ?? null,
                    $this->joinNameParts($value),
                ]);
                if ($this->looksLikePersonName($name)) {
                    return $name;
                }

                if (preg_match('/(buyer|customer|sender|person|address|contact)/i', (string) $key)) {
                    $name = $this->findCustomerReturnPersonNameRecursively($value, $depth + 1);
                    if ($name !== '') {
                        return $name;
                    }
                }
            }
        }

        return '';
    }

    protected function looksLikePersonName(string $name): bool
    {
        $name = trim($name);
        if ($name === '' || strpos($name, '@') !== false) {
            return false;
        }
        if (preg_match('/^[a-z0-9_.-]+$/i', $name) === 1 && strpos($name, ' ') === false) {
            return false;
        }

        return preg_match('/[\\p{L}]{2,}/u', $name) === 1;
    }

    protected function getCustomerReturnBuyerPhone(array $return): string
    {
        $buyer = is_array($return['buyer'] ?? null) ? $return['buyer'] : [];
        $phone = $this->firstNonEmptyString([
            $buyer['phoneNumber'] ?? null,
            $buyer['phone'] ?? null,
        ]);

        if ($phone !== '') {
            return $phone;
        }

        foreach (($return['parcels'] ?? []) as $parcel) {
            if (!is_array($parcel)) {
                continue;
            }
            $phone = $this->firstNonEmptyString([
                $parcel['sender']['phoneNumber'] ?? null,
                $parcel['sender']['phone'] ?? null,
            ]);
            if ($phone !== '') {
                return $phone;
            }
        }

        return '';
    }

    protected function getCustomerReturnDeliveryMethod(array $return): string
    {
        if ($this->isCustomerReturnOwnShipping($return)) {
            return 'Wysyłka własna';
        }

        $preferredParcel = $this->getPreferredCustomerReturnParcel($return);
        if ($preferredParcel) {
            $method = $this->firstNonEmptyString([
                $preferredParcel['carrierName'] ?? null,
                $preferredParcel['transportingCarrierId'] ?? null,
                $preferredParcel['truckingCarrierId'] ?? null,
                $preferredParcel['carrierId'] ?? null,
            ]);
            if ($method !== '') {
                return $method;
            }
        }

        foreach (($return['parcels'] ?? []) as $parcel) {
            if (!is_array($parcel)) {
                continue;
            }

            $method = $this->firstNonEmptyString([
                $parcel['carrierName'] ?? null,
                $parcel['transportingCarrierId'] ?? null,
                $parcel['truckingCarrierId'] ?? null,
                $parcel['carrierId'] ?? null,
            ]);
            if ($method !== '') {
                return $method;
            }
        }

        return '';
    }

    protected function getCustomerReturnWaybill(array $return): string
    {
        $preferredParcel = $this->getPreferredCustomerReturnParcel($return);
        if ($preferredParcel) {
            $waybill = $this->firstNonEmptyString([
                $preferredParcel['waybill'] ?? null,
                $preferredParcel['transportingWaybill'] ?? null,
                $preferredParcel['truckingWaybill'] ?? null,
            ]);
            if ($waybill !== '') {
                return $waybill;
            }
        }

        foreach (($return['parcels'] ?? []) as $parcel) {
            if (!is_array($parcel)) {
                continue;
            }

            $waybill = $this->firstNonEmptyString([
                $parcel['transportingWaybill'] ?? null,
                $parcel['truckingWaybill'] ?? null,
                $parcel['waybill'] ?? null,
            ]);
            if ($waybill !== '') {
                return $waybill;
            }
        }

        return '';
    }

    protected function getPreferredCustomerReturnParcel(array $return): array
    {
        foreach (($return['parcels'] ?? []) as $parcel) {
            if (!is_array($parcel)) {
                continue;
            }

            $carrierId = mb_strtoupper(trim((string) ($parcel['carrierId'] ?? '')));
            $waybill = trim((string) ($parcel['waybill'] ?? ''));
            if ($this->isCustomerReturnApiTrackingCarrier($carrierId) && $waybill !== '') {
                return $parcel;
            }
        }

        foreach (($return['parcels'] ?? []) as $parcel) {
            if (is_array($parcel)) {
                return $parcel;
            }
        }

        return [];
    }

    protected function getCustomerReturnTrackingUrl(array $return): string
    {
        $carrierId = '';
        $waybill = '';
        $preferredParcel = $this->getPreferredCustomerReturnParcel($return);
        if ($preferredParcel) {
            $preferredCarrierId = mb_strtoupper(trim((string) ($preferredParcel['carrierId'] ?? '')));
            $carrierId = $this->isCustomerReturnApiTrackingCarrier($preferredCarrierId)
                ? trim((string) ($preferredParcel['carrierId'] ?? ''))
                : $this->firstNonEmptyString([
                    $preferredParcel['transportingCarrierId'] ?? null,
                    $preferredParcel['truckingCarrierId'] ?? null,
                    $preferredParcel['carrierId'] ?? null,
                ]);
            $waybill = $this->isCustomerReturnApiTrackingCarrier($preferredCarrierId)
                ? trim((string) ($preferredParcel['waybill'] ?? ''))
                : $this->firstNonEmptyString([
                    $preferredParcel['transportingWaybill'] ?? null,
                    $preferredParcel['truckingWaybill'] ?? null,
                    $preferredParcel['waybill'] ?? null,
                ]);
        }

        if ($waybill === '') {
            return '';
        }

        return $this->buildCarrierTrackingUrl($carrierId, $waybill);
    }

    protected function findCustomerReturnTrackingEntry(array $return, string $waybill): array
    {
        $waybill = trim($waybill);
        if ($waybill === '') {
            return [];
        }

        foreach (($return['_tracking'] ?? []) as $trackingResponse) {
            if (!is_array($trackingResponse)) {
                continue;
            }

            foreach (($trackingResponse['waybills'] ?? []) as $trackingWaybill) {
                if (!is_array($trackingWaybill)) {
                    continue;
                }

                if (trim((string) ($trackingWaybill['waybill'] ?? '')) === $waybill) {
                    return $trackingWaybill;
                }
            }
        }

        return [];
    }

    protected function shouldUseCustomerReturnTrackingModal(array $return): bool
    {
        foreach (($return['parcels'] ?? []) as $parcel) {
            if (!is_array($parcel)) {
                continue;
            }

            $carrierId = mb_strtoupper(trim((string) ($parcel['carrierId'] ?? '')));
            $waybill = trim((string) ($parcel['waybill'] ?? ''));
            if ($this->isCustomerReturnApiTrackingCarrier($carrierId) && $waybill !== '') {
                return true;
            }
        }

        return false;
    }

    protected function isCustomerReturnApiTrackingCarrier(string $carrierId): bool
    {
        $carrierId = mb_strtoupper(trim($carrierId));

        return in_array($carrierId, ['ALLEGRO', 'INPOST'], true);
    }

    protected function translateCustomerReturnTrackingDescription(string $code, string $description): string
    {
        $code = mb_strtoupper(trim($code));
        $description = trim($description);
        $normalized = mb_strtolower(preg_replace('/\s+/', ' ', $description));

        $byDescription = [
            'parcel has been prepared by the sender' => 'Przesyłka została przygotowana przez nadawcę',
            'parcel has been dispatched' => 'Przesyłka została nadana',
            'parcel has been picked up from parcel locker by courier' => 'Przesyłka została odebrana z automatu przez kuriera',
            'courier has transferred the parcel to the warehouse' => 'Kurier przekazał przesyłkę do magazynu',
            'parcel has been picked up by the courier' => 'Przesyłka została odebrana przez kuriera',
            'parcel has been accepted at the branch' => 'Przesyłka została przyjęta w oddziale',
            'parcel has been released for delivery' => 'Przesyłka została wydana do doręczenia',
            'parcel has been delivered' => 'Przesyłka została doręczona',
            'prepared by sender' => 'Przesyłka została przygotowana przez nadawcę',
            'dispatched' => 'Przesyłka została nadana',
            'picked up from sender' => 'Przesyłka została odebrana od nadawcy',
            'accepted at inpost delivery center' => 'Przesyłka została przyjęta w oddziale InPost',
            'in transit' => 'Przesyłka jest w drodze',
            'in delivery' => 'Przesyłka została wydana do doręczenia',
            'delivered' => 'Przesyłka została doręczona',
        ];

        if ($normalized !== '' && isset($byDescription[$normalized])) {
            return $byDescription[$normalized];
        }

        $byCode = [
            'PENDING' => 'Przesyłka została przygotowana',
            'IN_TRANSIT' => 'Przesyłka jest w drodze',
            'RELEASED_FOR_DELIVERY' => 'Przesyłka została wydana do doręczenia',
            'DELIVERED' => 'Przesyłka została doręczona',
            'AVAILABLE_FOR_PICKUP' => 'Przesyłka czeka na odbiór',
            'RETURNED' => 'Przesyłka została zwrócona',
        ];

        if ($code !== '' && isset($byCode[$code])) {
            return $byCode[$code];
        }

        return $description;
    }

    protected function formatCustomerReturnTrackingCode(string $code): string
    {
        $code = mb_strtoupper(trim($code));
        if ($code === '') {
            return '';
        }

        $labels = [
            'PENDING' => 'Oczekuje',
            'IN_TRANSIT' => 'W drodze',
            'RELEASED_FOR_DELIVERY' => 'Wydana do doreczenia',
            'DELIVERED' => 'Doreczona',
            'AVAILABLE_FOR_PICKUP' => 'Gotowa do odbioru',
            'RETURNED' => 'Zwrocona',
        ];

        return $labels[$code] ?? str_replace('_', ' ', $code);
    }

    protected function buildCarrierTrackingUrl(string $carrierId, string $waybill): string
    {
        $carrier = mb_strtolower(trim($carrierId));
        $waybill = trim($waybill);
        if ($waybill === '') {
            return '';
        }

        if (strpos($carrier, 'inpost') !== false) {
            return 'https://inpost.pl/sledzenie-przesylek?number=' . rawurlencode($waybill);
        }
        if (strpos($carrier, 'dpd') !== false) {
            return 'https://tracktrace.dpd.com.pl/findParcel?p1=' . rawurlencode($waybill);
        }
        if (strpos($carrier, 'orlen') !== false || strpos($carrier, 'ruch') !== false) {
            return 'https://www.orlenpaczka.pl/sledz-paczke/' . rawurlencode($waybill);
        }
        if (strpos($carrier, 'dhl') !== false) {
            return 'https://www.dhl.com/pl-pl/home/tracking.html?tracking-id=' . rawurlencode($waybill);
        }
        if ($carrier === 'allegro') {
            return 'https://allegro.pl/kampania/one/kurier/sledzenie-paczki?numer=' . rawurlencode($waybill);
        }
        if (strpos($carrier, 'ups') !== false) {
            return 'https://www.ups.com/track?loc=pl_PL&tracknum=' . rawurlencode($waybill);
        }
        if (strpos($carrier, 'fedex') !== false) {
            return 'https://www.fedex.com/fedextrack/?trknbr=' . rawurlencode($waybill);
        }
        if (strpos($carrier, 'gls') !== false) {
            return 'https://gls-group.com/PL/pl/sledzenie-paczek/?match=' . rawurlencode($waybill);
        }
        if (strpos($carrier, 'poczta') !== false || strpos($carrier, 'polish_post') !== false) {
            return 'https://emonitoring.poczta-polska.pl/?numer=' . rawurlencode($waybill);
        }

        return 'https://salescenter.allegro.com/returns/?' . http_build_query([
            'query' => $waybill,
        ]);
    }

    protected function getCustomerReturnAddressLines(array $return): array
    {
        $address = [];
        foreach ([
            $return['returnAddress'] ?? null,
            $return['address'] ?? null,
            $return['seller']['returnAddress'] ?? null,
        ] as $candidate) {
            if (is_array($candidate) && $candidate) {
                $address = $candidate;
                break;
            }
        }

        if (!$address) {
            return [];
        }

        $name = $this->firstNonEmptyString([
            $address['name'] ?? null,
            $address['companyName'] ?? null,
            $this->joinNameParts($address),
        ]);
        $street = $this->firstNonEmptyString([$address['street'] ?? null, $address['addressLine1'] ?? null]);
        $postalCity = trim($this->firstNonEmptyString([$address['zipCode'] ?? null, $address['postCode'] ?? null]) . ' ' . $this->firstNonEmptyString([$address['city'] ?? null]));
        $country = $this->firstNonEmptyString([$address['countryCode'] ?? null, $address['country'] ?? null]);

        return array_values(array_filter([$name, $street, $postalCity, $country]));
    }

    protected function getCustomerReturnRefundLines(array $return): array
    {
        $bankAccount = $return['refund']['bankAccount'] ?? [];
        if (!is_array($bankAccount) || !$bankAccount) {
            return [];
        }

        $address = is_array($bankAccount['address'] ?? null) ? $bankAccount['address'] : [];
        $lines = [
            trim((string) ($bankAccount['iban'] ?? $bankAccount['accountNumber'] ?? '')),
            trim((string) ($bankAccount['owner'] ?? '')),
            trim((string) ($address['street'] ?? '')),
            trim($this->firstNonEmptyString([$address['postCode'] ?? null, $address['zipCode'] ?? null]) . ' ' . $this->firstNonEmptyString([$address['city'] ?? null])),
        ];

        return array_values(array_filter($lines));
    }

    protected function calculateCustomerReturnTotal(array $return): string
    {
        $total = 0.0;
        $currency = '';
        foreach (($return['items'] ?? []) as $item) {
            if (!is_array($item)) {
                continue;
            }

            $price = is_array($item['price'] ?? null) ? $item['price'] : [];
            $amount = trim((string) ($price['amount'] ?? ''));
            if ($amount === '' || !is_numeric(str_replace(',', '.', $amount))) {
                continue;
            }

            $quantity = max(1, (int) ($item['quantity'] ?? 1));
            $total += (float) str_replace(',', '.', $amount) * $quantity;
            $currency = trim((string) ($price['currency'] ?? $currency));
        }

        if ($total <= 0) {
            return '';
        }

        return number_format($total, 2, ',', ' ') . ($currency !== '' ? ' ' . $currency : '');
    }

    protected function calculateCustomerReturnItemAmount(array $item): float
    {
        $price = is_array($item['price'] ?? null) ? $item['price'] : [];
        $amount = trim((string) ($price['amount'] ?? ''));
        if ($amount === '' || !is_numeric(str_replace(',', '.', $amount))) {
            return 0.0;
        }

        return (float) str_replace(',', '.', $amount) * max(1, (int) ($item['quantity'] ?? 1));
    }

    protected function getCustomerReturnCurrency(array $return): string
    {
        foreach (($return['items'] ?? []) as $item) {
            if (!is_array($item)) {
                continue;
            }

            $currency = trim((string) ($item['price']['currency'] ?? ''));
            if ($currency !== '') {
                return $currency;
            }
        }

        return 'PLN';
    }

    protected function normalizeRefundAmount(string $amount): string
    {
        $amount = trim(str_replace([' ', "\xc2\xa0"], '', $amount));
        if ($amount === '') {
            return '';
        }

        $amount = str_replace(',', '.', $amount);
        if (!is_numeric($amount) || (float) $amount <= 0) {
            throw new RuntimeException('Nieprawidłowa kwota zwrotu: ' . $amount . '.');
        }

        return number_format((float) $amount, 2, '.', '');
    }

    protected function indexCheckoutLineItemsByOfferId(array $checkoutForm): array
    {
        $indexed = [];
        foreach (($checkoutForm['lineItems'] ?? []) as $lineItem) {
            if (!is_array($lineItem)) {
                continue;
            }

            $offerId = $this->extractLineItemOfferId($lineItem);
            if ($offerId !== '' && !isset($indexed[$offerId])) {
                $indexed[$offerId] = $lineItem;
            }
        }

        return $indexed;
    }

    protected function generateUuidV4(): string
    {
        $bytes = random_bytes(16);
        $bytes[6] = chr((ord($bytes[6]) & 0x0F) | 0x40);
        $bytes[8] = chr((ord($bytes[8]) & 0x3F) | 0x80);

        return vsprintf('%s%s-%s-%s-%s-%s%s%s', str_split(bin2hex($bytes), 4));
    }

    protected function getCustomerReturnRefundReasonOptions(): array
    {
        return [
            'REFUND' => 'zwrot produktu',
            'COMPLAINT' => 'reklamacja',
            'PRODUCT_NOT_AVAILABLE' => 'produkt niedostępny',
            'PAID_VALUE_TOO_LOW' => 'za niska wpłata',
            'OVERPAID' => 'zwrot nadpłaty',
            'CANCELLED_BY_BUYER' => 'anulowanie przez kupującego',
            'NOT_COLLECTED' => 'nieodebrane zamówienie',
        ];
    }

    protected function normalizeCustomerReturnRefundReason(string $reason): string
    {
        $reason = mb_strtoupper(trim($reason));
        $aliases = [
            'MISSING_ITEM' => 'PRODUCT_NOT_AVAILABLE',
            'OVERPAYMENT' => 'OVERPAID',
            'CANCELED_BY_BUYER' => 'CANCELLED_BY_BUYER',
            'UNCLAIMED' => 'NOT_COLLECTED',
            'LACK_OF_FULL_PAYMENT' => 'PAID_VALUE_TOO_LOW',
        ];

        return $aliases[$reason] ?? $reason;
    }

    protected function buildCustomerReturnRefundModalId(string $returnId): string
    {
        return 'aar-return-refund-modal-' . preg_replace('/[^a-zA-Z0-9_-]/', '-', $returnId);
    }

    protected function buildCustomerReturnRejectionModalId(string $returnId): string
    {
        return 'aar-return-rejection-modal-' . preg_replace('/[^a-zA-Z0-9_-]/', '-', $returnId);
    }

    protected function renderCustomerReturnRefundModal(string $returnId, array $return): string
    {
        if ($returnId === '' || !$this->canRefundCustomerReturn($return)) {
            return '';
        }

        $modalId = $this->buildCustomerReturnRefundModalId($returnId);
        $html = $this->htmlFragment('1727b1ec81bbc251c160') . Tools::safeOutput($modalId) . '" tabindex="-1" role="dialog" aria-labelledby="' . Tools::safeOutput($modalId . '-title') . '">';
        $html .= $this->htmlFragment('a04acc39bbf01025ebbd');
        $html .= $this->htmlFragment('d91ec07885dee8fb2180');
        $html .= $this->htmlFragment('d53c52f4f898f8ed293c');
        $html .= $this->htmlFragment('1ffc2c2a9b34fd8df40e');
        $html .= $this->htmlFragment('eec8c139fec0bb69cdb2') . Tools::safeOutput($modalId . '-title') . $this->htmlFragment('77a30cf9615e5cba5ef2');
        $html .= $this->htmlFragment('aac32651b10f567c461b');
        $html .= $this->htmlFragment('6416b918eef22c892aee');
        $html .= $this->renderCustomerReturnRefundForm($returnId, $return, false);
        $html .= $this->htmlFragment('aac32651b10f567c461b');
        $html .= $this->htmlFragment('aac32651b10f567c461b');
        $html .= $this->htmlFragment('aac32651b10f567c461b');
        $html .= $this->htmlFragment('aac32651b10f567c461b');

        return $html;
    }

    protected function renderCustomerReturnRejectionModal(string $returnId, array $return): string
    {
        if ($returnId === '' || !$this->canRejectCustomerReturn($return)) {
            return '';
        }

        $modalId = $this->buildCustomerReturnRejectionModalId($returnId);
        $html = $this->htmlFragment('e6d2a075d85390218b94') . Tools::safeOutput($modalId) . '" tabindex="-1" role="dialog" aria-labelledby="' . Tools::safeOutput($modalId . '-title') . '">';
        $html .= $this->htmlFragment('a04acc39bbf01025ebbd');
        $html .= $this->htmlFragment('d91ec07885dee8fb2180');
        $html .= $this->htmlFragment('d53c52f4f898f8ed293c');
        $html .= $this->htmlFragment('1ffc2c2a9b34fd8df40e');
        $html .= $this->htmlFragment('eec8c139fec0bb69cdb2') . Tools::safeOutput($modalId . '-title') . $this->htmlFragment('da7f23bd6913704ba886');
        $html .= $this->htmlFragment('aac32651b10f567c461b');
        $html .= $this->htmlFragment('6416b918eef22c892aee');
        $html .= $this->renderCustomerReturnRejectionForm($returnId, $return, false);
        $html .= $this->htmlFragment('aac32651b10f567c461b');
        $html .= $this->htmlFragment('aac32651b10f567c461b');
        $html .= $this->htmlFragment('aac32651b10f567c461b');
        $html .= $this->htmlFragment('aac32651b10f567c461b');

        return $html;
    }

    protected function renderCustomerReturnRejectionForm(string $returnId, array $return, bool $collapsed = false): string
    {
        if ($returnId === '' || !$this->canRejectCustomerReturn($return)) {
            return '';
        }

        $definitions = $this->getCustomerReturnRejectionReasonDefinitions();
        $html = $this->htmlFragment('0c3c1d22f75da4b050ba') . ($collapsed ? ' is-collapsed' : '') . '" onsubmit="return confirm(\'Wysłać odmowę zwrotu do Allegro?\');">';
        $html .= $this->htmlFragment('0eb620b3a2b5c23fc019') . Tools::safeOutput($returnId) . '">';
        $html .= $this->htmlFragment('3d713f74d86b24469744');
        $html .= $this->htmlFragment('d0dd3ad23d7b77b69e9c');
        $html .= $this->htmlFragment('2db067f894b0cea2f182');
        $html .= $this->htmlFragment('aac32651b10f567c461b');
        $html .= $this->htmlFragment('e1f6ea5762471adce1ca');
        foreach ($definitions as $code => $definition) {
            $label = (string) ($definition['label'] ?? '');
            $description = (string) ($definition['description'] ?? '');
            $html .= $this->htmlFragment('4827157d7858244ddc41');
            $html .= $this->htmlFragment('bd98b899e5e6edfb58fa') . Tools::safeOutput($code) . '"' . ($code === 'OTHER_REASON' ? ' checked' : '') . ' required>';
            $html .= $this->htmlFragment('e8dd0d7eb65fa62ebbd4');
            $html .= $this->htmlFragment('d92ea4abedf76a0363be') . Tools::safeOutput($label) . $this->htmlFragment('411fdb22d8d9298e5d32');
            if ($description !== '') {
                $html .= $this->htmlFragment('ea988115564831b86382') . Tools::safeOutput($description) . $this->htmlFragment('411fdb22d8d9298e5d32');
            }
            $html .= $this->htmlFragment('411fdb22d8d9298e5d32');
            $html .= $this->htmlFragment('3fc95dda2fe9090067ea');
        }
        $html .= $this->htmlFragment('aac32651b10f567c461b');
        $html .= $this->htmlFragment('43397482431861dd915c');
        $html .= $this->htmlFragment('4cf72b52bd0218c5dc9e') . Tools::safeOutput($returnId) . $this->htmlFragment('3d27ac68645bcb64a36d');
        $html .= $this->htmlFragment('f30c42939a8fc447f345') . Tools::safeOutput($returnId) . $this->htmlFragment('82fbb0601bbca2a5e13b');
        $html .= $this->htmlFragment('aac32651b10f567c461b');
        $html .= $this->htmlFragment('c78684adf88f6682b695');
        $html .= $this->htmlFragment('9ce180345c7993cc96eb');
        $html .= $this->htmlFragment('aac32651b10f567c461b');
        $html .= $this->htmlFragment('e0c7bb7b72eeecfc0734');

        return $html;
    }

    protected function renderCustomerReturnRefundForm(string $returnId, array $return, bool $collapsed = false): string
    {
        if ($returnId === '' || !$this->canRefundCustomerReturn($return)) {
            return '';
        }

        $items = is_array($return['items'] ?? null) ? $return['items'] : [];
        if (!$items) {
            return '';
        }

        $html = $this->htmlFragment('44b906540844055f31dc') . ($collapsed ? ' is-collapsed' : '') . '" onsubmit="return confirm(\'Zlecić zwrot pieniędzy w Allegro?\');">';
        $html .= $this->htmlFragment('0eb620b3a2b5c23fc019') . Tools::safeOutput($returnId) . '">';
        $html .= $this->htmlFragment('b8a1c39db64984d1b80b');
        $html .= $this->htmlFragment('16dbe614521ea98bdabf');
        $html .= $this->htmlFragment('ae07b10cc0519aad92ce');
        $html .= $this->htmlFragment('12ba2e59af45a5404386');
        $html .= $this->htmlFragment('748510cd46401eda7ccf');
        foreach ($this->getCustomerReturnRefundReasonOptions() as $code => $label) {
            $checked = $code === 'REFUND' ? ' checked' : '';
            $html .= $this->htmlFragment('8d8de19869d6517655d1');
            $html .= $this->htmlFragment('2ce97cae2b6ea30ed7b5') . Tools::safeOutput($code) . '"' . $checked . ' required>';
            $html .= $this->htmlFragment('f0a8ebd68c47ad5549c3') . Tools::safeOutput($label) . $this->htmlFragment('411fdb22d8d9298e5d32');
            $html .= $this->htmlFragment('3fc95dda2fe9090067ea');
        }
        $html .= $this->htmlFragment('aac32651b10f567c461b');
        $html .= $this->htmlFragment('aac32651b10f567c461b');
        $index = 0;
        foreach ($items as $item) {
            if (!is_array($item)) {
                continue;
            }

            $offerId = trim((string) ($item['offerId'] ?? ''));
            $amount = $this->calculateCustomerReturnItemAmount($item);
            if ($offerId === '' || $amount <= 0) {
                continue;
            }

            $currency = trim((string) ($item['price']['currency'] ?? 'PLN'));
            $name = trim((string) ($item['name'] ?? 'Produkt'));
            $quantity = max(1, (int) ($item['quantity'] ?? 1));
            $html .= $this->htmlFragment('dd95f5b6e1bc145ac6cf');
            $html .= $this->htmlFragment('5e78511c56961b786e5f') . (int) $index . '][offer_id]" value="' . Tools::safeOutput($offerId) . '">';
            $html .= $this->htmlFragment('5e78511c56961b786e5f') . (int) $index . '][currency]" value="' . Tools::safeOutput($currency !== '' ? $currency : 'PLN') . '">';
            $html .= $this->htmlFragment('b18eea6fa4787fb49764') . Tools::safeOutput($name) . $this->htmlFragment('f0a8ebd68c47ad5549c3') . Tools::safeOutput($quantity . ' ' . $this->pluralizePolish($quantity, 'sztuka', 'sztuki', 'sztuk')) . $this->htmlFragment('776b32bc638deda8a74f');
            $html .= $this->htmlFragment('9099303c133b44f25914');
            $html .= $this->htmlFragment('3fee403c4d103c96b4d0') . (int) $index . '][amount]" value="' . Tools::safeOutput(number_format($amount, 2, '.', '')) . '">';
            $html .= $this->htmlFragment('6cfed9c569a109006cae') . Tools::safeOutput($currency !== '' ? $currency : 'PLN') . $this->htmlFragment('411fdb22d8d9298e5d32');
            $html .= $this->htmlFragment('aac32651b10f567c461b');
            $html .= $this->htmlFragment('aac32651b10f567c461b');
            ++$index;
        }
        $html .= $this->htmlFragment('a966ffbeb5ee2b7b74fe');
        $html .= $this->htmlFragment('08842b15e6f7bb1d1edf') . Tools::safeOutput($this->getCustomerReturnCurrency($return)) . '">';
        $html .= $this->htmlFragment('061325503e9e439ead12');
        $html .= $this->htmlFragment('9099303c133b44f25914');
        $html .= $this->htmlFragment('894f08811d725af93536');
        $html .= $this->htmlFragment('6cfed9c569a109006cae') . Tools::safeOutput($this->getCustomerReturnCurrency($return)) . $this->htmlFragment('411fdb22d8d9298e5d32');
        $html .= $this->htmlFragment('aac32651b10f567c461b');
        $html .= $this->htmlFragment('aac32651b10f567c461b');
        $html .= $this->htmlFragment('ac710686d03489e81abc');
        $html .= $this->htmlFragment('4dae09f3b7809ce7fb89');
        $html .= $this->htmlFragment('aac32651b10f567c461b');
        $html .= $this->htmlFragment('e0c7bb7b72eeecfc0734');

        return $index > 0 ? $html : '';
    }

    protected function buildIssueOrderProductRows(string $checkoutFormId, string $offerId, string $offerQuantity, string $productId, ?array $linkedOrder = null): array
    {
        $rows = [];
        $rows[] = [
            'label' => 'Oferta',
            'value' => $offerId,
            'url' => $this->getAllegroOfferUrl($offerId),
        ];
        $rows[] = [
            'label' => 'Produkt',
            'value' => $productId,
            'url' => $this->getAllegroProductUrl($productId),
        ];

        return array_values(array_filter($rows, function (array $row): bool {
            return trim((string) $row['value']) !== '';
        }));
    }

    protected function formatPrestashopOrderReference(array $linkedOrder): string
    {
        $reference = trim((string) ($linkedOrder['reference'] ?? ''));
        if ($reference !== '' && $reference !== '#0') {
            return $reference;
        }

        $idOrder = (int) ($linkedOrder['id_order'] ?? 0);

        return $idOrder > 0 ? '#' . $idOrder : '';
    }

    protected function renderCheckoutBuyerDeliveryCard(string $checkoutFormId, string $buyerLogin = ''): string
    {
        $checkoutForm = $this->getStoredCheckoutFormContent($checkoutFormId);
        $buyerLines = $this->extractCheckoutBuyerLines($checkoutForm, $buyerLogin);
        $deliveryLines = $this->extractCheckoutDeliveryLines($checkoutForm);

        if (!$buyerLines && trim($buyerLogin) !== '') {
            $buyerLines[] = trim($buyerLogin);
        }

        $html = $this->htmlFragment('e4b14f9183fdee44984c');
        $html .= $this->htmlFragment('dd9be0b7db1ed89d51e5');

        $html .= $this->htmlFragment('677ac9c437543c83a022');
        $html .= $this->htmlFragment('9dd3f2e6e229188553a1');
        foreach ($buyerLines as $line) {
            $html .= $this->htmlFragment('f0a8ebd68c47ad5549c3') . Tools::safeOutput($line) . $this->htmlFragment('411fdb22d8d9298e5d32');
        }
        $html .= $this->htmlFragment('aac32651b10f567c461b');

        if ($deliveryLines) {
            $html .= $this->htmlFragment('677ac9c437543c83a022');
            $html .= $this->htmlFragment('9d71cb9498a7726a994d');
            foreach ($deliveryLines as $line) {
                $html .= $this->htmlFragment('f0a8ebd68c47ad5549c3') . Tools::safeOutput($line) . $this->htmlFragment('411fdb22d8d9298e5d32');
            }
            $html .= $this->htmlFragment('aac32651b10f567c461b');
        }

        $html .= $this->htmlFragment('aac32651b10f567c461b');
        $html .= $this->htmlFragment('aac32651b10f567c461b');

        return $html;
    }

    protected function getStoredCheckoutFormContent(string $checkoutFormId): array
    {
        $checkoutFormId = trim($checkoutFormId);
        if ($checkoutFormId === '') {
            return [];
        }

        foreach ($this->getX13OrderTableNames() as $tableName) {
            try {
                $raw = (string) Db::getInstance()->getValue('
                    SELECT `checkout_form_content`
                    FROM `' . bqSQL($tableName) . '`
                    WHERE `checkout_form` LIKE "%' . pSQL($checkoutFormId) . '%"
                        OR `checkout_form_content` LIKE "%' . pSQL($checkoutFormId) . '%"
                ');
            } catch (Throwable $e) {
                PrestaShopLogger::addLog('[AAR] checkout_form_content lookup skipped for ' . $tableName . ' / ' . $checkoutFormId . ': ' . $e->getMessage(), 2);
                continue;
            }

            $decoded = $this->decodeStoredCheckoutFormContent($raw);
            if ($decoded) {
                return $decoded;
            }
        }

        return [];
    }

    protected function decodeStoredCheckoutFormContent(string $raw): array
    {
        $raw = trim($raw);
        if ($raw === '') {
            return [];
        }

        $decoded = json_decode($raw, true);
        if (is_array($decoded)) {
            return $decoded;
        }

        $decoded = json_decode(html_entity_decode($raw, ENT_QUOTES | ENT_HTML5, 'UTF-8'), true);
        if (is_array($decoded)) {
            return $decoded;
        }

        $decoded = json_decode(stripslashes($raw), true);

        return is_array($decoded) ? $decoded : [];
    }

    protected function extractCheckoutBuyerLines(array $checkoutForm, string $buyerLogin = ''): array
    {
        $buyer = $checkoutForm['buyer'] ?? [];
        $deliveryAddress = $checkoutForm['delivery']['address'] ?? [];
        $invoiceAddress = $checkoutForm['invoice']['address'] ?? [];
        $buyer = is_array($buyer) ? $buyer : [];
        $deliveryAddress = is_array($deliveryAddress) ? $deliveryAddress : [];
        $invoiceAddress = is_array($invoiceAddress) ? $invoiceAddress : [];
        $lines = [];
        $name = $this->firstNonEmptyString([
            $this->joinNameParts($buyer),
            $buyer['name'] ?? null,
            $buyer['companyName'] ?? null,
            $this->joinNameParts($deliveryAddress),
            $this->joinNameParts($invoiceAddress),
        ]);
        $login = $this->firstNonEmptyString([
            $buyerLogin,
            $buyer['login'] ?? null,
            $buyer['userName'] ?? null,
        ]);
        $phone = $this->firstNonEmptyString([
            $buyer['phoneNumber'] ?? null,
            $buyer['phone'] ?? null,
            $deliveryAddress['phoneNumber'] ?? null,
            $deliveryAddress['phone'] ?? null,
            $invoiceAddress['phoneNumber'] ?? null,
        ]);

        foreach ([$name, $login, $phone] as $line) {
            if ($line !== '') {
                $lines[] = $line;
            }
        }

        return array_values(array_unique($lines));
    }

    protected function extractCheckoutDeliveryLines(array $checkoutForm): array
    {
        $address = $checkoutForm['delivery']['address'] ?? [];
        if (!is_array($address) || !$address) {
            $address = $checkoutForm['deliveryAddress'] ?? [];
        }
        if (!is_array($address) || !$address) {
            return [];
        }

        $name = $this->firstNonEmptyString([
            $this->joinNameParts($address),
            $address['name'] ?? null,
            $address['companyName'] ?? null,
        ]);
        $street = $this->firstNonEmptyString([
            $address['street'] ?? null,
            $address['addressLine1'] ?? null,
        ]);
        $postalCity = trim($this->firstNonEmptyString([$address['zipCode'] ?? null, $address['postCode'] ?? null]) . ' ' . $this->firstNonEmptyString([$address['city'] ?? null]));
        $country = $this->firstNonEmptyString([$address['countryCode'] ?? null, $address['country'] ?? null]);
        $postalCityCountry = trim($postalCity . ' ' . $country);
        $phone = $this->firstNonEmptyString([$address['phoneNumber'] ?? null, $address['phone'] ?? null]);
        $lines = [];

        foreach ([$name, $street, $postalCityCountry, $phone] as $line) {
            if ($line !== '') {
                $lines[] = $line;
            }
        }

        return array_values(array_unique($lines));
    }

    protected function joinNameParts(array $payload): string
    {
        return trim($this->firstNonEmptyString([$payload['firstName'] ?? null]) . ' ' . $this->firstNonEmptyString([$payload['lastName'] ?? null]));
    }

    protected function firstNonEmptyString(array $values): string
    {
        foreach ($values as $value) {
            if (!is_scalar($value)) {
                continue;
            }

            $value = trim((string) $value);
            if ($value !== '') {
                return $value;
            }
        }

        return '';
    }

    protected function resolveOrderDateByCheckoutForm(string $checkoutFormId): string
    {
        $checkoutFormId = trim($checkoutFormId);
        if ($checkoutFormId === '') {
            return '';
        }

        $row = [];
        try {
            $row = Db::getInstance()->getRow('
                SELECT *
                FROM `pr_xallegro_order`
                WHERE `checkout_form` LIKE "%' . pSQL($checkoutFormId) . '%"
            ');
        } catch (Throwable $e) {
            PrestaShopLogger::addLog('[AAR] order date lookup skipped for ' . $checkoutFormId . ': ' . $e->getMessage(), 2);
        }

        if (is_array($row)) {
            foreach (['occurred_at', 'occured_at', 'occurrence', 'event_time', 'event_date', 'created_at', 'updated_at', 'date_add', 'date_upd'] as $column) {
                $date = trim((string) ($row[$column] ?? ''));
                if ($date !== '' && strtotime($date) !== false) {
                    return $date;
                }
            }

            $checkoutForm = $this->decodeStoredCheckoutFormContent((string) ($row['checkout_form_content'] ?? ''));
            $date = $this->extractDateFromCheckoutFormPayload($checkoutForm);
            if ($date !== '') {
                return $date;
            }
        }

        $checkoutForm = $this->getStoredCheckoutFormContent($checkoutFormId);

        return $this->extractDateFromCheckoutFormPayload($checkoutForm);
    }

    protected function extractDateFromCheckoutFormPayload(array $payload): string
    {
        $preferredKeys = ['boughtAt', 'purchasedAt', 'createdAt', 'updatedAt', 'checkoutCompletedAt', 'finishedAt'];
        foreach ($preferredKeys as $key) {
            $date = trim((string) ($payload[$key] ?? ''));
            if ($date !== '' && strtotime($date) !== false) {
                return $date;
            }
        }

        foreach ($payload as $key => $value) {
            if (is_array($value)) {
                $date = $this->extractDateFromCheckoutFormPayload($value);
                if ($date !== '') {
                    return $date;
                }
                continue;
            }

            if (!is_scalar($value) || !preg_match('/(?:date|at|time)$/i', (string) $key)) {
                continue;
            }

            $date = trim((string) $value);
            if ($date !== '' && strtotime($date) !== false) {
                return $date;
            }
        }

        return '';
    }

    protected function formatPrestashopOrderDateWithAge(string $date): string
    {
        $formatted = $this->formatAllegroDate($date);
        if ($formatted === '') {
            return '';
        }

        $age = $this->formatDateAge($date);

        return $age !== '' ? $formatted . ' (' . $age . ')' : $formatted;
    }

    protected function formatIssueOpenDateSinceOrder(string $openedDate, string $orderDate): string
    {
        $formatted = $this->formatAllegroDate($openedDate);
        if ($formatted === '') {
            return '';
        }

        $distance = $this->formatDateDistance($orderDate, $openedDate);

        return $distance !== '' ? $formatted . ' (' . $distance . ' od zakupu)' : $formatted;
    }

    protected function formatDateDistance(string $startDate, string $endDate): string
    {
        try {
            $startedAt = new DateTimeImmutable($startDate);
            $endedAt = new DateTimeImmutable($endDate);
        } catch (Exception $exception) {
            return '';
        }

        if ($startedAt > $endedAt) {
            return '';
        }

        $diff = $startedAt->diff($endedAt);
        $parts = [];
        if ((int) $diff->y > 0) {
            $parts[] = $diff->y . ' ' . $this->pluralizePolish((int) $diff->y, 'rok', 'lata', 'lat');
        }
        if ((int) $diff->m > 0) {
            $parts[] = $diff->m . ' ' . $this->pluralizePolish((int) $diff->m, 'miesiąc', 'miesiące', 'miesięcy');
        }
        if ((int) $diff->d > 0 || !$parts) {
            $parts[] = $diff->d . ' ' . $this->pluralizePolish((int) $diff->d, 'dzień', 'dni', 'dni');
        }

        if (count($parts) === 1) {
            return $parts[0];
        }

        $last = array_pop($parts);

        return implode(', ', $parts) . ' i ' . $last;
    }

    protected function formatDateAge(string $date): string
    {
        try {
            $startedAt = new DateTimeImmutable($date);
            $now = new DateTimeImmutable('now');
        } catch (Exception $exception) {
            return '';
        }

        if ($startedAt > $now) {
            return '';
        }

        $days = (int) floor(($now->getTimestamp() - $startedAt->getTimestamp()) / 86400);
        if ($days < 31) {
            return $days . ' ' . $this->pluralizePolish($days, 'dzień', 'dni', 'dni') . ' temu';
        }

        $months = (int) floor($days / 30);
        if ($months < 12) {
            return $months . ' ' . $this->pluralizePolish($months, 'miesiąc', 'miesiące', 'miesięcy') . ' temu';
        }

        $years = (int) $startedAt->diff($now)->y;
        $anniversary = $startedAt->modify('+' . $years . ' years');
        $remainingDays = max(0, (int) $anniversary->diff($now)->days);
        $yearLabel = $years . ' ' . $this->pluralizePolish($years, 'rok', 'lata', 'lat');

        if ($remainingDays > 0) {
            return $yearLabel . ' i ' . $remainingDays . ' ' . $this->pluralizePolish($remainingDays, 'dzień', 'dni', 'dni') . ' temu';
        }

        return $yearLabel . ' temu';
    }

    protected function pluralizePolish(int $count, string $one, string $few, string $many): string
    {
        $mod10 = $count % 10;
        $mod100 = $count % 100;
        if ($count === 1) {
            return $one;
        }
        if ($mod10 >= 2 && $mod10 <= 4 && !($mod100 >= 12 && $mod100 <= 14)) {
            return $few;
        }

        return $many;
    }

    protected function renderClaimInfoCard(string $title, array $rows, string $body = '', bool $bodyIsHtml = false): string
    {
        $html = $this->htmlFragment('f04f1c3ba4acc09612f1');
        $html .= $this->htmlFragment('677dfc8a2943b6c313cb') . Tools::safeOutput($title) . $this->htmlFragment('60cd30ffe1b2da73e413');
        if ($rows) {
            $html .= $this->htmlFragment('c873ba64798050fd5735');
            foreach ($rows as $label => $value) {
                $url = '';
                $extraHtml = '';
                if (is_array($value)) {
                    $label = (string) ($value['label'] ?? $label);
                    $url = trim((string) ($value['url'] ?? ''));
                    $extraHtml = trim((string) ($value['extra_html'] ?? ''));
                    $value = $value['value'] ?? '';
                }

                $value = trim((string) $value);
                if ($value === '') {
                    continue;
                }

                $html .= $this->htmlFragment('15dd8048be0b8dbc2807');
                $html .= $this->htmlFragment('cfdbcaad3482a329281e') . Tools::safeOutput($label) . $this->htmlFragment('96d6798589dad89b3a5b');
                if ($url !== '') {
                    $html .= $this->htmlFragment('65f513a10558ac9cbfeb') . Tools::safeOutput($url) . '" target="_blank" rel="noopener noreferrer">' . Tools::safeOutput($value) . $this->htmlFragment('ecd5b806462c7dfdf078') . $extraHtml . $this->htmlFragment('e9a829f035777fbc1fe0');
                } else {
                    $html .= $this->htmlFragment('8657c55c257c3a365d41') . Tools::safeOutput($value) . $extraHtml . $this->htmlFragment('e9a829f035777fbc1fe0');
                }
                $html .= $this->htmlFragment('aac32651b10f567c461b');
            }
            $html .= $this->htmlFragment('5190f9c0a1366612a15d');
        }
        if ($body !== '') {
            $html .= $this->htmlFragment('37002add42c563d0dd39') . ($bodyIsHtml ? $body : nl2br(Tools::safeOutput($body))) . $this->htmlFragment('aac32651b10f567c461b');
        }
        $html .= $this->htmlFragment('aac32651b10f567c461b');

        return $html;
    }

    protected function getAllegroOrdersUrl(string $checkoutFormId): string
    {
        $checkoutFormId = trim($checkoutFormId);
        if ($checkoutFormId === '') {
            return '';
        }

        $account = $this->getConnectedAccount();
        $marketplaceLogin = trim((string) ($account['login'] ?? ''));
        $params = [
            'query' => $checkoutFormId,
        ];

        if ($marketplaceLogin !== '') {
            $params['marketplaceLogin'] = $marketplaceLogin;
        }

        return 'https://salescenter.allegro.com/orders/?' . http_build_query($params);
    }

    protected function getAllegroIssueUrl(array $issue): string
    {
        $issueId = trim((string) ($issue['id'] ?? ''));
        if ($issueId !== '') {
            return 'https://salescenter.allegro.com/claims/' . rawurlencode($issueId);
        }

        $referenceNumber = trim((string) ($issue['referenceNumber'] ?? ''));
        if ($referenceNumber === '') {
            return '';
        }

        $account = $this->getConnectedAccount();
        $marketplaceLogin = trim((string) ($account['login'] ?? ''));
        $params = [
            'query' => $referenceNumber,
        ];

        if ($marketplaceLogin !== '') {
            $params['marketplaceLogin'] = $marketplaceLogin;
        }

        return 'https://salescenter.allegro.com/issues/?' . http_build_query($params);
    }

    protected function getAllegroMessageThreadUrl(string $threadId): string
    {
        return 'https://salescenter.allegro.com/message-center/messages/thread/' . rawurlencode(trim($threadId));
    }

    protected function resolveMessageOfferThumbnailUrl(string $offerId): string
    {
        $offerId = trim($offerId);
        if ($offerId === '') {
            return '';
        }

        $cachedUrl = $this->getIssueThumbnailFromCache($offerId);
        if ($cachedUrl !== '') {
            return $cachedUrl;
        }

        try {
            $apiClient = new AllegroApiClient(new TokenManager());
            $offer = $apiClient->getProductOffer($offerId);
            if (!is_array($offer) || !$offer) {
                return '';
            }

            $thumbnailUrl = $this->extractFirstImageUrlFromOffer($offer);
            if ($thumbnailUrl !== '') {
                $this->storeIssueThumbnailCache($offerId, $thumbnailUrl);
            }

            return $thumbnailUrl;
        } catch (Throwable $e) {
            PrestaShopLogger::addLog('[AAR] Message offer thumbnail lookup failed for ' . $offerId . ': ' . $e->getMessage(), 2);

            return '';
        }
    }

    protected function getAllegroReturnUrl(array $return): string
    {
        $referenceNumber = trim((string) ($return['referenceNumber'] ?? ''));
        if ($referenceNumber !== '') {
            return $this->buildAllegroReturnsSearchUrl($referenceNumber);
        }

        $returnId = trim((string) ($return['id'] ?? ''));
        if ($returnId !== '') {
            return $this->buildAllegroReturnsSearchUrl($returnId);
        }

        return '';
    }

    protected function buildAllegroReturnsSearchUrl(string $search): string
    {
        $search = trim($search);
        if ($search === '') {
            return '';
        }

        $params = [
            'page' => 1,
            'limit' => 25,
            'search' => $search,
        ];

        $dateRange = $this->getCurrentReturnDateRangeFilter();
        if ($dateRange !== 'all') {
            $days = max(1, (int) $dateRange);
            $from = new DateTimeImmutable('now', new DateTimeZone('UTC'));
            $from = $from->modify('-' . $days . ' days')->setTime(0, 0, 0, 0);
            $params['from'] = $from->format('Y-m-d\TH:i:s.000\Z');
        }

        return 'https://salescenter.allegro.com/returns?' . http_build_query($params);
    }

    protected function getAllegroOfferUrl(string $offerId): string
    {
        $offerId = trim($offerId);
        if ($offerId === '') {
            return '';
        }

        return 'https://allegro.pl/oferta/' . rawurlencode($offerId);
    }

    protected function getAllegroProductUrl(string $productId): string
    {
        $productId = trim($productId);
        if ($productId === '') {
            return '';
        }

        return 'https://allegro.pl/produkt/' . rawurlencode($productId);
    }

    protected function extractIssueCheckoutFormId(array $issue): string
    {
        $ids = $this->extractCheckoutFormIdsFromPayload($issue);

        return $ids[0] ?? '';
    }

    protected function extractCheckoutFormIdsFromPayload(array $payload): array
    {
        $directCandidates = [
            $payload['checkoutForm']['id'] ?? null,
            $payload['checkoutFormId'] ?? null,
            $payload['checkout_form_id'] ?? null,
            $payload['order']['id'] ?? null,
            $payload['orderId'] ?? null,
            $payload['order_id'] ?? null,
            $payload['relatesTo']['order']['id'] ?? null,
            $payload['order']['checkoutForm']['id'] ?? null,
            $payload['order']['checkoutFormId'] ?? null,
            $payload['buyer']['order']['id'] ?? null,
            $payload['buyer']['order']['checkoutForm']['id'] ?? null,
            $payload['buyer']['order']['checkoutFormId'] ?? null,
        ];

        $ids = [];
        foreach ($directCandidates as $candidate) {
            if (!is_scalar($candidate)) {
                continue;
            }

            $value = trim((string) $candidate);
            if ($value !== '') {
                $ids[$value] = true;
            }
        }

        foreach ($this->findCheckoutFormIdsRecursively($payload) as $value) {
            $ids[$value] = true;
        }

        return array_keys($ids);
    }

    protected function findCheckoutFormIdRecursively(array $payload): string
    {
        $ids = $this->findCheckoutFormIdsRecursively($payload);

        return $ids[0] ?? '';
    }

    protected function findCheckoutFormIdsRecursively(array $payload): array
    {
        $ids = [];
        foreach ($payload as $key => $value) {
            $normalizedKey = strtolower((string) $key);
            if (in_array($normalizedKey, ['checkoutformid', 'checkout_form_id', 'checkout-form-id', 'orderid', 'order_id'], true)) {
                if (!is_scalar($value)) {
                    continue;
                }

                $candidate = trim((string) $value);
                if ($candidate !== '') {
                    $ids[$candidate] = true;
                }
            }

            if (in_array($normalizedKey, ['checkoutform', 'order'], true) && is_array($value)) {
                if (is_scalar($value['id'] ?? null)) {
                    $candidate = trim((string) $value['id']);
                    if ($candidate !== '') {
                        $ids[$candidate] = true;
                    }
                }
            }

            if (is_array($value)) {
                foreach ($this->findCheckoutFormIdsRecursively($value) as $candidate) {
                    $ids[$candidate] = true;
                }
            }
        }

        return array_keys($ids);
    }

    protected function renderLinkedOrderBody(?array $linkedOrder): string
    {
        if (!$linkedOrder) {
            return '';
        }

        $html = $this->htmlFragment('e4d9ab8fe3593342bf7c');
        $html .= $this->htmlFragment('f125a12fe59dc5f93b9f') . Tools::safeOutput($linkedOrder['url']) . $this->htmlFragment('9438523e1e1ee32fc2ef');
        if (!empty($linkedOrder['source'])) {
            $html .= $this->htmlFragment('4f91e65e228f8054babd') . Tools::safeOutput($linkedOrder['source']) . $this->htmlFragment('aac32651b10f567c461b');
        }
        $html .= $this->htmlFragment('aac32651b10f567c461b');

        return $html;
    }

    protected function buildThreadPreview(array $thread): string
    {
        $preview = (string) ($thread['lastMessage']['text'] ?? $thread['snippet'] ?? $thread['subject'] ?? '');
        $preview = $this->decodeAllegroText($preview);
        $preview = preg_replace('/\s+/u', ' ', trim($preview));

        if ($preview === null || $preview === '') {
            return '';
        }

        return mb_strimwidth($preview, 0, 72, '...');
    }

    protected function getThreadInterlocutorAvatarUrl(array $thread): string
    {
        $interlocutor = is_array($thread['interlocutor'] ?? null) ? $thread['interlocutor'] : [];
        $candidates = [
            $interlocutor['avatar']['url'] ?? null,
            $interlocutor['avatarUrl'] ?? null,
            $interlocutor['avatar'] ?? null,
            $interlocutor['image']['url'] ?? null,
            $interlocutor['imageUrl'] ?? null,
            $interlocutor['picture']['url'] ?? null,
            $interlocutor['pictureUrl'] ?? null,
            $thread['avatar']['url'] ?? null,
            $thread['avatarUrl'] ?? null,
        ];

        foreach ($candidates as $candidate) {
            $url = $this->normalizeIssueImageUrl($candidate);
            if ($url !== '') {
                return $url;
            }
        }

        return '';
    }

    protected function getAvatarInitial(string $login): string
    {
        $login = trim($login);
        if ($login === '') {
            return '?';
        }

        return mb_strtoupper(mb_substr($login, 0, 1));
    }

    protected function buildIssuePreview(array $issue): string
    {
        $issueType = mb_strtoupper(trim((string) ($issue['type'] ?? '')));
        if ($issueType === 'CLAIM') {
            $parts = [];
            $buyerLogin = trim((string) ($issue['buyer']['login'] ?? ''));
            $expectations = trim($this->formatIssueExpectations($issue['expectations'] ?? []));
            $referenceNumber = trim((string) ($issue['referenceNumber'] ?? ''));

            if ($buyerLogin !== '') {
                $parts[] = $buyerLogin;
            }
            if ($expectations !== '') {
                $parts[] = $expectations;
            } elseif ($referenceNumber !== '') {
                $parts[] = 'Nr ' . $referenceNumber;
            }

            $preview = implode(' • ', $parts);
            if ($preview !== '') {
                return mb_strimwidth($preview, 0, 72, '...');
            }
        }

        $preview = $this->resolveIssueTextValue($issue['lastMessage']['text'] ?? null);
        if ($preview === '') {
            $preview = $this->formatIssueSubjectText($this->resolveIssueTextValue($issue['subject'] ?? null));
        }
        $preview = $this->decodeAllegroText($preview);
        $preview = preg_replace('/\s+/u', ' ', trim($preview));

        if ($preview === null || $preview === '') {
            return '';
        }

        return mb_strimwidth($preview, 0, 72, '...');
    }

    protected function buildIssueSubject(array $issue): string
    {
        $issueType = mb_strtoupper(trim((string) ($issue['type'] ?? '')));
        if ($issueType === 'CLAIM') {
            $reasonType = trim((string) ($issue['reason']['type'] ?? ''));
            $formattedReason = $this->formatIssueReasonType($reasonType);
            if ($formattedReason !== '') {
                return $formattedReason;
            }
        }

        $orderId = (string) ($issue['order']['id'] ?? $issue['buyer']['order']['id'] ?? '');
        $reason = $this->formatIssueSubjectText($this->resolveIssueTextValue($issue['reason']['name'] ?? null));
        if ($reason === '') {
            $reason = $this->formatIssueSubjectText($this->resolveIssueTextValue($issue['reason'] ?? null));
        }
        if ($reason === '') {
            $reason = $this->formatIssueSubjectText($this->resolveIssueTextValue($issue['subject'] ?? null));
        }
        $buyerLogin = (string) ($issue['buyer']['login'] ?? $issue['participant']['login'] ?? '');

        if ($reason !== '') {
            return $reason;
        }

        if ($orderId !== '') {
            return 'Zamówienie ' . $orderId;
        }

        if ($buyerLogin !== '') {
            return 'Klient: ' . $buyerLogin;
        }

        return 'Zgłoszenie Allegro';
    }

    protected function buildIssueHeaderTitle(array $issue): string
    {
        $issueType = mb_strtoupper(trim((string) ($issue['type'] ?? '')));
        if ($issueType === 'CLAIM') {
            $referenceNumber = trim((string) ($issue['referenceNumber'] ?? ''));
            if ($referenceNumber !== '') {
                return 'Reklamacja ' . $referenceNumber;
            }

            return 'Reklamacja Allegro';
        }

        return $this->buildIssueSubject($issue);
    }

    protected function buildIssueHeaderSubtitle(array $issue, string $sectionTitle, array $messages = []): string
    {
        $issueType = mb_strtoupper(trim((string) ($issue['type'] ?? '')));
        if ($issueType === 'CLAIM') {
            $parts = [];
            $checkoutFormIds = $this->extractCheckoutFormIdsFromPayload($issue);
            foreach ($messages as $message) {
                if (is_array($message)) {
                    $checkoutFormIds = array_merge($checkoutFormIds, $this->extractCheckoutFormIdsFromPayload($message));
                }
            }
            $checkoutFormIds = array_values(array_unique(array_filter(array_map('strval', $checkoutFormIds))));
            $checkoutFormId = $checkoutFormIds[0] ?? '';

            if ($checkoutFormId !== '') {
                $parts[] = 'Zamówienie Allegro: ' . $checkoutFormId;
            }

            $linkedOrder = $this->resolvePrestashopOrderLink($issue, $messages);
            if (is_array($linkedOrder) && (int) ($linkedOrder['id_order'] ?? 0) > 0) {
                $parts[] = 'Zamówienie w sklepie: ' . $this->formatPrestashopOrderReference($linkedOrder);
            } else {
                $parts[] = 'Zamówienie w sklepie: brak';
            }

            return implode(' • ', $parts);
        }

        if ($issueType === 'DISPUTE') {
            $buyerLogin = trim((string) ($issue['buyer']['login'] ?? $issue['participant']['login'] ?? ''));
            if ($buyerLogin !== '') {
                return 'Dyskusja z ' . $buyerLogin;
            }

            return 'Dyskusja Allegro';
        }

        return trim($sectionTitle . ' Allegro');
    }

    protected function renderIssueHeaderSubtitle(array $issue, string $sectionTitle, array $messages = []): string
    {
        $issueType = mb_strtoupper(trim((string) ($issue['type'] ?? '')));
        if ($issueType !== 'CLAIM') {
            return Tools::safeOutput($this->buildIssueHeaderSubtitle($issue, $sectionTitle, $messages));
        }

        $parts = [];
        $checkoutFormIds = $this->extractCheckoutFormIdsFromPayload($issue);
        foreach ($messages as $message) {
            if (is_array($message)) {
                $checkoutFormIds = array_merge($checkoutFormIds, $this->extractCheckoutFormIdsFromPayload($message));
            }
        }
        $checkoutFormIds = array_values(array_unique(array_filter(array_map('strval', $checkoutFormIds))));
        $checkoutFormId = $checkoutFormIds[0] ?? '';

        if ($checkoutFormId !== '') {
            $allegroOrderUrl = $this->getAllegroOrdersUrl($checkoutFormId);
            $checkoutFormLabel = Tools::safeOutput($checkoutFormId);
            if ($allegroOrderUrl !== '') {
                $checkoutFormLabel = $this->htmlFragment('02c400f14d7569ede879') . Tools::safeOutput($allegroOrderUrl) . '" target="_blank" rel="noopener noreferrer">' . $checkoutFormLabel . $this->htmlFragment('ecd5b806462c7dfdf078');
            }
            $parts[] = 'Zamówienie Allegro: ' . $checkoutFormLabel;
        }

        $linkedOrder = $this->resolvePrestashopOrderLink($issue, $messages);
        if (is_array($linkedOrder) && (int) ($linkedOrder['id_order'] ?? 0) > 0) {
            $prestashopOrderLabel = Tools::safeOutput($this->formatPrestashopOrderReference($linkedOrder));
            $prestashopOrderUrl = trim((string) ($linkedOrder['url'] ?? ''));
            if ($prestashopOrderUrl !== '') {
                $prestashopOrderLabel = $this->htmlFragment('02c400f14d7569ede879') . Tools::safeOutput($prestashopOrderUrl) . '" target="_blank" rel="noopener noreferrer">' . $prestashopOrderLabel . $this->htmlFragment('ecd5b806462c7dfdf078');
            }
            $parts[] = 'Zamówienie w sklepie: ' . $prestashopOrderLabel;
        } else {
            $parts[] = 'Zamówienie w sklepie: brak';
        }

        return implode(' • ', $parts);
    }

    protected function resolveIssueThumbnailUrl(array $issue, bool $allowPrestashopFallback = true): string
    {
        $thumbnailContext = $this->extractIssueThumbnailContext($issue);
        $offerId = $thumbnailContext['offer_id'];
        $checkoutFormId = $thumbnailContext['checkout_form_id'];
        $issueId = $thumbnailContext['issue_id'];
        $cacheKeys = $this->buildIssueThumbnailCacheKeys($offerId, $checkoutFormId, '', $issueId);

        $cachedUrl = $this->getIssueThumbnailFromCaches($cacheKeys);
        if ($cachedUrl !== '') {
            return $cachedUrl;
        }

        if (!$allowPrestashopFallback) {
            return '';
        }

        $thumbnailUrl = '';
        if ($checkoutFormId !== '') {
            $thumbnailUrl = $this->resolvePrestashopOrderThumbnailUrlByCheckoutFormId(
                $checkoutFormId,
                $offerId
            );
        }

        if ($thumbnailUrl === '') {
            $thumbnailUrl = $this->resolvePrestashopOrderThumbnailUrl($issue);
        }

        if ($thumbnailUrl !== '') {
            $this->storeIssueThumbnailCaches($cacheKeys, $thumbnailUrl);

            return $thumbnailUrl;
        }

        return '';
    }

    public function warmIssueThumbnailCache(string $offerId, string $productId = '', string $checkoutFormId = '', string $issueId = ''): string
    {
        $offerId = trim($offerId);
        $productId = trim($productId);
        $checkoutFormId = trim($checkoutFormId);
        $issueId = trim($issueId);

        try {
            $apiClient = new AllegroApiClient(new TokenManager());
            $thumbnailUrl = '';
            $issuePayload = [];
            $messages = [];

            if ($issueId !== '') {
                try {
                    $issuePayload = $apiClient->getIssue($issueId);
                    if (is_array($issuePayload) && $issuePayload) {
                        $thumbnailUrl = $this->resolveIssueThumbnailUrl($issuePayload, true);
                        $resolvedContext = $this->extractIssueThumbnailContext($issuePayload);
                        if ($offerId === '') {
                            $offerId = $resolvedContext['offer_id'];
                        }
                        if ($productId === '') {
                            $productId = $resolvedContext['product_id'];
                        }
                        if ($checkoutFormId === '') {
                            $checkoutFormId = $resolvedContext['checkout_form_id'];
                        }
                    }
                } catch (Throwable $e) {
                    $thumbnailUrl = '';
                }

                try {
                    $messagesResponse = $apiClient->getIssueChat($issueId, 100);
                    $messages = $messagesResponse['chat'] ?? $messagesResponse['messages'] ?? [];
                    if (is_array($messages)) {
                        if ($checkoutFormId === '') {
                            foreach ($messages as $message) {
                                if (!is_array($message)) {
                                    continue;
                                }

                                $messageCheckoutFormIds = $this->extractCheckoutFormIdsFromPayload($message);
                                if ($messageCheckoutFormIds) {
                                    $checkoutFormId = (string) $messageCheckoutFormIds[0];
                                    break;
                                }
                            }
                        }

                        if ($offerId === '') {
                            $messageOfferId = $this->extractOfferId($messages);
                            if ($messageOfferId !== null) {
                                $offerId = $messageOfferId;
                            }
                        }
                    }
                } catch (Throwable $e) {
                    // Chat context is optional for thumbnails.
                }
            }

            $cacheKeys = $this->buildIssueThumbnailCacheKeys($offerId, $checkoutFormId, '', $issueId);
            $cachedUrl = $this->getIssueThumbnailFromCaches($cacheKeys);
            if ($thumbnailUrl === '' && $cachedUrl !== '') {
                return $cachedUrl;
            }

            if ($thumbnailUrl === '' && $checkoutFormId !== '') {
                $checkoutFormPayload = [];
                try {
                    $checkoutFormPayload = $apiClient->getCheckoutForm($checkoutFormId);
                } catch (Throwable $e) {
                    PrestaShopLogger::addLog('[AAR] Checkout form thumbnail lookup API failed for ' . $checkoutFormId . ': ' . $e->getMessage(), 2);
                    $checkoutFormPayload = $this->getStoredCheckoutFormContent($checkoutFormId);
                }

                if (is_array($checkoutFormPayload) && $checkoutFormPayload) {
                    $thumbnailUrl = $this->findPrestashopProductThumbnailByCheckoutFormSignature($checkoutFormPayload, $offerId);
                    if ($thumbnailUrl === '' && $checkoutFormId !== '') {
                        $thumbnailUrl = $this->findPrestashopOrderThumbnailByCheckoutFormSignature($checkoutFormId, $checkoutFormPayload, $offerId);
                    }
                    if ($thumbnailUrl === '') {
                        $resolvedOfferId = $this->extractFirstOfferIdFromCheckoutForm($checkoutFormPayload);
                        if ($offerId === '' && $resolvedOfferId !== '') {
                            $offerId = $resolvedOfferId;
                        }
                    }
                }
            }

            // Allegro sometimes omits identifiers from older claims or returns an
            // offer id which is no longer present in the stored checkout payload.
            // A linked single-product PrestaShop order is still unambiguous and is
            // a safer fallback than leaving the thumbnail empty.
            if ($thumbnailUrl === '' && $checkoutFormId !== '') {
                $thumbnailUrl = $this->resolvePrestashopOrderThumbnailUrlByCheckoutFormId(
                    $checkoutFormId,
                    $offerId,
                    is_array($checkoutFormPayload ?? null) ? $checkoutFormPayload : []
                );
            }

            if ($thumbnailUrl === '') {
                $identifierPayloads = [];
                if (is_array($issuePayload) && $issuePayload) {
                    $identifierPayloads[] = $issuePayload;
                }
                if (is_array($messages)) {
                    foreach ($messages as $message) {
                        if (is_array($message)) {
                            $identifierPayloads[] = $message;
                        }
                    }
                }

                $thumbnailUrl = $this->findPrestashopThumbnailByAllegroProductIdentifiers(
                    $apiClient,
                    $offerId,
                    $productId,
                    $checkoutFormId,
                    $identifierPayloads
                );
            }

            if ($thumbnailUrl !== '') {
                $this->storeIssueThumbnailCaches($this->buildIssueThumbnailCacheKeys($offerId, $checkoutFormId, '', $issueId), $thumbnailUrl);
            }

            return $thumbnailUrl;
        } catch (Throwable $e) {
            PrestaShopLogger::addLog('[AAR] Lazy thumbnail lookup failed for offer ' . $offerId . ' / product ' . $productId . ' / checkoutForm ' . $checkoutFormId . ' / issue ' . $issueId . ': ' . $e->getMessage(), 2);
        }

        return '';
    }

    public function debugIssueThumbnailLookup(string $offerId, string $productId = '', string $checkoutFormId = '', string $issueId = '', bool $refresh = false): array
    {
        $offerId = trim($offerId);
        $productId = trim($productId);
        $checkoutFormId = trim($checkoutFormId);
        $issueId = trim($issueId);

        $debug = [
            'ok' => false,
            'generated_at' => date('c'),
            'module_version' => $this->version,
            'thumbnail_logic_version' => 'ps-v15-linked-order-fallback',
            'inputs' => [
                'offer_id' => $offerId,
                'product_id' => $productId,
                'checkout_form_id' => $checkoutFormId,
                'issue_id' => $issueId,
            ],
            'resolved' => [
                'offer_id' => $offerId,
                'product_id' => $productId,
                'checkout_form_id' => $checkoutFormId,
                'issue_id' => $issueId,
            ],
            'cache' => [
                'keys' => [],
                'hit' => false,
                'url' => '',
                'refresh' => $refresh,
            ],
            'api' => [
                'issue' => null,
                'chat' => null,
                'checkout_form' => null,
            ],
            'checkout_form' => null,
            'final_url' => '',
            'reason' => '',
        ];

        try {
            $apiClient = new AllegroApiClient(new TokenManager());
            $issuePayload = [];
            $messages = [];

            if ($issueId !== '') {
                try {
                    $issuePayload = $apiClient->getIssue($issueId);
                    $issueContext = $this->extractIssueThumbnailContext($issuePayload);
                    $debug['api']['issue'] = [
                        'ok' => true,
                        'context' => $issueContext,
                    ];

                    if ($issuePayload) {
                        if ($offerId === '' && !empty($issueContext['offer_id'])) {
                            $offerId = (string) $issueContext['offer_id'];
                        }
                        if ($productId === '' && !empty($issueContext['product_id'])) {
                            $productId = (string) $issueContext['product_id'];
                        }
                        if ($checkoutFormId === '' && !empty($issueContext['checkout_form_id'])) {
                            $checkoutFormId = (string) $issueContext['checkout_form_id'];
                        }
                    }
                } catch (Throwable $e) {
                    $debug['api']['issue'] = [
                        'ok' => false,
                        'error' => $e->getMessage(),
                    ];
                }

                try {
                    $messagesResponse = $apiClient->getIssueChat($issueId, 100);
                    $messages = $messagesResponse['chat'] ?? $messagesResponse['messages'] ?? [];
                    $chatCheckoutFormIds = [];
                    $chatOfferIds = [];

                    if (is_array($messages)) {
                        foreach ($messages as $message) {
                            if (!is_array($message)) {
                                continue;
                            }

                            foreach ($this->extractCheckoutFormIdsFromPayload($message) as $id) {
                                $chatCheckoutFormIds[(string) $id] = true;
                            }

                            foreach ($this->extractIssueOfferIdsFromPayload($message) as $id) {
                                $chatOfferIds[(string) $id] = true;
                            }
                        }

                        if ($checkoutFormId === '' && $chatCheckoutFormIds) {
                            foreach (array_keys($chatCheckoutFormIds) as $id) {
                                $checkoutFormId = (string) $id;
                                break;
                            }
                        }

                        if ($offerId === '' && $chatOfferIds) {
                            foreach (array_keys($chatOfferIds) as $id) {
                                $offerId = (string) $id;
                                break;
                            }
                        }
                    }

                    $debug['api']['chat'] = [
                        'ok' => is_array($messages),
                        'message_count' => is_array($messages) ? count($messages) : 0,
                        'checkout_form_ids' => array_keys($chatCheckoutFormIds),
                        'offer_ids' => array_keys($chatOfferIds),
                    ];
                } catch (Throwable $e) {
                    $debug['api']['chat'] = [
                        'ok' => false,
                        'error' => $e->getMessage(),
                    ];
                }
            }

            $debug['resolved'] = [
                'offer_id' => $offerId,
                'product_id' => $productId,
                'checkout_form_id' => $checkoutFormId,
                'issue_id' => $issueId,
            ];

            $cacheKeys = $this->buildIssueThumbnailCacheKeys($offerId, $checkoutFormId, '', $issueId);
            $cachedUrl = $this->getIssueThumbnailFromCaches($cacheKeys);
            $debug['cache'] = [
                'keys' => $cacheKeys,
                'hit' => $cachedUrl !== '',
                'url' => $cachedUrl,
                'refresh' => $refresh,
            ];

            $thumbnailUrl = $refresh ? '' : $cachedUrl;
            if ($thumbnailUrl === '' && $checkoutFormId !== '') {
                $checkoutFormPayload = [];
                $source = 'api';

                try {
                    $checkoutFormPayload = $apiClient->getCheckoutForm($checkoutFormId);
                    $debug['api']['checkout_form'] = ['ok' => true, 'source' => 'api'];
                } catch (Throwable $e) {
                    $debug['api']['checkout_form'] = [
                        'ok' => false,
                        'source' => 'api',
                        'error' => $e->getMessage(),
                    ];
                    $checkoutFormPayload = $this->getStoredCheckoutFormContent($checkoutFormId);
                    $source = 'stored_checkout_form';
                }

                if (is_array($checkoutFormPayload) && $checkoutFormPayload) {
                    $debug['checkout_form'] = $this->summarizeCheckoutFormThumbnailDiagnostics($checkoutFormPayload, $offerId);
                    $debug['checkout_form']['source'] = $source;
                    $prestashopSignatureDebug = [];
                    $thumbnailUrl = $this->findPrestashopProductThumbnailByCheckoutFormSignature($checkoutFormPayload, $offerId, $prestashopSignatureDebug);
                    $debug['prestashop_signature_lookup'] = $prestashopSignatureDebug;
                    if ($thumbnailUrl === '' && $checkoutFormId !== '') {
                        $prestashopOrderDebug = [];
                        $thumbnailUrl = $this->findPrestashopOrderThumbnailByCheckoutFormSignature($checkoutFormId, $checkoutFormPayload, $offerId, $prestashopOrderDebug);
                        $debug['prestashop_order_lookup'] = $prestashopOrderDebug;
                    }
                    $debug['checkout_form']['allegro_image_url_ignored'] = $this->extractAllegroOrderImageUrlFromCheckoutForm($checkoutFormPayload, $offerId);

                    if ($thumbnailUrl === '') {
                        $resolvedOfferId = $this->extractFirstOfferIdFromCheckoutForm($checkoutFormPayload);
                        if ($offerId === '' && $resolvedOfferId !== '') {
                            $offerId = $resolvedOfferId;
                        }
                    }
                } else {
                    $debug['checkout_form'] = [
                        'source' => $source,
                        'present' => false,
                    ];
                }
            }

            if ($thumbnailUrl === '' && $checkoutFormId !== '') {
                $linkedOrderFallbackUrl = $this->resolvePrestashopOrderThumbnailUrlByCheckoutFormId(
                    $checkoutFormId,
                    $offerId,
                    is_array($checkoutFormPayload ?? null) ? $checkoutFormPayload : []
                );
                $debug['linked_order_fallback'] = [
                    'attempted' => true,
                    'url' => $linkedOrderFallbackUrl,
                ];
                $thumbnailUrl = $linkedOrderFallbackUrl;
            }

            if ($thumbnailUrl === '') {
                $allegroProductLookupDebug = [];
                $identifierPayloads = [];
                if (is_array($issuePayload) && $issuePayload) {
                    $identifierPayloads[] = $issuePayload;
                }
                if (is_array($messages)) {
                    foreach ($messages as $message) {
                        if (is_array($message)) {
                            $identifierPayloads[] = $message;
                        }
                    }
                }

                $thumbnailUrl = $this->findPrestashopThumbnailByAllegroProductIdentifiers(
                    $apiClient,
                    $offerId,
                    $productId,
                    $checkoutFormId,
                    $identifierPayloads,
                    $allegroProductLookupDebug
                );
                if ($allegroProductLookupDebug) {
                    $debug['allegro_product_identifier_lookup'] = $allegroProductLookupDebug;
                }
            }

            if ($thumbnailUrl !== '') {
                $this->storeIssueThumbnailCaches($this->buildIssueThumbnailCacheKeys($offerId, $checkoutFormId, '', $issueId), $thumbnailUrl);
                $debug['ok'] = true;
                $debug['final_url'] = $thumbnailUrl;
                if ($cachedUrl !== '' && !$refresh) {
                    $debug['reason'] = 'cache_hit';
                } elseif (!empty($debug['prestashop_signature_lookup']['url'])) {
                    $debug['reason'] = 'prestashop_signature_image';
                } elseif (!empty($debug['prestashop_order_lookup']['url'])) {
                    $debug['reason'] = 'prestashop_order_detail_image';
                } elseif (!empty($debug['allegro_product_identifier_lookup']['url'])) {
                    $debug['reason'] = 'allegro_product_identifier_image';
                } else {
                    $debug['reason'] = 'prestashop_image';
                }
            } elseif ($checkoutFormId === '') {
                $debug['reason'] = 'missing_checkout_form_id';
            } else {
                $debug['reason'] = 'prestashop_thumbnail_not_found';
            }
        } catch (Throwable $e) {
            $debug['reason'] = 'exception';
            $debug['error'] = $e->getMessage();
        }

        return $debug;
    }

    protected function buildIssueThumbnailCacheKeys(string $offerId = '', string $checkoutFormId = '', string $productId = '', string $issueId = ''): array
    {
        $issueId = trim($issueId);
        if ($issueId !== '') {
            $keys = ['issue-ps-v15:' . $issueId => true];

            $offerId = trim($offerId);
            if ($offerId !== '') {
                $keys['offer-ps-v15:' . $offerId] = true;
            }

            $checkoutFormId = trim($checkoutFormId);
            if ($checkoutFormId !== '') {
                $keys['checkout-ps-v15:' . $checkoutFormId] = true;
            }

            return array_keys($keys);
        }

        $keys = [];
        $primaryKey = $this->buildIssueThumbnailCacheKey($offerId, $checkoutFormId, $productId);
        if ($primaryKey !== '') {
            $keys[$primaryKey] = true;
        }

        $offerId = trim($offerId);
        if ($offerId !== '') {
            $keys['offer-ps-v15:' . $offerId] = true;
        }

        $checkoutFormId = trim($checkoutFormId);
        if ($checkoutFormId !== '') {
            $keys['checkout-ps-v15:' . $checkoutFormId] = true;
        }

        $productId = trim($productId);
        if ($productId !== '') {
            $keys['product-ps-v15:' . $productId] = true;
        }

        return array_keys($keys);
    }

    protected function buildIssueThumbnailCacheKey(string $offerId = '', string $checkoutFormId = '', string $productId = ''): string
    {
        $offerId = trim($offerId);
        if ($offerId !== '') {
            return 'offer-ps-v15:' . $offerId;
        }

        $checkoutFormId = trim($checkoutFormId);
        if ($checkoutFormId !== '') {
            return 'checkout-ps-v15:' . $checkoutFormId;
        }

        $productId = trim($productId);
        if ($productId !== '') {
            return 'product-ps-v15:' . $productId;
        }

        return '';
    }

    protected function normalizeIssueImageUrl($value): string
    {
        if (is_string($value)) {
            $value = trim($value);
            if ($value !== '' && strpos($value, '//') === 0) {
                $value = 'https:' . $value;
            }
            if ($value !== '' && preg_match('~^https?://~i', $value) && $this->isAllegroApiImageUrl($value)) {
                return $this->getProxiedAllegroImageUrl($value);
            }
            if ($value !== '' && preg_match('~^https?://~i', $value) && $this->isAllowedIssueImageUrl($value)) {
                return $value;
            }
        }

        if (is_array($value) && !empty($value['url']) && is_string($value['url'])) {
            $url = trim($value['url']);
            if ($url !== '' && strpos($url, '//') === 0) {
                $url = 'https:' . $url;
            }
            if ($url !== '' && preg_match('~^https?://~i', $url) && $this->isAllegroApiImageUrl($url)) {
                return $this->getProxiedAllegroImageUrl($url);
            }
            if ($url !== '' && preg_match('~^https?://~i', $url) && $this->isAllowedIssueImageUrl($url)) {
                return $url;
            }
        }

        return '';
    }

    protected function isAllegroApiImageUrl(string $url): bool
    {
        $host = strtolower((string) parse_url($url, PHP_URL_HOST));

        return $host === 'api.allegro.pl' || substr($host, -15) === '.api.allegro.pl';
    }

    protected function getProxiedAllegroImageUrl(string $url): string
    {
        return (string) $this->context->link->getModuleLink($this->name, 'image', [
            'token' => (string) Configuration::get(self::CONFIG_PREFIX . 'CRON_TOKEN'),
            'url' => base64_encode($url),
        ]);
    }

    protected function isAllowedIssueImageUrl(string $url): bool
    {
        $host = strtolower((string) parse_url($url, PHP_URL_HOST));
        if ($host === '') {
            return false;
        }

        if ($host === 'api.allegro.pl' || substr($host, -15) === '.api.allegro.pl') {
            return false;
        }

        return true;
    }

    protected function extractIssueThumbnailContext(array $issue): array
    {
        $offerIds = $this->extractIssueOfferIdsFromPayload($issue);
        $productIds = $this->extractIssueProductIdsFromPayload($issue);
        $checkoutFormIds = $this->extractCheckoutFormIdsFromPayload($issue);

        return [
            'issue_id' => trim((string) ($issue['id'] ?? '')),
            'offer_id' => $offerIds[0] ?? '',
            'product_id' => $productIds[0] ?? '',
            'checkout_form_id' => $checkoutFormIds[0] ?? '',
        ];
    }

    protected function extractIssueOfferIdsFromPayload(array $payload, array $path = [], int $depth = 0): array
    {
        if ($depth > 8) {
            return [];
        }

        $ids = [];
        foreach ($payload as $key => $value) {
            $keyString = (string) $key;
            $normalizedKey = strtolower(preg_replace('/[^a-z0-9]/i', '', $keyString));
            $currentPath = array_merge($path, [$normalizedKey]);

            if (is_scalar($value)) {
                $candidate = $this->normalizeOptionalId($value);
                if ($candidate !== '' && $this->isIssueOfferIdPath($currentPath)) {
                    $ids[$candidate] = true;
                }

                continue;
            }

            if (is_array($value)) {
                if ($normalizedKey === 'offer' && is_scalar($value['id'] ?? null)) {
                    $candidate = $this->normalizeOptionalId($value['id']);
                    if ($candidate !== '') {
                        $ids[$candidate] = true;
                    }
                }

                foreach ($this->extractIssueOfferIdsFromPayload($value, $currentPath, $depth + 1) as $candidate) {
                    $ids[$candidate] = true;
                }
            }
        }

        return array_keys($ids);
    }

    protected function isIssueOfferIdPath(array $path): bool
    {
        $last = end($path);
        if (in_array($last, ['offerid', 'idoferta', 'idoferty'], true)) {
            return true;
        }

        if ($last !== 'id') {
            return false;
        }

        $previous = count($path) > 1 ? $path[count($path) - 2] : '';

        return $previous === 'offer' || $previous === 'offers';
    }

    protected function extractIssueProductIdsFromPayload(array $payload, array $path = [], int $depth = 0): array
    {
        if ($depth > 8) {
            return [];
        }

        $ids = [];
        foreach ($payload as $key => $value) {
            $keyString = (string) $key;
            $normalizedKey = strtolower(preg_replace('/[^a-z0-9]/i', '', $keyString));
            $currentPath = array_merge($path, [$normalizedKey]);

            if (is_scalar($value)) {
                $candidate = $this->normalizeOptionalId($value);
                if ($candidate !== '' && $this->isIssueProductIdPath($currentPath)) {
                    $ids[$candidate] = true;
                }

                continue;
            }

            if (is_array($value)) {
                if ($normalizedKey === 'product' && is_scalar($value['id'] ?? null)) {
                    $candidate = $this->normalizeOptionalId($value['id']);
                    if ($candidate !== '') {
                        $ids[$candidate] = true;
                    }
                }

                foreach ($this->extractIssueProductIdsFromPayload($value, $currentPath, $depth + 1) as $candidate) {
                    $ids[$candidate] = true;
                }
            }
        }

        return array_keys($ids);
    }

    protected function isIssueProductIdPath(array $path): bool
    {
        $last = end($path);
        if (in_array($last, ['productid', 'idproduct'], true)) {
            return true;
        }

        if ($last !== 'id') {
            return false;
        }

        $previous = count($path) > 1 ? $path[count($path) - 2] : '';

        return $previous === 'product' || $previous === 'products';
    }

    protected function maybeDumpIssueDebugPayload(string $selectedIssueId, array $selectedIssue, array $messagesResponse, array $messages, array $issues): void
    {
        if ((int) Tools::getValue('aar_debug_issue') !== 1 || $selectedIssueId === '') {
            return;
        }

        $debugDir = __DIR__ . '/var/debug';
        if (!is_dir($debugDir)) {
            @mkdir($debugDir, 0775, true);
        }

        if (!is_dir($debugDir) || !is_writable($debugDir)) {
            PrestaShopLogger::addLog('[AAR] Issue debug dump skipped. Directory is not writable: ' . $debugDir, 2);

            return;
        }

        $payload = [
            'generated_at' => date('c'),
            'selected_issue_id' => $selectedIssueId,
            'selected_issue' => $selectedIssue,
            'messages_response' => $messagesResponse,
            'messages_sorted' => $messages,
            'issues_list_item' => $this->findIssueById($issues, $selectedIssueId) ?: [],
        ];

        $filePath = $debugDir . '/issue-' . preg_replace('/[^a-zA-Z0-9_-]/', '-', $selectedIssueId) . '.json';
        $written = @file_put_contents($filePath, json_encode($payload, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));

        if ($written === false) {
            PrestaShopLogger::addLog('[AAR] Issue debug dump write failed for ' . $selectedIssueId, 2);

            return;
        }

        PrestaShopLogger::addLog('[AAR] Issue debug dump saved: ' . $filePath, 1);
    }

    protected function maybeDumpCustomerReturnDebugPayload(string $selectedReturnId, array $selectedReturn, array $returns, array $selectedReturnRaw = []): void
    {
        if ((int) Tools::getValue('aar_debug_return') !== 1 || $selectedReturnId === '') {
            return;
        }

        $debugDir = __DIR__ . '/var/debug';
        if (!is_dir($debugDir)) {
            @mkdir($debugDir, 0775, true);
        }

        if (!is_dir($debugDir) || !is_writable($debugDir)) {
            PrestaShopLogger::addLog('[AAR] Customer return debug dump skipped. Directory is not writable: ' . $debugDir, 2);

            return;
        }

        $payload = [
            'generated_at' => date('c'),
            'selected_return_id' => $selectedReturnId,
            'selected_return' => $selectedReturn,
            'selected_return_raw' => $selectedReturnRaw,
            'returns_list_item' => $this->findCustomerReturnById($returns, $selectedReturnId) ?: [],
        ];

        $filePath = $debugDir . '/customer-return-' . preg_replace('/[^a-zA-Z0-9_-]/', '-', $selectedReturnId) . '.json';
        $written = @file_put_contents($filePath, json_encode($payload, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));

        if ($written === false) {
            PrestaShopLogger::addLog('[AAR] Customer return debug dump write failed for ' . $selectedReturnId, 2);

            return;
        }

        PrestaShopLogger::addLog('[AAR] Customer return debug dump saved: ' . $filePath, 1);
    }

    protected function maybeDumpIssueOfferDebugPayload(AllegroApiClient $apiClient, array $selectedIssue): void
    {
        if ((int) Tools::getValue('aar_debug_issue') !== 1) {
            return;
        }

        $offerId = trim((string) ($selectedIssue['offer']['id'] ?? ''));
        if ($offerId === '') {
            return;
        }

        $debugDir = __DIR__ . '/var/debug';
        if (!is_dir($debugDir)) {
            @mkdir($debugDir, 0775, true);
        }

        if (!is_dir($debugDir) || !is_writable($debugDir)) {
            PrestaShopLogger::addLog('[AAR] Offer debug dump skipped. Directory is not writable: ' . $debugDir, 2);

            return;
        }

        $payload = [
            'generated_at' => date('c'),
            'offer_id' => $offerId,
            'product_offer' => null,
            'product_offer_error' => null,
        ];

        try {
            $payload['product_offer'] = $apiClient->getProductOffer($offerId);
        } catch (Throwable $e) {
            $payload['product_offer_error'] = $e->getMessage();
        }

        $filePath = $debugDir . '/offer-' . preg_replace('/[^a-zA-Z0-9_-]/', '-', $offerId) . '.json';
        $written = @file_put_contents($filePath, json_encode($payload, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));

        if ($written === false) {
            PrestaShopLogger::addLog('[AAR] Offer debug dump write failed for ' . $offerId, 2);

            return;
        }

        PrestaShopLogger::addLog('[AAR] Offer debug dump saved: ' . $filePath, 1);
    }

    protected function maybeDumpIssueCheckoutFormDebugPayload(AllegroApiClient $apiClient, array $selectedIssue): void
    {
        if ((int) Tools::getValue('aar_debug_issue') !== 1) {
            return;
        }

        $checkoutFormId = $this->extractIssueCheckoutFormId($selectedIssue);
        if ($checkoutFormId === '') {
            return;
        }

        $debugDir = __DIR__ . '/var/debug';
        if (!is_dir($debugDir)) {
            @mkdir($debugDir, 0775, true);
        }

        if (!is_dir($debugDir) || !is_writable($debugDir)) {
            PrestaShopLogger::addLog('[AAR] Checkout form debug dump skipped. Directory is not writable: ' . $debugDir, 2);

            return;
        }

        $payload = [
            'generated_at' => date('c'),
            'checkout_form_id' => $checkoutFormId,
            'checkout_form' => null,
            'checkout_form_error' => null,
            'first_offer_id' => null,
            'product_offer' => null,
            'product_offer_error' => null,
        ];

        try {
            $payload['checkout_form'] = $apiClient->getCheckoutForm($checkoutFormId);
        } catch (Throwable $e) {
            $payload['checkout_form_error'] = $e->getMessage();
        }

        $firstOfferId = '';
        if (is_array($payload['checkout_form'])) {
            $firstOfferId = $this->extractFirstOfferIdFromCheckoutForm($payload['checkout_form']);
        }

        if ($firstOfferId !== '') {
            $payload['first_offer_id'] = $firstOfferId;

            try {
                $payload['product_offer'] = $apiClient->getProductOffer($firstOfferId);
            } catch (Throwable $e) {
                $payload['product_offer_error'] = $e->getMessage();
            }
        }

        $filePath = $debugDir . '/checkout-form-' . preg_replace('/[^a-zA-Z0-9_-]/', '-', $checkoutFormId) . '.json';
        $written = @file_put_contents($filePath, json_encode($payload, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));

        if ($written === false) {
            PrestaShopLogger::addLog('[AAR] Checkout form debug dump write failed for ' . $checkoutFormId, 2);

            return;
        }

        PrestaShopLogger::addLog('[AAR] Checkout form debug dump saved: ' . $filePath, 1);
    }

    protected function findImageUrlRecursively(array $payload, int $depth = 0): string
    {
        if ($depth > 6) {
            return '';
        }

        foreach ($payload as $key => $value) {
            if (is_string($value)) {
                $url = trim($value);
                if (
                    $url !== ''
                    && preg_match('~^https?://~i', $url)
                    && ($this->isAllowedIssueImageUrl($url) || $this->isAllegroApiImageUrl($url))
                    && (
                        stripos($url, 'allegroimg.com') !== false
                        || $this->isAllegroApiImageUrl($url)
                        || preg_match('~(^|_)(img|image|thumbnail)(_|$)~i', (string) $key)
                    )
                ) {
                    return $this->isAllegroApiImageUrl($url) ? $this->getProxiedAllegroImageUrl($url) : $url;
                }

                continue;
            }

            if (is_array($value)) {
                $directUrl = $this->normalizeIssueImageUrl($value);
                if ($directUrl !== '') {
                    return $directUrl;
                }

                $nestedUrl = $this->findImageUrlRecursively($value, $depth + 1);
                if ($nestedUrl !== '') {
                    return $nestedUrl;
                }
            }
        }

        return '';
    }

    protected function getIssueThumbnailCache(): array
    {
        $raw = Configuration::get(self::ISSUE_THUMB_CACHE_CONFIG);
        $cache = json_decode((string) $raw, true);

        return is_array($cache) ? $cache : [];
    }

    protected function getIssueThumbnailFromCache(string $offerId): string
    {
        if ($offerId === '') {
            return '';
        }

        $cache = $this->getIssueThumbnailCache();
        $url = $cache[$offerId] ?? '';

        return is_string($url) ? $this->normalizeIssueImageUrl($url) : '';
    }

    protected function getIssueThumbnailFromCaches(array $cacheKeys): string
    {
        foreach ($cacheKeys as $cacheKey) {
            $cachedUrl = $this->getIssueThumbnailFromCache((string) $cacheKey);
            if ($cachedUrl !== '') {
                return $cachedUrl;
            }
        }

        return '';
    }

    protected function storeIssueThumbnailCache(string $offerId, string $imageUrl): void
    {
        $offerId = trim($offerId);
        $imageUrl = trim($imageUrl);
        if ($offerId === '' || $imageUrl === '') {
            return;
        }

        $cache = $this->getIssueThumbnailCache();
        $cache[$offerId] = $imageUrl;

        if (count($cache) > 500) {
            $cache = array_slice($cache, -500, null, true);
        }

        Configuration::updateValue(self::ISSUE_THUMB_CACHE_CONFIG, json_encode($cache, JSON_UNESCAPED_SLASHES));
    }

    protected function storeIssueThumbnailCaches(array $cacheKeys, string $imageUrl): void
    {
        foreach ($cacheKeys as $cacheKey) {
            $this->storeIssueThumbnailCache((string) $cacheKey, $imageUrl);
        }
    }

    protected function getIssueThumbnailImageUrl(array $issue): string
    {
        $thumbnailContext = $this->extractIssueThumbnailContext($issue);
        $offerId = $thumbnailContext['offer_id'];
        $productId = $thumbnailContext['product_id'];
        $checkoutFormId = $thumbnailContext['checkout_form_id'];
        $issueId = $thumbnailContext['issue_id'];

        if ($offerId === '' && $productId === '' && $checkoutFormId === '' && $issueId === '') {
            return '';
        }

        return $this->context->link->getModuleLink($this->name, 'thumbnail', [
            'token' => (string) Configuration::get(self::CONFIG_PREFIX . 'CRON_TOKEN'),
            'offer_id' => $offerId,
            'product_id' => $issueId === '' ? $productId : '',
            'checkout_form_id' => $checkoutFormId,
            'issue_id' => $issueId,
            'mode' => 'image',
        ]);
    }

    protected function getIssueThumbnailDebugUrl(array $issue): string
    {
        $thumbnailContext = $this->extractIssueThumbnailContext($issue);
        $offerId = $thumbnailContext['offer_id'];
        $productId = $thumbnailContext['product_id'];
        $checkoutFormId = $thumbnailContext['checkout_form_id'];
        $issueId = $thumbnailContext['issue_id'];

        if ($offerId === '' && $productId === '' && $checkoutFormId === '' && $issueId === '') {
            return '';
        }

        return $this->context->link->getModuleLink($this->name, 'thumbnail', [
            'token' => (string) Configuration::get(self::CONFIG_PREFIX . 'CRON_TOKEN'),
            'offer_id' => $offerId,
            'product_id' => $issueId === '' ? $productId : '',
            'checkout_form_id' => $checkoutFormId,
            'issue_id' => $issueId,
            'debug' => 1,
            'refresh' => 1,
        ]);
    }

    protected function getThumbnailImageFallbackAttributes(string $debugUrl = ''): string
    {
        $debugAttribute = $debugUrl !== '' ? ' data-aar-thumb-debug-url="' . Tools::safeOutput($debugUrl) . '"' : '';
        $errorHandler = "this.style.display='none'; if(this.nextElementSibling){ this.nextElementSibling.style.display='block'; }"
            . " var u=this.getAttribute('data-aar-thumb-debug-url');"
            . " if(u&&window.console){ console.warn('[AAR] Thumbnail failed', this.src, u); }"
            . " if(u&&window.fetch){ fetch(u,{credentials:'same-origin'}).then(function(r){return r.json();}).then(function(j){ if(window.console){ console.log('[AAR] Thumbnail diagnostics', j); } }).catch(function(e){ if(window.console){ console.warn('[AAR] Thumbnail diagnostics failed', e); } }); }";

        return $debugAttribute . ' onload="if(this.nextElementSibling){ this.nextElementSibling.style.display=\'none\'; }" onerror="' . Tools::safeOutput($errorHandler) . '"';
    }

    protected function getCustomerReturnThumbnailImageUrl(array $return): string
    {
        $checkoutForm = is_array($return['_checkout_form'] ?? null) ? $return['_checkout_form'] : [];
        $eanThumbnailUrl = $this->findCustomerReturnThumbnailByEan13($return, $checkoutForm);
        if ($eanThumbnailUrl !== '') {
            return $eanThumbnailUrl;
        }

        $orderThumbnailUrl = $this->findCustomerReturnThumbnailFromLinkedOrder($return, $checkoutForm);
        if ($orderThumbnailUrl !== '') {
            return $orderThumbnailUrl;
        }

        if ($checkoutForm) {
            $prestashopThumbnailUrl = $this->findPrestashopProductThumbnailByCheckoutForm($checkoutForm);
            if ($prestashopThumbnailUrl !== '') {
                return $prestashopThumbnailUrl;
            }
        }

        foreach (($return['items'] ?? []) as $item) {
            if (!is_array($item)) {
                continue;
            }

            $prestashopThumbnailUrl = $this->findPrestashopProductThumbnailByReturnItem($item);
            if ($prestashopThumbnailUrl !== '') {
                return $prestashopThumbnailUrl;
            }
        }

        $offerId = '';
        foreach (($return['items'] ?? []) as $item) {
            if (!is_array($item)) {
                continue;
            }

            $offerId = trim((string) ($item['offerId'] ?? $item['offer']['id'] ?? ''));
            if ($offerId !== '') {
                break;
            }
        }

        $checkoutFormId = trim((string) ($return['orderId'] ?? $return['order']['id'] ?? ''));
        $returnId = trim((string) ($return['id'] ?? ''));
        if ($returnId !== '') {
            return $this->context->link->getModuleLink($this->name, 'returnthumbnail', [
                'token' => (string) Configuration::get(self::CONFIG_PREFIX . 'CRON_TOKEN'),
                'return_id' => $returnId,
            ]);
        }
        if ($offerId === '' && $checkoutFormId === '') {
            foreach (($return['items'] ?? []) as $item) {
                if (!is_array($item)) {
                    continue;
                }

                $directUrl = $this->resolveCustomerReturnItemThumbnailUrl($item, $return);
                if ($directUrl !== '') {
                    return $directUrl;
                }
            }

            return '';
        }

        return $this->context->link->getModuleLink($this->name, 'thumbnail', [
            'token' => (string) Configuration::get(self::CONFIG_PREFIX . 'CRON_TOKEN'),
            'offer_id' => $offerId,
            'checkout_form_id' => $checkoutFormId,
            'mode' => 'image',
        ]);
    }

    protected function getCustomerReturnListThumbnailImageUrl(string $returnId, array $return = []): string
    {
        $returnId = trim($returnId);
        if ($returnId === '') {
            return '';
        }

        $cachedUrl = $this->getCustomerReturnThumbnailFromCache($returnId);
        if ($cachedUrl !== '') {
            return $cachedUrl;
        }

        $offerId = '';
        foreach (($return['items'] ?? []) as $item) {
            if (!is_array($item)) {
                continue;
            }
            $offerId = trim((string) ($item['offerId'] ?? $item['offer']['id'] ?? ''));
            if ($offerId !== '') {
                break;
            }
        }
        $checkoutFormId = trim((string) ($return['orderId'] ?? $return['order']['id'] ?? ''));
        if ($offerId !== '' || $checkoutFormId !== '') {
            return $this->context->link->getModuleLink($this->name, 'thumbnail', [
                'token' => (string) Configuration::get(self::CONFIG_PREFIX . 'CRON_TOKEN'),
                'offer_id' => $offerId,
                'checkout_form_id' => $checkoutFormId,
                'mode' => 'image',
            ]);
        }

        return $this->context->link->getModuleLink($this->name, 'returnthumbnail', [
            'token' => (string) Configuration::get(self::CONFIG_PREFIX . 'CRON_TOKEN'),
            'return_id' => $returnId,
        ]);
    }

    protected function warmCustomerReturnListThumbnailCache(array $returns, array $selectedReturn = []): void
    {
        $selectedReturnId = trim((string) ($selectedReturn['id'] ?? ''));

        foreach ($returns as $return) {
            if (!is_array($return)) {
                continue;
            }

            $returnId = trim((string) ($return['id'] ?? ''));
            if ($returnId === '' || $this->getCustomerReturnThumbnailFromCache($returnId) !== '') {
                continue;
            }

            $source = $returnId === $selectedReturnId && $selectedReturn ? $selectedReturn : $return;
            $checkoutForm = is_array($source['_checkout_form'] ?? null) ? $source['_checkout_form'] : [];
            if (!$checkoutForm) {
                $checkoutFormId = trim((string) ($source['orderId'] ?? $source['order']['id'] ?? ''));
                if ($checkoutFormId !== '') {
                    $checkoutForm = $this->getStoredCheckoutFormContent($checkoutFormId);
                    if ($checkoutForm) {
                        $source['_checkout_form'] = $checkoutForm;
                    }
                }
            }

            foreach (($source['items'] ?? []) as $item) {
                if (!is_array($item)) {
                    continue;
                }

                $url = $this->resolveCustomerReturnItemThumbnailUrl($item, $source);
                if ($url !== '') {
                    $this->storeCustomerReturnThumbnailCache($returnId, $url);
                    break;
                }
            }
        }
    }

    protected function getCustomerReturnThumbnailFromCache(string $returnId): string
    {
        $cache = json_decode((string) Configuration::get(self::RETURN_THUMB_CACHE_CONFIG), true);
        if (!is_array($cache)) {
            return '';
        }

        $cachedUrl = trim((string) ($cache['return-v2:' . trim($returnId)] ?? ''));
        if ($cachedUrl !== '' && strpos($cachedUrl, '/') === 0 && strpos($cachedUrl, '//') !== 0) {
            return $cachedUrl;
        }

        return $this->normalizeIssueImageUrl($cachedUrl);
    }

    protected function storeCustomerReturnThumbnailCache(string $returnId, string $url): void
    {
        $returnId = trim($returnId);
        $url = trim($url);
        if ($returnId === '' || $url === '') {
            return;
        }

        $cache = json_decode((string) Configuration::get(self::RETURN_THUMB_CACHE_CONFIG), true);
        if (!is_array($cache)) {
            $cache = [];
        }
        $cache['return-v2:' . $returnId] = $url;
        if (count($cache) > 500) {
            $cache = array_slice($cache, -500, null, true);
        }
        Configuration::updateValue(self::RETURN_THUMB_CACHE_CONFIG, json_encode($cache, JSON_UNESCAPED_SLASHES));
    }

    public function resolveCustomerReturnThumbnailById(string $returnId): string
    {
        $returnId = trim($returnId);
        if ($returnId === '') {
            return '';
        }

        $cachedUrl = $this->getCustomerReturnThumbnailFromCache($returnId);
        if ($cachedUrl !== '') {
            return $cachedUrl;
        }

        $apiClient = new AllegroApiClient(new TokenManager());
        $return = $apiClient->getCustomerReturn($returnId);
        if (!is_array($return) || !$return) {
            return '';
        }

        $return = $this->enrichCustomerReturnWithCheckoutForm($apiClient, $return);
        $checkoutForm = is_array($return['_checkout_form'] ?? null) ? $return['_checkout_form'] : [];
        $checkoutFormId = trim((string) ($return['orderId'] ?? $return['order']['id'] ?? ''));

        // The product rows in return details already use the most reliable,
        // item-specific resolver. Reuse its first valid result for the list so
        // both places always display the same product image.
        foreach (($return['items'] ?? []) as $item) {
            if (!is_array($item)) {
                continue;
            }

            $itemThumbnailUrl = $this->resolveCustomerReturnItemThumbnailUrl($item, $return);
            if ($itemThumbnailUrl !== '') {
                $this->storeCustomerReturnThumbnailCache($returnId, $itemThumbnailUrl);

                return $itemThumbnailUrl;
            }
        }

        $eanThumbnailUrl = $this->findCustomerReturnThumbnailByEan13($return, $checkoutForm);
        if ($eanThumbnailUrl !== '') {
            $this->storeCustomerReturnThumbnailCache($returnId, $eanThumbnailUrl);

            return $eanThumbnailUrl;
        }

        $orderThumbnailUrl = $this->findCustomerReturnThumbnailFromLinkedOrder($return, $checkoutForm);
        if ($orderThumbnailUrl !== '') {
            $this->storeCustomerReturnThumbnailCache($returnId, $orderThumbnailUrl);

            return $orderThumbnailUrl;
        }

        foreach (($return['items'] ?? []) as $item) {
            if (!is_array($item)) {
                continue;
            }

            $url = $this->findPrestashopProductThumbnailByReturnItem($item);
            if ($url !== '') {
                $this->storeCustomerReturnThumbnailCache($returnId, $url);

                return $url;
            }

            foreach ([
                $item['imageUrl'] ?? null,
                $item['thumbnailUrl'] ?? null,
                $item['image'] ?? null,
                $item['thumbnail'] ?? null,
            ] as $candidate) {
                $url = $this->normalizeIssueImageUrl($candidate);
                if ($url !== '') {
                    $this->storeCustomerReturnThumbnailCache($returnId, $url);

                    return $url;
                }
            }

            $offerId = trim((string) ($item['offerId'] ?? $item['offer']['id'] ?? ''));
            if ($offerId !== '') {
                try {
                    $offer = $apiClient->getProductOffer($offerId);
                    if (is_array($offer)) {
                        $url = $this->findPrestashopThumbnailByEan13Payload($offer);
                        if ($url === '') {
                            $url = $this->findPrestashopProductThumbnailByOfferPayload($offer);
                        }
                        if ($url === '') {
                            $url = $this->findImageUrlRecursively($offer);
                        }
                        if ($url !== '') {
                            $this->storeCustomerReturnThumbnailCache($returnId, $url);

                            return $url;
                        }
                    }
                } catch (Throwable $e) {
                    PrestaShopLogger::addLog('[AAR] Return thumbnail offer lookup failed for ' . $offerId . ': ' . $e->getMessage(), 2);
                }
            }
        }

        if ($checkoutForm) {
            $url = $this->findPrestashopProductThumbnailByCheckoutForm($checkoutForm);
            if ($url === '') {
                $url = $this->findImageUrlRecursively($checkoutForm);
            }
            if ($url !== '') {
                $this->storeCustomerReturnThumbnailCache($returnId, $url);

                return $url;
            }
        }

        $url = $checkoutFormId !== ''
            ? $this->resolvePrestashopOrderThumbnailUrlByCheckoutFormId($checkoutFormId, '', $checkoutForm)
            : '';
        if ($url !== '') {
            $this->storeCustomerReturnThumbnailCache($returnId, $url);
        }

        return $url;
    }

    protected function findCustomerReturnThumbnailByEan13(array $return, array $checkoutForm = []): string
    {
        foreach (($return['items'] ?? []) as $item) {
            if (!is_array($item)) {
                continue;
            }

            $url = $this->findPrestashopThumbnailByEan13Payload($item);
            if ($url !== '') {
                return $url;
            }

            $offerId = trim((string) ($item['offerId'] ?? $item['offer']['id'] ?? ''));
            if ($offerId === '') {
                continue;
            }
            foreach ($this->getCheckoutLineItemsForOfferId($checkoutForm, $offerId) as $lineItem) {
                if (!is_array($lineItem)) {
                    continue;
                }

                $url = $this->findPrestashopThumbnailByEan13Payload($lineItem);
                if ($url !== '') {
                    return $url;
                }
            }
        }

        return '';
    }

    protected function findCustomerReturnThumbnailFromLinkedOrder(array $return, array $checkoutForm = []): string
    {
        $checkoutFormId = trim((string) ($return['orderId'] ?? $return['order']['id'] ?? ''));
        if ($checkoutFormId === '') {
            return '';
        }

        foreach (($return['items'] ?? []) as $item) {
            if (!is_array($item)) {
                continue;
            }

            $offerId = trim((string) ($item['offerId'] ?? $item['offer']['id'] ?? ''));
            if ($offerId === '') {
                continue;
            }

            $url = $this->resolvePrestashopOrderThumbnailUrlByCheckoutFormId(
                $checkoutFormId,
                $offerId,
                $checkoutForm
            );
            if ($url !== '') {
                return $url;
            }
        }

        return '';
    }

    protected function findPrestashopThumbnailByEan13Payload(array $payload): string
    {
        foreach ($this->extractEan13Candidates($payload) as $ean13) {
            $url = $this->findPrestashopProductThumbnailByIdentifier($ean13);
            if ($url !== '') {
                return $url;
            }
        }

        return '';
    }

    protected function extractEan13Candidates(array $payload, int $depth = 0): array
    {
        if ($depth > 8) {
            return [];
        }

        $candidates = [];
        foreach ([
            $payload['external']['id'] ?? null,
            $payload['offer']['external']['id'] ?? null,
            $payload['product']['external']['id'] ?? null,
        ] as $externalId) {
            if (!is_scalar($externalId)) {
                continue;
            }

            $digits = preg_replace('/\D+/', '', (string) $externalId);
            if (is_string($digits) && strlen($digits) === 13) {
                $candidates[$digits] = true;
            }
        }

        $parameterName = mb_strtolower(trim((string) ($payload['name'] ?? $payload['id'] ?? '')));
        if (preg_match('/\b(ean|ean13|gtin)\b/i', $parameterName) === 1) {
            foreach (['value', 'values', 'valuesIds'] as $valueKey) {
                $values = is_array($payload[$valueKey] ?? null) ? $payload[$valueKey] : [$payload[$valueKey] ?? null];
                foreach ($values as $value) {
                    if (is_scalar($value)) {
                        $digits = preg_replace('/\D+/', '', (string) $value);
                        if (is_string($digits) && strlen($digits) === 13) {
                            $candidates[$digits] = true;
                        }
                    }
                }
            }
        }

        foreach ($payload as $key => $value) {
            if (is_scalar($value) && preg_match('/(ean|ean13|gtin)/i', (string) $key) === 1) {
                $digits = preg_replace('/\D+/', '', (string) $value);
                if (is_string($digits) && strlen($digits) === 13) {
                    $candidates[$digits] = true;
                }
            } elseif (is_array($value)) {
                foreach ($this->extractEan13Candidates($value, $depth + 1) as $ean13) {
                    $candidates[$ean13] = true;
                }
            }
        }

        return array_keys($candidates);
    }

    protected function resolveCustomerReturnItemThumbnailUrl(array $item, array $return = []): string
    {
        $checkoutForm = is_array($return['_checkout_form'] ?? null) ? $return['_checkout_form'] : [];
        $eanThumbnailUrl = $this->findCustomerReturnThumbnailByEan13(
            ['items' => [$item]],
            $checkoutForm
        );
        if ($eanThumbnailUrl !== '') {
            return $eanThumbnailUrl;
        }

        $orderThumbnailUrl = $this->findCustomerReturnThumbnailFromLinkedOrder(
            array_merge($return, ['items' => [$item]]),
            $checkoutForm
        );
        if ($orderThumbnailUrl !== '') {
            return $orderThumbnailUrl;
        }

        $prestashopThumbnailUrl = $this->findPrestashopProductThumbnailByReturnItem($item);
        if ($prestashopThumbnailUrl !== '') {
            return $prestashopThumbnailUrl;
        }

        foreach ([
            $item['imageUrl'] ?? null,
            $item['thumbnailUrl'] ?? null,
            $item['image'] ?? null,
            $item['thumbnail'] ?? null,
            $item['offer']['imageUrl'] ?? null,
            $item['offer']['image'] ?? null,
            $item['offer']['thumbnail'] ?? null,
        ] as $candidate) {
            $imageUrl = $this->normalizeIssueImageUrl($candidate);
            if ($imageUrl !== '') {
                return $imageUrl;
            }
        }

        foreach (['images', 'thumbnails'] as $key) {
            foreach (($item[$key] ?? []) as $image) {
                $imageUrl = $this->normalizeIssueImageUrl($image);
                if ($imageUrl !== '') {
                    return $imageUrl;
                }
            }
        }

        $recursiveUrl = $this->findImageUrlRecursively($item);
        if ($recursiveUrl !== '') {
            return $recursiveUrl;
        }

        $offerId = trim((string) ($item['offerId'] ?? $item['offer']['id'] ?? ''));
        $checkoutFormId = trim((string) ($return['orderId'] ?? $return['order']['id'] ?? ''));
        if ($offerId === '' && $checkoutFormId === '') {
            return '';
        }

        return $this->context->link->getModuleLink($this->name, 'thumbnail', [
            'token' => (string) Configuration::get(self::CONFIG_PREFIX . 'CRON_TOKEN'),
            'offer_id' => $offerId,
            'checkout_form_id' => $checkoutFormId,
            'mode' => 'image',
        ]);
    }

    protected function extractFirstImageUrlFromOffer(array $offer, bool $allowCatalogProductImages = true): string
    {
        $prestashopThumbnailUrl = $this->findPrestashopProductThumbnailByOfferPayload($offer);
        if ($prestashopThumbnailUrl !== '') {
            return $prestashopThumbnailUrl;
        }

        $directCandidates = [
            $offer['imageUrl'] ?? null,
            $offer['image']['url'] ?? null,
            $offer['image'] ?? null,
            $offer['thumbnailUrl'] ?? null,
            $offer['thumbnail']['url'] ?? null,
            $offer['thumbnail'] ?? null,
            $offer['primaryImage']['url'] ?? null,
            $offer['primaryImage'] ?? null,
            $offer['representativeImage']['url'] ?? null,
            $offer['representativeImage'] ?? null,
            $offer['coverImage']['url'] ?? null,
            $offer['coverImage'] ?? null,
            $offer['imageUrlTemplate'] ?? null,
        ];

        foreach ($directCandidates as $candidate) {
            $imageUrl = $this->normalizeIssueImageUrl($candidate);
            if ($imageUrl !== '') {
                return $imageUrl;
            }
        }

        foreach (($offer['images'] ?? []) as $image) {
            $imageUrl = $this->normalizeIssueImageUrl($image);
            if ($imageUrl !== '') {
                return $imageUrl;
            }
        }

        if ($allowCatalogProductImages) {
            foreach (($offer['productSet'] ?? []) as $productSet) {
                if (!is_array($productSet)) {
                    continue;
                }

                foreach (($productSet['product']['images'] ?? []) as $image) {
                    $imageUrl = $this->normalizeIssueImageUrl($image);
                    if ($imageUrl !== '') {
                        return $imageUrl;
                    }
                }
            }
        }

        $recursiveUrl = $this->findImageUrlRecursively($allowCatalogProductImages ? $offer : $this->removeCatalogProductImageSources($offer));
        if ($recursiveUrl !== '') {
            return $recursiveUrl;
        }

        return '';
    }

    protected function extractFirstImageUrlFromCheckoutForm(array $checkoutForm, bool $allowCatalogProductImages = true, string $offerId = ''): string
    {
        $offerId = trim($offerId);
        $lineItems = $this->getCheckoutLineItemsForOfferId($checkoutForm, $offerId);

        foreach ($lineItems as $lineItem) {
            $offerPayload = is_array($lineItem['offer'] ?? null) ? $lineItem['offer'] : [];
            if ($offerPayload) {
                $imageUrl = $this->extractFirstImageUrlFromOffer($offerPayload, $allowCatalogProductImages);
                if ($imageUrl !== '') {
                    return $imageUrl;
                }
            }

            if ($allowCatalogProductImages) {
                foreach (($lineItem['offer']['productSet'] ?? []) as $productSet) {
                    if (!is_array($productSet)) {
                        continue;
                    }

                    $imageUrl = $this->extractFirstImageUrlFromOffer($productSet);
                    if ($imageUrl !== '') {
                        return $imageUrl;
                    }
                }
            }
        }

        return $allowCatalogProductImages ? $this->findImageUrlRecursively($checkoutForm) : '';
    }

    protected function summarizeCheckoutFormThumbnailDiagnostics(array $checkoutForm, string $offerId = ''): array
    {
        $offerId = trim($offerId);
        $lineItems = is_array($checkoutForm['lineItems'] ?? null) ? $checkoutForm['lineItems'] : [];
        $summary = [
            'present' => true,
            'top_level_keys' => array_slice(array_keys($checkoutForm), 0, 30),
            'requested_offer_id' => $offerId,
            'first_offer_id' => $this->extractFirstOfferIdFromCheckoutForm($checkoutForm),
            'line_items_count' => count($lineItems),
            'recursive_image_url' => $this->findImageUrlRecursively($checkoutForm),
            'selected_image_url' => $this->extractAllegroOrderImageUrlFromCheckoutForm($checkoutForm, $offerId),
            'line_items' => [],
        ];

        $index = 0;
        foreach ($lineItems as $lineItem) {
            if (!is_array($lineItem)) {
                continue;
            }

            $offer = is_array($lineItem['offer'] ?? null) ? $lineItem['offer'] : [];
            $lineOfferId = $this->extractLineItemOfferId($lineItem);
            $lineOfferExternalId = $this->extractLineItemOfferExternalId($lineItem);
            $identifierCandidates = $this->extractPrestashopProductIdentifiersFromPayload($lineItem);
            $signatureDebug = [];
            $lineSummary = [
                'index' => $index,
                'id' => (string) ($lineItem['id'] ?? ''),
                'offer_id' => $lineOfferId,
                'offer_external_id' => $lineOfferExternalId,
                'offer_name' => (string) ($offer['name'] ?? $lineItem['name'] ?? ''),
                'matches_requested_offer' => $offerId !== '' && $lineOfferId === $offerId,
                'identifier_candidates' => $identifierCandidates,
                'prestashop_signature_thumbnail_url' => $this->findPrestashopProductThumbnailByLineItemSignature($lineItem, $signatureDebug),
                'prestashop_signature_match' => $signatureDebug,
                'direct_image_candidates' => [],
                'images_count' => is_array($lineItem['images'] ?? null) ? count($lineItem['images']) : 0,
                'thumbnails_count' => is_array($lineItem['thumbnails'] ?? null) ? count($lineItem['thumbnails']) : 0,
                'offer_images_count' => is_array($offer['images'] ?? null) ? count($offer['images']) : 0,
                'offer_thumbnails_count' => is_array($offer['thumbnails'] ?? null) ? count($offer['thumbnails']) : 0,
                'product_set_count' => is_array($offer['productSet'] ?? null) ? count($offer['productSet']) : 0,
                'first_image_url' => $this->extractAllegroOrderImageUrlFromCheckoutForm(['lineItems' => [$lineItem]], ''),
            ];

            foreach ([
                'imageUrl' => $lineItem['imageUrl'] ?? null,
                'thumbnailUrl' => $lineItem['thumbnailUrl'] ?? null,
                'image' => $lineItem['image'] ?? null,
                'thumbnail' => $lineItem['thumbnail'] ?? null,
                'offer.imageUrl' => $offer['imageUrl'] ?? null,
                'offer.image.url' => is_array($offer['image'] ?? null) ? ($offer['image']['url'] ?? null) : null,
                'offer.image' => $offer['image'] ?? null,
                'offer.thumbnailUrl' => $offer['thumbnailUrl'] ?? null,
                'offer.thumbnail.url' => is_array($offer['thumbnail'] ?? null) ? ($offer['thumbnail']['url'] ?? null) : null,
                'offer.thumbnail' => $offer['thumbnail'] ?? null,
                'offer.primaryImage.url' => is_array($offer['primaryImage'] ?? null) ? ($offer['primaryImage']['url'] ?? null) : null,
                'offer.primaryImage' => $offer['primaryImage'] ?? null,
                'offer.representativeImage.url' => is_array($offer['representativeImage'] ?? null) ? ($offer['representativeImage']['url'] ?? null) : null,
                'offer.representativeImage' => $offer['representativeImage'] ?? null,
            ] as $path => $candidate) {
                $imageUrl = $this->normalizeIssueImageUrl($candidate);
                if ($imageUrl !== '') {
                    $lineSummary['direct_image_candidates'][$path] = $imageUrl;
                }
            }

            foreach (($offer['productSet'] ?? []) as $productSet) {
                if (!is_array($productSet)) {
                    continue;
                }

                $images = $productSet['product']['images'] ?? [];
                if (is_array($images)) {
                    $lineSummary['product_set_images_count'] = ($lineSummary['product_set_images_count'] ?? 0) + count($images);
                }
            }

            $summary['line_items'][] = $lineSummary;
            ++$index;

            if (count($summary['line_items']) >= 12) {
                $summary['line_items_truncated'] = true;
                break;
            }
        }

        return $summary;
    }

    protected function extractAllegroOrderImageUrlFromCheckoutForm(array $checkoutForm, string $offerId = ''): string
    {
        $offerId = trim($offerId);
        $lineItems = $this->getCheckoutLineItemsForOfferId($checkoutForm, $offerId);

        foreach ($lineItems as $lineItem) {
            foreach ([
                $lineItem['imageUrl'] ?? null,
                $lineItem['thumbnailUrl'] ?? null,
                $lineItem['image'] ?? null,
                $lineItem['thumbnail'] ?? null,
                $lineItem['offer']['imageUrl'] ?? null,
                $lineItem['offer']['image']['url'] ?? null,
                $lineItem['offer']['image'] ?? null,
                $lineItem['offer']['thumbnailUrl'] ?? null,
                $lineItem['offer']['thumbnail']['url'] ?? null,
                $lineItem['offer']['thumbnail'] ?? null,
                $lineItem['offer']['primaryImage']['url'] ?? null,
                $lineItem['offer']['primaryImage'] ?? null,
                $lineItem['offer']['representativeImage']['url'] ?? null,
                $lineItem['offer']['representativeImage'] ?? null,
            ] as $candidate) {
                $imageUrl = $this->normalizeIssueImageUrl($candidate);
                if ($imageUrl !== '') {
                    return $imageUrl;
                }
            }

            foreach (['images', 'thumbnails'] as $key) {
                foreach (($lineItem[$key] ?? []) as $image) {
                    $imageUrl = $this->normalizeIssueImageUrl($image);
                    if ($imageUrl !== '') {
                        return $imageUrl;
                    }
                }

                foreach (($lineItem['offer'][$key] ?? []) as $image) {
                    $imageUrl = $this->normalizeIssueImageUrl($image);
                    if ($imageUrl !== '') {
                        return $imageUrl;
                    }
                }
            }

            foreach (($lineItem['offer']['productSet'] ?? []) as $productSet) {
                if (!is_array($productSet)) {
                    continue;
                }

                foreach (($productSet['product']['images'] ?? []) as $image) {
                    $imageUrl = $this->normalizeIssueImageUrl($image);
                    if ($imageUrl !== '') {
                        return $imageUrl;
                    }
                }
            }

            $recursiveUrl = $this->findImageUrlRecursively($lineItem);
            if ($recursiveUrl !== '') {
                return $recursiveUrl;
            }
        }

        return $this->findImageUrlRecursively($checkoutForm);
    }

    protected function getCheckoutLineItemsForOfferId(array $checkoutForm, string $offerId = ''): array
    {
        $offerId = trim($offerId);
        $matchedLineItems = [];
        $fallbackLineItems = [];
        $hasAnyLineItemOfferId = false;

        foreach ($this->extractCheckoutLineItems($checkoutForm) as $lineItem) {
            if (!is_array($lineItem)) {
                continue;
            }

            $lineOfferId = $this->extractLineItemOfferId($lineItem);
            if ($lineOfferId !== '') {
                $hasAnyLineItemOfferId = true;
            }

            if ($offerId !== '' && $lineOfferId === $offerId) {
                $matchedLineItems[] = $lineItem;
                continue;
            }

            $fallbackLineItems[] = $lineItem;
        }

        if ($offerId !== '') {
            if ($matchedLineItems) {
                return $matchedLineItems;
            }

            if ($hasAnyLineItemOfferId) {
                return [];
            }
        }

        return $fallbackLineItems;
    }

    protected function extractCheckoutLineItems(array $checkoutForm): array
    {
        $lineItems = $checkoutForm['lineItems'] ?? [];
        if (!is_array($lineItems)) {
            return [];
        }

        // X13 stores older checkout forms as lineItems.items, while the current
        // Allegro REST response exposes lineItems directly as an array.
        if (isset($lineItems['items']) && is_array($lineItems['items'])) {
            $lineItems = $lineItems['items'];
        }

        return array_values(array_filter($lineItems, 'is_array'));
    }

    protected function getCheckoutLineItemOfferIds(array $checkoutForm): array
    {
        $offerIds = [];
        foreach ($this->extractCheckoutLineItems($checkoutForm) as $lineItem) {
            if (!is_array($lineItem)) {
                continue;
            }

            $lineOfferId = $this->extractLineItemOfferId($lineItem);
            if ($lineOfferId !== '') {
                $offerIds[$lineOfferId] = true;
            }
        }

        return array_keys($offerIds);
    }

    protected function extractLineItemOfferId(array $lineItem): string
    {
        $offer = is_array($lineItem['offer'] ?? null) ? $lineItem['offer'] : [];
        $candidates = [
            $offer['id'] ?? null,
            $lineItem['offerId'] ?? null,
            $lineItem['offer_id'] ?? null,
            $lineItem['idOffer'] ?? null,
            $lineItem['id_oferta'] ?? null,
            $lineItem['id_oferty'] ?? null,
        ];

        foreach ($candidates as $candidate) {
            $value = $this->normalizeOptionalId($candidate);
            if ($value !== '') {
                return $value;
            }
        }

        $offerIds = $this->extractIssueOfferIdsFromPayload($lineItem);

        return $offerIds[0] ?? '';
    }

    protected function extractLineItemOfferExternalId(array $lineItem): string
    {
        $offer = is_array($lineItem['offer'] ?? null) ? $lineItem['offer'] : [];
        $candidates = [
            $offer['external']['id'] ?? null,
            $offer['externalId'] ?? null,
            $lineItem['external']['id'] ?? null,
            $lineItem['externalId'] ?? null,
            $lineItem['external_id'] ?? null,
            $lineItem['signature'] ?? null,
        ];

        foreach ($candidates as $candidate) {
            $value = $this->normalizeOptionalId($candidate);
            if ($value !== '') {
                return $value;
            }
        }

        return '';
    }

    protected function findPrestashopProductThumbnailByCheckoutFormSignature(array $checkoutForm, string $offerId = '', &$lookupDebug = null): string
    {
        $offerId = trim($offerId);
        if ($lookupDebug === null) {
            $lookupDebug = [];
        }

        $lookupDebug = [
            'requested_offer_id' => $offerId,
            'line_items' => [],
            'url' => '',
        ];

        $lineItems = $this->getCheckoutLineItemsForOfferId($checkoutForm, $offerId);
        if ($offerId !== '' && !$lineItems) {
            $lookupDebug['line_item_selection'] = [
                'source' => 'requested_offer_id_not_found',
                'available_offer_ids' => $this->getCheckoutLineItemOfferIds($checkoutForm),
            ];

            return '';
        }

        foreach ($lineItems as $lineItem) {
            $lineDebug = [];
            $thumbnailUrl = $this->findPrestashopProductThumbnailByLineItemSignature($lineItem, $lineDebug);
            $lookupDebug['line_items'][] = $lineDebug;

            if ($thumbnailUrl !== '') {
                $lookupDebug['url'] = $thumbnailUrl;

                return $thumbnailUrl;
            }
        }

        return '';
    }

    protected function findPrestashopThumbnailByAllegroProductIdentifiers(AllegroApiClient $apiClient, string $offerId = '', string $productId = '', string $checkoutFormId = '', array $payloads = [], &$lookupDebug = null): string
    {
        $offerId = trim($offerId);
        $productId = trim($productId);
        $checkoutFormId = trim($checkoutFormId);
        if ($lookupDebug === null) {
            $lookupDebug = [];
        }

        $lookupDebug = [
            'offer_id' => $offerId,
            'product_id' => $productId,
            'checkout_form_id' => $checkoutFormId,
            'payload_identifiers' => [],
            'product_offer_api' => null,
            'product_api' => null,
            'identifier_candidates' => [],
            'linked_order' => null,
            'order_detail_lookup' => null,
            'prestashop_identifier_lookup' => [],
            'url' => '',
        ];

        $identifiers = [];
        foreach ($payloads as $payload) {
            if (!is_array($payload)) {
                continue;
            }

            foreach ($this->extractPrestashopProductIdentifiersFromPayload($payload) as $identifier) {
                $identifier = trim((string) $identifier);
                if ($identifier !== '') {
                    $identifiers[$identifier] = true;
                    $lookupDebug['payload_identifiers'][$identifier] = true;
                }
            }
        }

        if ($offerId !== '') {
            try {
                $offerPayload = $apiClient->getProductOffer($offerId);
                $offerIdentifiers = $this->extractPrestashopProductIdentifiersFromPayload($offerPayload);
                foreach ($offerIdentifiers as $identifier) {
                    $identifier = trim((string) $identifier);
                    if ($identifier !== '') {
                        $identifiers[$identifier] = true;
                    }
                }

                $lookupDebug['product_offer_api'] = [
                    'ok' => true,
                    'top_level_keys' => array_slice(array_keys($offerPayload), 0, 30),
                    'identifier_candidates' => array_values(array_unique(array_map('strval', $offerIdentifiers))),
                ];
            } catch (Throwable $e) {
                $lookupDebug['product_offer_api'] = [
                    'ok' => false,
                    'error' => $e->getMessage(),
                ];
            }
        }

        if ($productId !== '') {
            try {
                $productPayload = $apiClient->getProduct($productId);
                $productIdentifiers = $this->extractPrestashopProductIdentifiersFromPayload($productPayload);
                foreach ($productIdentifiers as $identifier) {
                    $identifier = trim((string) $identifier);
                    if ($identifier !== '') {
                        $identifiers[$identifier] = true;
                    }
                }

                $lookupDebug['product_api'] = [
                    'ok' => true,
                    'top_level_keys' => array_slice(array_keys($productPayload), 0, 30),
                    'identifier_candidates' => array_values(array_unique(array_map('strval', $productIdentifiers))),
                ];
            } catch (Throwable $e) {
                $lookupDebug['product_api'] = [
                    'ok' => false,
                    'error' => $e->getMessage(),
                ];
            }
        }

        $lookupDebug['payload_identifiers'] = array_keys($lookupDebug['payload_identifiers']);
        $identifiers = $this->filterPrestashopIdentifierCandidates(array_keys($identifiers));
        $lookupDebug['identifier_candidates'] = $identifiers;
        if (!$identifiers) {
            return '';
        }

        if ($checkoutFormId !== '') {
            $linkedOrder = $this->findPrestashopOrderByX13CheckoutForm($checkoutFormId);
            if (is_array($linkedOrder) && (int) ($linkedOrder['id_order'] ?? 0) > 0) {
                $idOrder = (int) $linkedOrder['id_order'];
                $lookupDebug['linked_order'] = [
                    'id_order' => $idOrder,
                    'reference' => (string) ($linkedOrder['reference'] ?? ''),
                    'source' => (string) ($linkedOrder['source'] ?? ''),
                ];

                $orderDetailDebug = [];
                $match = $this->findPrestashopOrderDetailMatchByIdentifiers($idOrder, $identifiers, $orderDetailDebug);
                $lookupDebug['order_detail_lookup'] = $orderDetailDebug;
                if ((int) ($match['id_product'] ?? 0) > 0) {
                    $imageDebug = [];
                    $thumbnailUrl = $this->getPrestashopProductThumbnailUrl(
                        (int) $match['id_product'],
                        (int) ($match['id_product_attribute'] ?? 0),
                        $imageDebug
                    );
                    $lookupDebug['order_detail_lookup']['image'] = $imageDebug;
                    $lookupDebug['order_detail_lookup']['url'] = $thumbnailUrl;
                    if ($thumbnailUrl !== '') {
                        $lookupDebug['url'] = $thumbnailUrl;

                        return $thumbnailUrl;
                    }
                }
            }
        }

        foreach ($identifiers as $identifier) {
            $matchDebug = [];
            $thumbnailUrl = $this->findPrestashopProductThumbnailByIdentifier($identifier, $matchDebug);
            $lookupDebug['prestashop_identifier_lookup'][] = $matchDebug;
            if ($thumbnailUrl !== '') {
                $lookupDebug['url'] = $thumbnailUrl;

                return $thumbnailUrl;
            }
        }

        return '';
    }

    protected function filterPrestashopIdentifierCandidates(array $identifiers): array
    {
        $filtered = [];
        foreach ($identifiers as $identifier) {
            $identifier = trim((string) $identifier);
            if ($identifier === '') {
                continue;
            }

            if (preg_match('/^[0-9]{8,14}$/', $identifier) !== 1 && preg_match('/^[A-Za-z0-9._-]{4,64}$/', $identifier) !== 1) {
                continue;
            }

            $filtered[$identifier] = true;
        }

        return array_keys($filtered);
    }

    protected function findPrestashopOrderThumbnailByCheckoutFormSignature(string $checkoutFormId, array $checkoutForm, string $offerId = '', &$lookupDebug = null): string
    {
        $checkoutFormId = trim($checkoutFormId);
        $offerId = trim($offerId);
        if ($lookupDebug === null) {
            $lookupDebug = [];
        }

        $lookupDebug = [
            'checkout_form_id' => $checkoutFormId,
            'requested_offer_id' => $offerId,
            'linked_order' => null,
            'line_items' => [],
            'url' => '',
        ];

        if ($checkoutFormId === '') {
            $lookupDebug['error'] = 'missing_checkout_form_id';

            return '';
        }

        $linkedOrder = $this->findPrestashopOrderByX13CheckoutForm($checkoutFormId);
        if (!is_array($linkedOrder) || (int) ($linkedOrder['id_order'] ?? 0) <= 0) {
            $lookupDebug['error'] = 'prestashop_order_not_found';

            return '';
        }

        $idOrder = (int) $linkedOrder['id_order'];
        $lookupDebug['linked_order'] = [
            'id_order' => $idOrder,
            'reference' => (string) ($linkedOrder['reference'] ?? ''),
            'source' => (string) ($linkedOrder['source'] ?? ''),
        ];

        $lineItems = $this->getCheckoutLineItemsForOfferId($checkoutForm, $offerId);
        if ($offerId !== '' && !$lineItems) {
            $availableOfferIds = $this->getCheckoutLineItemOfferIds($checkoutForm);
            $lookupDebug['line_item_selection'] = [
                'source' => 'requested_offer_id_not_found',
                'available_offer_ids' => $availableOfferIds,
            ];

            if ($availableOfferIds) {
                return '';
            }
        }

        foreach ($lineItems as $lineItem) {
            $lineDebug = [];
            $thumbnailUrl = $this->getPrestashopOrderThumbnailUrlByLineItem(
                $idOrder,
                $lineItem,
                $lineDebug
            );
            $lookupDebug['line_items'][] = $lineDebug;

            if ($thumbnailUrl !== '') {
                $lookupDebug['url'] = $thumbnailUrl;

                return $thumbnailUrl;
            }
        }

        $fallbackMatch = $this->findSinglePrestashopOrderDetailProductMatch($idOrder);
        if ((int) ($fallbackMatch['id_product'] ?? 0) > 0) {
            $imageDebug = [];
            $thumbnailUrl = $this->getPrestashopProductThumbnailUrl(
                (int) $fallbackMatch['id_product'],
                (int) ($fallbackMatch['id_product_attribute'] ?? 0),
                $imageDebug
            );
            $lookupDebug['order_fallback'] = array_merge($fallbackMatch, [
                'image' => $imageDebug,
                'url' => $thumbnailUrl,
            ]);

            if ($thumbnailUrl !== '') {
                $lookupDebug['url'] = $thumbnailUrl;

                return $thumbnailUrl;
            }
        }

        return '';
    }

    protected function findPrestashopProductThumbnailByLineItemSignature(array $lineItem, &$lineDebug = null): string
    {
        if ($lineDebug === null) {
            $lineDebug = [];
        }

        $offer = is_array($lineItem['offer'] ?? null) ? $lineItem['offer'] : [];
        $lineOfferId = $this->extractLineItemOfferId($lineItem);
        $lineOfferExternalId = $this->extractLineItemOfferExternalId($lineItem);
        $identifiers = $this->extractPrestashopProductIdentifiersFromPayload($lineItem);
        $lineDebug = [
            'line_item_id' => (string) ($lineItem['id'] ?? ''),
            'offer_id' => $lineOfferId,
            'offer_external_id' => $lineOfferExternalId,
            'offer_name' => (string) ($offer['name'] ?? $lineItem['name'] ?? ''),
            'identifier_candidates' => $identifiers,
            'matches' => [],
            'url' => '',
        ];

        foreach ($identifiers as $identifier) {
            $matchDebug = [];
            $thumbnailUrl = $this->findPrestashopProductThumbnailByIdentifier($identifier, $matchDebug);
            $lineDebug['matches'][] = $matchDebug;

            if ($thumbnailUrl !== '') {
                $lineDebug['url'] = $thumbnailUrl;

                return $thumbnailUrl;
            }
        }

        return '';
    }

    protected function removeCatalogProductImageSources(array $payload): array
    {
        unset($payload['productSet'], $payload['product'], $payload['products']);

        return $payload;
    }

    protected function issueAllowsCatalogProductThumbnails(array $issue): bool
    {
        $issueType = mb_strtoupper(trim((string) ($issue['type'] ?? '')));

        return $issueType !== 'CLAIM';
    }

    protected function extractFirstOfferIdFromCheckoutForm(array $checkoutForm): string
    {
        $offerIds = $this->extractIssueOfferIdsFromPayload($checkoutForm);

        return $offerIds[0] ?? '';
    }

    protected function findPrestashopProductThumbnailByCheckoutForm(array $checkoutForm): string
    {
        foreach (($checkoutForm['lineItems'] ?? []) as $lineItem) {
            if (!is_array($lineItem)) {
                continue;
            }

            $externalId = trim((string) ($lineItem['offer']['external']['id'] ?? ''));
            if ($externalId !== '') {
                $thumbnailUrl = $this->findPrestashopProductThumbnailByIdentifier($externalId);
                if ($thumbnailUrl !== '') {
                    return $thumbnailUrl;
                }
            }

            $offerId = $this->extractLineItemOfferId($lineItem);
            if ($offerId !== '') {
                $thumbnailUrl = $this->findPrestashopProductThumbnailByIdentifier($offerId);
                if ($thumbnailUrl !== '') {
                    return $thumbnailUrl;
                }
            }

            $offerName = trim((string) ($lineItem['offer']['name'] ?? ''));
            if ($offerName !== '') {
                $thumbnailUrl = $this->findPrestashopProductThumbnailByName($offerName);
                if ($thumbnailUrl !== '') {
                    return $thumbnailUrl;
                }
            }
        }

        return '';
    }

    protected function findPrestashopProductThumbnailByOfferPayload(array $offer): string
    {
        $offerId = trim((string) ($offer['id'] ?? $offer['offer']['id'] ?? ''));
        if ($offerId !== '') {
            $thumbnailUrl = $this->findPrestashopProductThumbnailByIdentifier($offerId);
            if ($thumbnailUrl !== '') {
                return $thumbnailUrl;
            }
        }

        foreach ($this->extractPrestashopProductIdentifiersFromPayload($offer) as $identifier) {
            $thumbnailUrl = $this->findPrestashopProductThumbnailByIdentifier($identifier);
            if ($thumbnailUrl !== '') {
                return $thumbnailUrl;
            }
        }

        foreach ($this->extractPrestashopProductNamesFromPayload($offer) as $name) {
            $thumbnailUrl = $this->findPrestashopProductThumbnailByName($name);
            if ($thumbnailUrl !== '') {
                return $thumbnailUrl;
            }
        }

        return '';
    }

    protected function findPrestashopProductThumbnailByReturnItem(array $item): string
    {
        foreach ($this->extractPrestashopProductIdentifiersFromPayload($item) as $identifier) {
            $thumbnailUrl = $this->findPrestashopProductThumbnailByIdentifier($identifier);
            if ($thumbnailUrl !== '') {
                return $thumbnailUrl;
            }
        }

        $offerId = trim((string) ($item['offerId'] ?? $item['offer']['id'] ?? ''));
        if ($offerId !== '') {
            $thumbnailUrl = $this->findPrestashopProductThumbnailByIdentifier($offerId);
            if ($thumbnailUrl !== '') {
                return $thumbnailUrl;
            }
        }

        foreach ($this->extractPrestashopProductNamesFromPayload($item) as $name) {
            $thumbnailUrl = $this->findPrestashopProductThumbnailByName($name);
            if ($thumbnailUrl !== '') {
                return $thumbnailUrl;
            }
        }

        return '';
    }

    protected function extractPrestashopProductIdentifiersFromPayload(array $payload): array
    {
        $candidates = [
            $payload['external']['id'] ?? null,
            $payload['externalId'] ?? null,
            $payload['external_id'] ?? null,
            $payload['reference'] ?? null,
            $payload['sku'] ?? null,
            $payload['signature'] ?? null,
            $payload['signatura'] ?? null,
            $payload['ean'] ?? null,
            $payload['ean13'] ?? null,
            $payload['gtin'] ?? null,
            $payload['barcode'] ?? null,
            $payload['producerCode'] ?? null,
            $payload['product']['external']['id'] ?? null,
            $payload['product']['reference'] ?? null,
            $payload['product']['sku'] ?? null,
            $payload['product']['ean'] ?? null,
            $payload['product']['ean13'] ?? null,
            $payload['offer']['external']['id'] ?? null,
            $payload['offer']['externalId'] ?? null,
            $payload['offer']['reference'] ?? null,
            $payload['offer']['sku'] ?? null,
            $payload['offer']['signature'] ?? null,
            $payload['offer']['signatura'] ?? null,
            $payload['offer']['ean'] ?? null,
            $payload['offer']['ean13'] ?? null,
        ];
        $identifiers = [];

        foreach ($candidates as $candidate) {
            if (!is_scalar($candidate)) {
                continue;
            }

            $identifier = trim((string) $candidate);
            if ($identifier !== '') {
                $identifiers[$identifier] = true;
                $digitsOnly = preg_replace('/\D+/', '', $identifier);
                if (is_string($digitsOnly) && $digitsOnly !== '' && $digitsOnly !== $identifier && strlen($digitsOnly) >= 8) {
                    $identifiers[$digitsOnly] = true;
                }
            }
        }

        foreach ($this->extractPrestashopProductIdentifiersRecursively($payload) as $identifier) {
            $identifiers[$identifier] = true;
        }

        return array_keys($identifiers);
    }

    protected function extractPrestashopProductIdentifiersRecursively(array $payload, int $depth = 0): array
    {
        if ($depth > 8) {
            return [];
        }

        $identifiers = [];
        $parameterName = strtolower(trim((string) ($payload['name'] ?? $payload['id'] ?? '')));
        $parameterKeyMatches = preg_match('/(ean|ean13|gtin|isbn|upc|sku|reference|external|barcode|producer)/i', $parameterName) === 1;
        if ($parameterKeyMatches) {
            foreach (['value', 'values', 'valuesIds'] as $valueKey) {
                $value = $payload[$valueKey] ?? null;
                if (is_scalar($value)) {
                    $identifier = trim((string) $value);
                    if ($identifier !== '') {
                        $identifiers[$identifier] = true;
                    }
                } elseif (is_array($value)) {
                    foreach ($value as $item) {
                        if (!is_scalar($item)) {
                            continue;
                        }

                        $identifier = trim((string) $item);
                        if ($identifier !== '') {
                            $identifiers[$identifier] = true;
                        }
                    }
                }
            }
        }

        foreach ($payload as $key => $value) {
            $key = (string) $key;
            if (is_scalar($value) && preg_match('/(ean|ean13|gtin|isbn|upc|sku|signature|signatura|reference|external.?id|barcode|producer.?code)/i', $key) === 1) {
                $identifier = trim((string) $value);
                if ($identifier !== '') {
                    $identifiers[$identifier] = true;
                }
            }

            if (is_array($value)) {
                foreach ($this->extractPrestashopProductIdentifiersRecursively($value, $depth + 1) as $identifier) {
                    $identifiers[$identifier] = true;
                }
            }
        }

        return array_keys($identifiers);
    }

    protected function extractPrestashopProductNamesFromPayload(array $payload): array
    {
        $candidates = [
            $payload['name'] ?? null,
            $payload['title'] ?? null,
            $payload['product']['name'] ?? null,
            $payload['product']['title'] ?? null,
            $payload['offer']['name'] ?? null,
            $payload['offer']['title'] ?? null,
        ];
        $names = [];

        foreach ($candidates as $candidate) {
            if (!is_scalar($candidate)) {
                continue;
            }

            $name = trim((string) $candidate);
            if ($name !== '') {
                $names[$name] = true;
            }
        }

        foreach ($this->extractPrestashopProductNamesRecursively($payload) as $name) {
            $names[$name] = true;
        }

        return array_keys($names);
    }

    protected function extractPrestashopProductNamesRecursively(array $payload, int $depth = 0): array
    {
        if ($depth > 6) {
            return [];
        }

        $names = [];
        foreach ($payload as $key => $value) {
            $key = (string) $key;
            if (is_scalar($value) && preg_match('/(^|_)(name|title|productName|offerName)(_|$)/i', $key) === 1) {
                $name = trim((string) $value);
                if ($name !== '') {
                    $names[$name] = true;
                }
            }

            if (is_array($value)) {
                foreach ($this->extractPrestashopProductNamesRecursively($value, $depth + 1) as $name) {
                    $names[$name] = true;
                }
            }
        }

        return array_keys($names);
    }

    protected function findPrestashopProductThumbnailByIdentifier(string $identifier, &$matchDebug = null): string
    {
        $identifier = trim($identifier);
        if ($matchDebug === null) {
            $matchDebug = [];
        }

        $identifierCandidates = $this->buildPrestashopIdentifierCandidates($identifier);
        $matchDebug = [
            'identifier' => $identifier,
            'identifier_candidates' => $identifierCandidates,
            'source' => 'not_found',
            'id_product' => 0,
            'id_product_attribute' => 0,
            'checked_fields' => [
                'product_attribute.ean13',
                'product_attribute.reference',
                'product_attribute.supplier_reference',
                'product_attribute.upc',
                'product.ean13',
                'product.reference',
                'product.supplier_reference',
                'product.upc',
                'product_supplier.product_supplier_reference',
                'cargostockmanager_product_logistics.module_model',
            ],
            'url' => '',
            'errors' => [],
        ];

        if ($identifier === '' || !$identifierCandidates) {
            return '';
        }

        $attributeCondition = $this->buildPrestashopIdentifierSqlCondition('pa', [
            'ean13',
            'reference',
            'supplier_reference',
            'upc',
        ], $identifierCandidates);
        $attributeSql = 'SELECT pa.`id_product`, pa.`id_product_attribute`
            FROM `' . _DB_PREFIX_ . 'product_attribute` pa
            WHERE ' . $attributeCondition . '
            ORDER BY pa.`id_product_attribute` ASC';

        try {
            $attributeRow = Db::getInstance()->getRow($attributeSql);
        } catch (Throwable $e) {
            PrestaShopLogger::addLog('[AAR] PrestaShop combination thumbnail lookup by identifier skipped: ' . $e->getMessage(), 2);
            $matchDebug['errors'][] = 'product_attribute: ' . $e->getMessage();
            $attributeRow = [];
        }

        $idProduct = (int) ($attributeRow['id_product'] ?? 0);
        $idProductAttribute = (int) ($attributeRow['id_product_attribute'] ?? 0);
        if ($idProduct > 0 && $idProductAttribute > 0) {
            $imageDebug = [];
            $thumbnailUrl = $this->getPrestashopProductThumbnailUrl($idProduct, $idProductAttribute, $imageDebug);
            $matchDebug = [
                'identifier' => $identifier,
                'identifier_candidates' => $identifierCandidates,
                'source' => 'product_attribute',
                'id_product' => $idProduct,
                'id_product_attribute' => $idProductAttribute,
                'image' => $imageDebug,
                'url' => $thumbnailUrl,
            ];

            if ($thumbnailUrl !== '') {
                return $thumbnailUrl;
            }
        }

        $supplierCondition = $this->buildPrestashopIdentifierSqlCondition('psup', [
            'product_supplier_reference',
        ], $identifierCandidates);
        $supplierSql = 'SELECT psup.`id_product`, psup.`id_product_attribute`
            FROM `' . _DB_PREFIX_ . 'product_supplier` psup
            WHERE ' . $supplierCondition . '
            ORDER BY psup.`id_product_attribute` DESC, psup.`id_product` ASC';

        try {
            $supplierRow = Db::getInstance()->getRow($supplierSql);
        } catch (Throwable $e) {
            PrestaShopLogger::addLog('[AAR] PrestaShop product supplier thumbnail lookup by identifier skipped: ' . $e->getMessage(), 2);
            $matchDebug['errors'][] = 'product_supplier: ' . $e->getMessage();
            $supplierRow = [];
        }

        $idProduct = (int) ($supplierRow['id_product'] ?? 0);
        $idProductAttribute = (int) ($supplierRow['id_product_attribute'] ?? 0);
        if ($idProduct > 0) {
            $imageDebug = [];
            $thumbnailUrl = $this->getPrestashopProductThumbnailUrl($idProduct, $idProductAttribute, $imageDebug);
            $matchDebug = [
                'identifier' => $identifier,
                'identifier_candidates' => $identifierCandidates,
                'source' => 'product_supplier',
                'id_product' => $idProduct,
                'id_product_attribute' => $idProductAttribute,
                'image' => $imageDebug,
                'url' => $thumbnailUrl,
            ];

            if ($thumbnailUrl !== '') {
                return $thumbnailUrl;
            }
        }

        $logisticsTable = _DB_PREFIX_ . 'cargostockmanager_product_logistics';
        $logisticsCondition = $this->buildPrestashopIdentifierSqlCondition('psl', [
            'module_model',
        ], $identifierCandidates);
        $logisticsSql = 'SELECT psl.`id_product`, psl.`id_product_attribute`
            FROM `' . bqSQL($logisticsTable) . '` psl
            WHERE ' . $logisticsCondition . '
            ORDER BY psl.`id_product_attribute` DESC, psl.`id_product` ASC';

        try {
            $logisticsRow = Db::getInstance()->getRow($logisticsSql);
        } catch (Throwable $e) {
            $logisticsRow = [];
        }

        $idProduct = (int) ($logisticsRow['id_product'] ?? 0);
        $idProductAttribute = (int) ($logisticsRow['id_product_attribute'] ?? 0);
        if ($idProduct > 0) {
            $imageDebug = [];
            $thumbnailUrl = $this->getPrestashopProductThumbnailUrl($idProduct, $idProductAttribute, $imageDebug);
            $matchDebug = [
                'identifier' => $identifier,
                'identifier_candidates' => $identifierCandidates,
                'source' => 'cargostockmanager_product_logistics',
                'id_product' => $idProduct,
                'id_product_attribute' => $idProductAttribute,
                'image' => $imageDebug,
                'url' => $thumbnailUrl,
            ];

            if ($thumbnailUrl !== '') {
                return $thumbnailUrl;
            }
        }

        $productCondition = $this->buildPrestashopIdentifierSqlCondition('p', [
            'ean13',
            'reference',
            'supplier_reference',
            'upc',
        ], $identifierCandidates);
        $sql = 'SELECT p.`id_product`
            FROM `' . _DB_PREFIX_ . 'product` p
            WHERE ' . $productCondition . '
            ORDER BY p.`id_product` ASC';

        try {
            $row = Db::getInstance()->getRow($sql);
        } catch (Throwable $e) {
            PrestaShopLogger::addLog('[AAR] PrestaShop product thumbnail lookup by identifier skipped: ' . $e->getMessage(), 2);
            $matchDebug['errors'][] = 'product: ' . $e->getMessage();

            return '';
        }
        $idProduct = (int) ($row['id_product'] ?? 0);
        $imageDebug = [];
        $thumbnailUrl = $this->getPrestashopProductThumbnailUrl($idProduct, 0, $imageDebug);
        if ($idProduct > 0) {
            $matchDebug = [
                'identifier' => $identifier,
                'identifier_candidates' => $identifierCandidates,
                'source' => 'product',
                'id_product' => $idProduct,
                'id_product_attribute' => 0,
                'image' => $imageDebug,
                'url' => $thumbnailUrl,
            ];
        }

        return $thumbnailUrl;
    }

    protected function buildPrestashopIdentifierCandidates(string $identifier): array
    {
        $identifier = trim($identifier);
        if ($identifier === '') {
            return [];
        }

        $candidates = [$identifier];
        $compact = preg_replace('/[\s-]+/u', '', $identifier);
        if (is_string($compact) && $compact !== '') {
            $candidates[] = $compact;
        }

        $digitsOnly = preg_replace('/\D+/', '', $identifier);
        if (is_string($digitsOnly) && $digitsOnly !== '') {
            $candidates[] = $digitsOnly;

            if (strlen($digitsOnly) === 12) {
                $candidates[] = '0' . $digitsOnly;
            }

            if (strlen($digitsOnly) === 13 && substr($digitsOnly, 0, 1) === '0') {
                $candidates[] = substr($digitsOnly, 1);
            }

            if (strlen($digitsOnly) === 14 && substr($digitsOnly, 0, 1) === '0') {
                $candidates[] = substr($digitsOnly, 1);
            }

            if (strlen($digitsOnly) > 13) {
                $candidates[] = substr($digitsOnly, -13);
            }
        }

        $unique = [];
        foreach ($candidates as $candidate) {
            $candidate = trim((string) $candidate);
            if ($candidate !== '') {
                $unique[$candidate] = true;
            }
        }

        return array_keys($unique);
    }

    protected function buildPrestashopIdentifierSqlCondition(string $alias, array $fields, array $identifiers): string
    {
        $alias = preg_replace('/[^A-Za-z0-9_]/', '', $alias);
        if (!is_string($alias) || $alias === '') {
            return '1 = 0';
        }

        $conditions = [];
        foreach ($identifiers as $identifier) {
            $identifier = trim((string) $identifier);
            if ($identifier === '') {
                continue;
            }

            foreach ($fields as $field) {
                $field = preg_replace('/[^A-Za-z0-9_]/', '', (string) $field);
                if (!is_string($field) || $field === '') {
                    continue;
                }

                $expr = '`' . bqSQL($alias) . '`.`' . bqSQL($field) . '`';
                $candidate = pSQL($identifier);
                $conditions[] = 'TRIM(' . $expr . ') = "' . $candidate . '"';
                $conditions[] = 'REPLACE(REPLACE(REPLACE(TRIM(' . $expr . '), " ", ""), "-", ""), "\t", "") = "' . $candidate . '"';
            }
        }

        $conditions = array_values(array_unique($conditions));
        if (!$conditions) {
            return '1 = 0';
        }

        return '(' . implode(' OR ', $conditions) . ')';
    }

    protected function findPrestashopProductThumbnailByName(string $name): string
    {
        $name = trim($name);
        if ($name === '') {
            return '';
        }

        $idLang = (int) ($this->context->language->id ?? Configuration::get('PS_LANG_DEFAULT'));
        $idShop = (int) ($this->context->shop->id ?? 1);

        $sql = 'SELECT pl.`id_product`
            FROM `' . _DB_PREFIX_ . 'product_lang` pl
            WHERE pl.`id_lang` = ' . (int) $idLang . '
                AND pl.`id_shop` = ' . (int) $idShop . '
                AND (
                    pl.`name` = "' . pSQL($name) . '"
                    OR pl.`name` LIKE "%' . pSQL($name) . '%"
                    OR "' . pSQL($name) . '" LIKE CONCAT("%", pl.`name`, "%")
                )
            ORDER BY
                CASE WHEN pl.`name` = "' . pSQL($name) . '" THEN 0 ELSE 1 END,
                CHAR_LENGTH(pl.`name`) ASC,
                pl.`id_product` ASC';

        try {
            $row = Db::getInstance()->getRow($sql);
        } catch (Throwable $e) {
            PrestaShopLogger::addLog('[AAR] PrestaShop product thumbnail lookup by name skipped: ' . $e->getMessage(), 2);

            return '';
        }
        $idProduct = (int) ($row['id_product'] ?? 0);

        return $this->getPrestashopProductThumbnailUrl($idProduct);
    }

    protected function getPrestashopProductThumbnailUrl(int $idProduct, int $idProductAttribute = 0, &$imageDebug = null): string
    {
        if ($imageDebug === null) {
            $imageDebug = [];
        }

        $imageDebug = [
            'id_product' => $idProduct,
            'id_product_attribute' => $idProductAttribute,
            'id_image' => 0,
            'image_source' => '',
            'link_rewrite' => '',
            'image_ids' => '',
            'legacy_url' => '',
            'url' => '',
            'errors' => [],
        ];

        if ($idProduct <= 0) {
            return '';
        }

        $idLang = (int) ($this->context->language->id ?? Configuration::get('PS_LANG_DEFAULT'));
        $idShop = (int) ($this->context->shop->id ?? 1);
        $linkRewrite = $this->getPrestashopProductLinkRewrite($idProduct, $idLang, $idShop);
        if ($linkRewrite === '') {
            $linkRewrite = 'product';
        }
        $imageDebug['link_rewrite'] = $linkRewrite;

        $idImage = 0;

        if ($idProductAttribute > 0) {
            $attributeSql = 'SELECT MIN(pai.`id_image`)
                FROM `' . _DB_PREFIX_ . 'product_attribute_image` pai
                WHERE pai.`id_product_attribute` = ' . (int) $idProductAttribute;

            try {
                $idImage = (int) Db::getInstance()->getValue($attributeSql);
            } catch (Throwable $e) {
                PrestaShopLogger::addLog('[AAR] PrestaShop combination image lookup skipped for product #' . (int) $idProduct . ' attribute #' . (int) $idProductAttribute . ': ' . $e->getMessage(), 2);
                $imageDebug['errors'][] = 'product_attribute_image: ' . $e->getMessage();
                $idImage = 0;
            }

            if ($idImage > 0) {
                $imageDebug['image_source'] = 'product_attribute_image';
            }
        }

        if ($idImage <= 0) {
            foreach ([
                'SELECT MAX(i.`id_image`) FROM `' . _DB_PREFIX_ . 'image` i WHERE i.`id_product` = ' . (int) $idProduct . ' AND i.`cover` = 1',
                'SELECT MIN(i.`id_image`) FROM `' . _DB_PREFIX_ . 'image` i WHERE i.`id_product` = ' . (int) $idProduct,
            ] as $sql) {
                try {
                    $idImage = (int) Db::getInstance()->getValue($sql);
                } catch (Throwable $e) {
                    PrestaShopLogger::addLog('[AAR] PrestaShop product image lookup skipped for product #' . (int) $idProduct . ': ' . $e->getMessage(), 2);
                    $imageDebug['errors'][] = 'image: ' . $e->getMessage();
                    $idImage = 0;
                }

                if ($idImage > 0) {
                    break;
                }
            }

            if ($idImage > 0) {
                $imageDebug['image_source'] = 'product_image';
            }
        }

        if ($idImage <= 0) {
            return '';
        }

        $imageIds = (string) $idProduct . '-' . (string) $idImage;
        $imageDebug['id_image'] = $idImage;
        $imageDebug['image_ids'] = $imageIds;
        $legacyUrl = $this->buildPrestashopLegacyImageUrl($idImage, 'small_default');
        $imageDebug['legacy_url'] = $legacyUrl;
        if ($legacyUrl !== '') {
            $imageDebug['url'] = $legacyUrl;

            return $legacyUrl;
        }

        try {
            $url = (string) $this->context->link->getImageLink($linkRewrite, $imageIds, 'small_default');
        } catch (Throwable $e) {
            $imageDebug['errors'][] = 'getImageLink(product-image): ' . $e->getMessage();
            $url = '';
        }

        if ($url === '') {
            try {
                $url = (string) $this->context->link->getImageLink($linkRewrite, (string) $idImage, 'small_default');
            } catch (Throwable $e) {
                $imageDebug['errors'][] = 'getImageLink(image): ' . $e->getMessage();
                $url = '';
            }
        }

        $imageDebug['url'] = $url;

        return $url;
    }

    protected function buildPrestashopLegacyImageUrl(int $idImage, string $imageType = 'small_default'): string
    {
        if ($idImage <= 0) {
            return '';
        }

        $digits = str_split((string) $idImage);
        $path = 'img/p/' . implode('/', $digits) . '/' . (int) $idImage . '-' . preg_replace('/[^A-Za-z0-9_-]/', '', $imageType) . '.jpg';
        $baseUri = defined('__PS_BASE_URI__') ? (string) __PS_BASE_URI__ : '/';
        $domain = '';

        try {
            if (method_exists('Tools', 'getShopDomainSsl')) {
                $domain = (string) Tools::getShopDomainSsl(true);
            } elseif (method_exists('Tools', 'getShopDomain')) {
                $domain = (string) Tools::getShopDomain(true);
            }
        } catch (Throwable $e) {
            $domain = '';
        }

        if ($domain === '') {
            $domain = (string) Configuration::get('PS_SHOP_DOMAIN_SSL');
            if ($domain !== '' && strpos($domain, 'http') !== 0) {
                $domain = 'https://' . $domain;
            }
        }

        if ($domain === '') {
            return '/' . $path;
        }

        return rtrim($domain, '/') . '/' . trim($baseUri, '/') . (trim($baseUri, '/') !== '' ? '/' : '') . $path;
    }

    protected function getPrestashopProductLinkRewrite(int $idProduct, int $idLang, int $idShop): string
    {
        if ($idProduct <= 0) {
            return '';
        }

        $queries = [
            'SELECT `link_rewrite`
                FROM `' . _DB_PREFIX_ . 'product_lang`
                WHERE `id_product` = ' . (int) $idProduct . '
                    AND `id_lang` = ' . (int) $idLang . '
                    AND `id_shop` = ' . (int) $idShop,
            'SELECT `link_rewrite`
                FROM `' . _DB_PREFIX_ . 'product_lang`
                WHERE `id_product` = ' . (int) $idProduct . '
                    AND `id_lang` = ' . (int) $idLang . '
                ORDER BY `id_shop` ASC',
            'SELECT `link_rewrite`
                FROM `' . _DB_PREFIX_ . 'product_lang`
                WHERE `id_product` = ' . (int) $idProduct . '
                ORDER BY `id_lang` ASC',
        ];

        foreach ($queries as $sql) {
            try {
                $linkRewrite = trim((string) Db::getInstance()->getValue($sql));
            } catch (Throwable $e) {
                continue;
            }

            if ($linkRewrite !== '') {
                return $linkRewrite;
            }
        }

        return '';
    }

    protected function renderIssuesFilters(string $issueKind, string $statusFilter, string $query, bool $showIssueKindFilter = true): string
    {
        $html = $this->htmlFragment('64bdd196d26804558c41') . Tools::safeOutput($this->getCurrentIssuesFilterActionUrl()) . '" class="aar-issues-filters' . ($showIssueKindFilter ? ' has-kind-filter' : '') . '" autocomplete="off">';
        $currentController = trim((string) Tools::getValue('controller'));
        $tokenController = $currentController !== ''
            ? $currentController
            : $this->resolveAdminControllerName('AdminAllegroCustomerServiceComplaints');
        $currentToken = trim((string) Tools::getAdminTokenLite($tokenController));
        if ($currentController !== '') {
            $html .= $this->htmlFragment('6e7807eefa9e72e6a446') . Tools::safeOutput($currentController) . '">';
        }
        if ($currentToken !== '') {
            $html .= $this->htmlFragment('dd58843e653862574331') . Tools::safeOutput($currentToken) . '">';
        }
        $html .= $this->htmlFragment('3091c38a80ab56aee236');
        if ($showIssueKindFilter) {
            $html .= $this->htmlFragment('eb70306f1258d3def421');
            foreach ($this->getIssueKindFilterOptions() as $value => $label) {
                $html .= $this->htmlFragment('5f0ccbf50845efd83670') . Tools::safeOutput($value) . '"' . ($issueKind === $value ? ' selected' : '') . '>' . Tools::safeOutput($label) . $this->htmlFragment('620f24ad3a01b0d2fe67');
            }
            $html .= $this->htmlFragment('8f6159402823c46958a7');
        } else {
            $html .= $this->htmlFragment('92c005e0de148d29f20b') . Tools::safeOutput($issueKind) . '">';
        }
        $html .= $this->htmlFragment('730b740402eb0c7fae6f');
        foreach ($this->getIssueStatusFilterOptions() as $value => $label) {
            $html .= $this->htmlFragment('5f0ccbf50845efd83670') . Tools::safeOutput($value) . '"' . ($statusFilter === $value ? ' selected' : '') . '>' . Tools::safeOutput($label) . $this->htmlFragment('620f24ad3a01b0d2fe67');
        }
        $html .= $this->htmlFragment('8f6159402823c46958a7');
        $html .= $this->htmlFragment('97603ae8fb4d63b13987') . Tools::safeOutput($query) . '" placeholder="nr zgłoszenia, zamówienia, kupujący, produkt..." autocomplete="off" autocorrect="off" autocapitalize="none" spellcheck="false" enterkeyhint="search" inputmode="search" data-form-type="other" data-lpignore="true" data-1p-ignore="true">';
        $html .= $this->htmlFragment('dd52e3ab8be937ed29cf');
        if ($query !== '' || $statusFilter !== 'all' || ($showIssueKindFilter && $issueKind !== 'ALL')) {
            $html .= $this->htmlFragment('3c28f24a1d95ba50668f') . Tools::safeOutput($this->getIssueClearFiltersUrl($issueKind)) . $this->htmlFragment('da7197316644ff6075fc');
        }
        $html .= $this->htmlFragment('e0c7bb7b72eeecfc0734');

        return $html;
    }

    protected function renderMessagesToolbar(): string
    {
        $query = trim((string) Tools::getValue('message_query'));
        $unreadOnly = (int) Tools::getValue('message_unread') === 1;
        $withoutReply = (int) Tools::getValue('message_without_reply') === 1;
        $html = $this->htmlFragment('3032253a1eb28a11d114');
        $filterActive = $query !== '' || $unreadOnly || $withoutReply;
        $html .= $this->htmlFragment('780dd26be5e883ee2c7f') . ($filterActive ? '1' : '0') . $this->htmlFragment('ab98d2cdc57dfa7d5c0f') . Tools::safeOutput($this->getAdminLinkFor('AdminAllegroCustomerServiceMessages')) . '" class="aar-messages-filters" autocomplete="off">';
        $html .= $this->htmlFragment('2e6f1522a5e010c39da0');
        $html .= $this->htmlFragment('dd58843e653862574331') . Tools::safeOutput((string) Tools::getAdminTokenLite('AdminAllegroCustomerServiceMessages')) . '">';
        $html .= $this->htmlFragment('9bf294c9aecb0594bcd9');
        $html .= $this->htmlFragment('8e3830c6b014e5c4c630') . Tools::safeOutput($query) . $this->htmlFragment('33baa1625b7bd0d6e8ac');
        $liveSubmit = 'if(this.form.requestSubmit){this.form.requestSubmit();}else{this.form.submit();}';
        $html .= $this->htmlFragment('f1e2d4dba43078ece19c') . ($unreadOnly ? ' checked' : '') . ' onchange="' . Tools::safeOutput($liveSubmit) . $this->htmlFragment('c3922907f2f7a78566d0');
        $html .= $this->htmlFragment('71c96e548f74377c11b3') . ($withoutReply ? ' checked' : '') . ' onchange="' . Tools::safeOutput($liveSubmit) . $this->htmlFragment('7a93a2fade92a23c96b1');
        $html .= $this->htmlFragment('7eab0e9ceacc44cc703e');

        return $html;
    }

    protected function filterMessageThreads(array $threads): array
    {
        $query = mb_strtolower(trim((string) Tools::getValue('message_query')));
        $unreadOnly = (int) Tools::getValue('message_unread') === 1;
        $withoutReply = (int) Tools::getValue('message_without_reply') === 1;

        return array_values(array_filter($threads, function ($thread) use ($query, $unreadOnly, $withoutReply): bool {
            if (!is_array($thread)) {
                return false;
            }
            if ($query !== '' && mb_stripos((string) ($thread['interlocutor']['login'] ?? ''), $query) === false) {
                return false;
            }
            if ($unreadOnly && (bool) ($thread['read'] ?? true)) {
                return false;
            }
            if ($withoutReply && !$this->threadIsWaitingForSellerReply($thread)) {
                return false;
            }

            return true;
        }));
    }

    protected function enrichThreadsWithReplyState(AllegroApiClient $apiClient, array $threads): array
    {
        $cache = json_decode((string) Configuration::get(self::THREAD_REPLY_STATE_CACHE_CONFIG), true);
        if (!is_array($cache)) {
            $cache = [];
        }
        $cacheChanged = false;

        foreach ($threads as &$thread) {
            if (!is_array($thread)) {
                continue;
            }

            $threadId = trim((string) ($thread['id'] ?? ''));
            $lastMessageDateTime = trim((string) ($thread['lastMessageDateTime'] ?? ''));
            if ($threadId === '') {
                continue;
            }

            $cached = is_array($cache[$threadId] ?? null) ? $cache[$threadId] : [];
            if (($cached['last_message_at'] ?? null) === $lastMessageDateTime && array_key_exists('requires_reply', $cached)) {
                $thread['_requires_reply'] = (bool) $cached['requires_reply'];
                continue;
            }

            try {
                $response = $apiClient->getThreadMessages($threadId, 1, 0);
                $messages = is_array($response['messages'] ?? null) ? $response['messages'] : [];
                usort($messages, function (array $a, array $b): int {
                    return (strtotime((string) ($b['createdAt'] ?? '')) ?: 0) <=> (strtotime((string) ($a['createdAt'] ?? '')) ?: 0);
                });
                $latestMessage = is_array($messages[0] ?? null) ? $messages[0] : [];
                $requiresReply = (bool) ($latestMessage['author']['isInterlocutor'] ?? false);
                $thread['_requires_reply'] = $requiresReply;
                $cache[$threadId] = [
                    'last_message_at' => $lastMessageDateTime,
                    'requires_reply' => $requiresReply,
                    'checked_at' => date('c'),
                ];
                $cacheChanged = true;
            } catch (Throwable $e) {
                if (array_key_exists('requires_reply', $cached)) {
                    $thread['_requires_reply'] = (bool) $cached['requires_reply'];
                } else {
                    $thread['_requires_reply'] = false;
                }
                PrestaShopLogger::addLog('[AAR] Thread reply state lookup failed for ' . $threadId . ': ' . $e->getMessage(), 2);
            }
        }
        unset($thread);

        if ($cacheChanged) {
            if (count($cache) > 1000) {
                $cache = array_slice($cache, -1000, null, true);
            }
            Configuration::updateValue(self::THREAD_REPLY_STATE_CACHE_CONFIG, json_encode($cache, JSON_UNESCAPED_SLASHES));
        }

        return $threads;
    }

    protected function threadIsWaitingForSellerReply(array $thread): bool
    {
        if (array_key_exists('_requires_reply', $thread)) {
            return (bool) $thread['_requires_reply'];
        }

        if (isset($thread['lastMessage']['author']['isInterlocutor'])) {
            return (bool) $thread['lastMessage']['author']['isInterlocutor'];
        }

        $authorLogin = trim((string) ($thread['lastMessage']['author']['login'] ?? ''));
        $interlocutorLogin = trim((string) ($thread['interlocutor']['login'] ?? ''));

        if ($authorLogin !== '' && $interlocutorLogin !== '') {
            return $authorLogin === $interlocutorLogin;
        }

        // The threads endpoint often omits lastMessage.author. An unread thread
        // still means the buyer has sent a message which has not been handled.
        return !(bool) ($thread['read'] ?? true);
    }

    protected function renderIssuesToolbar(string $issueType): string
    {
        $issueKind = $this->getCurrentIssueKindFilter($issueType);
        $statusFilter = $this->getCurrentIssueStatusFilter();
        $query = trim((string) Tools::getValue('issue_query'));
        $showIssueKindFilter = mb_strtoupper($issueType) === 'ALL';
        $refreshUrl = $this->getIssuesAdminUrl($issueType, [
            'aar_refresh' => 1,
            '_refresh' => time(),
        ]);

        $html = $this->htmlFragment('0eea05e54e7937b7a97e');
        $html .= $this->htmlFragment('ab85734bd630f53d7e91');
        $html .= $this->renderIssuesFilters($issueKind, $statusFilter, $query, $showIssueKindFilter);
        $html .= $this->htmlFragment('10e3e14c7b7eb26d2433');
        $html .= $this->htmlFragment('a5aea34f23198ff9c7ee') . Tools::safeOutput($refreshUrl) . $this->htmlFragment('6b47578f28c890359709');
        $html .= $this->htmlFragment('aac32651b10f567c461b');
        $html .= $this->htmlFragment('aac32651b10f567c461b');

        return $html;
    }

    protected function renderReturnsToolbar(): string
    {
        $statusFilter = $this->getCurrentReturnStatusFilter();
        $dateRange = $this->getCurrentReturnDateRangeFilter();
        $query = trim((string) Tools::getValue('return_query'));
        $refreshUrl = $this->getReturnsAdminUrl([
            'aar_refresh' => 1,
            '_refresh' => time(),
        ]);
        $clearUrl = $this->getAdminLinkFor('AdminAllegroCustomerServiceReturns');

        $html = $this->htmlFragment('fdf0bb91d76f95129689');
        $html .= $this->htmlFragment('bae47717eff43eb5e676');
        $html .= $this->htmlFragment('64bdd196d26804558c41') . Tools::safeOutput($this->getCurrentReturnsFilterActionUrl()) . '" class="aar-returns-filters" autocomplete="off">';
        $currentController = trim((string) Tools::getValue('controller'));
        $tokenController = $currentController !== ''
            ? $currentController
            : $this->resolveAdminControllerName('AdminAllegroCustomerServiceReturns');
        $currentToken = trim((string) Tools::getAdminTokenLite($tokenController));
        if ($currentController !== '') {
            $html .= $this->htmlFragment('6e7807eefa9e72e6a446') . Tools::safeOutput($currentController) . '">';
        }
        if ($currentToken !== '') {
            $html .= $this->htmlFragment('dd58843e653862574331') . Tools::safeOutput($currentToken) . '">';
        }
        $html .= $this->htmlFragment('235bf9443b8f750f787d');
        $html .= $this->htmlFragment('16856c27d3b294611f93');
        foreach ($this->getCustomerReturnStatusFilterOptions() as $value => $label) {
            $html .= $this->htmlFragment('5f0ccbf50845efd83670') . Tools::safeOutput($value) . '"' . ($statusFilter === $value ? ' selected' : '') . '>' . Tools::safeOutput($label) . $this->htmlFragment('620f24ad3a01b0d2fe67');
        }
        $html .= $this->htmlFragment('8f6159402823c46958a7');
        $html .= $this->htmlFragment('2c3117992c36c675405d');
        foreach ($this->getCustomerReturnDateRangeOptions() as $value => $label) {
            $html .= $this->htmlFragment('5f0ccbf50845efd83670') . Tools::safeOutput($value) . '"' . ($dateRange === $value ? ' selected' : '') . '>' . Tools::safeOutput($label) . $this->htmlFragment('620f24ad3a01b0d2fe67');
        }
        $html .= $this->htmlFragment('8f6159402823c46958a7');
        $html .= $this->htmlFragment('1b9d75988ec88953de61') . Tools::safeOutput($query) . '" placeholder="nr zwrotu, przesyłki, telefon kupującego..." autocomplete="off" autocorrect="off" autocapitalize="none" spellcheck="false" enterkeyhint="search" inputmode="search" data-form-type="other" data-lpignore="true" data-1p-ignore="true">';
        $html .= $this->htmlFragment('dd52e3ab8be937ed29cf');
        if ($query !== '' || $statusFilter !== 'all' || $dateRange !== '90') {
            $html .= $this->htmlFragment('3c28f24a1d95ba50668f') . Tools::safeOutput($clearUrl) . $this->htmlFragment('da7197316644ff6075fc');
        }
        $html .= $this->htmlFragment('e0c7bb7b72eeecfc0734');
        $html .= $this->htmlFragment('f0244430c3e8f8e7f9ac');
        $html .= $this->htmlFragment('a5aea34f23198ff9c7ee') . Tools::safeOutput($refreshUrl) . $this->htmlFragment('6b47578f28c890359709');
        $html .= $this->htmlFragment('aac32651b10f567c461b');
        $html .= $this->htmlFragment('aac32651b10f567c461b');

        return $html;
    }

    protected function getCurrentReturnsFilterActionUrl(): string
    {
        $requestUri = isset($_SERVER['REQUEST_URI']) ? trim((string) $_SERVER['REQUEST_URI']) : '';
        if ($requestUri !== '') {
            $cleanUri = preg_replace('/([&?])return_id=[^&]*/', '$1', $requestUri);
            $cleanUri = preg_replace('/([&?])return_pages=[^&]*/', '$1', (string) $cleanUri);
            $cleanUri = preg_replace('/&&+/', '&', (string) $cleanUri);
            $cleanUri = str_replace('?&', '?', (string) $cleanUri);
            $cleanUri = preg_replace('/[?&]+$/', '', (string) $cleanUri);

            return $cleanUri;
        }

        return $this->getAdminLinkFor('AdminAllegroCustomerServiceReturns');
    }

    protected function getCurrentIssuesFilterActionUrl(): string
    {
        $requestUri = isset($_SERVER['REQUEST_URI']) ? trim((string) $_SERVER['REQUEST_URI']) : '';
        if ($requestUri !== '') {
            $cleanUri = preg_replace('/([&?])issue_id=[^&]*/', '$1', $requestUri);
            $cleanUri = preg_replace('/([&?])issue_pages=[^&]*/', '$1', (string) $cleanUri);
            $cleanUri = preg_replace('/&&+/', '&', (string) $cleanUri);
            $cleanUri = str_replace('?&', '?', (string) $cleanUri);
            $cleanUri = preg_replace('/[?&]+$/', '', (string) $cleanUri);

            return $cleanUri;
        }

        $currentController = trim((string) Tools::getValue('controller'));
        if ($currentController === '') {
            $currentController = $this->resolveAdminControllerName('AdminAllegroCustomerServiceComplaints');
        }

        return $this->context->link->getAdminLink($currentController, true);
    }

    protected function getIssueClearFiltersUrl(string $issueKind): string
    {
        $currentController = trim((string) Tools::getValue('controller'));
        if ($currentController === '') {
            $currentController = $issueKind === 'DISPUTE'
                ? $this->resolveAdminControllerName('AdminAllegroCustomerServiceDisputes')
                : $this->resolveAdminControllerName('AdminAllegroCustomerServiceComplaints');
        }

        return $this->context->link->getAdminLink($currentController, true);
    }

    protected function getIssueKindFilterOptions(): array
    {
        return [
            'ALL' => 'wszystkie',
            'DISPUTE' => 'Dyskusje',
            'CLAIM' => 'Reklamacje',
        ];
    }

    protected function getCurrentIssueKindFilter(string $defaultIssueType): string
    {
        $defaultIssueType = mb_strtoupper(trim($defaultIssueType));
        if (in_array($defaultIssueType, ['DISPUTE', 'CLAIM'], true)) {
            return $defaultIssueType;
        }

        $kind = mb_strtoupper(trim((string) Tools::getValue('issue_kind', $defaultIssueType)));
        $options = $this->getIssueKindFilterOptions();

        return isset($options[$kind]) ? $kind : mb_strtoupper($defaultIssueType);
    }

    protected function getCurrentIssuePageCount(): int
    {
        return max(1, min(20, (int) Tools::getValue('issue_pages', 1)));
    }

    protected function getCurrentThreadPageCount(): int
    {
        return max(1, min(20, (int) Tools::getValue('thread_pages', 1)));
    }

    protected function getCurrentReturnPageCount(): int
    {
        return max(1, min(20, (int) Tools::getValue('return_pages', 1)));
    }

    protected function getFilteredCustomerReturns(AllegroApiClient $apiClient, int $pageCount = 1, &$hasMoreReturns = false): array
    {
        $returns = [];
        $seenReturnIds = [];
        $hasMoreReturns = false;
        $limit = 100;
        $pageCount = max(1, $pageCount);
        $filters = $this->getCurrentReturnApiFilters();

        for ($page = 0; $page < $pageCount; ++$page) {
            $response = $apiClient->getCustomerReturns($limit, $page * $limit, $filters);
            $responseReturns = $response['customerReturns'] ?? [];
            if (!is_array($responseReturns)) {
                $responseReturns = [];
            }
            if (count($responseReturns) >= $limit && $page === $pageCount - 1) {
                $hasMoreReturns = true;
            }

            foreach ($responseReturns as $return) {
                if (!is_array($return)) {
                    continue;
                }

                $returnId = trim((string) ($return['id'] ?? ''));
                if ($returnId !== '') {
                    if (isset($seenReturnIds[$returnId])) {
                        continue;
                    }

                    $seenReturnIds[$returnId] = true;
                }

                $returns[] = $return;
            }
        }

        usort($returns, function (array $a, array $b): int {
            return (strtotime((string) ($b['createdAt'] ?? '')) ?: 0) <=> (strtotime((string) ($a['createdAt'] ?? '')) ?: 0);
        });

        $query = trim((string) Tools::getValue('return_query'));
        if ($query !== '') {
            $returns = $this->filterCustomerReturnsBySearch($apiClient, $returns, $query);
        }

        return $returns;
    }

    protected function getCurrentReturnApiFilters(): array
    {
        $filters = [];
        $status = $this->getCurrentReturnStatusFilter();
        if ($status !== 'all') {
            $filters['status'] = $status;
        }

        $dateRange = $this->getCurrentReturnDateRangeFilter();
        if ($dateRange !== 'all') {
            $days = max(1, (int) $dateRange);
            $from = new DateTimeImmutable('now', new DateTimeZone('UTC'));
            $from = $from->modify('-' . $days . ' days')->setTime(0, 0, 0, 0);
            $filters['createdAt.gte'] = $from->format('Y-m-d\TH:i:s.000\Z');
        }

        return $filters;
    }

    protected function filterCustomerReturnsBySearch(AllegroApiClient $apiClient, array $returns, string $query): array
    {
        $filtered = [];

        foreach ($returns as $return) {
            if (!is_array($return)) {
                continue;
            }

            if ($this->customerReturnMatchesSearch($return, $query)) {
                $filtered[] = $return;
                continue;
            }

            $returnId = trim((string) ($return['id'] ?? ''));
            if ($returnId === '') {
                continue;
            }

            try {
                $details = $apiClient->getCustomerReturn($returnId);
                if (is_array($details) && $details && $this->customerReturnMatchesSearch($details, $query)) {
                    $filtered[] = $details;
                }
            } catch (Throwable $e) {
                PrestaShopLogger::addLog('[AAR] Customer return search details fetch failed for ' . $returnId . ': ' . $e->getMessage(), 2);
            }
        }

        return $filtered;
    }

    protected function customerReturnMatchesSearch(array $return, string $query): bool
    {
        $query = trim($query);
        if ($query === '') {
            return true;
        }

        $parts = [];
        $parts[] = (string) ($return['id'] ?? '');
        $parts[] = (string) ($return['referenceNumber'] ?? '');
        $parts[] = (string) ($return['orderId'] ?? '');
        $parts[] = (string) ($return['buyer']['login'] ?? '');
        $parts[] = (string) ($return['buyer']['email'] ?? '');
        $parts[] = (string) ($return['buyer']['firstName'] ?? '');
        $parts[] = (string) ($return['buyer']['lastName'] ?? '');
        $parts[] = (string) ($return['buyer']['phoneNumber'] ?? '');
        $parts[] = (string) ($return['delivery']['phoneNumber'] ?? '');
        $parts[] = (string) ($return['sender']['phoneNumber'] ?? '');

        foreach (($return['items'] ?? []) as $item) {
            if (!is_array($item)) {
                continue;
            }
            $parts[] = (string) ($item['name'] ?? '');
            $parts[] = (string) ($item['offerId'] ?? '');
            $parts[] = (string) ($item['reason']['type'] ?? '');
            $parts[] = (string) ($item['reason']['userComment'] ?? '');
        }

        foreach (($return['parcels'] ?? []) as $parcel) {
            if (!is_array($parcel)) {
                continue;
            }
            $parts[] = (string) ($parcel['waybill'] ?? '');
            $parts[] = (string) ($parcel['transportingWaybill'] ?? '');
            $parts[] = (string) ($parcel['sender']['phoneNumber'] ?? '');
        }

        $parts[] = $this->getCustomerReturnBuyerName($return);

        $nonEmptyParts = array_filter($parts, static function ($part) {
            return is_string($part) && $part !== '';
        });
        $haystack = $this->normalizeSearchText(implode(' ', $nonEmptyParts));
        $needle = $this->normalizeSearchText($query);
        if ($needle !== '' && strpos($haystack, $needle) !== false) {
            return true;
        }

        $haystackCompact = $this->normalizeSearchTextCompact(implode('', $nonEmptyParts));
        $needleCompact = $this->normalizeSearchTextCompact($query);

        return $needleCompact !== '' && strpos($haystackCompact, $needleCompact) !== false;
    }

    protected function normalizeSearchText(string $value): string
    {
        $value = Tools::replaceAccentedChars($value);
        $value = mb_strtolower($value);
        $value = preg_replace('/\s+/u', ' ', $value);

        return trim((string) $value);
    }

    protected function normalizeSearchTextCompact(string $value): string
    {
        $value = $this->normalizeSearchText($value);

        return (string) preg_replace('/[^a-z0-9]+/u', '', $value);
    }

    protected function extractSearchableScalars(array $payload): array
    {
        $values = [];
        foreach ($payload as $value) {
            if (is_scalar($value)) {
                $text = trim((string) $value);
                if ($text !== '') {
                    $values[] = $text;
                }
                continue;
            }

            if (is_array($value)) {
                $values = array_merge($values, $this->extractSearchableScalars($value));
            }
        }

        return $values;
    }

    protected function getCurrentReturnStatusFilter(): string
    {
        $status = mb_strtoupper(trim((string) Tools::getValue('return_status', 'all')));
        $options = $this->getCustomerReturnStatusFilterOptions();

        return isset($options[$status]) ? $status : 'all';
    }

    protected function getCurrentReturnDateRangeFilter(): string
    {
        $range = trim((string) Tools::getValue('return_date_range', '90'));
        $options = $this->getCustomerReturnDateRangeOptions();

        return isset($options[$range]) ? $range : '90';
    }

    protected function getCurrentReturnQueryType(): string
    {
        $type = trim((string) Tools::getValue('return_query_type', 'referenceNumber'));
        $options = $this->getCustomerReturnQueryTypeOptions();

        return isset($options[$type]) ? $type : 'referenceNumber';
    }

    protected function getCustomerReturnStatusFilterOptions(): array
    {
        return [
            'all' => 'wszystkie',
            'CREATED' => 'utworzone',
            'DISPATCHED' => 'nadane',
            'IN_TRANSIT' => 'w transporcie',
            'DELIVERED' => 'dostarczone',
            'WAREHOUSE_DELIVERED' => 'w magazynie',
            'WAREHOUSE_VERIFICATION' => 'w weryfikacji',
            'FINISHED' => 'zakończone',
            'FINISHED_APT' => 'zakończone APT',
            'REJECTED' => 'odrzucone',
            'COMMISSION_REFUND_CLAIMED' => 'wniosek o prowizję',
            'COMMISSION_REFUNDED' => 'prowizja zwrócona',
        ];
    }

    protected function getCustomerReturnDateRangeOptions(): array
    {
        return [
            '30' => 'ostatnie 30 dni',
            '90' => 'ostatnie 90 dni',
            '180' => 'ostatnie 180 dni',
            '365' => 'ostatni rok',
            'all' => 'całe archiwum',
        ];
    }

    protected function getCustomerReturnQueryTypeOptions(): array
    {
        return [
            'referenceNumber' => 'nr zwrotu',
            'customerReturnId' => 'id zwrotu',
            'orderId' => 'id zamówienia',
            'buyer.login' => 'login kupującego',
            'buyer.email' => 'e-mail kupującego',
            'items.offerId' => 'id oferty',
            'items.name' => 'nazwa produktu',
            'parcels.waybill' => 'nr przesyłki',
            'parcels.transportingWaybill' => 'nr przesyłki przewoźnika',
        ];
    }

    protected function getFilteredIssuesForKind(AllegroApiClient $apiClient, string $issueKind, string $statusFilter, int $pageCount = 1, &$hasMoreIssues = false): array
    {
        $issueKinds = $issueKind === 'ALL' ? ['DISPUTE', 'CLAIM'] : [$issueKind];
        $issues = [];
        $seenIssueIds = [];
        $hasMoreIssues = false;
        $limit = 100;
        $pageCount = max(1, $pageCount);

        foreach ($issueKinds as $singleIssueType) {
            for ($page = 0; $page < $pageCount; ++$page) {
                $response = $apiClient->getIssues($limit, $page * $limit, ['type' => $singleIssueType]);
                $responseIssues = $response['issues'] ?? [];
                if (count($responseIssues) >= $limit && $page === $pageCount - 1) {
                    $hasMoreIssues = true;
                }

                foreach ($responseIssues as $issue) {
                    if (is_array($issue)) {
                        $returnedIssueType = mb_strtoupper(trim((string) ($issue['type'] ?? '')));
                        if ($returnedIssueType !== '' && $returnedIssueType !== $singleIssueType) {
                            continue;
                        }

                        $issueId = trim((string) ($issue['id'] ?? ''));
                        if ($issueId !== '') {
                            if (isset($seenIssueIds[$issueId])) {
                                continue;
                            }

                            $seenIssueIds[$issueId] = true;
                        }

                        $issue['type'] = $issue['type'] ?? $singleIssueType;
                        $issues[] = $issue;
                    }
                }
            }
        }

        $issues = $this->filterIssuesByStatus($issues, $statusFilter);
        $query = trim((string) Tools::getValue('issue_query'));
        if ($query !== '') {
            $issues = $this->filterIssuesBySearch($apiClient, $issues, $query);
        }

        usort($issues, function (array $a, array $b): int {
            return $this->getIssueSortTimestamp($b) <=> $this->getIssueSortTimestamp($a);
        });

        return $issues;
    }

    protected function filterIssuesBySearch(AllegroApiClient $apiClient, array $issues, string $query): array
    {
        $filtered = [];

        foreach ($issues as $issue) {
            if (!is_array($issue)) {
                continue;
            }

            if ($this->issueMatchesSearch($issue, $query)) {
                $filtered[] = $issue;
                continue;
            }

            $issueId = trim((string) ($issue['id'] ?? ''));
            if ($issueId === '') {
                continue;
            }

            try {
                $details = $apiClient->getIssue($issueId);
                if (is_array($details) && $details && $this->issueMatchesSearch($details, $query)) {
                    $details['type'] = $details['type'] ?? ($issue['type'] ?? '');
                    $filtered[] = $details;
                }
            } catch (Throwable $e) {
                PrestaShopLogger::addLog('[AAR] Issue search details fetch failed for ' . $issueId . ': ' . $e->getMessage(), 2);
            }
        }

        return $filtered;
    }

    protected function issueMatchesSearch(array $issue, string $query): bool
    {
        $query = trim($query);
        if ($query === '') {
            return true;
        }

        $parts = [];
        $parts[] = (string) ($issue['id'] ?? '');
        $parts[] = (string) ($issue['referenceNumber'] ?? '');
        $parts[] = (string) ($issue['buyer']['login'] ?? '');
        $parts[] = (string) ($issue['buyer']['email'] ?? '');
        $parts[] = (string) ($issue['participant']['login'] ?? '');
        $parts[] = (string) ($issue['order']['id'] ?? '');
        $parts[] = (string) ($issue['buyer']['order']['id'] ?? '');
        $parts[] = (string) ($issue['relatesTo']['order']['id'] ?? '');
        $parts[] = (string) ($issue['offer']['id'] ?? '');
        $parts[] = (string) ($issue['relatesTo']['offer']['id'] ?? '');
        $parts[] = $this->buildIssueSubject($issue);
        $parts[] = $this->buildIssuePreview($issue);
        $parts[] = $this->formatIssueStatus((string) ($issue['currentState']['status'] ?? $issue['status'] ?? ''));
        $parts[] = $this->formatIssueTypeLabel((string) ($issue['type'] ?? ''));

        foreach ($this->extractCheckoutFormIdsFromPayload($issue) as $id) {
            $parts[] = $id;
        }
        foreach ($this->extractIssueOfferIdsFromPayload($issue) as $id) {
            $parts[] = $id;
        }
        foreach ($this->extractIssueProductIdsFromPayload($issue) as $id) {
            $parts[] = $id;
        }
        foreach ($this->extractSearchableScalars($issue) as $value) {
            $parts[] = $value;
        }

        $parts = array_values(array_unique(array_filter($parts, static function ($part) {
            return is_string($part) && $part !== '';
        })));
        $haystack = $this->normalizeSearchText(implode(' ', $parts));
        $needle = $this->normalizeSearchText($query);
        if ($needle !== '' && strpos($haystack, $needle) !== false) {
            return true;
        }

        $haystackCompact = $this->normalizeSearchTextCompact(implode('', $parts));
        $needleCompact = $this->normalizeSearchTextCompact($query);

        return $needleCompact !== '' && strpos($haystackCompact, $needleCompact) !== false;
    }

    protected function getIssueSortTimestamp(array $issue): int
    {
        $date = (string) (
            $issue['lastMessage']['createdAt']
            ?? $issue['updatedAt']
            ?? $issue['createdAt']
            ?? $issue['openedDate']
            ?? ''
        );

        return strtotime($date) ?: 0;
    }

    protected function getIssueSectionTitleForKind(string $issueKind, string $defaultSectionTitle): string
    {
        if ($issueKind === 'ALL') {
            return 'Reklamacje i dyskusje';
        }

        if ($issueKind === 'DISPUTE') {
            return 'Dyskusje';
        }

        if ($issueKind === 'CLAIM') {
            return 'Reklamacje';
        }

        return $defaultSectionTitle;
    }

    protected function formatIssueSubjectText(string $subject): string
    {
        $normalized = mb_strtolower(trim($subject));
        $normalized = preg_replace('/[\s\p{Z}_-]+/u', ' ', $normalized) ?? $normalized;
        $normalized = trim($normalized);
        if ($normalized === '') {
            return '';
        }

        $map = [
            'i have a problem returning the product' => 'Mam problem ze zwrotem produktu',
            'no refund after returning the product' => 'Brak zwrotu środków po odesłaniu produktu',
            'missing product element' => 'Brak elementu produktu',
            'defects emerged during use' => 'Wada ujawniona podczas użytkowania',
            'defect found during use' => 'Wada ujawniona podczas użytkowania',
            'product and parcel damaged in transit' => 'Produkt i przesyłka uszkodzone w transporcie',
            'product and parcel damaged (in transit)' => 'Produkt i przesyłka uszkodzone w transporcie',
            'i have not received the product' => 'Nie otrzymałem produktu',
            'no product in the parcel' => 'Brak produktu w przesyłce',
            'product not as described' => 'Produkt niezgodny z opisem',
            'not as described' => 'Produkt niezgodny z opisem',
            'damaged product' => 'Uszkodzony produkt',
            'the seller does not want to accept the return' => 'Sprzedający nie chce przyjąć zwrotu',
            'seller does not want to accept the return' => 'Sprzedający nie chce przyjąć zwrotu',
            'the seller doesn\'t want to accept the return' => 'Sprzedający nie chce przyjąć zwrotu',
            'seller doesn\'t want to accept the return' => 'Sprzedający nie chce przyjąć zwrotu',
            'the seller refuses to accept the return' => 'Sprzedający odmawia przyjęcia zwrotu',
            'seller refuses to accept the return' => 'Sprzedający odmawia przyjęcia zwrotu',
            'the seller refused to accept the return' => 'Sprzedający odmówił przyjęcia zwrotu',
            'seller refused to accept the return' => 'Sprzedający odmówił przyjęcia zwrotu',
            'the seller rejected the return' => 'Sprzedający odrzucił zwrot',
            'seller rejected the return' => 'Sprzedający odrzucił zwrot',
        ];

        return $map[$normalized] ?? $subject;
    }

    protected function resolveIssueTextValue($value): string
    {
        if (is_string($value)) {
            return trim($value);
        }

        if (is_numeric($value)) {
            return trim((string) $value);
        }

        if (!is_array($value)) {
            return '';
        }

        foreach (['pl', 'pl-PL', 'en', 'en-US', 'name', 'label', 'value', 'message', 'text'] as $key) {
            if (array_key_exists($key, $value)) {
                $resolved = $this->resolveIssueTextValue($value[$key]);
                if ($resolved !== '') {
                    return $resolved;
                }
            }
        }

        foreach ($value as $item) {
            $resolved = $this->resolveIssueTextValue($item);
            if ($resolved !== '') {
                return $resolved;
            }
        }

        return '';
    }

    protected function threadRequiresSellerReply(array $thread): bool
    {
        if (array_key_exists('_requires_reply', $thread)) {
            return (bool) $thread['_requires_reply'];
        }

        $read = (bool) ($thread['read'] ?? true);
        if ($read) {
            return false;
        }

        if (isset($thread['lastMessage']['author']['isInterlocutor'])) {
            return (bool) $thread['lastMessage']['author']['isInterlocutor'];
        }

        if (isset($thread['lastMessage']['author']['login'], $thread['interlocutor']['login'])) {
            return (string) $thread['lastMessage']['author']['login'] === (string) $thread['interlocutor']['login'];
        }

        return $read === false;
    }

    protected function issueRequiresSellerReply(array $issue): bool
    {
        $status = mb_strtoupper(trim((string) ($issue['status'] ?? '')));
        if ($status === 'CLOSED' || $status === 'RESOLVED') {
            return false;
        }

        if (isset($issue['lastMessage']['author']['role'])) {
            return mb_strtoupper((string) $issue['lastMessage']['author']['role']) !== 'SELLER';
        }

        return true;
    }

    protected function isIssueCustomerMessage(array $message): bool
    {
        if (isset($message['author']['role'])) {
            return mb_strtoupper((string) $message['author']['role']) !== 'SELLER';
        }

        return true;
    }

    protected function getIssueAuthorLabel(array $message, array $issue): string
    {
        $role = mb_strtoupper((string) ($message['author']['role'] ?? ''));
        if ($role === 'SELLER') {
            return 'Ty';
        }

        $login = (string) ($message['author']['login'] ?? $issue['buyer']['login'] ?? '');
        if ($login !== '') {
            return $login;
        }

        if ($role === 'ALLEGRO') {
            return 'Allegro';
        }

        return 'Klient';
    }

    protected function formatIssueStatus(string $status): string
    {
        $map = [
            'NEW' => 'Nowa',
            'OPEN' => 'Otwarta',
            'IN_PROGRESS' => 'W trakcie',
            'DISPUTE_ONGOING' => 'Dyskusja w toku',
            'DISPUTE_UNRESOLVED' => 'Dyskusja nierozwiązana',
            'DISPUTE_RESOLVED' => 'Dyskusja rozwiązana',
            'DISPUTE_CLOSED' => 'Dyskusja zamknięta',
            'CLAIM_SUBMITTED' => 'Reklamacja zgłoszona',
            'CLAIM_REJECTED' => 'Reklamacja odrzucona',
            'CLAIM_ACCEPTED' => 'Reklamacja uznana',
            'RESOLVED' => 'Rozwiązana',
            'CLOSED' => 'Zamknięta',
        ];

        $status = mb_strtoupper(trim($status));

        return $map[$status] ?? ($status !== '' ? str_replace('_', ' ', $status) : 'Nieznany status');
    }

    protected function formatIssueListStatus(string $status): string
    {
        $status = mb_strtoupper(trim($status));

        $map = [
            'DISPUTE_ONGOING' => 'W toku',
            'DISPUTE_UNRESOLVED' => 'Nierozwiązana',
            'DISPUTE_RESOLVED' => 'Rozwiązana',
            'DISPUTE_CLOSED' => 'Zamknięta',
            'CLAIM_SUBMITTED' => 'Zgłoszona',
            'CLAIM_REJECTED' => 'Odrzucona',
            'CLAIM_ACCEPTED' => 'Uznana',
        ];

        return $map[$status] ?? $this->formatIssueStatus($status);
    }

    protected function getIssueStatusFilterOptions(): array
    {
        return [
            'all' => 'wszystkie',
            'in_progress' => 'w toku',
            'unresolved' => 'nierozwiązane',
            'resolved' => 'rozwiązane',
            'overdue' => 'przedawnione',
        ];
    }

    protected function getCurrentIssueStatusFilter(): string
    {
        $filter = trim((string) Tools::getValue('status_filter', 'all'));
        $options = $this->getIssueStatusFilterOptions();

        return isset($options[$filter]) ? $filter : 'all';
    }

    protected function filterIssuesByStatus(array $issues, string $statusFilter): array
    {
        if ($statusFilter === 'all') {
            return $issues;
        }

        return array_values(array_filter($issues, function (array $issue) use ($statusFilter): bool {
            $resolved = $this->isIssueResolved($issue);
            $overdue = $this->isIssueOverdue($issue);

            switch ($statusFilter) {
                case 'in_progress':
                    return !$resolved && !$overdue;
                case 'unresolved':
                    return !$resolved;
                case 'resolved':
                    return $resolved;
                case 'overdue':
                    return $overdue;
                default:
                    return true;
            }
        }));
    }

    protected function isIssueResolved(array $issue): bool
    {
        $status = mb_strtoupper(trim((string) ($issue['currentState']['status'] ?? $issue['status'] ?? '')));

        return in_array($status, ['CLAIM_ACCEPTED', 'CLAIM_REJECTED', 'RESOLVED', 'CLOSED'], true);
    }

    protected function isIssueOverdue(array $issue): bool
    {
        if ($this->isIssueResolved($issue)) {
            return false;
        }

        $dueDate = (string) ($issue['decisionDueDate'] ?? $issue['currentState']['statusDueDate'] ?? '');
        $dueTimestamp = strtotime($dueDate);

        return $dueTimestamp !== false && $dueTimestamp < time();
    }

    protected function getIssueStatusClass(string $status): string
    {
        $status = mb_strtoupper(trim($status));

        if (in_array($status, ['CLAIM_ACCEPTED', 'RESOLVED', 'CLOSED', 'DISPUTE_CLOSED'], true)) {
            return 'is-ok';
        }

        if (in_array($status, ['CLAIM_REJECTED'], true)) {
            return 'is-overdue';
        }

        if (in_array($status, ['NEW', 'OPEN', 'IN_PROGRESS', 'DISPUTE_ONGOING'], true)) {
            return 'is-warning';
        }

        if ($status === 'DISPUTE_RESOLVED') {
            return 'is-ok';
        }

        return 'is-neutral';
    }

    protected function formatIssueTypeLabel(string $issueType): string
    {
        $issueType = mb_strtoupper(trim($issueType));

        if ($issueType === 'DISPUTE') {
            return 'Dyskusja';
        }

        if ($issueType === 'CLAIM') {
            return 'Reklamacja';
        }

        return '';
    }

    protected function getIssueTypeBadgeClass(string $issueType): string
    {
        $issueType = mb_strtoupper(trim($issueType));

        if ($issueType === 'DISPUTE') {
            return 'is-dispute';
        }

        if ($issueType === 'CLAIM') {
            return 'is-claim';
        }

        return 'is-neutral';
    }

    protected function formatIssueReasonType(string $reasonType): string
    {
        $map = [
            'MISSING_PRODUCT_ELEMENT' => 'Brak elementu produktu',
            'DEFECTS_EMERGED_DURING_USE' => 'Wada ujawniona podczas użytkowania',
            'DEFECT_FOUND_DURING_USE' => 'Wada ujawniona podczas użytkowania',
            'PRODUCT_NOT_AS_DESCRIBED' => 'Produkt niezgodny z opisem',
            'NOT_AS_DESCRIBED' => 'Produkt niezgodny z opisem',
            'NOT AS DESCRIBED' => 'Produkt niezgodny z opisem',
            'DAMAGED_PRODUCT' => 'Uszkodzony produkt',
            'PRODUCT_DOES_NOT_WORK' => 'Produkt nie działa',
            'WRONG_PRODUCT' => 'Błędny produkt',
            'INCOMPLETE_PRODUCT' => 'Niekompletny produkt',
            'MISSING_ACCESSORY' => 'Brak akcesorium',
            'BROKEN_PRODUCT' => 'Uszkodzony produkt',
            'PRODUCT_AND_PARCEL_DAMAGED_IN_TRANSIT' => 'Produkt i przesyłka uszkodzone w transporcie',
            'QUALITY_ISSUE' => 'Problem z jakością produktu',
            'OTHER' => 'Inny powód',
        ];

        $reasonType = mb_strtoupper(trim($reasonType));
        $reasonType = preg_replace('/[\s\p{Z}_-]+/u', '_', $reasonType) ?? $reasonType;
        $reasonType = trim($reasonType, '_');

        if ($reasonType === '') {
            return '';
        }

        if (isset($map[$reasonType])) {
            return $map[$reasonType];
        }

        $pretty = mb_strtolower(str_replace('_', ' ', $reasonType));

        return mb_strtoupper(mb_substr($pretty, 0, 1)) . mb_substr($pretty, 1);
    }

    protected function formatIssueRight(string $right): string
    {
        $map = [
            'COMPLAINT' => 'Reklamacja ustawowa',
            'WARRANTY' => 'Gwarancja',
        ];

        $right = mb_strtoupper(trim($right));

        return $map[$right] ?? ($right !== '' ? str_replace('_', ' ', $right) : '');
    }

    protected function formatIssueExpectations(array $expectations): string
    {
        if (!$expectations) {
            return '';
        }

        $map = [
            'EXCHANGE' => 'Wymiana',
            'REPAIR' => 'Naprawa',
            'REFUND' => 'Zwrot środków',
            'PRICE_REDUCTION' => 'Obniżenie ceny',
        ];

        $labels = [];
        foreach ($expectations as $expectation) {
            if (!is_array($expectation)) {
                continue;
            }

            $name = mb_strtoupper(trim((string) ($expectation['name'] ?? '')));
            if ($name === '') {
                continue;
            }

            $labels[] = $map[$name] ?? str_replace('_', ' ', $name);
        }

        return implode(', ', array_unique($labels));
    }

    protected function findCustomerReturnById(array $returns, string $returnId): ?array
    {
        foreach ($returns as $return) {
            if (is_array($return) && (string) ($return['id'] ?? '') === $returnId) {
                return $return;
            }
        }

        return null;
    }

    protected function buildCustomerReturnSubject(array $return): string
    {
        $items = $return['items'] ?? [];
        if (is_array($items) && isset($items[0]) && is_array($items[0])) {
            $name = trim((string) ($items[0]['name'] ?? ''));
            if ($name !== '') {
                return $name;
            }
        }

        $referenceNumber = trim((string) ($return['referenceNumber'] ?? ''));
        if ($referenceNumber !== '') {
            return 'Zwrot ' . $referenceNumber;
        }

        $buyerLogin = trim((string) ($return['buyer']['login'] ?? ''));
        if ($buyerLogin !== '') {
            return 'Zwrot od ' . $buyerLogin;
        }

        return 'Zwrot Allegro';
    }

    protected function buildCustomerReturnPreview(array $return): string
    {
        return '';
    }

    protected function buildCustomerReturnHeaderTitle(array $return): string
    {
        $referenceNumber = trim((string) ($return['referenceNumber'] ?? ''));
        if ($referenceNumber !== '') {
            return 'Zwrot ' . $referenceNumber;
        }

        return 'Zwrot Allegro';
    }

    protected function buildCustomerReturnHeaderSubtitle(array $return): string
    {
        $parts = [];
        $buyerLogin = trim((string) ($return['buyer']['login'] ?? ''));
        $createdAt = $this->formatAllegroDate((string) ($return['createdAt'] ?? ''));

        if ($buyerLogin !== '') {
            $parts[] = $buyerLogin;
        }
        if ($createdAt !== '') {
            $parts[] = $createdAt;
        }

        return $parts ? implode(' • ', $parts) : 'Zwrot kliencki Allegro';
    }

    protected function renderCustomerReturnHeaderMeta(array $return): string
    {
        $parts = [];
        $orderId = trim((string) ($return['orderId'] ?? ''));

        if ($orderId !== '') {
            $orderUrl = $this->getAllegroOrdersUrl($orderId);
            if ($orderUrl !== '') {
                $parts[] = $this->htmlFragment('12500825435037f5f88f') . Tools::safeOutput($orderUrl) . '" target="_blank" rel="noopener noreferrer">' . Tools::safeOutput($orderId) . $this->htmlFragment('030d4238cba6a61e9eaa');
            } else {
                $parts[] = $this->htmlFragment('9eb12d615f8f2e148d1c') . Tools::safeOutput($orderId) . $this->htmlFragment('411fdb22d8d9298e5d32');
            }
        }

        $prestashopOrder = $this->resolvePrestashopOrderLinkForReturn($return);
        if ($prestashopOrder !== null) {
            $prestashopOrderLabel = Tools::safeOutput($this->formatPrestashopOrderReference($prestashopOrder));
            $prestashopOrderUrl = trim((string) ($prestashopOrder['url'] ?? ''));
            if ($prestashopOrderUrl !== '') {
                $parts[] = $this->htmlFragment('ab541aeec2d7c1c49a84') . Tools::safeOutput($prestashopOrderUrl) . '" target="_blank" rel="noopener noreferrer">' . $prestashopOrderLabel . $this->htmlFragment('030d4238cba6a61e9eaa');
            } else {
                $parts[] = $this->htmlFragment('48226d9ce963387febd9') . $prestashopOrderLabel . $this->htmlFragment('411fdb22d8d9298e5d32');
            }
        }

        if (!$parts) {
            return $this->htmlFragment('474cdbb2f6a135794e9d');
        }

        return $this->htmlFragment('cdb6a41090dfe370856f') . implode($this->htmlFragment('e390477c81c44118626d'), $parts) . $this->htmlFragment('3f0e243eb74ef9d8ab22');
    }

    protected function resolvePrestashopOrderLinkForReturn(array $return): ?array
    {
        $checkoutFormId = trim((string) ($return['orderId'] ?? ''));
        if ($checkoutFormId === '') {
            return null;
        }

        $resolved = $this->findPrestashopOrderByX13CheckoutForm($checkoutFormId);
        if ($resolved !== null) {
            return $resolved;
        }

        return $this->findPrestashopOrderByExternalIdentifier($checkoutFormId);
    }

    protected function renderCustomerReturnHeaderBadges(array $return): string
    {
        $status = (string) ($return['status'] ?? '');
        $statusClass = $this->getCustomerReturnStatusClass($status);
        $isFulfillment = isset($return['isFulfillment']) ? (bool) $return['isFulfillment'] : false;
        $html = $this->htmlFragment('c12899cfd4c54f64a7f1');
        $html .= $this->htmlFragment('1c6cd79dff123b375a24') . Tools::safeOutput($statusClass) . ' ' . Tools::safeOutput($statusClass) . '">' . Tools::safeOutput($this->formatCustomerReturnStatus($status)) . $this->htmlFragment('411fdb22d8d9298e5d32');
        if ($isFulfillment) {
            $html .= $this->htmlFragment('bcb3f514a2916e3f2e7e');
        }
        $html .= $this->htmlFragment('aac32651b10f567c461b');

        return $html;
    }

    protected function formatCustomerReturnStatus(string $status): string
    {
        $status = mb_strtoupper(trim($status));
        $map = [
            'CREATED' => 'Utworzony',
            'DISPATCHED' => 'Nadany',
            'IN_TRANSIT' => 'W transporcie',
            'DELIVERED' => 'Dostarczony',
            'FINISHED' => 'Zakończony',
            'FINISHED_APT' => 'Zakończony APT',
            'REJECTED' => 'Odrzucony',
            'COMMISSION_REFUND_CLAIMED' => 'Wniosek o prowizję',
            'COMMISSION_REFUNDED' => 'Prowizja zwrócona',
            'WAREHOUSE_DELIVERED' => 'W magazynie',
            'WAREHOUSE_VERIFICATION' => 'W weryfikacji',
        ];

        return $map[$status] ?? ($status !== '' ? str_replace('_', ' ', $status) : 'Nieznany status');
    }

    protected function getCustomerReturnStatusClass(string $status): string
    {
        $status = mb_strtoupper(trim($status));
        if (in_array($status, ['FINISHED', 'FINISHED_APT', 'COMMISSION_REFUNDED'], true)) {
            return 'is-ok';
        }
        if (in_array($status, ['REJECTED'], true)) {
            return 'is-overdue';
        }
        if (in_array($status, ['CREATED', 'DISPATCHED', 'IN_TRANSIT', 'DELIVERED', 'WAREHOUSE_DELIVERED', 'WAREHOUSE_VERIFICATION', 'COMMISSION_REFUND_CLAIMED'], true)) {
            return 'is-warning';
        }

        return 'is-neutral';
    }

    protected function formatCustomerReturnReasonType(string $reasonType): string
    {
        $reasonType = mb_strtoupper(trim($reasonType));
        $map = [
            'NONE' => 'Odstąpienie bez podania przyczyny',
            'NO_REASON' => 'Odstąpienie bez podania przyczyny',
            'WITHOUT_REASON' => 'Odstąpienie bez podania przyczyny',
            'NO_REASON_GIVEN' => 'Odstąpienie bez podania przyczyny',
            'NOT_SPECIFIED' => 'Odstąpienie bez podania przyczyny',
            'NOT_AS_DESCRIBED' => 'Niezgodny z opisem',
            'DAMAGED' => 'Uszkodzony',
            'WRONG_PRODUCT' => 'Błędny produkt',
            'INCOMPLETE' => 'Niekompletny',
            'DOES_NOT_FIT' => 'Nie pasuje',
            'DONT_LIKE_IT' => 'Nie pasuje mi',
            'WITHDRAWAL' => 'Odstąpienie bez podania przyczyny',
            'OTHER_FLAW' => 'Inna wada',
            'DIFFERENT' => 'Towar inny niż zamówiony',
            'OTHER' => 'Inny powód',
        ];

        if ($reasonType === '') {
            return '';
        }

        return $map[$reasonType] ?? str_replace('_', ' ', $reasonType);
    }

    protected function resolveCustomerReturnReasonComment(array $item): string
    {
        $reason = is_array($item['reason'] ?? null) ? $item['reason'] : [];
        foreach ([
            $reason['userComment'] ?? null,
            $reason['comment'] ?? null,
            $reason['description'] ?? null,
            $reason['note'] ?? null,
            $reason['name'] ?? null,
            $item['reasonComment'] ?? null,
            $item['returnReason'] ?? null,
        ] as $candidate) {
            $value = $this->resolveIssueTextValue($candidate);
            if ($value !== '') {
                return $value;
            }
        }

        return '';
    }

    protected function buildCustomerReturnRefundRows(array $return): array
    {
        $bankAccount = $return['refund']['bankAccount'] ?? [];
        if (!is_array($bankAccount) || !$bankAccount) {
            return [];
        }

        $address = is_array($bankAccount['address'] ?? null) ? $bankAccount['address'] : [];
        $addressLine = trim(implode(', ', array_filter([
            trim((string) ($address['street'] ?? '')),
            trim((string) ($address['postCode'] ?? '')),
            trim((string) ($address['city'] ?? '')),
            trim((string) ($address['countryCode'] ?? '')),
        ])));

        return [
            'Właściciel' => trim((string) ($bankAccount['owner'] ?? '')),
            'IBAN' => $this->maskBankAccount((string) ($bankAccount['iban'] ?? $bankAccount['accountNumber'] ?? '')),
            'SWIFT' => trim((string) ($bankAccount['swift'] ?? '')),
            'Adres' => $addressLine,
        ];
    }

    protected function buildCustomerReturnRejectionRows(array $return): array
    {
        $rejection = $return['rejection'] ?? [];
        if (!is_array($rejection) || !$rejection) {
            return [];
        }

        return [
            'Powód' => $this->formatCustomerReturnRejectionCode((string) ($rejection['code'] ?? '')),
            'Uzasadnienie' => trim((string) ($rejection['reason'] ?? '')),
            'Data' => $this->formatAllegroDate((string) ($rejection['createdAt'] ?? '')),
        ];
    }

    protected function getCustomerReturnRejectionOptions(): array
    {
        return [
            'REFUND_REJECTED' => 'Inny powód',
            'NEW_ITEM_SENT' => 'Wysłano nowy towar',
            'ITEM_FIXED' => 'Naprawa towaru',
            'MISSING_PART_SENT' => 'Dosłanie brakujących elementów',
            'ITEM_MISMATCH' => 'Zwrot niewłaściwego towaru',
            'BUSINESS_PURCHASE' => 'Zakup na firmę',
            'NO_RETURN_RIGHT' => 'Towar nie podlega zwrotowi',
        ];
    }

    protected function getCustomerReturnRejectionReasonDefinitions(): array
    {
        return [
            'NO_RETURN_RIGHT' => [
                'api_code' => 'NO_RETURN_RIGHT',
                'label' => 'Towar nie podlega zwrotowi',
                'description' => 'Np. rozpieczętowane produkty higieniczne, treści cyfrowe, albo produkty wykonane na indywidualne zamówienie kupującego.',
            ],
            'BUSINESS_PURCHASE' => [
                'api_code' => 'BUSINESS_PURCHASE',
                'label' => 'Zakup na firmę',
                'description' => 'Zakup na spółkę, a w przypadku jednoosobowej działalności - zakup o charakterze zawodowym.',
            ],
            'ITEM_MISMATCH' => [
                'api_code' => 'ITEM_MISMATCH',
                'label' => 'Zwrot niewłaściwego towaru',
                'description' => '',
            ],
            'NEW_ITEM_SENT' => [
                'api_code' => 'NEW_ITEM_SENT',
                'label' => 'Wymiana towaru',
                'description' => '',
            ],
            'ITEM_FIXED' => [
                'api_code' => 'ITEM_FIXED',
                'label' => 'Naprawa towaru',
                'description' => '',
            ],
            'MISSING_PART_SENT' => [
                'api_code' => 'MISSING_PART_SENT',
                'label' => 'Dosłanie brakujących elementów',
                'description' => '',
            ],
            'OTHER_REASON' => [
                'api_code' => 'REFUND_REJECTED',
                'label' => 'Inny powód',
                'description' => 'Podaj szczegóły w uzasadnieniu',
            ],
        ];
    }

    protected function formatCustomerReturnRejectionCode(string $code): string
    {
        $code = mb_strtoupper(trim($code));
        $options = $this->getCustomerReturnRejectionOptions();

        return $options[$code] ?? ($code !== '' ? str_replace('_', ' ', $code) : '');
    }

    protected function formatMoneyValue($value): string
    {
        if (!is_array($value)) {
            return '';
        }

        $amount = trim((string) ($value['amount'] ?? ''));
        $currency = trim((string) ($value['currency'] ?? ''));
        if ($amount === '') {
            return '';
        }

        return trim($amount . ' ' . $currency);
    }

    protected function maskEmail(string $email): string
    {
        $email = trim($email);
        if ($email === '' || strpos($email, '@') === false) {
            return $email;
        }

        [$local, $domain] = explode('@', $email, 2);
        $visible = mb_substr($local, 0, 2);

        return $visible . str_repeat('*', max(3, mb_strlen($local) - 2)) . '@' . $domain;
    }

    protected function maskPhone(string $phone): string
    {
        $phone = trim($phone);
        if ($phone === '') {
            return '';
        }

        return preg_replace('/\d(?=\d{3})/', '*', $phone) ?: $phone;
    }

    protected function formatPhoneNumber(string $phone): string
    {
        $phone = trim($phone);
        if ($phone === '') {
            return '';
        }

        $digits = preg_replace('/\D+/', '', $phone);
        if ($digits === null || $digits === '') {
            return $phone;
        }

        if (strlen($digits) === 11 && strpos($digits, '48') === 0) {
            return '+48 ' . substr($digits, 2, 3) . ' ' . substr($digits, 5, 3) . ' ' . substr($digits, 8, 3);
        }

        if (strlen($digits) === 9) {
            return substr($digits, 0, 3) . ' ' . substr($digits, 3, 3) . ' ' . substr($digits, 6, 3);
        }

        if (strpos($phone, '+') === 0 && strlen($digits) > 9) {
            return '+' . substr($digits, 0, max(1, strlen($digits) - 9)) . ' ' . substr($digits, -9, 3) . ' ' . substr($digits, -6, 3) . ' ' . substr($digits, -3);
        }

        return $phone;
    }

    protected function maskBankAccount(string $account): string
    {
        $account = preg_replace('/\s+/', '', trim($account));
        if ($account === null || $account === '') {
            return '';
        }

        if (mb_strlen($account) <= 8) {
            return str_repeat('*', mb_strlen($account));
        }

        return mb_substr($account, 0, 4) . str_repeat('*', max(8, mb_strlen($account) - 8)) . mb_substr($account, -4);
    }

    protected function buildClaimTimeMeta(array $issue, array $messages = []): array
    {
        $openedDate = (string) ($issue['openedDate'] ?? '');
        $decisionDueDate = (string) ($issue['decisionDueDate'] ?? '');
        $status = mb_strtoupper(trim((string) ($issue['currentState']['status'] ?? $issue['status'] ?? '')));
        $openedTs = strtotime($openedDate);
        $dueTs = strtotime($decisionDueDate);
        $now = time();

        if (!$dueTs) {
            return [
                'headline' => 'Brak terminu decyzji',
                'subline' => '',
                'progress_percent' => 0,
                'marker_percent' => 0,
                'show_marker' => false,
                'status_class' => 'is-neutral',
                'resolved_at' => '',
            ];
        }

        $total = max(1, $dueTs - ($openedTs ?: $now));
        $decisionMeta = $this->resolveClaimDecisionMeta($issue, $messages);

        if (in_array($status, ['CLAIM_ACCEPTED', 'CLAIM_REJECTED'], true)) {
            $resolvedAt = $decisionMeta['created_at'] ?? '';
            $decisionTs = strtotime((string) $resolvedAt);
            if ($decisionTs !== false && $decisionTs > 0) {
                $elapsedAtDecision = max(0, min($total, $decisionTs - ($openedTs ?: $decisionTs)));
                $progressPercent = (int) max(4, min(100, round(($elapsedAtDecision / $total) * 100)));
                $delta = $decisionTs - $dueTs;

                if ($delta > 0) {
                    return [
                        'headline' => 'Reklamacja rozpatrzona po terminie',
                        'subline' => 'Rozpatrzono po ' . $this->formatDuration($delta),
                        'progress_percent' => 100,
                        'marker_percent' => 100,
                        'show_marker' => true,
                        'marker_label' => $this->getClaimDecisionMarkerLabel($status),
                        'status_class' => 'is-overdue',
                        'resolved_at' => (string) $resolvedAt,
                    ];
                }

                $beforeDeadline = abs($delta);

                return [
                    'headline' => 'Reklamacja rozpatrzona w terminie',
                    'subline' => $beforeDeadline > 0
                        ? 'Rozpatrzono przed terminem o ' . $this->formatDuration($beforeDeadline)
                        : 'Rozpatrzono dokładnie w terminie',
                    'progress_percent' => $progressPercent,
                    'marker_percent' => $progressPercent,
                    'show_marker' => true,
                    'marker_label' => $this->getClaimDecisionMarkerLabel($status),
                    'status_class' => 'is-ok',
                    'resolved_at' => (string) $resolvedAt,
                ];
            }

            return [
                'headline' => 'Reklamacja rozpatrzona',
                'subline' => 'Brak dokładnej daty rozpatrzenia w danych Allegro',
                'progress_percent' => 100,
                'marker_percent' => 100,
                'show_marker' => false,
                'marker_label' => '',
                'status_class' => 'is-neutral',
                'resolved_at' => '',
            ];
        }

        $elapsed = max(0, min($total, $now - ($openedTs ?: $now)));
        $remaining = $dueTs - $now;
        $progressPercent = (int) max(4, min(100, round(($elapsed / $total) * 100)));

        if ($remaining < 0) {
            return [
                'headline' => 'Termin decyzji minął',
                'subline' => 'Po terminie o ' . $this->formatDuration(abs($remaining)),
                'progress_percent' => 100,
                'marker_percent' => 100,
                'show_marker' => false,
                'status_class' => 'is-overdue',
                'resolved_at' => '',
            ];
        }

        if ($remaining <= 2 * 24 * 3600) {
            return [
                'headline' => 'Mało czasu na decyzję',
                'subline' => 'Pozostało ' . $this->formatDuration($remaining),
                'progress_percent' => $progressPercent,
                'marker_percent' => $progressPercent,
                'show_marker' => false,
                'status_class' => 'is-warning',
                'resolved_at' => '',
            ];
        }

        return [
            'headline' => 'Czas na rozpatrzenie reklamacji',
            'subline' => 'Pozostało ' . $this->formatDuration($remaining),
            'progress_percent' => $progressPercent,
            'marker_percent' => $progressPercent,
            'show_marker' => false,
            'status_class' => 'is-ok',
            'resolved_at' => '',
        ];
    }

    protected function resolveClaimDecisionMeta(array $issue, array $messages = []): array
    {
        $candidates = [
            ['value' => $issue['resolution']['createdAt'] ?? null, 'source' => 'resolution.createdAt'],
            ['value' => $issue['resolution']['resolvedAt'] ?? null, 'source' => 'resolution.resolvedAt'],
            ['value' => $issue['currentState']['changedAt'] ?? null, 'source' => 'currentState.changedAt'],
            ['value' => $issue['currentState']['statusChangedAt'] ?? null, 'source' => 'currentState.statusChangedAt'],
            ['value' => $issue['currentState']['updatedAt'] ?? null, 'source' => 'currentState.updatedAt'],
            ['value' => $issue['resolvedAt'] ?? null, 'source' => 'resolvedAt'],
            ['value' => $issue['updatedAt'] ?? null, 'source' => 'updatedAt'],
        ];

        foreach ($candidates as $candidate) {
            $createdAt = trim((string) ($candidate['value'] ?? ''));
            if ($createdAt === '' || strtotime($createdAt) === false) {
                continue;
            }

            return [
                'created_at' => $createdAt,
                'source' => (string) $candidate['source'],
            ];
        }

        $latestDecisionMessage = null;
        foreach ($messages as $message) {
            if (!is_array($message)) {
                continue;
            }

            $createdAt = trim((string) ($message['createdAt'] ?? ''));
            if ($createdAt === '' || strtotime($createdAt) === false) {
                continue;
            }

            $role = mb_strtoupper(trim((string) ($message['author']['role'] ?? '')));
            if (!in_array($role, ['SELLER', 'ALLEGRO'], true)) {
                continue;
            }

            $messageType = mb_strtoupper(trim((string) ($message['type'] ?? '')));
            $messageText = mb_strtolower($this->resolveIssueTextValue($message['text'] ?? ''));
            $looksLikeDecision = in_array($messageType, ['CLAIM_ACCEPTED', 'CLAIM_REJECTED', 'ACCEPTED', 'REJECTED'], true)
                || preg_match('/(uznan|odrzucon|rozpatrzon|accepted|rejected)/u', $messageText) === 1;

            if (!$looksLikeDecision) {
                continue;
            }

            $latestDecisionMessage = $createdAt;
        }

        if ($latestDecisionMessage !== null) {
            return [
                'created_at' => $latestDecisionMessage,
                'source' => 'chat.decision_message',
            ];
        }

        return [];
    }

    protected function renderClaimProgressBar(string $className, array $timeMeta): string
    {
        $progressPercent = (float) ($timeMeta['progress_percent'] ?? 0);
        $markerPercent = (float) ($timeMeta['marker_percent'] ?? $progressPercent);
        $showMarker = !empty($timeMeta['show_marker']);
        $markerLabel = trim((string) ($timeMeta['marker_label'] ?? ''));
        $flagClass = $markerPercent >= 88 ? ' aar-claim-progress-flag-right' : '';

        $html = $this->htmlFragment('834e25fc21c57c69258d') . Tools::safeOutput($className) . '">';
        $html .= $this->htmlFragment('3e23d75fa4bb7dbb6bbc') . Tools::safeOutput((string) $progressPercent) . $this->htmlFragment('30f8b6654321dabfda39');
        if ($showMarker) {
            $html .= $this->htmlFragment('c858412745e39ff4a947') . Tools::safeOutput((string) $markerPercent) . $this->htmlFragment('30d0d76b3390675e4ec9');
            if ($markerLabel !== '') {
                $html .= $this->htmlFragment('267c33ddd05021a7fbe8') . Tools::safeOutput($flagClass) . '" style="left:' . Tools::safeOutput((string) $markerPercent) . '%">' . Tools::safeOutput($markerLabel) . $this->htmlFragment('5a173609876c90d5f22b');
            }
        }
        $html .= $this->htmlFragment('aac32651b10f567c461b');

        return $html;
    }

    protected function getClaimDecisionMarkerLabel(string $status): string
    {
        $status = mb_strtoupper(trim($status));

        if ($status === 'CLAIM_ACCEPTED') {
            return 'Uznana';
        }

        if ($status === 'CLAIM_REJECTED') {
            return 'Odrzucona';
        }

        return 'Rozpatrzona';
    }

    protected function formatDuration(int $seconds): string
    {
        $days = (int) floor($seconds / 86400);
        $hours = (int) floor(($seconds % 86400) / 3600);

        if ($days > 0) {
            return $days . ' d ' . $hours . ' h';
        }

        $minutes = (int) floor(($seconds % 3600) / 60);
        if ($hours > 0) {
            return $hours . ' h ' . $minutes . ' min';
        }

        return max(0, $minutes) . ' min';
    }

    protected function renderIssueHeaderBadges(array $issue): string
    {
        if (mb_strtoupper((string) ($issue['type'] ?? '')) !== 'CLAIM') {
            return '';
        }

        $status = (string) ($issue['currentState']['status'] ?? '');
        $statusClass = $this->getIssueStatusClass($status);

        $html = $this->htmlFragment('c12899cfd4c54f64a7f1');
        $html .= $this->htmlFragment('1c6cd79dff123b375a24') . Tools::safeOutput($statusClass) . ' ' . Tools::safeOutput($statusClass) . '">' . Tools::safeOutput($this->formatIssueStatus($status)) . $this->htmlFragment('411fdb22d8d9298e5d32');
        $html .= $this->htmlFragment('aac32651b10f567c461b');

        return $html;
    }

    protected function resolvePrestashopOrderLink(array $issue, array $messages = []): ?array
    {
        $checkoutFormIds = $this->extractCheckoutFormIdsFromPayload($issue);
        foreach ($messages as $message) {
            if (is_array($message)) {
                $checkoutFormIds = array_merge($checkoutFormIds, $this->extractCheckoutFormIdsFromPayload($message));
            }
        }
        $checkoutFormIds = array_values(array_unique(array_filter(array_map('strval', $checkoutFormIds))));

        foreach ($checkoutFormIds as $checkoutFormId) {
            $resolved = $this->findPrestashopOrderByX13CheckoutForm($checkoutFormId);
            if ($resolved !== null) {
                return $resolved;
            }
        }

        $identifiers = array_filter(array_unique(array_merge($checkoutFormIds, array_map('strval', [
            (string) ($issue['order']['id'] ?? ''),
            (string) ($issue['buyer']['order']['id'] ?? ''),
        ]))));

        foreach ($identifiers as $identifier) {
            $resolved = $this->findPrestashopOrderByExternalIdentifier($identifier);
            if ($resolved !== null) {
                return $resolved;
            }
        }

        $resolved = $this->findPrestashopOrderByX13IssueHints($issue);
        if ($resolved !== null) {
            return $resolved;
        }

        return null;
    }

    protected function findPrestashopOrderByX13CheckoutForm(string $checkoutFormId): ?array
    {
        $checkoutFormId = trim($checkoutFormId);
        if ($checkoutFormId === '') {
            return null;
        }

        $directOrder = $this->findPrestashopOrderByPrXallegroCheckoutForm($checkoutFormId);
        if ($directOrder !== null) {
            return $directOrder;
        }

        foreach ($this->getX13OrderTableNames() as $tableName) {
            try {
                $row = Db::getInstance()->getRow('
                    SELECT xo.`id_order`
                    FROM `' . bqSQL($tableName) . '` xo
                    WHERE (
                        TRIM(xo.`checkout_form`) = "' . pSQL($checkoutFormId) . '"
                        OR xo.`checkout_form` LIKE "%' . pSQL($checkoutFormId) . '%"
                    )
                        AND xo.`id_order` IS NOT NULL
                        AND xo.`id_order` > 0
                    ORDER BY xo.`id_xallegro_order` DESC
                ');
            } catch (Throwable $e) {
                PrestaShopLogger::addLog('[AAR] x13 order link lookup skipped for ' . $tableName . '.checkout_form ' . $checkoutFormId . ': ' . $e->getMessage(), 2);
                continue;
            }

            if (is_array($row) && (int) ($row['id_order'] ?? 0) > 0) {
                return $this->buildPrestashopOrderLinkFromRow($row, $tableName . '.checkout_form');
            }

            try {
                $row = Db::getInstance()->getRow('
                    SELECT xo.`id_order`
                    FROM `' . bqSQL($tableName) . '` xo
                    WHERE xo.`checkout_form_content` LIKE "%' . pSQL($checkoutFormId) . '%"
                        AND xo.`id_order` IS NOT NULL
                        AND xo.`id_order` > 0
                    ORDER BY xo.`id_xallegro_order` DESC
                ');
            } catch (Throwable $e) {
                PrestaShopLogger::addLog('[AAR] x13 order content lookup skipped for ' . $tableName . '.checkout_form_content ' . $checkoutFormId . ': ' . $e->getMessage(), 2);
                continue;
            }

            if (is_array($row) && (int) ($row['id_order'] ?? 0) > 0) {
                return $this->buildPrestashopOrderLinkFromRow($row, $tableName . '.checkout_form_content');
            }
        }

        return null;
    }

    protected function findPrestashopOrderByPrXallegroCheckoutForm(string $checkoutFormId): ?array
    {
        $checkoutFormId = trim($checkoutFormId);
        if ($checkoutFormId === '') {
            return null;
        }

        $conditions = [
            '`checkout_form` = "' . pSQL($checkoutFormId) . '"',
            'TRIM(`checkout_form`) = "' . pSQL($checkoutFormId) . '"',
            '`checkout_form` LIKE "' . pSQL($checkoutFormId) . '"',
            '`checkout_form` LIKE "%' . pSQL($checkoutFormId) . '%"',
            '`checkout_form_content` LIKE "%' . pSQL($checkoutFormId) . '%"',
        ];

        foreach ($conditions as $condition) {
            $row = $this->findPrestashopOrderRowInPrXallegroOrderByCondition($condition, $checkoutFormId);
            if ($row !== null) {
                return $this->buildPrestashopOrderLinkFromRow($row, 'pr_xallegro_order.checkout_form');
            }
        }

        return null;
    }

    protected function findPrestashopOrderRowInPrXallegroOrderByCondition(string $condition, string $checkoutFormId): ?array
    {
        try {
            $idOrder = (int) Db::getInstance()->getValue('
                SELECT `id_order`
                FROM `pr_xallegro_order`
                WHERE ' . $condition . '
                    AND `id_order` > 0
            ');
        } catch (Throwable $e) {
            PrestaShopLogger::addLog('[AAR] direct pr_xallegro_order checkout_form lookup skipped for ' . $checkoutFormId . ': ' . $e->getMessage(), 2);

            return null;
        }

        if ($idOrder <= 0) {
            return null;
        }

        return ['id_order' => $idOrder];
    }

    protected function buildPrestashopOrderLookupMissLabel(string $checkoutFormId): string
    {
        $dbName = '';
        $tableStatus = 'brak danych';

        try {
            $dbName = (string) Db::getInstance()->getValue('SELECT DATABASE()');
        } catch (Throwable $e) {
            $dbName = 'blad DB';
        }

        try {
            $count = (int) Db::getInstance()->getValue('
                SELECT COUNT(*)
                FROM `pr_xallegro_order`
                WHERE `checkout_form` LIKE "%' . pSQL($checkoutFormId) . '%"
            ');
            $tableStatus = 'pasujace rekordy: ' . $count;
        } catch (Throwable $e) {
            $tableStatus = 'blad COUNT: ' . $e->getMessage();
        }

        try {
            $idOrder = (int) Db::getInstance()->getValue('
                SELECT `id_order`
                FROM `pr_xallegro_order`
                WHERE `checkout_form` LIKE "%' . pSQL($checkoutFormId) . '%"
            ');
            $tableStatus .= ', id_order: ' . $idOrder;
        } catch (Throwable $e) {
            $tableStatus .= ', blad ID: ' . $e->getMessage();
        }

        $parts = ['Nie znaleziono w PrestaShop'];
        if ($dbName !== '') {
            $parts[] = 'DB: ' . $dbName;
        }
        $parts[] = $tableStatus;

        return implode(' | ', $parts);
    }

    protected function getX13OrderTableNames(): array
    {
        $prefix = (string) _DB_PREFIX_;
        $prefixWithoutTrailingUnderscore = rtrim($prefix, '_');
        $tables = [
            $prefix . 'xallegro_order',
            $prefixWithoutTrailingUnderscore . '_xallegro_order',
            'pr_xallegro_order',
        ];

        try {
            $rows = Db::getInstance()->executeS('SHOW TABLES LIKE "%xallegro\\_order"');
            if (is_array($rows)) {
                foreach ($rows as $row) {
                    $tableName = (string) reset($row);
                    if ($tableName !== '') {
                        $tables[] = $tableName;
                    }
                }
            }
        } catch (Throwable $e) {
            PrestaShopLogger::addLog('[AAR] x13 order table discovery skipped: ' . $e->getMessage(), 2);
        }

        return array_values(array_unique(array_filter($tables, function (string $tableName): bool {
            return $this->isSafeSqlIdentifier($tableName);
        })));
    }

    protected function buildPrestashopOrderLinkFromRow(array $row, string $source): ?array
    {
        $idOrder = (int) ($row['id_order'] ?? 0);
        if ($idOrder <= 0) {
            return null;
        }

        $reference = trim((string) ($row['reference'] ?? ''));
        if ($reference === '') {
            $orderRow = $this->findPrestashopOrderRowById($idOrder);
            $reference = trim((string) ($orderRow['reference'] ?? ''));
        }

        return [
            'id_order' => $idOrder,
            'reference' => $reference !== '' ? $reference : ('#' . $idOrder),
            'url' => $this->getPrestashopOrderViewUrl($idOrder),
            'source' => $source,
        ];
    }

    protected function findPrestashopOrderRowById(int $idOrder): array
    {
        if ($idOrder <= 0) {
            return [];
        }

        foreach ($this->getPrestashopCoreTableNames('orders') as $tableName) {
            try {
                $row = Db::getInstance()->getRow('
                    SELECT `id_order`, `reference`
                    FROM `' . bqSQL($tableName) . '`
                    WHERE `id_order` = ' . (int) $idOrder . '
                ');
            } catch (Throwable $e) {
                PrestaShopLogger::addLog('[AAR] order reference lookup skipped for ' . $tableName . ' #' . (int) $idOrder . ': ' . $e->getMessage(), 2);
                continue;
            }

            if (is_array($row) && (int) ($row['id_order'] ?? 0) > 0) {
                return $row;
            }
        }

        return [];
    }

    protected function getPrestashopCoreTableNames(string $baseName): array
    {
        $prefix = (string) _DB_PREFIX_;
        $prefixWithoutTrailingUnderscore = rtrim($prefix, '_');

        return array_values(array_unique(array_filter([
            $prefix . $baseName,
            $prefixWithoutTrailingUnderscore . '_' . $baseName,
            'pr_' . $baseName,
        ], function (string $tableName): bool {
            return $this->isSafeSqlIdentifier($tableName);
        })));
    }

    protected function getPrestashopOrderViewUrl(int $idOrder): string
    {
        if ($idOrder <= 0) {
            return '';
        }

        $adminBase = $this->getCurrentAdminIndexUrl();
        if ($adminBase === '') {
            $adminBase = $this->context->link->getAdminBaseLink();
            $adminBase = preg_replace('#/index\.php(?:/.*)?$#', '/index.php', (string) $adminBase);
            $adminBase = rtrim((string) $adminBase, '/');
        }

        return $adminBase . '/sell/orders/' . (int) $idOrder . '/view';
    }

    protected function getCurrentAdminIndexUrl(): string
    {
        $isHttps = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
            || (string) ($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https';
        $scheme = $isHttps ? 'https' : 'http';
        $host = trim((string) ($_SERVER['HTTP_HOST'] ?? ''));
        $scriptName = trim((string) ($_SERVER['SCRIPT_NAME'] ?? ''));

        if ($host === '' || $scriptName === '') {
            return '';
        }

        $adminDir = rtrim(str_replace('\\', '/', dirname($scriptName)), '/');

        return $scheme . '://' . $host . $adminDir . '/index.php';
    }

    protected function findPrestashopOrderByX13IssueHints(array $issue): ?array
    {
        $offerId = trim((string) ($issue['offer']['id'] ?? ''));
        $buyerLogin = trim((string) ($issue['buyer']['login'] ?? ''));
        $buyerId = trim((string) ($issue['buyer']['id'] ?? ''));
        if ($offerId === '' || ($buyerLogin === '' && $buyerId === '')) {
            return null;
        }

        $tableName = _DB_PREFIX_ . 'xallegro_order';
        $buyerCondition = [];
        if ($buyerLogin !== '') {
            $buyerCondition[] = 'xo.`checkout_form_content` LIKE "%' . pSQL($buyerLogin) . '%"';
        }
        if ($buyerId !== '') {
            $buyerCondition[] = 'xo.`checkout_form_content` LIKE "%' . pSQL($buyerId) . '%"';
        }

        try {
            $row = Db::getInstance()->getRow('
                SELECT xo.`id_order`, o.`reference`
                FROM `' . bqSQL($tableName) . '` xo
                INNER JOIN `' . _DB_PREFIX_ . 'orders` o ON (o.`id_order` = xo.`id_order`)
                WHERE xo.`checkout_form_content` LIKE "%' . pSQL($offerId) . '%"
                    AND (' . implode(' OR ', $buyerCondition) . ')
                    AND xo.`id_order` IS NOT NULL
                ORDER BY xo.`id_xallegro_order` DESC
            ');
        } catch (Throwable $e) {
            PrestaShopLogger::addLog('[AAR] x13 order content lookup skipped for offer ' . $offerId . ': ' . $e->getMessage(), 2);

            return null;
        }

        if (!is_array($row) || (int) ($row['id_order'] ?? 0) <= 0) {
            return null;
        }

        return $this->buildPrestashopOrderLinkFromRow($row, $tableName . '.checkout_form_content');
    }

    protected function findPrestashopOrderByExternalIdentifier(string $identifier): ?array
    {
        static $candidates = null;

        $identifier = trim($identifier);
        if ($identifier === '') {
            return null;
        }

        if ($candidates === null) {
            $candidates = $this->discoverPrestashopOrderLinkCandidates();
        }

        foreach ($candidates as $candidate) {
            $tableName = trim((string) ($candidate['table'] ?? ''));
            $matchColumn = trim((string) ($candidate['match_column'] ?? ''));
            if (!$this->isSafeSqlIdentifier($tableName) || !$this->isSafeSqlIdentifier($matchColumn)) {
                continue;
            }

            $sql = 'SELECT * FROM `' . bqSQL($tableName) . '` WHERE `' . bqSQL($matchColumn) . '` = "' . pSQL($identifier) . '"';

            try {
                $row = Db::getInstance()->getRow($sql);
            } catch (Throwable $e) {
                PrestaShopLogger::addLog('[AAR] Order link lookup skipped for ' . $tableName . '.' . $matchColumn . ': ' . $e->getMessage(), 2);
                continue;
            }

            if (!is_array($row)) {
                continue;
            }

            $idOrder = $this->extractPrestashopOrderIdFromRow($row);
            if ($idOrder <= 0) {
                continue;
            }

            $orderRow = Db::getInstance()->getRow('SELECT id_order, reference FROM `' . _DB_PREFIX_ . 'orders` WHERE id_order=' . (int) $idOrder);
            if (!is_array($orderRow)) {
                continue;
            }

            return $this->buildPrestashopOrderLinkFromRow($orderRow, $tableName . '.' . $matchColumn);
        }

        return null;
    }

    protected function resolvePrestashopOrderThumbnailUrl(array $issue, array $messages = []): string
    {
        $linkedOrder = $this->resolvePrestashopOrderLink($issue, $messages);
        if (!is_array($linkedOrder) || (int) ($linkedOrder['id_order'] ?? 0) <= 0) {
            return '';
        }

        return $this->getPrestashopOrderThumbnailUrl((int) $linkedOrder['id_order']);
    }

    protected function resolvePrestashopOrderThumbnailUrlByCheckoutFormId(string $checkoutFormId, string $offerId = '', array $checkoutForm = []): string
    {
        $linkedOrder = $this->findPrestashopOrderByX13CheckoutForm($checkoutFormId);
        if (!is_array($linkedOrder) || (int) ($linkedOrder['id_order'] ?? 0) <= 0) {
            return '';
        }

        $idOrder = (int) $linkedOrder['id_order'];
        if (!$checkoutForm) {
            $checkoutForm = $this->getStoredCheckoutFormContent($checkoutFormId);
        }

        $lineItem = $this->findCheckoutLineItemByOfferId($checkoutForm, $offerId);
        if ($lineItem) {
            $thumbnailUrl = $this->getPrestashopOrderThumbnailUrlByLineItem($idOrder, $lineItem);
            if ($thumbnailUrl !== '') {
                return $thumbnailUrl;
            }
        }

        if ($offerId !== '') {
            $singleProductMatch = $this->findSinglePrestashopOrderDetailProductMatch($idOrder);
            if ((int) ($singleProductMatch['id_product'] ?? 0) > 0) {
                return $this->getPrestashopProductThumbnailUrl(
                    (int) $singleProductMatch['id_product'],
                    (int) ($singleProductMatch['id_product_attribute'] ?? 0)
                );
            }

            return '';
        }

        return $this->getPrestashopOrderThumbnailUrl($idOrder);
    }

    protected function findCheckoutLineItemByOfferId(array $checkoutForm, string $offerId): array
    {
        $offerId = trim($offerId);
        $firstLineItem = [];
        $hasAnyLineItemOfferId = false;
        foreach (($checkoutForm['lineItems'] ?? []) as $lineItem) {
            if (!is_array($lineItem)) {
                continue;
            }

            if (!$firstLineItem) {
                $firstLineItem = $lineItem;
            }

            $lineOfferId = $this->extractLineItemOfferId($lineItem);
            if ($lineOfferId !== '') {
                $hasAnyLineItemOfferId = true;
            }

            if ($offerId !== '' && $lineOfferId === $offerId) {
                return $lineItem;
            }
        }

        if ($offerId !== '' && $hasAnyLineItemOfferId) {
            return [];
        }

        return $firstLineItem;
    }

    protected function getPrestashopOrderThumbnailUrlByLineItem(int $idOrder, array $lineItem, &$lineDebug = null): string
    {
        if ($idOrder <= 0) {
            return '';
        }

        $match = $this->findPrestashopOrderDetailMatchByLineItem($idOrder, $lineItem, $lineDebug);
        $idProduct = (int) ($match['id_product'] ?? 0);
        $idProductAttribute = (int) ($match['id_product_attribute'] ?? 0);
        if ($idProduct <= 0) {
            return '';
        }

        $imageDebug = [];
        $thumbnailUrl = $this->getPrestashopProductThumbnailUrl($idProduct, $idProductAttribute, $imageDebug);
        if (is_array($lineDebug)) {
            $lineDebug['image'] = $imageDebug;
            $lineDebug['url'] = $thumbnailUrl;
        }

        return $thumbnailUrl;
    }

    protected function findPrestashopOrderProductIdByLineItem(int $idOrder, array $lineItem): int
    {
        $match = $this->findPrestashopOrderDetailMatchByLineItem($idOrder, $lineItem);

        return (int) ($match['id_product'] ?? 0);
    }

    protected function findPrestashopOrderDetailMatchByIdentifiers(int $idOrder, array $identifiers, &$lookupDebug = null): array
    {
        if ($lookupDebug === null) {
            $lookupDebug = [];
        }

        $lookupDebug = [
            'id_order' => $idOrder,
            'identifier_candidates' => array_values(array_map('strval', $identifiers)),
            'matches' => [],
        ];

        if ($idOrder <= 0) {
            $lookupDebug['error'] = 'missing_id_order';

            return [];
        }

        foreach ($identifiers as $identifier) {
            $identifier = trim((string) $identifier);
            if ($identifier === '') {
                continue;
            }

            $identifierVariants = $this->buildPrestashopIdentifierCandidates($identifier);
            $condition = $this->buildPrestashopIdentifierSqlCondition('od', [
                'product_reference',
                'product_supplier_reference',
                'product_ean13',
                'product_upc',
            ], $identifierVariants);
            $sql = 'SELECT od.`product_id`, od.`product_attribute_id`, od.`product_reference`, od.`product_supplier_reference`, od.`product_ean13`, od.`product_upc`, od.`product_name`
                FROM `' . _DB_PREFIX_ . 'order_detail` od
                WHERE od.`id_order` = ' . (int) $idOrder . '
                    AND ' . $condition . '
                ORDER BY od.`id_order_detail` ASC';

            try {
                $row = Db::getInstance()->getRow($sql);
            } catch (Throwable $e) {
                PrestaShopLogger::addLog('[AAR] Order detail identifier fallback skipped for order #' . (int) $idOrder . ': ' . $e->getMessage(), 2);
                $lookupDebug['matches'][] = [
                    'identifier' => $identifier,
                    'source' => 'error',
                    'error' => $e->getMessage(),
                ];
                continue;
            }

            if (is_array($row) && (int) ($row['product_id'] ?? 0) > 0) {
                $match = $this->buildPrestashopOrderDetailMatchFromRow($row, 'order_detail_identifier', [
                    'identifier' => $identifier,
                    'identifier_candidates' => $identifierVariants,
                ]);
                $lookupDebug['matches'][] = $match;

                return $match;
            }

            $lookupDebug['matches'][] = [
                'identifier' => $identifier,
                'identifier_candidates' => $identifierVariants,
                'source' => 'not_found',
            ];
        }

        return [];
    }

    protected function findPrestashopOrderDetailMatchByLineItem(int $idOrder, array $lineItem, &$lineDebug = null): array
    {
        $identifiers = $this->extractPrestashopProductIdentifiersFromPayload($lineItem);
        $ignoredNames = $this->extractPrestashopProductNamesFromPayload($lineItem);
        $offer = is_array($lineItem['offer'] ?? null) ? $lineItem['offer'] : [];
        $lineOfferId = $this->extractLineItemOfferId($lineItem);
        $lineOfferExternalId = $this->extractLineItemOfferExternalId($lineItem);
        if ($lineDebug === null) {
            $lineDebug = [];
        }

        $lineDebug = [
            'id_order' => $idOrder,
            'line_item_id' => (string) ($lineItem['id'] ?? ''),
            'offer_id' => $lineOfferId,
            'offer_external_id' => $lineOfferExternalId,
            'offer_name' => (string) ($offer['name'] ?? $lineItem['name'] ?? ''),
            'identifier_candidates' => $identifiers,
            'name_candidates_ignored' => $ignoredNames,
            'name_matching' => 'disabled',
            'matches' => [],
            'url' => '',
        ];

        foreach ($identifiers as $identifier) {
            $identifier = trim((string) $identifier);
            if ($identifier === '') {
                continue;
            }

            $identifierVariants = $this->buildPrestashopIdentifierCandidates($identifier);
            $condition = $this->buildPrestashopIdentifierSqlCondition('od', [
                'product_reference',
                'product_supplier_reference',
                'product_ean13',
                'product_upc',
            ], $identifierVariants);
            $sql = 'SELECT od.`product_id`, od.`product_attribute_id`, od.`product_reference`, od.`product_supplier_reference`, od.`product_ean13`, od.`product_upc`, od.`product_name`
                FROM `' . _DB_PREFIX_ . 'order_detail` od
                WHERE od.`id_order` = ' . (int) $idOrder . '
                    AND ' . $condition . '
                ORDER BY od.`id_order_detail` ASC';

            try {
                $row = Db::getInstance()->getRow($sql);
            } catch (Throwable $e) {
                PrestaShopLogger::addLog('[AAR] Order detail identifier match skipped for order #' . (int) $idOrder . ': ' . $e->getMessage(), 2);
                $row = [];
            }

            if (is_array($row) && (int) ($row['product_id'] ?? 0) > 0) {
                $match = [
                    'source' => 'order_detail_identifier',
                    'identifier' => $identifier,
                    'identifier_candidates' => $identifierVariants,
                    'id_product' => (int) $row['product_id'],
                    'id_product_attribute' => (int) ($row['product_attribute_id'] ?? 0),
                    'product_reference' => (string) ($row['product_reference'] ?? ''),
                    'product_supplier_reference' => (string) ($row['product_supplier_reference'] ?? ''),
                    'product_ean13' => (string) ($row['product_ean13'] ?? ''),
                    'product_upc' => (string) ($row['product_upc'] ?? ''),
                    'product_name' => (string) ($row['product_name'] ?? ''),
                ];
                $lineDebug['matches'][] = $match;

                return $match;
            }
        }

        $singleProductMatch = $this->findSinglePrestashopOrderDetailProductMatch($idOrder);
        if ((int) ($singleProductMatch['id_product'] ?? 0) > 0) {
            $lineDebug['matches'][] = $singleProductMatch;

            return $singleProductMatch;
        }

        $lineDebug['matches'][] = [
            'source' => 'order_detail_not_found',
        ];

        return [];
    }

    protected function findSinglePrestashopOrderDetailProductMatch(int $idOrder): array
    {
        if ($idOrder <= 0) {
            return [];
        }

        $rows = $this->getPrestashopOrderProductDetailRows($idOrder);
        if (!$rows) {
            return [];
        }

        $unique = [];
        foreach ($rows as $row) {
            $idProduct = (int) ($row['product_id'] ?? 0);
            if ($idProduct <= 0) {
                continue;
            }

            $key = $idProduct . ':' . (int) ($row['product_attribute_id'] ?? 0);
            $unique[$key] = $row;
        }

        if (count($unique) !== 1) {
            return [];
        }

        return $this->buildPrestashopOrderDetailMatchFromRow(reset($unique), 'order_detail_single_product');
    }

    protected function getPrestashopOrderProductDetailRows(int $idOrder): array
    {
        if ($idOrder <= 0) {
            return [];
        }

        $sql = 'SELECT od.`product_id`, od.`product_attribute_id`, od.`product_reference`, od.`product_supplier_reference`, od.`product_ean13`, od.`product_upc`, od.`product_name`
            FROM `' . _DB_PREFIX_ . 'order_detail` od
            WHERE od.`id_order` = ' . (int) $idOrder . '
                AND od.`product_id` > 0
            ORDER BY od.`id_order_detail` ASC';

        try {
            $rows = Db::getInstance()->executeS($sql);
        } catch (Throwable $e) {
            PrestaShopLogger::addLog('[AAR] Order detail rows lookup skipped for order #' . (int) $idOrder . ': ' . $e->getMessage(), 2);

            return [];
        }

        return is_array($rows) ? $rows : [];
    }

    protected function buildPrestashopOrderDetailMatchFromRow(array $row, string $source, array $extra = []): array
    {
        return array_merge([
            'source' => $source,
            'id_product' => (int) ($row['product_id'] ?? 0),
            'id_product_attribute' => (int) ($row['product_attribute_id'] ?? 0),
            'product_reference' => (string) ($row['product_reference'] ?? ''),
            'product_supplier_reference' => (string) ($row['product_supplier_reference'] ?? ''),
            'product_ean13' => (string) ($row['product_ean13'] ?? ''),
            'product_upc' => (string) ($row['product_upc'] ?? ''),
            'product_name' => (string) ($row['product_name'] ?? ''),
        ], $extra);
    }

    protected function getPrestashopOrderThumbnailUrl(int $idOrder): string
    {
        if ($idOrder <= 0) {
            return '';
        }

        $sql = 'SELECT od.`product_id`, od.`product_attribute_id`
            FROM `' . _DB_PREFIX_ . 'order_detail` od
            WHERE od.`id_order` = ' . (int) $idOrder . '
                AND od.`product_id` > 0
            ORDER BY od.`id_order_detail` ASC';

        try {
            $row = Db::getInstance()->getRow($sql);
        } catch (Throwable $e) {
            PrestaShopLogger::addLog('[AAR] PrestaShop order thumbnail lookup skipped for order #' . (int) $idOrder . ': ' . $e->getMessage(), 2);

            return '';
        }
        if (!is_array($row) || (int) ($row['product_id'] ?? 0) <= 0) {
            return '';
        }

        return $this->getPrestashopProductThumbnailUrl((int) $row['product_id'], (int) ($row['product_attribute_id'] ?? 0));
    }

    protected function discoverPrestashopOrderLinkCandidates(): array
    {
        $tables = Db::getInstance()->executeS('SHOW TABLES');
        if (!is_array($tables)) {
            return [];
        }

        $matchNeedles = ['checkout', 'allegro', 'external', 'marketplace', 'order_uuid', 'orderuid', 'buyform'];
        $idOrderColumns = ['id_order', 'order_id', 'id_orders', 'id_ps_order'];
        $candidates = [];

        foreach ($tables as $tableRow) {
            $tableName = (string) reset($tableRow);
            if ($tableName === '' || strpos($tableName, _DB_PREFIX_) !== 0) {
                continue;
            }

            if (!preg_match('/(allegro|x13|marketplace|order)/i', $tableName)) {
                continue;
            }

            $columnsRows = Db::getInstance()->executeS('SHOW COLUMNS FROM `' . bqSQL($tableName) . '`');
            if (!is_array($columnsRows)) {
                continue;
            }

            $columns = array_map(function (array $column): string {
                return (string) ($column['Field'] ?? '');
            }, $columnsRows);

            $hasIdOrder = (bool) array_intersect($idOrderColumns, $columns);
            if (!$hasIdOrder) {
                continue;
            }

            foreach ($columns as $column) {
                if (!$this->isSafeSqlIdentifier($column) || in_array($column, $idOrderColumns, true)) {
                    continue;
                }

                foreach ($matchNeedles as $needle) {
                    if (stripos($column, $needle) !== false) {
                        $candidates[] = [
                            'table' => $tableName,
                            'match_column' => $column,
                        ];
                        break;
                    }
                }
            }
        }

        return $candidates;
    }

    protected function isSafeSqlIdentifier(string $identifier): bool
    {
        return $identifier !== '' && preg_match('/^[A-Za-z0-9_]+$/', $identifier) === 1;
    }

    protected function extractPrestashopOrderIdFromRow(array $row): int
    {
        foreach (['id_order', 'order_id', 'id_orders', 'id_ps_order'] as $key) {
            if (isset($row[$key]) && (int) $row[$key] > 0) {
                return (int) $row[$key];
            }
        }

        return 0;
    }

    protected function renderInboxColorStyles(): string
    {
        return $this->htmlFragment('79865ea0a512dbb7810f');
    }

    protected function renderSettingsForm(): string
    {
        $fieldsForm = [
            'form' => [
                'legend' => [
                    'title' => $this->trans('Ustawienia ogólne', [], 'Modules.Allegrocustomerservice.Admin'),
                    'icon' => 'icon-cogs',
                ],
                'input' => [
                    [
                        'type' => 'switch',
                        'label' => $this->trans('Włącz moduł', [], 'Modules.Allegrocustomerservice.Admin'),
                        'desc' => $this->trans('Włącza automatyczne skanowanie wiadomości i wysyłanie odpowiedzi przez CRON. Wyłączenie nie blokuje panelu ani funkcji ręcznych.', [], 'Modules.Allegrocustomerservice.Admin'),
                        'name' => self::CONFIG_PREFIX . 'ENABLED',
                        'is_bool' => true,
                        'values' => [
                            ['id' => 'aar_enabled_on', 'value' => 1, 'label' => $this->trans('Yes', [], 'Admin.Global')],
                            ['id' => 'aar_enabled_off', 'value' => 0, 'label' => $this->trans('No', [], 'Admin.Global')],
                        ],
                    ],
                    [
                        'type' => 'switch',
                        'label' => $this->trans('Tryb testowy automatycznych odpowiedzi', [], 'Modules.Allegrocustomerservice.Admin'),
                        'desc' => $this->trans('Gdy jest włączony, automatyczne odpowiedzi są analizowane i logowane, ale nie są wysyłane.', [], 'Modules.Allegrocustomerservice.Admin'),
                        'name' => self::CONFIG_PREFIX . 'TEST_MODE',
                        'is_bool' => true,
                        'values' => [
                            ['id' => 'aar_test_on', 'value' => 1, 'label' => $this->trans('Yes', [], 'Admin.Global')],
                            ['id' => 'aar_test_off', 'value' => 0, 'label' => $this->trans('No', [], 'Admin.Global')],
                        ],
                    ],
                    [
                        'type' => 'text',
                        'label' => $this->trans('Limit pobieranych wątków', [], 'Modules.Allegrocustomerservice.Admin'),
                        'name' => self::CONFIG_PREFIX . 'POLL_LIMIT',
                    ],
                    [
                        'type' => 'text',
                        'label' => $this->trans('Przerwa między automatycznymi odpowiedziami (minuty)', [], 'Modules.Allegrocustomerservice.Admin'),
                        'name' => self::CONFIG_PREFIX . 'COOLDOWN_MINUTES',
                    ],
                ],
                'submit' => [
                    'name' => 'submitAarSettings',
                    'title' => $this->trans('Zapisz', [], 'Modules.Allegrocustomerservice.Admin'),
                ],
            ],
        ];

        $helper = new HelperForm();
        $helper->module = $this;
        $helper->name_controller = $this->name;
        $helper->identifier = $this->identifier;
        $helper->token = Tools::getAdminTokenLite('AdminModules');
        $helper->currentIndex = AdminController::$currentIndex . '&configure=' . $this->name;
        $helper->submit_action = 'submitAarSettings';
        $helper->default_form_language = (int) $this->context->language->id;
        $helper->allow_employee_form_lang = (int) $this->context->language->id;
        $helper->fields_value = [
            self::CONFIG_PREFIX . 'ENABLED' => (int) Configuration::get(self::CONFIG_PREFIX . 'ENABLED'),
            self::CONFIG_PREFIX . 'TEST_MODE' => (int) Configuration::get(self::CONFIG_PREFIX . 'TEST_MODE'),
            self::CONFIG_PREFIX . 'REDIRECT_URI' => (string) Configuration::get(self::CONFIG_PREFIX . 'REDIRECT_URI'),
            self::CONFIG_PREFIX . 'POLL_LIMIT' => (int) Configuration::get(self::CONFIG_PREFIX . 'POLL_LIMIT'),
            self::CONFIG_PREFIX . 'COOLDOWN_MINUTES' => (int) Configuration::get(self::CONFIG_PREFIX . 'COOLDOWN_MINUTES'),
        ];

        return $helper->generateForm([$fieldsForm]);
    }

    protected function renderRuleForm(?array $rule = null): string
    {
        $isEdit = is_array($rule);
        $actionLabel = $isEdit ? 'Zapisz regułę' : 'Dodaj regułę';
        $submitName = $isEdit ? 'submitAarSaveRule' : 'submitAarAddRule';
        $matchTypeOptions = $this->getRuleMatchTypeOptions();

        $values = [
            'id_rule' => (int) ($rule['id_rule'] ?? 0),
            'name' => (string) ($rule['name'] ?? ''),
            'enabled' => (int) ($rule['enabled'] ?? 1),
            'priority' => (int) ($rule['priority'] ?? 100),
            'match_type' => (string) ($rule['match_type'] ?? 'contains'),
            'keywords' => (string) ($rule['keywords'] ?? ''),
            'response_template' => (string) ($rule['response_template'] ?? ''),
            'only_first_message' => (int) ($rule['only_first_message'] ?? 1),
            'cooldown_minutes' => (int) ($rule['cooldown_minutes'] ?? 60),
        ];

        $modalId = 'aar-rule-modal';
        $modalTitle = $isEdit
            ? $this->trans('Edycja reguły automatycznej odpowiedzi', [], 'Modules.Allegrocustomerservice.Admin')
            : $this->trans('Dodaj regułę automatycznej odpowiedzi', [], 'Modules.Allegrocustomerservice.Admin');

        $html = $this->htmlFragment('2dc98106ecb898abbb85') . $modalId . '" tabindex="-1" role="dialog" aria-hidden="true">';
        $html .= $this->htmlFragment('a04acc39bbf01025ebbd');
        $html .= $this->htmlFragment('d91ec07885dee8fb2180');
        $html .= $this->htmlFragment('671002696b5570be225e');
        $html .= $this->htmlFragment('d53c52f4f898f8ed293c');
        $html .= $this->htmlFragment('2e8f4e2bc06595fafeaf');
        $html .= $this->htmlFragment('b6405ad52d4cac1862cc') . $modalTitle . $this->htmlFragment('167241b96f2b077c0273');
        $html .= $this->htmlFragment('aac32651b10f567c461b');
        $html .= $this->htmlFragment('6416b918eef22c892aee');
        if ($isEdit) {
            $html .= $this->htmlFragment('8a87b5938cc5c384897f') . (int) $values['id_rule'] . '">';
        }
        $html .= $this->htmlFragment('ee13baf6efcd6519cfda') . Tools::safeOutput($values['name']) . $this->htmlFragment('1bcf087da9925e97eac2');
        $html .= $this->htmlFragment('8381ccb26b222888d95c') . (int) $values['priority'] . $this->htmlFragment('6221ccb7573e123ebd92');
        $html .= $this->htmlFragment('ab79917613ee3d925491');
        foreach ($matchTypeOptions as $matchType => $label) {
            $html .= $this->htmlFragment('5f0ccbf50845efd83670') . Tools::safeOutput($matchType) . '"' . ($values['match_type'] === $matchType ? ' selected' : '') . '>' . Tools::safeOutput($label) . $this->htmlFragment('620f24ad3a01b0d2fe67');
        }
        $html .= $this->htmlFragment('6b4b24bf479e319e9712');
        $html .= $this->htmlFragment('0b3dc52c04c0a15ca5f9') . Tools::safeOutput($values['keywords']) . $this->htmlFragment('42d7d3da4e42fe21355b');
        $html .= $this->htmlFragment('9c5aaa37bdc6595585e1') . Tools::safeOutput($values['response_template']) . $this->htmlFragment('42d7d3da4e42fe21355b');
        $html .= $this->htmlFragment('21f108d7dd6ca038b9ad') . (int) $values['cooldown_minutes'] . $this->htmlFragment('6221ccb7573e123ebd92');
        $html .= $this->htmlFragment('fda54c452159e0f9e450') . ($values['only_first_message'] ? ' checked' : '') . $this->htmlFragment('ea46fb1e4833edbd8edf');
        $html .= $this->htmlFragment('46c0d3c2ec910b75b3e9') . ($values['enabled'] ? ' checked' : '') . $this->htmlFragment('927390d4993883a5994b');
        $html .= $this->htmlFragment('aac32651b10f567c461b');
        $html .= $this->htmlFragment('5b94a554b4af4f48d3c5');
        if ($isEdit) {
            $cancelUrl = AdminController::$currentIndex . '&configure=' . $this->name . '&token=' . Tools::getAdminTokenLite('AdminModules');
            $html .= $this->htmlFragment('689d88c0bfdf9956c9dc') . Tools::safeOutput($cancelUrl) . $this->htmlFragment('eb5a630ddd755ffe1bf2');
        } else {
            $html .= $this->htmlFragment('8db8da5e68a15c37de3c');
        }
        $html .= $this->htmlFragment('67bfccb1f773f993e56d') . $submitName . '" type="submit">' . $actionLabel . $this->htmlFragment('d8de48c79715e8f2762e');
        $html .= $this->htmlFragment('aac32651b10f567c461b');
        $html .= $this->htmlFragment('e0c7bb7b72eeecfc0734');
        $html .= $this->htmlFragment('bd1770902d0bb0db962c');

        if ($isEdit) {
            $html .= $this->htmlFragment('d4c5f73bcb268fc52c4e') . $modalId . $this->htmlFragment('e97de9e99bdf1a7386e8');
        }

        return $html;
    }

    protected function renderRulesTable(): string
    {
        $rules = Db::getInstance()->executeS('SELECT * FROM `' . _DB_PREFIX_ . 'allegro_ar_rule` ORDER BY priority ASC, id_rule DESC');
        $html = $this->htmlFragment('389bc1a93a22a94284fa');
        $html .= $this->htmlFragment('44c441e2f84e75f1d765') . $this->trans('Reguły automatycznych odpowiedzi', [], 'Modules.Allegrocustomerservice.Admin') . $this->htmlFragment('a6c57bf5252e5005b93d');
        $html .= $this->htmlFragment('ba1394f60b8c51547069');
        $html .= $this->htmlFragment('29b0c2eed10c84dd1175');
        $html .= $this->htmlFragment('31139f8760584accd4e0');
        $html .= $this->htmlFragment('aac32651b10f567c461b');
        $html .= $this->htmlFragment('bf5be171731f365f6fc4');
        if (!$rules) {
            $html .= $this->htmlFragment('76d306827b3c62681ee4');
        } else {
            foreach ($rules as $rule) {
                $editUrl = AdminController::$currentIndex . '&configure=' . $this->name . '&token=' . Tools::getAdminTokenLite('AdminModules') . '&edit_rule=' . (int) $rule['id_rule'];
                $deleteUrl = AdminController::$currentIndex . '&configure=' . $this->name . '&token=' . Tools::getAdminTokenLite('AdminModules') . '&delete_rule=' . (int) $rule['id_rule'];
                $matchTypeOptions = $this->getRuleMatchTypeOptions();
                $html .= $this->htmlFragment('9b84c614b473bf1d182e');
                $html .= $this->htmlFragment('ad76f84d9f135f96caee') . (int) $rule['id_rule'] . $this->htmlFragment('b8073d8a2f01abcc6c6b');
                $html .= $this->htmlFragment('ad76f84d9f135f96caee') . Tools::safeOutput($rule['name']) . $this->htmlFragment('b8073d8a2f01abcc6c6b');
                $html .= $this->htmlFragment('ad76f84d9f135f96caee') . Tools::safeOutput($matchTypeOptions[(string) $rule['match_type']] ?? (string) $rule['match_type']) . $this->htmlFragment('b8073d8a2f01abcc6c6b');
                $html .= $this->htmlFragment('ad76f84d9f135f96caee') . (int) $rule['priority'] . $this->htmlFragment('b8073d8a2f01abcc6c6b');
                $html .= $this->htmlFragment('ad76f84d9f135f96caee') . ((int) $rule['enabled'] ? 'Tak' : 'Nie') . $this->htmlFragment('b8073d8a2f01abcc6c6b');
                $html .= $this->htmlFragment('4f4cd8d2530f5cf54586') . nl2br(Tools::safeOutput($rule['keywords'])) . $this->htmlFragment('1607e82b489cb6914b0d');
                $html .= $this->htmlFragment('111c4c53971d960da99e') . Tools::safeOutput($editUrl) . $this->htmlFragment('293a77fb2552a98b207d') . Tools::safeOutput($deleteUrl) . $this->htmlFragment('cc4c613d1a8c6bc0e395');
                $html .= $this->htmlFragment('3ed7440ce0756928276f');
            }
        }
        $html .= $this->htmlFragment('7fa98554c4a983f787a6');

        return $html;
    }

    protected function buildQuickReplyReplacementsForThread(array $thread, array $messages): array
    {
        $buyerLogin = trim((string) ($thread['interlocutor']['login'] ?? ''));
        $orderId = (string) ($this->extractOrderId($messages) ?? '');
        $offerId = (string) ($this->extractOfferId($messages) ?? '');
        $orderDate = $orderId !== '' ? $this->resolveOrderDateByCheckoutForm($orderId) : '';

        return $this->buildQuickReplyReplacementMap($buyerLogin, $orderId, $offerId, $orderDate, '');
    }

    protected function buildQuickReplyReplacementsForIssue(array $issue, array $messages): array
    {
        $buyerLogin = trim((string) ($issue['buyer']['login'] ?? ''));
        $orderId = trim((string) ($issue['order']['id'] ?? $issue['buyer']['order']['id'] ?? ($this->extractOrderId($messages) ?? '')));
        $offerId = trim((string) ($issue['offer']['id'] ?? $issue['offer']['offerId'] ?? ($this->extractOfferId($messages) ?? '')));
        $claimQuantity = max(0, (int) ($issue['offer']['quantity'] ?? 0));
        $checkoutFormIds = $this->extractCheckoutFormIdsFromPayload($issue);

        foreach ($messages as $message) {
            if (is_array($message)) {
                $checkoutFormIds = array_merge($checkoutFormIds, $this->extractCheckoutFormIdsFromPayload($message));
            }
        }

        $checkoutFormIds = array_values(array_unique(array_filter(array_map('strval', $checkoutFormIds))));
        $checkoutFormId = $checkoutFormIds[0] ?? $orderId;
        $orderDate = $checkoutFormId !== '' ? $this->resolveOrderDateByCheckoutForm($checkoutFormId) : '';
        $issueDate = $this->resolveIssueDateForTemplate($issue);
        $claimAmountData = $this->resolveIssueClaimAmountReplacementData($issue, $messages, $checkoutFormId, $offerId, $claimQuantity);
        if (trim((string) ($claimAmountData['claim_product_name'] ?? '')) === '') {
            $claimAmountData['claim_product_name'] = $this->resolveIssueOfferTitleReplacement($issue, $messages, $offerId);
        }
        $claimAmountData['claim_reason'] = $this->formatIssueReasonType((string) ($issue['reason']['type'] ?? ''));
        $claimAmountData['claim_reason_description'] = $this->decodeAllegroText(
            $this->resolveIssueTextValue($issue['reason']['description'] ?? null)
        );
        if ($claimAmountData['claim_reason_description'] === '') {
            $claimAmountData['claim_reason_description'] = $claimAmountData['claim_reason'];
        }

        return $this->buildQuickReplyReplacementMap($buyerLogin, $orderId, $offerId, $orderDate, $issueDate, $claimAmountData);
    }

    protected function buildQuickReplyReplacementMap(string $buyerLogin, string $orderId, string $offerId, string $orderDateRaw, string $issueDateRaw, array $extra = []): array
    {
        $orderDate = $this->formatQuickReplyDate($orderDateRaw, false);
        $orderDateTime = $this->formatQuickReplyDate($orderDateRaw, true);
        $issueDate = $this->formatQuickReplyDate($issueDateRaw, false);
        $issueDateTime = $this->formatQuickReplyDate($issueDateRaw, true);
        $claimAmount = trim((string) ($extra['claim_amount'] ?? ''));
        $claimAmountValue = trim((string) ($extra['claim_amount_value'] ?? ''));
        $claimCurrency = trim((string) ($extra['claim_currency'] ?? ''));
        $claimQuantity = trim((string) ($extra['claim_quantity'] ?? ''));
        $claimUnitAmount = trim((string) ($extra['claim_unit_amount'] ?? ''));
        $claimUnitAmountValue = trim((string) ($extra['claim_unit_amount_value'] ?? ''));
        $claimProductName = trim((string) ($extra['claim_product_name'] ?? ''));
        $claimReason = trim((string) ($extra['claim_reason'] ?? ''));
        $claimReasonDescription = rtrim(trim((string) ($extra['claim_reason_description'] ?? '')), '.!?');

        return [
            '{buyer_login}' => $buyerLogin,
            '{shop_name}' => (string) Configuration::get('PS_SHOP_NAME'),
            '{order_id}' => $orderId,
            '{offer_id}' => $offerId,
            '{offertitle}' => $claimProductName,
            '{offer_title}' => $claimProductName,
            '{tytul_oferty}' => $claimProductName,
            '{orderdate}' => $orderDate,
            '{order_date}' => $orderDate,
            '{purchasedate}' => $orderDate,
            '{purchase_date}' => $orderDate,
            '{orderdatetime}' => $orderDateTime,
            '{order_datetime}' => $orderDateTime,
            '{claimdate}' => $issueDate,
            '{claim_date}' => $issueDate,
            '{claimsubmitteddate}' => $issueDate,
            '{claim_submitted_date}' => $issueDate,
            '{claimreceiveddate}' => $issueDate,
            '{claim_received_date}' => $issueDate,
            '{claimdatetime}' => $issueDateTime,
            '{claim_datetime}' => $issueDateTime,
            '{issuedate}' => $issueDate,
            '{issue_date}' => $issueDate,
            '{issuedatetime}' => $issueDateTime,
            '{issue_datetime}' => $issueDateTime,
            '{claimamount}' => $claimAmount,
            '{claim_amount}' => $claimAmount,
            '{claimamountvalue}' => $claimAmountValue,
            '{claim_amount_value}' => $claimAmountValue,
            '{claimcurrency}' => $claimCurrency,
            '{claim_currency}' => $claimCurrency,
            '{claimquantity}' => $claimQuantity,
            '{claim_quantity}' => $claimQuantity,
            '{claimunitamount}' => $claimUnitAmount,
            '{claim_unit_amount}' => $claimUnitAmount,
            '{claimunitamountvalue}' => $claimUnitAmountValue,
            '{claim_unit_amount_value}' => $claimUnitAmountValue,
            '{claimproductname}' => $claimProductName,
            '{claim_product_name}' => $claimProductName,
            '{claimedproductname}' => $claimProductName,
            '{claimed_product_name}' => $claimProductName,
            '{issueamount}' => $claimAmount,
            '{issue_amount}' => $claimAmount,
            '{issuecurrency}' => $claimCurrency,
            '{issue_currency}' => $claimCurrency,
            '{issueproductname}' => $claimProductName,
            '{issue_product_name}' => $claimProductName,
            '{productname}' => $claimProductName,
            '{product_name}' => $claimProductName,
            '{claimreason}' => $claimReason,
            '{claim_reason}' => $claimReason,
            '{claimreasondescription}' => $claimReasonDescription,
            '{claim_reason_description}' => $claimReasonDescription,
            '{claimdescription}' => $claimReasonDescription,
            '{claim_description}' => $claimReasonDescription,
        ];
    }

    protected function resolveIssueClaimAmountReplacementData(array $issue, array $messages, string $checkoutFormId = '', string $offerId = '', int $claimQuantity = 0): array
    {
        $checkoutFormId = trim($checkoutFormId);
        $offerId = trim($offerId);
        $fallbackData = $this->buildIssueClaimFallbackReplacementData($issue);

        if ($checkoutFormId === '') {
            $checkoutFormIds = $this->extractCheckoutFormIdsFromPayload($issue);
            foreach ($messages as $message) {
                if (is_array($message)) {
                    $checkoutFormIds = array_merge($checkoutFormIds, $this->extractCheckoutFormIdsFromPayload($message));
                }
            }
            $checkoutFormIds = array_values(array_unique(array_filter(array_map('strval', $checkoutFormIds))));
            $checkoutFormId = $checkoutFormIds[0] ?? '';
        }

        if ($offerId === '') {
            $offerId = trim((string) ($issue['offer']['id'] ?? $issue['offer']['offerId'] ?? ($this->extractOfferId($messages) ?? '')));
        }

        if ($checkoutFormId === '') {
            return $fallbackData;
        }

        $checkoutForm = $this->resolveIssueCheckoutFormPayloadForQuickReply($checkoutFormId);
        $lineItems = [];
        if ($checkoutForm) {
            $lineItems = $this->getCheckoutLineItemsForOfferId($checkoutForm, $offerId);
            $allLineItems = $this->extractCheckoutLineItems($checkoutForm);
            if (!$lineItems && count($allLineItems) === 1) {
                $lineItems = $allLineItems;
            }
        }

        foreach ($lineItems as $lineItem) {
            if (!is_array($lineItem)) {
                continue;
            }

            $claimAmountData = $this->extractIssueClaimAmountReplacementDataFromLineItem($lineItem, $claimQuantity);
            if ($claimAmountData['claim_product_name'] === '' && $fallbackData['claim_product_name'] !== '') {
                $claimAmountData['claim_product_name'] = $fallbackData['claim_product_name'];
            }
            if ($claimAmountData['claim_product_name'] !== '') {
                $fallbackData['claim_product_name'] = $claimAmountData['claim_product_name'];
            }

            if ($claimAmountData['claim_amount'] !== '') {
                return $claimAmountData;
            }
        }

        $prestashopData = $this->resolveIssueClaimAmountReplacementDataFromPrestashopOrder(
            $issue,
            $messages,
            $lineItems,
            $offerId,
            $claimQuantity
        );
        if ($prestashopData['claim_product_name'] === '' && $fallbackData['claim_product_name'] !== '') {
            $prestashopData['claim_product_name'] = $fallbackData['claim_product_name'];
        }
        if ($prestashopData['claim_amount'] !== '') {
            return $prestashopData;
        }

        return $fallbackData;
    }

    protected function resolveIssueClaimAmountReplacementDataFromPrestashopOrder(array $issue, array $messages, array $lineItems, string $offerId = '', int $claimQuantity = 0): array
    {
        $empty = $this->buildEmptyIssueClaimAmountReplacementData();
        $linkedOrder = $this->resolvePrestashopOrderLink($issue, $messages);
        $idOrder = (int) ($linkedOrder['id_order'] ?? 0);
        if ($idOrder <= 0) {
            return $empty;
        }

        foreach ($lineItems as $lineItem) {
            if (!is_array($lineItem)) {
                continue;
            }

            $match = $this->findPrestashopOrderDetailMatchByLineItem($idOrder, $lineItem);
            $row = $this->getPrestashopClaimOrderDetailRow(
                $idOrder,
                (int) ($match['id_product'] ?? 0),
                (int) ($match['id_product_attribute'] ?? 0)
            );
            if ($row) {
                return $this->extractIssueClaimAmountReplacementDataFromPrestashopOrderDetailRow($row, $claimQuantity);
            }
        }

        $row = $this->getPrestashopClaimOrderDetailRowByX13Offer($idOrder, $offerId);
        if ($row) {
            return $this->extractIssueClaimAmountReplacementDataFromPrestashopOrderDetailRow($row, $claimQuantity);
        }

        return $empty;
    }

    protected function getPrestashopClaimOrderDetailRow(int $idOrder, int $idProduct, int $idProductAttribute = 0): array
    {
        if ($idOrder <= 0 || $idProduct <= 0) {
            return [];
        }

        try {
            $row = Db::getInstance()->getRow('
                SELECT od.`product_name`, od.`product_quantity`, od.`unit_price_tax_incl`, c.`iso_code` AS `currency`
                FROM `' . _DB_PREFIX_ . 'order_detail` od
                INNER JOIN `' . _DB_PREFIX_ . 'orders` o ON (o.`id_order` = od.`id_order`)
                LEFT JOIN `' . _DB_PREFIX_ . 'currency` c ON (c.`id_currency` = o.`id_currency`)
                WHERE od.`id_order` = ' . (int) $idOrder . '
                    AND od.`product_id` = ' . (int) $idProduct . '
                    AND od.`product_attribute_id` = ' . (int) $idProductAttribute . '
                ORDER BY od.`id_order_detail` ASC
            ');
        } catch (Throwable $e) {
            PrestaShopLogger::addLog('[AAR] Claim order detail price lookup skipped for order #' . $idOrder . ': ' . $e->getMessage(), 2);

            return [];
        }

        return is_array($row) ? $row : [];
    }

    protected function getPrestashopClaimOrderDetailRowByX13Offer(int $idOrder, string $offerId): array
    {
        $offerId = trim($offerId);
        if ($idOrder <= 0 || $offerId === '' || !preg_match('/^[0-9]+$/', $offerId)) {
            return [];
        }

        try {
            $row = Db::getInstance()->getRow('
                SELECT od.`product_name`, od.`product_quantity`, od.`unit_price_tax_incl`, c.`iso_code` AS `currency`
                FROM `' . _DB_PREFIX_ . 'xallegro_auction` xa
                INNER JOIN `' . _DB_PREFIX_ . 'order_detail` od
                    ON (od.`product_id` = xa.`id_product`
                        AND od.`product_attribute_id` = COALESCE(xa.`id_product_attribute`, 0))
                INNER JOIN `' . _DB_PREFIX_ . 'orders` o ON (o.`id_order` = od.`id_order`)
                LEFT JOIN `' . _DB_PREFIX_ . 'currency` c ON (c.`id_currency` = o.`id_currency`)
                WHERE od.`id_order` = ' . (int) $idOrder . '
                    AND xa.`id_auction` = "' . pSQL($offerId) . '"
                ORDER BY od.`id_order_detail` ASC
            ');
        } catch (Throwable $e) {
            PrestaShopLogger::addLog('[AAR] X13 offer price lookup skipped for offer ' . $offerId . ' / order #' . $idOrder . ': ' . $e->getMessage(), 2);

            return [];
        }

        return is_array($row) ? $row : [];
    }

    protected function extractIssueClaimAmountReplacementDataFromPrestashopOrderDetailRow(array $row, int $claimQuantity = 0): array
    {
        $empty = $this->buildEmptyIssueClaimAmountReplacementData();
        $empty['claim_product_name'] = trim((string) ($row['product_name'] ?? ''));
        $rawAmount = str_replace(',', '.', trim((string) ($row['unit_price_tax_incl'] ?? '')));
        if ($rawAmount === '' || !is_numeric($rawAmount)) {
            return $empty;
        }

        $unitAmount = (float) $rawAmount;
        $purchasedQuantity = max(1, (int) ($row['product_quantity'] ?? 1));
        $quantity = $claimQuantity > 0 ? min($claimQuantity, $purchasedQuantity) : $purchasedQuantity;
        $totalAmount = $unitAmount * $quantity;
        $currency = trim((string) ($row['currency'] ?? ''));

        $totalAmountValue = number_format($totalAmount, 2, '.', '');
        $totalAmountFormatted = number_format($totalAmount, 2, ',', ' ');
        $unitAmountValue = number_format($unitAmount, 2, '.', '');
        $unitAmountFormatted = number_format($unitAmount, 2, ',', ' ');
        if ($currency !== '') {
            $totalAmountFormatted .= ' ' . $currency;
            $unitAmountFormatted .= ' ' . $currency;
        }

        return [
            'claim_amount' => $totalAmountFormatted,
            'claim_amount_value' => $totalAmountValue,
            'claim_currency' => $currency,
            'claim_quantity' => (string) $quantity,
            'claim_unit_amount' => $unitAmountFormatted,
            'claim_unit_amount_value' => $unitAmountValue,
            'claim_product_name' => $empty['claim_product_name'],
        ];
    }

    protected function resolveIssueCheckoutFormPayloadForQuickReply(string $checkoutFormId): array
    {
        $checkoutFormId = trim($checkoutFormId);
        if ($checkoutFormId === '') {
            return [];
        }

        try {
            $apiClient = new AllegroApiClient(new TokenManager());
            $checkoutForm = $apiClient->getCheckoutForm($checkoutFormId);
            if (is_array($checkoutForm) && $checkoutForm) {
                return $checkoutForm;
            }
        } catch (Throwable $e) {
            PrestaShopLogger::addLog('[AAR] Quick reply checkout form fetch failed for ' . $checkoutFormId . ': ' . $e->getMessage(), 2);
        }

        return $this->getStoredCheckoutFormContent($checkoutFormId);
    }

    protected function extractIssueClaimAmountReplacementDataFromLineItem(array $lineItem, int $claimQuantity = 0): array
    {
        $empty = $this->buildEmptyIssueClaimAmountReplacementData();
        $empty['claim_product_name'] = $this->extractIssueClaimProductNameFromLineItem($lineItem);
        $price = is_array($lineItem['price'] ?? null) ? $lineItem['price'] : [];
        if (!$price && is_array($lineItem['originalPrice'] ?? null)) {
            $price = $lineItem['originalPrice'];
        }
        $rawAmount = trim((string) ($price['amount'] ?? ''));
        if ($rawAmount === '') {
            return $empty;
        }

        $normalizedAmount = str_replace([' ', "\xc2\xa0"], '', $rawAmount);
        $normalizedAmount = str_replace(',', '.', $normalizedAmount);
        if (!is_numeric($normalizedAmount)) {
            return $empty;
        }

        $unitAmount = (float) $normalizedAmount;
        $purchasedQuantity = max(1, (int) ($lineItem['quantity'] ?? 1));
        $quantity = $claimQuantity > 0 ? min($claimQuantity, $purchasedQuantity) : $purchasedQuantity;
        $totalAmount = $unitAmount * $quantity;
        $currency = trim((string) ($price['currency'] ?? ''));

        $totalAmountValue = number_format($totalAmount, 2, '.', '');
        $totalAmountFormatted = number_format($totalAmount, 2, ',', ' ');
        if ($currency !== '') {
            $totalAmountFormatted .= ' ' . $currency;
        }

        $unitAmountValue = number_format($unitAmount, 2, '.', '');
        $unitAmountFormatted = number_format($unitAmount, 2, ',', ' ');
        if ($currency !== '') {
            $unitAmountFormatted .= ' ' . $currency;
        }

        return [
            'claim_amount' => $totalAmountFormatted,
            'claim_amount_value' => $totalAmountValue,
            'claim_currency' => $currency,
            'claim_quantity' => (string) $quantity,
            'claim_unit_amount' => $unitAmountFormatted,
            'claim_unit_amount_value' => $unitAmountValue,
            'claim_product_name' => $empty['claim_product_name'],
        ];
    }

    protected function extractIssueClaimProductNameFromLineItem(array $lineItem): string
    {
        $offer = is_array($lineItem['offer'] ?? null) ? $lineItem['offer'] : [];
        $candidates = [
            $offer['name'] ?? null,
            $offer['title'] ?? null,
            $lineItem['name'] ?? null,
            $lineItem['title'] ?? null,
            $lineItem['product']['name'] ?? null,
            $lineItem['product']['title'] ?? null,
        ];

        foreach ($candidates as $candidate) {
            $name = $this->resolveIssueTextValue($candidate);
            if ($name !== '') {
                return $name;
            }
        }

        return '';
    }

    protected function buildIssueClaimFallbackReplacementData(array $issue): array
    {
        $data = $this->buildEmptyIssueClaimAmountReplacementData();
        $candidates = [
            $issue['offer']['name'] ?? null,
            $issue['offer']['title'] ?? null,
            $issue['product']['name'] ?? null,
            $issue['product']['title'] ?? null,
        ];

        foreach ($candidates as $candidate) {
            $name = $this->resolveIssueTextValue($candidate);
            if ($name !== '') {
                $data['claim_product_name'] = $name;

                break;
            }
        }

        return $data;
    }

    protected function resolveIssueOfferTitleReplacement(array $issue, array $messages, string $offerId = ''): string
    {
        $offerId = trim($offerId);
        if ($offerId === '') {
            $offerId = trim((string) ($issue['offer']['id'] ?? $issue['offer']['offerId'] ?? ($this->extractOfferId($messages) ?? '')));
        }

        if ($offerId !== '') {
            try {
                $offer = (new AllegroApiClient(new TokenManager()))->getProductOffer($offerId);
                foreach ([
                    $offer['name'] ?? null,
                    $offer['title'] ?? null,
                    $offer['offer']['name'] ?? null,
                    $offer['offer']['title'] ?? null,
                ] as $candidate) {
                    $title = $this->resolveIssueTextValue($candidate);
                    if ($title !== '') {
                        return $title;
                    }
                }
            } catch (Throwable $e) {
                PrestaShopLogger::addLog('[AAR] Quick reply offer title lookup failed for offer ' . $offerId . ': ' . $e->getMessage(), 2);
            }
        }

        $linkedOrder = $this->resolvePrestashopOrderLink($issue, $messages);
        $singleProduct = $this->findSinglePrestashopOrderDetailProductMatch((int) ($linkedOrder['id_order'] ?? 0));

        return trim((string) ($singleProduct['product_name'] ?? ''));
    }

    protected function buildEmptyIssueClaimAmountReplacementData(): array
    {
        return [
            'claim_amount' => '',
            'claim_amount_value' => '',
            'claim_currency' => '',
            'claim_quantity' => '',
            'claim_unit_amount' => '',
            'claim_unit_amount_value' => '',
            'claim_product_name' => '',
        ];
    }

    protected function applyQuickReplyTemplateReplacements(string $text, array $replacements): string
    {
        if ($text === '' || !$replacements) {
            return $text;
        }

        $normalized = [];
        foreach ($replacements as $token => $value) {
            if (!is_scalar($token)) {
                continue;
            }

            $token = trim((string) $token);
            if ($token === '') {
                continue;
            }

            $normalized[strtolower($token)] = is_scalar($value) ? (string) $value : '';
        }

        if (!$normalized) {
            return $text;
        }

        $result = preg_replace_callback('/\{[a-z0-9_]+\}/i', function (array $match) use ($normalized): string {
            $token = strtolower((string) $match[0]);
            if ($token === '') {
                return '';
            }

            return array_key_exists($token, $normalized) ? $normalized[$token] : (string) $match[0];
        }, $text);

        return is_string($result) ? $result : $text;
    }

    protected function resolveIssueDateForTemplate(array $issue): string
    {
        foreach (['openedDate', 'createdAt', 'updatedAt'] as $key) {
            $value = trim((string) ($issue[$key] ?? ''));
            if ($value !== '' && strtotime($value) !== false) {
                return $value;
            }
        }

        $lastMessageDate = trim((string) ($issue['lastMessage']['createdAt'] ?? ''));
        if ($lastMessageDate !== '' && strtotime($lastMessageDate) !== false) {
            return $lastMessageDate;
        }

        return '';
    }

    protected function formatQuickReplyDate(string $value, bool $withTime = false): string
    {
        $value = trim($value);
        if ($value === '') {
            return '';
        }

        $timestamp = strtotime($value);
        if ($timestamp === false) {
            return '';
        }

        return date($withTime ? 'Y-m-d H:i' : 'Y-m-d', $timestamp);
    }

    protected function renderReplyExpandToggle(): string
    {
        $html = $this->htmlFragment('76585433da6e75eff0c6');
        $html .= $this->htmlFragment('8b42a9d0ee2f50e18c32');
        $html .= $this->htmlFragment('b9cd067dfe98cd6e2a04');
        $html .= $this->htmlFragment('b9cd067dfe98cd6e2a04');
        $html .= $this->htmlFragment('b9cd067dfe98cd6e2a04');
        $html .= $this->htmlFragment('411fdb22d8d9298e5d32');
        $html .= $this->htmlFragment('c61942e24146c734a0d6');
        $html .= $this->htmlFragment('d8de48c79715e8f2762e');

        return $html;
    }

    protected function renderQuickReplySelect(array $replacements = []): string
    {
        $templates = $this->getQuickReplyTemplates();

        if (!$templates) {
            return '';
        }

        $items = '';

        foreach ($templates as $template) {
            $text = $this->applyQuickReplyTemplateReplacements((string) ($template['response_template'] ?? ''), $replacements);
            if (trim($text) === '') {
                continue;
            }

            $items .= $this->htmlFragment('f1e1affdd6308460b7a1');
            $items .= $this->htmlFragment('d08ee50d9521b20a41f5') . Tools::safeOutput($text) . '">';
            $items .= Tools::safeOutput((string) ($template['name'] ?? 'Gotowa wiadomość'));
            $items .= $this->htmlFragment('d8de48c79715e8f2762e');
            $items .= $this->htmlFragment('16d2938ae98cd040db3a');
        }

        if ($items === '') {
            return '';
        }

        $html = $this->htmlFragment('7c54a4ae16ad23e5db38');
        $html .= $this->htmlFragment('e4162f84d310dca01f2d');
        $html .= $this->htmlFragment('0580e4b96d272a0e4997');
        $html .= $this->htmlFragment('e4b1746383934d54e726');
        $html .= $this->htmlFragment('d8de48c79715e8f2762e');
        $html .= $this->htmlFragment('2215c26d4d994a5b3e79');
        $html .= $items;
        $html .= $this->htmlFragment('348845d8804b5c895e2a');
        $html .= $this->htmlFragment('aac32651b10f567c461b');

        return $html;
    }

    protected function getQuickReplyTemplates(): array
    {
        $configuredTemplates = $this->getConfiguredQuickReplyTemplates();
        if ($configuredTemplates || $this->hasConfiguredQuickReplies()) {
            return $configuredTemplates;
        }

        return $this->getRuleBasedQuickReplyTemplates();
    }

    protected function hasConfiguredQuickReplies(): bool
    {
        return trim((string) Configuration::get(self::QUICK_REPLIES_CONFIG)) !== '';
    }

    protected function getConfiguredQuickReplyTemplates(): array
    {
        $raw = (string) Configuration::get(self::QUICK_REPLIES_CONFIG);
        if ($raw === '') {
            return [];
        }

        $decoded = json_decode($raw, true);
        if (!is_array($decoded)) {
            return [];
        }

        $templates = [];
        foreach ($decoded as $row) {
            if (!is_array($row)) {
                continue;
            }

            $templateText = trim((string) ($row['response_template'] ?? $row['text'] ?? ''));
            if ($templateText === '') {
                continue;
            }

            if (isset($row['enabled']) && (int) $row['enabled'] !== 1) {
                continue;
            }

            $templates[] = [
                'id_rule' => 0,
                'name' => trim((string) ($row['name'] ?? 'Gotowa odpowiedź')),
                'response_template' => $templateText,
            ];
        }

        return $templates;
    }

    protected function getRuleBasedQuickReplyTemplates(): array
    {
        $templates = Db::getInstance()->executeS(
            'SELECT id_rule, name, response_template FROM `' . _DB_PREFIX_ . 'allegro_ar_rule` WHERE enabled = 1 ORDER BY priority ASC, id_rule DESC'
        );

        return is_array($templates) ? $templates : [];
    }

    protected function renderQuickRepliesSettingsPanel(): string
    {
        $rows = $this->getQuickReplyRowsForSettings();

        $html = $this->htmlFragment('c2f1e9cf97e9c304fb17');

        $html .= $this->htmlFragment('017cea7b53210d8bae2c');
        $html .= $this->htmlFragment('44c65f359beeee7d578e');
        $html .= $this->htmlFragment('f6edc631175c10764f73');
        $html .= $this->htmlFragment('71d8add1192959c3a33a');
        $html .= $this->htmlFragment('aac32651b10f567c461b');
        $html .= $this->htmlFragment('f5f16bcda25efdae86f5');
        $html .= $this->htmlFragment('802fe0f002ac4dcedd2b');
        $html .= $this->htmlFragment('7cc0e7a3a1047005ea10');
        $html .= $this->htmlFragment('a0b55362f957a0f11dec');
        $html .= $this->htmlFragment('9960784fd6b96a12fbf5');
        $html .= $this->htmlFragment('3989165b7924bf193ace');
        $html .= $this->htmlFragment('ac94edc847a94a14c16a');
        $html .= $this->htmlFragment('aee2de443d9bc7cac246');

        if (!$rows) {
            $html .= $this->htmlFragment('78e007f777cf1a6db39b');
        } else {
            foreach ($rows as $index => $row) {
                $enabled = (int) ($row['enabled'] ?? 1) === 1;
                $name = (string) ($row['name'] ?? 'Gotowa odpowiedź');
                $text = (string) ($row['response_template'] ?? '');
                $html .= $this->htmlFragment('f4c47ecec5c57f200471') . (int) $index . '">';
                $html .= $this->htmlFragment('e43ac3d1ac277eda6847') . (int) $index . ']" value="' . ($enabled ? '1' : '0') . $this->htmlFragment('e69e6a48897674983cfe') . ($enabled ? '' : ' is-disabled') . '">' . ($enabled ? 'Aktywna' : 'Wyłączona') . $this->htmlFragment('c2e851dc0760b9cacd7c');
                $html .= $this->htmlFragment('47352a51743068e4d60b') . (int) $index . ']" value="' . Tools::safeOutput($name) . $this->htmlFragment('581a2c2368248e197ff1') . Tools::safeOutput($name) . $this->htmlFragment('c2e851dc0760b9cacd7c');
                $html .= $this->htmlFragment('98984924dc45c13501ee') . (int) $index . ']" style="display:none;">' . Tools::safeOutput($text) . $this->htmlFragment('798de03a0f76fc699674') . nl2br(Tools::safeOutput($text)) . $this->htmlFragment('56ef702a1018b1d2e7be');
                $html .= $this->htmlFragment('c475c6a23274a039682d');
                $html .= $this->htmlFragment('3ed7440ce0756928276f');
            }
        }

        $html .= $this->htmlFragment('57d99a57d8a70c2c050e');
        $html .= $this->htmlFragment('e0c7bb7b72eeecfc0734');
        $html .= $this->htmlFragment('aac32651b10f567c461b');
        $html .= $this->htmlFragment('aac32651b10f567c461b');

        $html .= $this->htmlFragment('afd7e1217dad248aae7b');
        $html .= $this->htmlFragment('b62c1a34c0e3ea7baef3');
        $html .= $this->htmlFragment('014784f8bbfbc1976bc9');
        $html .= $this->htmlFragment('5d217cb0fd9f80203fdd');
        $html .= $this->htmlFragment('6416b918eef22c892aee');
        $html .= $this->htmlFragment('531b590904d2c360318e');
        $html .= $this->htmlFragment('28a27baca999aec61eba');
        $html .= $this->htmlFragment('61caacd9d1bacb031f98');
        $html .= $this->htmlFragment('10c277da07c22c61c9db');
        $html .= $this->htmlFragment('aac32651b10f567c461b');
        $html .= $this->htmlFragment('61dd50abe005987782fe');
        $html .= $this->htmlFragment('c6103998e3e77513f208');

        $html .= $this->htmlFragment('ef338972b29d2a560d24');

        return $html;
    }

    protected function getQuickReplyRowsForSettings(): array
    {
        $raw = (string) Configuration::get(self::QUICK_REPLIES_CONFIG);
        if ($raw !== '') {
            $decoded = json_decode($raw, true);
            if (is_array($decoded)) {
                $rows = [];
                foreach ($decoded as $row) {
                    if (!is_array($row)) {
                        continue;
                    }

                    $rows[] = [
                        'name' => trim((string) ($row['name'] ?? '')),
                        'response_template' => trim((string) ($row['response_template'] ?? $row['text'] ?? '')),
                        'enabled' => isset($row['enabled']) ? (int) $row['enabled'] : 1,
                    ];
                }

                return $rows;
            }

            return [];
        }

        $rules = $this->getRuleBasedQuickReplyTemplates();
        $rows = [];
        foreach ($rules as $rule) {
            $rows[] = [
                'name' => trim((string) ($rule['name'] ?? '')),
                'response_template' => trim((string) ($rule['response_template'] ?? '')),
                'enabled' => 1,
            ];
        }

        return $rows;
    }

    protected function renderLogsTable(): string
    {
        $logs = Db::getInstance()->executeS('SELECT * FROM `' . _DB_PREFIX_ . 'allegro_ar_log` ORDER BY id_log DESC LIMIT 50');
        $html = $this->htmlFragment('2822a15eff7a270ac8d8') . $this->trans('Ostatnie logi', [], 'Modules.Allegrocustomerservice.Admin') . $this->htmlFragment('a6c57bf5252e5005b93d');
        $html .= $this->htmlFragment('274a1de194e1f4b812b2');
        $html .= $this->htmlFragment('2fd621d45f4fd29b7930');
        if (!$logs) {
            $html .= $this->htmlFragment('cec28a180aabb17c6dd6');
        } else {
            foreach ($logs as $log) {
                $html .= $this->htmlFragment('9b84c614b473bf1d182e');
                $html .= $this->htmlFragment('ad76f84d9f135f96caee') . Tools::safeOutput($log['created_at']) . $this->htmlFragment('b8073d8a2f01abcc6c6b');
                $html .= $this->htmlFragment('ad76f84d9f135f96caee') . Tools::safeOutput($this->formatLogAction((string) $log['action'])) . $this->htmlFragment('b8073d8a2f01abcc6c6b');
                $html .= $this->htmlFragment('ad76f84d9f135f96caee') . Tools::safeOutput($log['thread_id']) . $this->htmlFragment('b8073d8a2f01abcc6c6b');
                $html .= $this->htmlFragment('ad76f84d9f135f96caee') . Tools::safeOutput($log['matched_rule']) . $this->htmlFragment('b8073d8a2f01abcc6c6b');
                $html .= $this->htmlFragment('ad76f84d9f135f96caee') . ((int) $log['success'] ? 'OK' : 'FAIL') . $this->htmlFragment('b8073d8a2f01abcc6c6b');
                $html .= $this->htmlFragment('fba4982c1d900fe7fd96') . $this->renderLogDetails($log) . $this->htmlFragment('fe86512d40eb618a8f3c');
                $html .= $this->htmlFragment('3ed7440ce0756928276f');
            }
        }
        $html .= $this->htmlFragment('7fa98554c4a983f787a6');

        return $html;
    }

    protected function renderUpdatePanel(): string
    {
        $updater = $this->getUpdater();
        $currentVersion = (string) $this->version;
        $licenseStatus = $this->getLicenseStatus();
        $licenseDetails = is_array($licenseStatus['details'] ?? null) ? $licenseStatus['details'] : [];
        $licensePayload = is_array($licenseDetails['payload'] ?? null) ? $licenseDetails['payload'] : [];
        $licenseCustomer = trim((string) ($licenseDetails['customer'] ?? $licensePayload['customer'] ?? ''));
        $licenseDomain = trim((string) ($licenseDetails['domain'] ?? $licensePayload['domain'] ?? ''));
        $updatesUntil = trim((string) ($licenseDetails['updates_until'] ?? ''));
        $licensePlan = trim((string) ($licenseDetails['plan'] ?? ''));
        $domain = method_exists('Tools', 'getShopDomainSsl')
            ? (string) Tools::getShopDomainSsl(false)
            : (string) Tools::getShopDomain(false);
        $ajaxUrl = str_replace('&amp;', '&', $this->context->link->getAdminLink('AdminModules', true, [], [
            'configure' => $this->name,
            'ajax' => 1,
        ]));

        $html = $this->htmlFragment('12ece6d97975ed6ac5f1');

        $html .= $this->htmlFragment('aa51b4fa27a55536fe62');
        $html .= $this->htmlFragment('551d3431f59b24aeec54') . $this->trans('Informacje o module', [], 'Modules.Allegrocustomerservice.Admin') . $this->htmlFragment('a6c57bf5252e5005b93d');
        $html .= $this->htmlFragment('3ad5ab0917aaae71b6e9');
        $html .= $this->htmlFragment('5f8583fee472b568e990') . Tools::safeOutput($currentVersion) . $this->htmlFragment('8dad793c25981e398e7a');
        $html .= $this->htmlFragment('3d597c47969a2a1c7ad2') . Tools::safeOutput($licenseCustomer !== '' ? $licenseCustomer : '—') . $this->htmlFragment('8dad793c25981e398e7a');
        $html .= $this->htmlFragment('9e69133781202df504cf') . Tools::safeOutput($licenseDomain !== '' ? $licenseDomain : ($domain !== '' ? $domain : '—')) . $this->htmlFragment('8dad793c25981e398e7a');
        $html .= $this->htmlFragment('a89e7118b5233251f157') . Tools::safeOutput($updatesUntil !== '' ? $updatesUntil : ($licensePlan === 'legacy' ? 'Starsza licencja' : '—')) . $this->htmlFragment('8dad793c25981e398e7a');
        $html .= $this->htmlFragment('aac32651b10f567c461b');

        $html .= $this->htmlFragment('5727fb5de50651a8fc98');
        $html .= $this->htmlFragment('505b4e7e88bcb20bddee') . json_encode($ajaxUrl) . $this->htmlFragment('08283f5636090d58604d');
        $html .= $this->htmlFragment('aac32651b10f567c461b');

        return $html;
    }

    protected function getUpdater(): AllegroCustomerServiceUpdater
    {
        return new AllegroCustomerServiceUpdater($this->getLocalPath(), $this, $this->getLicenseService());
    }

    public function getPrestinoBuild(): int
    {
        return self::PRESTINO_BUILD;
    }

    protected function formatLogAction(string $action): string
    {
        $labels = [
            'test_reply' => 'TEST: wysłałby odpowiedź',
            'reply_sent' => 'Wysłano automatyczną odpowiedź',
            'reply_failed' => 'Błąd automatycznej odpowiedzi',
            'no_match' => 'Brak pasującej reguły',
            'first_message_skip' => 'Pominięto: to nie pierwsza wiadomość',
            'cooldown_skip' => 'Pominięto: aktywna przerwa',
            'manual_reply_sent' => 'Wysłano ręczną odpowiedź',
            'manual_reply_failed' => 'Błąd ręcznej odpowiedzi',
            'issue_reply_sent' => 'Wysłano odpowiedź w zgłoszeniu',
            'issue_reply_failed' => 'Błąd odpowiedzi w zgłoszeniu',
            'mark_read_failed' => 'Nie udało się oznaczyć jako przeczytane',
        ];

        return $labels[$action] ?? $action;
    }

    protected function renderLogDetails(array $log): string
    {
        $request = $this->decodeLogPayload((string) ($log['request_payload'] ?? ''));
        $response = $this->decodeLogPayload((string) ($log['response_payload'] ?? ''));
        $parts = [];

        $incoming = (string) ($request['incoming'] ?? $request['text'] ?? '');
        if ($incoming !== '') {
            $parts[] = $this->htmlFragment('c3d943f98a6a841be2c8') . nl2br(Tools::safeOutput($this->shortenLogText($incoming, 260)));
        }

        $outgoing = (string) ($response['outgoing'] ?? '');
        if ($outgoing !== '') {
            $parts[] = $this->htmlFragment('a5f4c958039d71807f86') . nl2br(Tools::safeOutput($this->shortenLogText($outgoing, 360)));
        }

        $reason = (string) ($response['reason'] ?? '');
        if ($reason !== '') {
            $parts[] = $this->htmlFragment('9b1bf8b9d5d8bd2e7d21') . Tools::safeOutput($reason);
        }

        $error = (string) ($request['error'] ?? $response['error'] ?? '');
        if ($error !== '') {
            $parts[] = $this->htmlFragment('483eae5e891f6eef0185') . Tools::safeOutput($this->shortenLogText($error, 260));
        }

        $context = $request['context'] ?? [];
        if (is_array($context)) {
            $contextParts = [];
            if (!empty($context['recipient_login'])) {
                $contextParts[] = 'kupujący: ' . (string) $context['recipient_login'];
            }
            if (!empty($context['order_id'])) {
                $contextParts[] = 'zamówienie: ' . (string) $context['order_id'];
            }
            if (!empty($context['offer_id'])) {
                $contextParts[] = 'oferta: ' . (string) $context['offer_id'];
            }
            if ($contextParts) {
                $parts[] = $this->htmlFragment('dc8f1a44dc80da05540c') . Tools::safeOutput(implode(', ', $contextParts));
            }
        }

        if (!$parts) {
            $raw = (string) ($log['response_payload'] ?? $log['request_payload'] ?? '');
            $parts[] = Tools::safeOutput($this->shortenLogText($raw, 260));
        }

        return implode($this->htmlFragment('65aef1adba8672a5fe79'), $parts);
    }

    protected function decodeLogPayload(string $payload): array
    {
        $decoded = json_decode($payload, true);

        return is_array($decoded) ? $decoded : [];
    }

    protected function shortenLogText(string $text, int $limit): string
    {
        $text = trim($text);
        if (mb_strlen($text) <= $limit) {
            return $text;
        }

        return mb_substr($text, 0, $limit - 3) . '...';
    }

    protected function findThreadById(array $threads, string $threadId): ?array
    {
        foreach ($threads as $thread) {
            if (is_array($thread) && (string) ($thread['id'] ?? '') === $threadId) {
                return $thread;
            }
        }

        return null;
    }

    protected function findIssueById(array $issues, string $issueId): ?array
    {
        foreach ($issues as $issue) {
            if (is_array($issue) && (string) ($issue['id'] ?? '') === $issueId) {
                return $issue;
            }
        }

        return null;
    }

    protected function extractOrderId(array $messages): ?string
    {
        foreach ($messages as $message) {
            if (!is_array($message)) {
                continue;
            }

            $orderId = $this->normalizeOptionalId($message['relatesTo']['order']['id'] ?? null);
            if ($orderId !== '') {
                return $orderId;
            }
        }

        return null;
    }

    protected function extractOfferId(array $messages): ?string
    {
        foreach ($messages as $message) {
            if (!is_array($message)) {
                continue;
            }

            $offerId = $this->normalizeOptionalId($message['relatesTo']['offer']['id'] ?? null);
            if ($offerId !== '') {
                return $offerId;
            }
        }

        return null;
    }

    protected function normalizeOptionalId($value): string
    {
        if (!is_scalar($value)) {
            return '';
        }

        $value = trim((string) $value);
        if ($value === '' || mb_strtolower($value) === 'null') {
            return '';
        }

        return $value;
    }

    protected function decodeAllegroText(string $text): string
    {
        return html_entity_decode($text, ENT_QUOTES | ENT_HTML5, 'UTF-8');
    }

    protected function formatAllegroDate(string $date): string
    {
        if ($date === '') {
            return '';
        }

        $timestamp = strtotime($date);
        if (!$timestamp) {
            return $date;
        }

        return date('Y-m-d H:i', $timestamp);
    }

    protected function getAdminMessagesUrl(array $params = []): string
    {
        foreach (['message_query', 'message_unread', 'message_without_reply'] as $filterName) {
            if (!isset($params[$filterName])) {
                $filterValue = trim((string) Tools::getValue($filterName));
                if ($filterValue !== '') {
                    $params[$filterName] = $filterValue;
                }
            }
        }
        if (!isset($params['thread_pages'])) {
            $threadPages = $this->getCurrentThreadPageCount();
            if ($threadPages > 1) {
                $params['thread_pages'] = $threadPages;
            }
        }

        return $this->getAdminLinkFor('AdminAllegroCustomerServiceMessages', $params);
    }

    protected function getReturnsAdminUrl(array $params = []): string
    {
        if (!isset($params['return_status'])) {
            $params['return_status'] = $this->getCurrentReturnStatusFilter();
        }
        if (!isset($params['return_date_range'])) {
            $params['return_date_range'] = $this->getCurrentReturnDateRangeFilter();
        }
        if (!isset($params['return_query'])) {
            $params['return_query'] = trim((string) Tools::getValue('return_query'));
        }
        if (!isset($params['return_pages'])) {
            $returnPages = $this->getCurrentReturnPageCount();
            if ($returnPages > 1) {
                $params['return_pages'] = $returnPages;
            }
        }

        $params = array_filter($params, function ($value): bool {
            return $value !== null && $value !== false && $value !== '';
        });

        return $this->getAdminLinkFor('AdminAllegroCustomerServiceReturns', $params);
    }

    protected function getIssuesAdminUrl(string $issueType, array $params = []): string
    {
        $normalizedType = mb_strtoupper($issueType);
        if ($normalizedType === 'CLAIM') {
            $controller = 'AdminAllegroCustomerServiceComplaints';
        } elseif ($normalizedType === 'DISPUTE') {
            $controller = 'AdminAllegroCustomerServiceDisputes';
        } else {
            $currentController = (string) Tools::getValue('controller');
            $controller = $currentController === 'AdminAllegroCustomerServiceDisputes'
                ? 'AdminAllegroCustomerServiceDisputes'
                : 'AdminAllegroCustomerServiceComplaints';
        }

        if (!isset($params['status_filter'])) {
            $statusFilter = $this->getCurrentIssueStatusFilter();
            if ($statusFilter !== 'all') {
                $params['status_filter'] = $statusFilter;
            }
        }
        if (!isset($params['issue_kind'])) {
            $issueKind = $this->getCurrentIssueKindFilter($normalizedType !== '' ? $normalizedType : 'CLAIM');
            if ($issueKind !== 'CLAIM') {
                $params['issue_kind'] = $issueKind;
            }
        }
        if (!isset($params['issue_query'])) {
            $issueQuery = trim((string) Tools::getValue('issue_query'));
            if ($issueQuery !== '') {
                $params['issue_query'] = $issueQuery;
            }
        }
        if (!isset($params['issue_pages'])) {
            $issuePages = $this->getCurrentIssuePageCount();
            if ($issuePages > 1) {
                $params['issue_pages'] = $issuePages;
            }
        }

        return $this->getAdminLinkFor($controller, $params);
    }

    protected function getEditedRule(): ?array
    {
        $idRule = (int) Tools::getValue('edit_rule');
        if ($idRule <= 0) {
            return null;
        }

        $rule = Db::getInstance()->getRow('SELECT * FROM `' . _DB_PREFIX_ . 'allegro_ar_rule` WHERE id_rule=' . (int) $idRule);

        return is_array($rule) ? $rule : null;
    }

    protected function getRuleMatchTypeOptions(): array
    {
        return [
            'contains' => 'Zawiera jedno ze słów lub zdań z listy',
            'exact' => 'Jest dokładnie równe tej treści',
            'regex' => 'Pasuje do zaawansowanego wzorca (regex)',
        ];
    }

    protected function getOauthCallbackUrl(): string
    {
        return $this->context->link->getModuleLink($this->name, 'oauth');
    }

    protected function getAuthorizationUrl(): string
    {
        return '';
    }

    protected function hasAllegroAuthBackend(): bool
    {
        return (new TokenManager())->hasAuthBackend();
    }

    protected function getConnectedAccount(): ?array
    {
        $account = Db::getInstance()->getRow('SELECT allegro_user_id, login, expires_at, scope, active, date_upd FROM `' . _DB_PREFIX_ . 'allegro_ar_account` ORDER BY id_account ASC');

        return is_array($account) ? $account : null;
    }
}

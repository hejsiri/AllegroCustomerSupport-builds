<?php

class AllegroAutoresponderThumbnailModuleFrontController extends ModuleFrontController
{
    public $display_header = false;
    public $display_footer = false;

    public function initContent()
    {
        parent::initContent();

        $token = trim((string) Tools::getValue('token'));
        $expected = trim((string) Configuration::get(AllegroAutoresponder::CONFIG_PREFIX . 'CRON_TOKEN'));
        if ($expected === '' || !hash_equals($expected, $token)) {
            $this->respondError(403, 'Invalid token');
        }

        $offerId = trim((string) Tools::getValue('offer_id'));
        $productId = trim((string) Tools::getValue('product_id'));
        $checkoutFormId = trim((string) Tools::getValue('checkout_form_id'));
        $issueId = trim((string) Tools::getValue('issue_id'));
        $mode = trim((string) Tools::getValue('mode'));

        if ($offerId === '' && $productId === '' && $checkoutFormId === '' && $issueId === '') {
            $this->respondError(400, 'Missing identifiers');
        }

        try {
            $url = $this->module->warmIssueThumbnailCache($offerId, $productId, $checkoutFormId, $issueId);

            if ($mode === 'image') {
                if ($url === '') {
                    http_response_code(404);
                    exit;
                }

                Tools::redirectLink($url);
            }

            header('Content-Type: application/json');
            die(json_encode([
                'ok' => $url !== '',
                'url' => $url,
            ]));
        } catch (Throwable $e) {
            $this->respondError(500, $e->getMessage());
        }
    }

    protected function respondError(int $statusCode, string $message): void
    {
        if (trim((string) Tools::getValue('mode')) === 'image') {
            http_response_code($statusCode);
            exit;
        }

        header('Content-Type: application/json');
        http_response_code($statusCode);
        die(json_encode([
            'ok' => false,
            'message' => $message,
        ]));
    }
}

<?php

if (!defined('_PS_VERSION_')) {
    exit;
}

if (!class_exists('AllegroCustomerServiceUpdater', false)) {
class AllegroCustomerServiceUpdater
{
    public const CONFIG_UPDATE_CHANNEL = 'AAR_UPDATE_CHANNEL';
    public const UPDATE_CHANNEL_PUBLIC = 'public';
    public const UPDATE_CHANNEL_BETA = 'beta';
    private const API_URL = 'https://www.prestino.pl/prestino-update.php';
    private const BUILD_CONFIGURATION_KEY = 'AAR_PRESTINO_BUILD';

    private $module;
    private $license;

    public function __construct(string $modulePath, Module $module, ?AllegroCustomerServiceLicense $license = null)
    {
        $this->module = $module;
        $this->license = $license ?: new AllegroCustomerServiceLicense($modulePath, Context::getContext(), $module);
    }

    public function isConfigured(): bool
    {
        return true;
    }

    /** Zachowane dla zgodności ze starszymi migracjami i formularzami. */
    public function getConfiguredChannel(): string
    {
        return self::UPDATE_CHANNEL_PUBLIC;
    }

    public function saveConfiguredChannel(string $unusedChannel): void
    {
        Configuration::deleteByName(self::CONFIG_UPDATE_CHANNEL);
    }

    public static function getAvailableChannels(): array
    {
        return [self::UPDATE_CHANNEL_PUBLIC];
    }

    public function checkForUpdates(?string $unusedChannel = null): array
    {
        $response = $this->request('check');
        $data = json_decode((string) $response['body'], true);
        if (!is_array($data) || empty($data['status']) || empty($data['manifest'])) {
            throw new RuntimeException((string) ($data['message'] ?? 'Serwer aktualizacji zwrócił nieprawidłową odpowiedź.'));
        }
        $payload = $this->verifyManifest((string) $data['manifest'], 'prestino_update_check');

        return [
            'configured' => true,
            'available' => !empty($payload['available']),
            'updates_allowed' => !empty($payload['updates_allowed']),
            'current_version' => (string) ($payload['installed_version'] ?? $this->module->version),
            'current_build' => (int) ($payload['installed_build'] ?? $this->module->getPrestinoBuild()),
            'version' => (string) ($payload['latest_version'] ?? ''),
            'build' => (int) ($payload['latest_build'] ?? 0),
            'updates_until' => (string) ($payload['updates_until'] ?? ''),
            'notes' => '',
        ];
    }

    public function getChangelogForUpdate(?string $unusedChannel = null): array
    {
        return [
            'from_version' => (string) $this->module->version,
            'to_version' => '',
            'entries' => [],
        ];
    }

    public function installAvailableUpdate(?string $unusedChannel = null): array
    {
        $temporary = tempnam(sys_get_temp_dir(), 'allegro-customer-service-prestino-update-');
        if ($temporary === false) {
            throw new RuntimeException('Nie udało się utworzyć pliku tymczasowego aktualizacji.');
        }
        $zipPath = $temporary . '.zip';
        @unlink($temporary);
        $backupPath = '';
        $installedVersion = (string) $this->module->version;
        $installedBuild = $this->module->getPrestinoBuild();

        try {
            $response = $this->request('download', $zipPath);
            $manifest = (string) ($response['headers']['x-prestino-update-manifest'] ?? '');
            $payload = $this->verifyManifest($manifest, 'prestino_update_download');
            $expectedHash = strtolower((string) ($payload['sha256'] ?? ''));
            $actualHash = strtolower((string) hash_file('sha256', $zipPath));
            if ($expectedHash === '' || !hash_equals($expectedHash, $actualHash)) {
                throw new RuntimeException('Suma kontrolna paczki aktualizacyjnej jest nieprawidłowa.');
            }

            $version = (string) ($payload['version'] ?? '');
            $build = (int) ($payload['build'] ?? 0);
            $this->validatePackage($zipPath, $version, $build);
            $backupPath = $this->createBackup();
            $this->extractPackage($zipPath);

            if (version_compare($version, $installedVersion, '<')) {
                throw new RuntimeException('Serwer aktualizacji zwrócił starszą wersję modułu.');
            }
            if (version_compare($version, $installedVersion, '>')) {
                $this->module->version = $version;
                $this->module->database_version = (string) Db::getInstance()->getValue(
                    'SELECT `version` FROM `' . _DB_PREFIX_ . "module` WHERE `name` = '" . pSQL($this->module->name) . "'"
                );
                if (Module::initUpgradeModule($this->module)) {
                    $upgrade = $this->module->runUpgradeModule();
                    if (empty($upgrade['success']) || !empty($upgrade['number_upgrade_left'])) {
                        throw new RuntimeException('PrestaShop nie zdołał zakończyć migracji modułu.');
                    }
                }
            }

            $this->runPrestinoMigrations($installedBuild, $build);
            if (!Configuration::updateValue(self::BUILD_CONFIGURATION_KEY, $build)
                || !Module::upgradeModuleVersion($this->module->name, $version)
            ) {
                throw new RuntimeException('PrestaShop nie zdołał zapisać nowej wersji modułu.');
            }
            Tools::clearAllCache();

            return [
                'ok' => true,
                'version' => $version,
                'build' => $build,
                'backup' => $backupPath,
                'message' => 'Zainstalowano Obsługę Klienta Allegro ' . $version . ' · build Prestino ' . $build . '.',
            ];
        } catch (Throwable $e) {
            if ($backupPath !== '') {
                $this->restoreBackup($backupPath);
                Configuration::updateValue(self::BUILD_CONFIGURATION_KEY, $installedBuild);
                Module::upgradeModuleVersion($this->module->name, $installedVersion);
                Tools::clearAllCache();
            }
            throw $e;
        } finally {
            @unlink($zipPath);
        }
    }

    private function request(string $action, string $targetPath = ''): array
    {
        if (!function_exists('curl_init')) {
            throw new RuntimeException('Serwer nie udostępnia biblioteki cURL wymaganej do aktualizacji.');
        }
        $licenseStatus = $this->license->getStatus();
        if (empty($licenseStatus['valid'])) {
            throw new RuntimeException('Aktualizacja wymaga prawidłowej licencji Prestino.');
        }
        $details = is_array($licenseStatus['details'] ?? null) ? $licenseStatus['details'] : [];
        if (empty($details['license_id'])) {
            throw new RuntimeException('Ta licencja została wystawiona w starszym systemie. Pobierz nową licencję Prestino, aby korzystać z aktualizacji.');
        }
        $token = $this->license->getLicenseKey();
        if ($token === '') {
            throw new RuntimeException('Nie można odczytać licencji modułu.');
        }

        $headers = [];
        $handle = curl_init(self::API_URL);
        $file = null;
        if ($handle === false) {
            throw new RuntimeException('Nie udało się połączyć z serwerem aktualizacji.');
        }

        try {
            curl_setopt_array($handle, [
                CURLOPT_POST => true,
                CURLOPT_POSTFIELDS => http_build_query([
                    'update_action' => $action,
                    'license_token' => $token,
                    'module' => $this->module->name,
                    'version' => $this->module->version,
                    'build' => $this->module->getPrestinoBuild(),
                    'domain' => $this->currentDomain(),
                    'prestashop_version' => _PS_VERSION_,
                    'php_version' => PHP_VERSION,
                ]),
                CURLOPT_CONNECTTIMEOUT => 8,
                CURLOPT_TIMEOUT => $action === 'download' ? 120 : 15,
                CURLOPT_FOLLOWLOCATION => false,
                CURLOPT_SSL_VERIFYPEER => true,
                CURLOPT_SSL_VERIFYHOST => 2,
                CURLOPT_USERAGENT => 'AllegroCustomerServicePrestinoUpdater/' . $this->module->version,
                CURLOPT_HEADERFUNCTION => static function ($curl, string $header) use (&$headers): int {
                    $length = strlen($header);
                    $parts = explode(':', $header, 2);
                    if (count($parts) === 2) {
                        $headers[strtolower(trim($parts[0]))] = trim($parts[1]);
                    }

                    return $length;
                },
            ]);

            if ($targetPath !== '') {
                $file = fopen($targetPath, 'wb');
                if ($file === false) {
                    throw new RuntimeException('Nie można zapisać pobieranej aktualizacji.');
                }
                curl_setopt($handle, CURLOPT_FILE, $file);
                $body = '';
            } else {
                curl_setopt($handle, CURLOPT_RETURNTRANSFER, true);
                $body = curl_exec($handle);
            }

            $executed = $targetPath !== '' ? curl_exec($handle) : $body;
            if ($executed === false) {
                throw new RuntimeException('Błąd połączenia z serwerem aktualizacji: ' . curl_error($handle));
            }

            $status = (int) curl_getinfo($handle, CURLINFO_HTTP_CODE);
            if ($status !== 200) {
                if ($file !== null) {
                    fclose($file);
                    $file = null;
                    $body = is_file($targetPath) ? (string) file_get_contents($targetPath) : '';
                }
                $error = json_decode((string) $body, true);
                throw new RuntimeException((string) ($error['message'] ?? 'Serwer aktualizacji odrzucił żądanie.'));
            }

            return ['body' => (string) $body, 'headers' => $headers];
        } finally {
            if (is_resource($file)) {
                fclose($file);
            }
            curl_close($handle);
        }
    }

    private function verifyManifest(string $token, string $expectedType): array
    {
        $parts = explode('.', trim($token), 2);
        if (count($parts) !== 2) {
            throw new RuntimeException('Brak podpisu odpowiedzi serwera aktualizacji.');
        }
        $payloadJson = $this->base64UrlDecode($parts[0]);
        $signature = $this->base64UrlDecode($parts[1]);
        $payload = json_decode($payloadJson, true);
        $keyPath = $this->module->getLocalPath() . 'keys/license_public.pem';
        if (!is_array($payload) || $signature === '' || !is_readable($keyPath)
            || openssl_verify($parts[0], $signature, (string) file_get_contents($keyPath), OPENSSL_ALGO_SHA256) !== 1
        ) {
            throw new RuntimeException('Podpis odpowiedzi serwera aktualizacji jest nieprawidłowy.');
        }
        $details = $this->license->getStatus()['details'] ?? [];
        if (($payload['type'] ?? '') !== $expectedType
            || ($payload['module'] ?? '') !== $this->module->name
            || ($payload['license_id'] ?? '') !== ($details['license_id'] ?? '')
            || (int) ($payload['expires_at'] ?? 0) < time()
        ) {
            throw new RuntimeException('Odpowiedź serwera aktualizacji nie pasuje do tej licencji.');
        }

        return $payload;
    }

    private function validatePackage(string $path, string $version, int $build): void
    {
        $zip = new ZipArchive();
        if ($zip->open($path) !== true) {
            throw new RuntimeException('Pobrana paczka aktualizacyjna jest uszkodzona.');
        }
        try {
            for ($index = 0; $index < $zip->numFiles; ++$index) {
                $entry = (string) $zip->getNameIndex($index);
                if ($entry === '' || strpos($entry, "\0") !== false || strpos($entry, '\\') !== false
                    || strpos($entry, '/') === 0 || strpos('/' . $entry, '/../') !== false
                    || strpos($entry, $this->module->name . '/') !== 0
                ) {
                    throw new RuntimeException('Paczka aktualizacyjna zawiera niedozwoloną ścieżkę.');
                }
            }
            $mainFile = $zip->getFromName($this->module->name . '/' . $this->module->name . '.php');
            $configXml = $zip->getFromName($this->module->name . '/config.xml');
            $releaseJson = $zip->getFromName($this->module->name . '/prestino-release.json');
            $release = is_string($releaseJson) ? json_decode($releaseJson, true) : null;
            if (!is_string($mainFile) || !is_string($configXml)
                || !preg_match('~<version><!\\[CDATA\\[([^]]+)]]></version>~', $configXml, $matches)
                || (string) $matches[1] !== $version
                || !is_array($release)
                || (string) ($release['upstream_version'] ?? '') !== $version
                || (int) ($release['prestino_build'] ?? 0) !== $build
                || $zip->locateName($this->module->name . '/license.php') === false
            ) {
                throw new RuntimeException('Paczka nie zawiera oczekiwanej wersji licencjonowanego modułu.');
            }
        } finally {
            $zip->close();
        }
    }

    private function createBackup(): string
    {
        $directory = _PS_ROOT_DIR_ . '/var/backups/prestino-modules';
        if (!is_dir($directory) && !@mkdir($directory, 0750, true) && !is_dir($directory)) {
            throw new RuntimeException('Nie udało się utworzyć katalogu kopii bezpieczeństwa.');
        }
        $path = $directory . '/' . $this->module->name . '-' . date('Ymd-His') . '.zip';
        $zip = new ZipArchive();
        if ($zip->open($path, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== true) {
            throw new RuntimeException('Nie udało się utworzyć kopii bezpieczeństwa modułu.');
        }
        $source = rtrim($this->module->getLocalPath(), '/\\');
        $iterator = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($source, FilesystemIterator::SKIP_DOTS),
            RecursiveIteratorIterator::SELF_FIRST
        );
        foreach ($iterator as $item) {
            $relative = $this->module->name . '/' . substr($item->getPathname(), strlen($source) + 1);
            if ($item->isDir()) {
                $zip->addEmptyDir($relative);
            } elseif ($item->isFile()) {
                $zip->addFile($item->getPathname(), $relative);
            }
        }
        $zip->close();

        return $path;
    }

    private function extractPackage(string $path): void
    {
        $zip = new ZipArchive();
        if ($zip->open($path) !== true || !$zip->extractTo(_PS_MODULE_DIR_) || !$zip->close()) {
            throw new RuntimeException('Nie udało się rozpakować zweryfikowanej aktualizacji modułu.');
        }
    }

    private function runPrestinoMigrations(int $fromBuild, int $toBuild): void
    {
        if ($toBuild <= $fromBuild) {
            return;
        }
        $files = glob($this->module->getLocalPath() . 'upgrade/prestino/upgrade-*.php') ?: [];
        $migrations = [];
        foreach ($files as $file) {
            if (preg_match('/upgrade-(\\d+)\\.php$/', $file, $matches) === 1) {
                $build = (int) $matches[1];
                if ($build > $fromBuild && $build <= $toBuild) {
                    $migrations[$build] = $file;
                }
            }
        }
        ksort($migrations, SORT_NUMERIC);
        foreach ($migrations as $build => $file) {
            require_once $file;
            $function = 'upgrade_allegro_customer_service_prestino_' . $build;
            if (!is_callable($function) || !$function($this->module)) {
                throw new RuntimeException('Nie udało się wykonać migracji buildu Prestino ' . $build . '.');
            }
        }
    }

    private function restoreBackup(string $path): void
    {
        $zip = new ZipArchive();
        if ($zip->open($path) === true) {
            $zip->extractTo(_PS_MODULE_DIR_);
            $zip->close();
        }
    }

    private function currentDomain(): string
    {
        $context = Context::getContext();
        $baseUrl = isset($context->shop) && method_exists($context->shop, 'getBaseURL')
            ? (string) $context->shop->getBaseURL(true)
            : '';
        $host = parse_url($baseUrl, PHP_URL_HOST);

        if (!is_string($host) || $host === '') {
            $host = (string) ($_SERVER['HTTP_HOST'] ?? $_SERVER['SERVER_NAME'] ?? '');
        }

        return is_string($host) ? $host : '';
    }

    private function base64UrlDecode(string $value): string
    {
        $value = strtr($value, '-_', '+/');
        $decoded = base64_decode($value . str_repeat('=', (4 - strlen($value) % 4) % 4), true);

        return is_string($decoded) ? $decoded : '';
    }
}
}

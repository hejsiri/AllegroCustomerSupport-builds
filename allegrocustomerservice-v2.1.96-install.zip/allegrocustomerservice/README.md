# Obsługa Klienta Allegro dla PrestaShop

Moduł `allegrocustomerservice` integruje obsługę klienta Allegro z panelem administracyjnym PrestaShop 8. Umożliwia pracę z wiadomościami, dyskusjami, reklamacjami i zwrotami, a także ręczne oraz automatyczne odpowiadanie klientom bez przechodzenia między wieloma ekranami Allegro.

## Najważniejsze funkcje

- osobne menu „Obsługa Klienta Allegro” w Back Office,
- autoryzacja konta Allegro przez Device Flow,
- obsługa wiadomości i ręcznych odpowiedzi,
- obsługa dyskusji oraz reklamacji,
- obsługa zwrotów towarów,
- reguły automatycznych odpowiedzi uruchamiane przez CRON,
- gotowe odpowiedzi do ręcznego użycia,
- tryb testowy autorespondera,
- logi skanowania i wysyłania odpowiedzi,
- licencjonowanie przypisane do domeny,
- podpisane aktualizacje modułu z kanału publicznego lub beta.

## Wymagania

- PrestaShop 8.0 lub nowszy,
- połączenie sklepu przez HTTPS,
- aktywna aplikacja Allegro z wymaganymi uprawnieniami API,
- backend autoryzacji producenta skonfigurowany dla Device Flow,
- ważny plik `license.php` dostarczony przez wydawcę,
- możliwość cyklicznego wywoływania adresu CRON.

## Instalacja

1. Zainstaluj paczkę ZIP z katalogiem głównym `allegrocustomerservice` przez Menedżer modułów PrestaShop.
2. Upewnij się, że w katalogu `modules/allegrocustomerservice/` znajduje się ważny plik `license.php`.
3. Otwórz menu **Obsługa Klienta Allegro → Ustawienia**.
4. Kliknij **Połącz konto Allegro** i wykonaj proces autoryzacji.
5. Skonfiguruj ustawienia ogólne, gotowe odpowiedzi oraz reguły automatyczne.
6. Dodaj pokazany w ustawieniach adres CRON do harmonogramu serwera.
7. Na początku pozostaw włączony tryb testowy i sprawdź logi po ręcznym skanowaniu.

Po instalacji moduł tworzy własne tabele bazy danych, ustawienia konfiguracyjne oraz pozycje menu Back Office.

## Menu modułu

### Wiadomości

Sekcja prezentuje komunikator Allegro bezpośrednio w Back Office:

- listę wątków i podgląd wybranej rozmowy,
- wysyłanie ręcznych odpowiedzi,
- oznaczanie wątków wymagających odpowiedzi,
- wyróżnianie nieprzeczytanych rozmów,
- wyszukiwanie po loginie odbiorcy,
- filtry „Nieprzeczytane” i „Bez mojej odpowiedzi”,
- leniwe pobieranie kolejnych paczek wątków,
- avatary klientów lub inicjały loginów,
- powiększanie pola wpisywania wiadomości,
- wybieranie gotowych odpowiedzi z menu przy edytorze,
- miniaturę produktu przy wiadomości klienta powiązanej z konkretną ofertą.

Liczba nieprzeczytanych wiadomości może być pokazywana jako plakietka przy pozycji menu.

### Dyskusje

Sekcja służy do obsługi dyskusji Allegro. Udostępnia:

- listę zgłoszeń i podgląd pełnej rozmowy,
- wyszukiwanie po danych zgłoszenia, kupującym, zamówieniu i ofercie,
- wysyłanie odpowiedzi bez opuszczania PrestaShop,
- dane powiązanego zamówienia oraz produktu,
- linki do zamówienia Allegro i zamówienia PrestaShop,
- miniatury produktów z bezpiecznymi mechanizmami zapasowymi.

### Reklamacje

Reklamacje są prezentowane w podobnym układzie do dyskusji. Moduł pokazuje między innymi:

- status i typ zgłoszenia,
- temat oraz przetłumaczony powód reklamacji,
- dane kupującego, zamówienia i oferty,
- historię wiadomości,
- produkt i jego miniaturę,
- formularz ręcznej odpowiedzi,
- gotowe odpowiedzi ze zmiennymi reklamacyjnymi.

### Zwroty towarów

Sekcja zwrotów obejmuje:

- listę zwrotów i ich bieżące statusy,
- wyszukiwanie i filtrowanie,
- plakietkę liczby oczekujących zwrotów w menu,
- szczegóły klienta, zamówienia, dostawy i zwracanych pozycji,
- dopasowanie produktów i zdjęć z PrestaShop po ofercie, EAN lub historycznej pozycji zamówienia,
- informacje o przesyłce zwrotnej i śledzeniu,
- obsługę decyzji zwrotowej,
- możliwość wykonania zwrotu środków z obsługiwanym powodem Allegro,
- diagnostykę danych API zwrotu z możliwością kopiowania JSON-u.

## Ustawienia modułu

### Połączenie konta Allegro

Przycisk **Połącz konto Allegro** uruchamia Device Flow. Po udanej autoryzacji panel pokazuje login, identyfikator konta oraz datę ważności tokenu. Token jest automatycznie odświeżany przez mechanizm modułu. Konto można rozłączyć z poziomu ustawień.

Autoryzacja wymaga backendu producenta skonfigurowanego w module lub przez stałą `AAR_ALLEGRO_AUTH_BACKEND_URL`.

### Ustawienia ogólne

- **Włącz moduł** — zezwala zadaniu CRON na automatyczne skanowanie wiadomości i wysyłanie odpowiedzi. Wyłączenie nie blokuje panelu, ręcznych odpowiedzi ani ręcznego skanowania.
- **Tryb testowy automatycznych odpowiedzi** — analizuje wiadomości i zapisuje planowane odpowiedzi w logach, ale nie wysyła ich do klientów.
- **Limit pobieranych wątków** — maksymalna liczba wątków pobieranych podczas jednego skanowania.
- **Przerwa między automatycznymi odpowiedziami** — ogólna wartość konfiguracyjna; reguły mają również własny czas blokady używany przy dopasowaniu.

> Ważne: wiadomość przeanalizowana w trybie testowym zostaje oznaczona jako przetworzona. Po wyłączeniu trybu testowego moduł nie wraca automatycznie do tej samej wiadomości.

## Gotowe odpowiedzi

Gotowe odpowiedzi są ręcznymi szablonami dostępnymi w menu przy polu odpowiedzi. Panel ustawień pokazuje listę tylko do odczytu, a dodawanie i edycja odbywają się w oknie modalnym.

Każdy szablon zawiera:

- nazwę,
- treść odpowiedzi,
- status aktywny lub wyłączony.

Obsługiwane zmienne ręcznych szablonów:

| Zmienna | Znaczenie |
| --- | --- |
| `{buyer_login}` | login kupującego |
| `{shop_name}` | nazwa sklepu PrestaShop |
| `{order_id}` | identyfikator zamówienia Allegro |
| `{offer_id}` | identyfikator oferty Allegro |
| `{offer_title}` | tytuł reklamowanej oferty Allegro |
| `{orderdate}` | data zamówienia |
| `{purchase_date}` | data zakupu (alias daty zamówienia) |
| `{orderdatetime}` | data i godzina zamówienia |
| `{claimdate}` | data reklamacji lub zgłoszenia |
| `{claim_submitted_date}` | data złożenia reklamacji |
| `{claim_received_date}` | data doręczenia reklamacji sprzedającemu (w Allegro taka sama jak data otwarcia zgłoszenia) |
| `{claimdatetime}` | data i godzina reklamacji lub zgłoszenia |
| `{claim_product_name}` | nazwa reklamowanego produktu |
| `{claim_reason}` | przetłumaczona kategoria powodu reklamacji |
| `{claim_reason_description}` | opis wady podany przez kupującego |
| `{claim_amount}` | łączna kwota reklamowanej pozycji z walutą |
| `{claim_amount_value}` | wartość kwoty bez symbolu waluty |
| `{claim_currency}` | kod waluty |
| `{claim_quantity}` | liczba sztuk |
| `{claim_unit_amount}` | kwota jednostkowa z walutą |

Dostępne są również zgodne aliasy części zmiennych, między innymi warianty z podkreśleniami dla dat oraz nazwy produktu.

## Automatyczne odpowiedzi

Automatyczne odpowiedzi działają na podstawie aktywnych reguł. Dla każdej reguły można ustawić:

- nazwę,
- aktywność,
- priorytet,
- typ dopasowania,
- słowa kluczowe,
- szablon odpowiedzi,
- ograniczenie do pierwszej automatycznej odpowiedzi w wątku,
- czas blokady kolejnej odpowiedzi w minutach.

Reguły są sprawdzane według priorytetu. Moduł odpowiada tylko wtedy, gdy najnowsza wiadomość pochodzi od klienta, nie została wcześniej przetworzona, pasuje do reguły i spełnia ograniczenia pierwszej wiadomości oraz czasu blokady.

Zmienne dostępne w automatycznych odpowiedziach:

- `{message}` — treść wiadomości klienta,
- `{shop_name}` — nazwa sklepu,
- `{buyer_login}` — login kupującego,
- `{order_id}` — identyfikator zamówienia,
- `{offer_id}` — identyfikator oferty.

Przycisk **Importuj reguły startowe** dodaje przykładowy zestaw reguł, który należy dopasować do polityki obsługi sklepu.

## CRON

Adres zadania jest widoczny w ustawieniach modułu. Można go skopiować lub otworzyć w nowej karcie. Ma postać:

```text
https://sklep.example/modules/allegrocustomerservice/cron.php?token=TAJNY_TOKEN
```

Przykładowa konfiguracja systemowego CRON-u wykonywana co 5 minut:

```cron
*/5 * * * * curl -fsS "https://sklep.example/modules/allegrocustomerservice/cron.php?token=TAJNY_TOKEN" >/dev/null
```

Poprawne wykonanie zwraca bezpieczne podsumowanie JSON, na przykład:

```json
{
  "ok": true,
  "threads_checked": 20,
  "customer_messages": 3,
  "matched": 2,
  "sent": 1,
  "test_replies": 0,
  "skipped": 1,
  "failed": 0
}
```

Odpowiedź nie zawiera treści wiadomości ani danych klientów. Token CRON należy traktować jak hasło: nie publikować go i zmienić po ujawnieniu.

Znaczenie liczników:

- `threads_checked` — sprawdzone wątki,
- `customer_messages` — najnowsze wiadomości rozpoznane jako pochodzące od klientów,
- `matched` — wiadomości dopasowane do reguły,
- `sent` — faktycznie wysłane odpowiedzi,
- `test_replies` — odpowiedzi zapisane tylko w trybie testowym,
- `skipped` — wiadomości pominięte,
- `failed` — błędy przetwarzania lub wysyłania.

## Logi

Panel **Ostatnie logi** pokazuje 50 najnowszych zdarzeń. Przycisk **Uruchom skan ręczny** wykonuje ten sam skaner bez oczekiwania na CRON.

Najważniejsze typy zdarzeń:

- `reply_sent` — wysłano automatyczną odpowiedź,
- `test_reply` — przygotowano odpowiedź w trybie testowym,
- `no_match` — żadna reguła nie pasowała,
- `first_message_skip` — pominięto ze względu na ograniczenie pierwszej odpowiedzi,
- `cooldown_skip` — aktywny czas blokady,
- `reply_failed` — wysłanie odpowiedzi nie powiodło się,
- `manual_reply_sent` / `manual_reply_failed` — wynik ręcznej odpowiedzi,
- `mark_read_failed` — nie udało się oznaczyć wątku jako przeczytanego.

Logi mogą zawierać dane potrzebne do diagnozy obsługi klienta, dlatego dostęp do panelu powinien być ograniczony do uprawnionych pracowników.

## Licencja

Moduł wymaga podpisanego pliku `license.php` umieszczonego w katalogu modułu. Licencja jest generowana i dostarczana przez wydawcę; generator nie jest częścią paczki instalacyjnej.

Weryfikowane są między innymi:

- nazwa modułu,
- przypisana domena,
- termin ważności,
- podpis kryptograficzny.

Nieprawidłowa lub wygasła licencja blokuje chronione funkcje modułu i CRON. Aktualizator zachowuje lokalny plik `license.php` podczas instalowania nowej wersji.

## Aktualizacje

Panel **Informacje o module** pokazuje bieżącą wersję, dane licencji, domenę i termin ważności. Po wejściu do ustawień moduł automatycznie sprawdza dostępność aktualizacji.

Dostępne kanały:

- `public` — stabilne wydania,
- `beta` — wydania testowe.

Aktualizacje są pobierane z manifestu, weryfikowane sumą SHA-256 oraz podpisem, a następnie instalowane po świadomym kliknięciu przycisku. Samo wejście do ustawień nigdy nie instaluje aktualizacji automatycznie.

## Bezpieczeństwo i dobre praktyki

- używaj HTTPS,
- nie udostępniaj adresu CRON z tokenem,
- po ujawnieniu tokenu wygeneruj nowy,
- rozpocznij konfigurację z włączonym trybem testowym,
- przed wyłączeniem trybu testowego przejrzyj reguły i logi,
- ustaw rozsądny czas blokady w każdej regule,
- ogranicz dostęp pracowników do ustawień i logów,
- regularnie instaluj stabilne aktualizacje,
- przed aktualizacją produkcyjną wykonuj kopię bazy danych i katalogu modułu.

## Diagnostyka

### CRON zwraca `Module disabled`

Włącz przełącznik **Włącz moduł** w ustawieniach. Ręczne funkcje mogą działać mimo wyłączonego automatycznego CRON-u.

### CRON zwraca `Invalid token`

Skopiuj ponownie pełny adres z ustawień i sprawdź, czy harmonogram nie usuwa ani nie koduje fragmentu parametru `token`.

### CRON zwraca błąd licencji

Sprawdź obecność `license.php`, domenę sklepu oraz termin ważności pokazany w panelu **Informacje o module**.

### CRON działa, ale nie wysyła odpowiedzi

Sprawdź kolejno:

1. czy tryb testowy jest wyłączony,
2. czy istnieje aktywna reguła pasująca do wiadomości,
3. czy nie obowiązuje czas blokady,
4. czy reguła nie jest ograniczona do pierwszej odpowiedzi,
5. czy wiadomość nie została już wcześniej przetworzona,
6. co zapisano w panelu **Ostatnie logi**.

### Wiadomość została wykryta w trybie testowym

Nie zostanie automatycznie przetworzona ponownie po wyłączeniu trybu testowego. Autoresponder zadziała na kolejnych nowych wiadomościach klienta.

## Dane techniczne

- techniczna nazwa modułu: `allegrocustomerservice`,
- prefiks konfiguracji: `AAR_`,
- prefiks tabel bazy danych: `allegro_ar_`,
- główny endpoint CRON: `modules/allegrocustomerservice/cron.php`,
- minimalna wersja PrestaShop: 8.0.

Historia zmian znajduje się w pliku [CHANGELOG.md](CHANGELOG.md).

<?php

if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_0_2_190($module)
{
    return Configuration::updateValue('AAR_PRESTINO_BUILD', 2);
}

<?php

if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_2_1_90($module)
{
    return Configuration::updateValue('AAR_PRESTINO_BUILD', 4);
}

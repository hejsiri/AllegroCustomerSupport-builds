<?php

if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_2_1_79($module)
{
    if (!$module instanceof AllegroCustomerService || !$module->installClaimRejectionQuickReply()) {
        return false;
    }

    $raw = (string) Configuration::get('AAR_QUICK_REPLIES');
    if ($raw !== '') {
        $rows = json_decode($raw, true);
        if (is_array($rows)) {
            $changed = false;
            foreach ($rows as &$row) {
                if (!is_array($row) || trim((string) ($row['name'] ?? '')) !== 'Odpowiedź na reklamację — odmowa') {
                    continue;
                }

                $text = (string) ($row['response_template'] ?? $row['text'] ?? '');
                $updatedText = str_replace(
                    'dotyczącą produktu „{claim_product_name}”',
                    'dotyczącą produktu {offer_title}',
                    $text
                );
                if ($updatedText !== $text) {
                    $row['response_template'] = $updatedText;
                    unset($row['text']);
                    $changed = true;
                }
            }
            unset($row);

            if ($changed && !Configuration::updateValue(
                'AAR_QUICK_REPLIES',
                json_encode($rows, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)
            )) {
                return false;
            }
        }
    }

    return Configuration::updateValue('AAR_CLAIM_REJECTION_TEMPLATE_MIGRATED', 1)
        && Configuration::updateValue('AAR_PRESTINO_BUILD', 3)
        && Configuration::deleteByName('AAR_UPDATE_CHANNEL') !== false;
}

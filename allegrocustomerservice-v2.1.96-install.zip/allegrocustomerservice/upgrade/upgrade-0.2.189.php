<?php

if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_0_2_189($module)
{
    return Configuration::updateValue('AAR_PRESTINO_BUILD', 1)
        && Configuration::deleteByName('AAR_UPDATE_CHANNEL') !== false;
}

(function () {
  'use strict';

  function updaterUrl(action) {
    var config = window.allegroCustomerServicePrestino || {};
    var baseUrl = config.updateUrl || '';

    return baseUrl
      ? baseUrl + (baseUrl.indexOf('?') === -1 ? '?' : '&') + 'action=' + encodeURIComponent(action)
      : '';
  }

  function createAlertsContainer() {
    var page = document.querySelector('.aar-settings-page');
    var existing = document.querySelector('.aar-prestino-alerts');
    var container;

    if (existing) {
      return existing;
    }
    if (!page) {
      return null;
    }

    container = document.createElement('div');
    container.className = 'aar-prestino-alerts';
    page.insertBefore(container, page.firstChild);

    return container;
  }

  function addCloseButton(alert) {
    var closeButton;

    if (!alert || alert.querySelector('.aar-prestino-alert-close')) {
      return;
    }

    closeButton = document.createElement('button');
    closeButton.type = 'button';
    closeButton.className = 'aar-prestino-alert-close';
    closeButton.setAttribute('aria-label', 'Zamknij alert');
    closeButton.title = 'Zamknij';
    closeButton.textContent = '\u00d7';
    closeButton.addEventListener('click', function () {
      alert.remove();
    });
    alert.insertBefore(closeButton, alert.firstChild);
  }

  function renderLicense(container) {
    var config = window.allegroCustomerServicePrestino || {};
    var holder;
    var alert;

    if (!config.licenseHtml) {
      return;
    }

    holder = document.createElement('div');
    holder.innerHTML = config.licenseHtml;
    alert = holder.firstElementChild;
    if (alert) {
      addCloseButton(alert);
      container.appendChild(alert);
    }
  }

  function installUpdate(button) {
    var url = updaterUrl('InstallUpdate');

    if (!url || button.disabled) {
      return;
    }

    button.disabled = true;
    button.textContent = 'Aktualizowanie…';

    fetch(url, {method: 'POST', credentials: 'same-origin'})
      .then(function (response) { return response.json(); })
      .then(function (response) {
        if (!response.ok) {
          throw new Error(response.message || response.error || 'Aktualizacja nie powiodła się.');
        }
        if (window.showSuccessMessage) {
          window.showSuccessMessage(response.message || 'Moduł został zaktualizowany.');
        }
        button.textContent = 'Zaktualizowano';
        window.setTimeout(function () { window.location.reload(); }, 1200);
      })
      .catch(function (error) {
        button.disabled = false;
        button.textContent = 'Aktualizuj teraz';
        if (window.showErrorMessage) {
          window.showErrorMessage(error.message || 'Aktualizacja nie powiodła się.');
        }
      });
  }

  function renderUpdate(container, update) {
    var alert;
    var row;
    var content;
    var title;
    var description;
    var button;

    if (!update || !update.available || !update.updates_allowed) {
      return;
    }

    alert = document.createElement('div');
    alert.className = 'alert alert-warning aar-prestino-update-alert';
    row = document.createElement('div');
    row.className = 'aar-prestino-update-row';
    content = document.createElement('div');
    content.className = 'aar-prestino-update-content';
    title = document.createElement('strong');
    title.textContent = 'Dostępna aktualizacja: Obsługa Klienta Allegro ' + update.version + '. ';
    description = document.createElement('span');
    description.textContent = 'Możesz bezpiecznie zaktualizować moduł bezpośrednio z Prestino.';
    button = document.createElement('button');
    button.type = 'button';
    button.className = 'btn btn-warning aar-prestino-update-button';
    button.textContent = 'Aktualizuj teraz';
    button.addEventListener('click', function () { installUpdate(button); });
    addCloseButton(alert);
    content.appendChild(title);
    content.appendChild(description);
    row.appendChild(content);
    row.appendChild(button);
    alert.appendChild(row);
    container.appendChild(alert);
  }

  function checkUpdate(container) {
    var config = window.allegroCustomerServicePrestino || {};
    var url = updaterUrl('CheckForUpdates');

    if (!config.valid || !url) {
      return;
    }

    fetch(url, {method: 'POST', credentials: 'same-origin'})
      .then(function (response) { return response.json(); })
      .then(function (response) {
        if (response.ok && response.status) {
          renderUpdate(container, response.status);
        }
      })
      .catch(function () {
        // Brak połączenia z Prestino nie blokuje ustawień modułu.
      });
  }

  function initialize() {
    var container = createAlertsContainer();

    if (!container) {
      return;
    }

    renderLicense(container);
    checkUpdate(container);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initialize);
  } else {
    initialize();
  }
}());

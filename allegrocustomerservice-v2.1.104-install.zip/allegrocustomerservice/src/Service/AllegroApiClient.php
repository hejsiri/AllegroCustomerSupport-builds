<?php
namespace PrestaShop\Module\AllegroCustomerService\Service;

use Configuration;
use Tools;

if (!class_exists(__NAMESPACE__ . '\\AllegroApiClient', false)) {
class AllegroApiClient
{
    private const API_URL = 'https://api.allegro.pl';
    private const ACCEPT = 'application/vnd.allegro.public.v1+json';
    private const ACCEPT_BETA = 'application/vnd.allegro.beta.v1+json';
    private const CONNECT_TIMEOUT = 10;
    private const REQUEST_TIMEOUT = 20;

    /** @var TokenManager */
    private $tokenManager;

    public function __construct(TokenManager $tokenManager)
    {
        $this->tokenManager = $tokenManager;
    }

    public function getThreads(int $limit = 20, int $offset = 0): array
    {
        return $this->request('GET', '/messaging/threads?limit=' . max(1, min(20, $limit)) . '&offset=' . max(0, $offset));
    }

    public function getThread(string $threadId): array
    {
        return $this->request('GET', '/messaging/threads/' . rawurlencode($threadId));
    }

    public function getThreadMessages(string $threadId, int $limit = 20, int $offset = 0): array
    {
        return $this->request('GET', '/messaging/threads/' . rawurlencode($threadId) . '/messages?limit=' . max(1, min(20, $limit)) . '&offset=' . max(0, $offset));
    }

    public function getIssues(int $limit = 20, int $offset = 0, array $filters = []): array
    {
        $params = [
            'limit' => max(1, min(100, $limit)),
            'offset' => max(0, $offset),
        ];

        foreach ($filters as $name => $value) {
            if (!is_scalar($value)) {
                continue;
            }

            $value = trim((string) $value);
            if ($value === '') {
                continue;
            }

            $params[$name] = $value;
        }

        return $this->request('GET', '/sale/issues?' . http_build_query($params), null, self::ACCEPT_BETA);
    }

    public function getIssue(string $issueId): array
    {
        return $this->request('GET', '/sale/issues/' . rawurlencode($issueId), null, self::ACCEPT_BETA);
    }

    public function getCustomerReturns(int $limit = 100, int $offset = 0, array $filters = []): array
    {
        $params = [
            'limit' => max(1, min(1000, $limit)),
            'offset' => max(0, $offset),
        ];

        foreach ($filters as $name => $value) {
            if (!is_scalar($value)) {
                continue;
            }

            $value = trim((string) $value);
            if ($value === '') {
                continue;
            }

            $params[$name] = $value;
        }

        return $this->request('GET', '/order/customer-returns?' . http_build_query($params), null, self::ACCEPT_BETA);
    }

    public function getCustomerReturn(string $customerReturnId): array
    {
        return $this->request('GET', '/order/customer-returns/' . rawurlencode($customerReturnId), null, self::ACCEPT_BETA);
    }

    public function getCarrierTracking(string $carrierId, array $waybills): array
    {
        $carrierId = trim($carrierId);
        $waybills = array_values(array_unique(array_filter(array_map(static function ($waybill): string {
            return trim((string) $waybill);
        }, $waybills))));

        if ($carrierId === '' || !$waybills) {
            return [];
        }

        $params = [];
        foreach (array_slice($waybills, 0, 20) as $waybill) {
            $params[] = 'waybill=' . rawurlencode($waybill);
        }

        return $this->request('GET', '/order/carriers/' . rawurlencode($carrierId) . '/tracking?' . implode('&', $params));
    }

    public function rejectCustomerReturn(string $customerReturnId, string $code, string $reason = ''): array
    {
        $payload = [
            'rejection' => [
                'code' => $code,
            ],
        ];

        $reason = trim($reason);
        if ($reason !== '') {
            $payload['rejection']['reason'] = $reason;
        }

        return $this->request(
            'POST',
            '/order/customer-returns/' . rawurlencode($customerReturnId) . '/rejection',
            $payload,
            self::ACCEPT_BETA
        );
    }

    public function createPaymentRefund(array $payload): array
    {
        return $this->request('POST', '/payments/refunds', $payload);
    }

    public function getProductOffer(string $offerId): array
    {
        return $this->request('GET', '/sale/product-offers/' . rawurlencode($offerId));
    }

    public function getProduct(string $productId): array
    {
        return $this->request('GET', '/sale/products/' . rawurlencode($productId));
    }

    public function getCheckoutForm(string $checkoutFormId): array
    {
        return $this->request('GET', '/order/checkout-forms/' . rawurlencode($checkoutFormId));
    }

    public function getIssueChat(string $issueId, int $limit = 20, int $offset = 0): array
    {
        return $this->request(
            'GET',
            '/sale/issues/' . rawurlencode($issueId) . '/chat?limit=' . max(1, min(100, $limit)) . '&offset=' . max(0, $offset),
            null,
            self::ACCEPT_BETA
        );
    }

    public function getAllIssueChat(string $issueId, int $expectedCount = 0): array
    {
        $limit = 100;
        $offset = 0;
        $maxPages = 100;
        $messagesByKey = [];
        $error = '';
        $finished = false;
        $pagesFetched = 0;

        for ($page = 0; $page < $maxPages; $page++) {
            try {
                $response = $this->getIssueChat($issueId, $limit, $offset);
            } catch (\Throwable $e) {
                if ($page === 0) {
                    throw $e;
                }

                $error = $e->getMessage();
                break;
            }

            $pagesFetched++;
            $pageMessages = $response['chat'] ?? $response['messages'] ?? [];
            if (!is_array($pageMessages)) {
                $pageMessages = [];
            }

            foreach ($pageMessages as $message) {
                if (!is_array($message)) {
                    continue;
                }

                $messageId = trim((string) ($message['id'] ?? ''));
                $key = $messageId !== ''
                    ? 'id:' . $messageId
                    : 'hash:' . hash('sha256', (string) json_encode($message, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
                $messagesByKey[$key] = $message;
            }

            $pageCount = count($pageMessages);
            if ($pageCount < $limit) {
                $finished = true;
                break;
            }

            $offset += $limit;
        }

        $messages = array_values($messagesByKey);
        $fetchedCount = count($messages);
        $complete = $finished && $error === '' && ($expectedCount <= 0 || $fetchedCount >= $expectedCount);

        return [
            'chat' => $messages,
            'history' => [
                'expected_count' => max(0, $expectedCount),
                'fetched_count' => $fetchedCount,
                'pages_fetched' => $pagesFetched,
                'complete' => $complete,
                'error' => $error,
                'limit_reached' => !$finished && $error === '',
            ],
        ];
    }

    public function downloadIssueAttachment(string $attachmentId): array
    {
        $attachmentId = trim($attachmentId);
        if (!preg_match('/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i', $attachmentId)) {
            throw new \RuntimeException('Invalid Allegro issue attachment ID.');
        }

        $token = $this->tokenManager->getValidAccessToken();
        $url = self::API_URL . '/sale/issues/attachments/' . rawurlencode($attachmentId);
        $responseHeaders = [];
        $headers = [
            'Authorization: Bearer ' . $token,
            'Accept: */*',
            'User-Agent: PrestaShop-AllegroCustomerSupport/0.1',
        ];

        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, self::CONNECT_TIMEOUT);
        curl_setopt($ch, CURLOPT_TIMEOUT, self::REQUEST_TIMEOUT);
        curl_setopt($ch, CURLOPT_HEADERFUNCTION, static function ($ch, string $header) use (&$responseHeaders): int {
            $separator = strpos($header, ':');
            if ($separator !== false) {
                $name = mb_strtolower(trim(substr($header, 0, $separator)));
                $value = trim(substr($header, $separator + 1));
                if ($name !== '') {
                    $responseHeaders[$name] = $value;
                }
            }

            return strlen($header);
        });

        $body = curl_exec($ch);
        $status = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $contentType = trim((string) curl_getinfo($ch, CURLINFO_CONTENT_TYPE));
        if ($body === false) {
            $error = curl_error($ch);
            curl_close($ch);
            throw new \RuntimeException('cURL error: ' . $error);
        }
        curl_close($ch);

        if ($status >= 400 || $status < 200) {
            throw new \RuntimeException('Allegro API attachment download error (' . $status . ').');
        }

        return [
            'body' => $body,
            'content_type' => $contentType,
            'content_disposition' => (string) ($responseHeaders['content-disposition'] ?? ''),
        ];
    }

    public function sendIssueMessage(string $issueId, string $text, string $type = 'REGULAR', array $attachments = []): array
    {
        return $this->request('POST', '/sale/issues/' . rawurlencode($issueId) . '/message', [
            'text' => $text,
            'attachments' => $attachments,
            'type' => $type,
        ], self::ACCEPT_BETA);
    }

    public function changeIssueClaimStatus(string $issueId, string $status, string $message, ?array $partialRefund = null): array
    {
        $payload = [
            'status' => $status,
            'message' => $message,
        ];

        if ($partialRefund !== null) {
            $payload['partialRefund'] = $partialRefund;
        }

        return $this->request(
            'POST',
            '/sale/issues/' . rawurlencode($issueId) . '/status',
            $payload,
            self::ACCEPT_BETA
        );
    }

    public function declareIssueAttachment(string $fileName, int $size): array
    {
        $fileName = trim(basename($fileName));
        if ($fileName === '' || $size <= 0) {
            throw new \RuntimeException('Invalid issue attachment metadata.');
        }

        $token = $this->tokenManager->getValidAccessToken();
        $url = self::API_URL . '/sale/issues/attachments';
        $location = '';
        $headers = [
            'Authorization: Bearer ' . $token,
            'Accept: ' . self::ACCEPT_BETA,
            'Content-Type: ' . self::ACCEPT_BETA,
            'User-Agent: PrestaShop-AllegroCustomerSupport/0.1',
        ];

        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, self::CONNECT_TIMEOUT);
        curl_setopt($ch, CURLOPT_TIMEOUT, self::REQUEST_TIMEOUT);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode([
            'fileName' => $fileName,
            'size' => $size,
        ]));
        curl_setopt($ch, CURLOPT_HEADERFUNCTION, static function ($ch, string $header) use (&$location): int {
            if (stripos($header, 'Location:') === 0) {
                $location = trim(substr($header, strlen('Location:')));
            }

            return strlen($header);
        });

        $raw = curl_exec($ch);
        $status = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        if ($raw === false) {
            $error = curl_error($ch);
            curl_close($ch);
            throw new \RuntimeException('cURL error: ' . $error);
        }
        curl_close($ch);

        if ($status >= 400) {
            throw new \RuntimeException('Allegro API attachment declaration error (' . $status . '): ' . $raw);
        }

        $decoded = json_decode($raw, true);
        $attachmentId = trim((string) ($decoded['id'] ?? ''));
        if ($attachmentId === '' || $location === '') {
            throw new \RuntimeException('Allegro API did not return the attachment ID or upload URL.');
        }

        return [
            'id' => $attachmentId,
            'uploadUrl' => $location,
        ];
    }

    public function uploadIssueAttachment(string $uploadUrl, string $contents, string $contentType): array
    {
        $parts = parse_url($uploadUrl);
        if (($parts['scheme'] ?? '') !== 'https' || mb_strtolower((string) ($parts['host'] ?? '')) !== 'api.allegro.pl') {
            throw new \RuntimeException('Allegro API returned an invalid attachment upload URL.');
        }
        if ($contents === '') {
            throw new \RuntimeException('Issue attachment file is empty.');
        }

        $token = $this->tokenManager->getValidAccessToken();
        $headers = [
            'Authorization: Bearer ' . $token,
            'Accept: ' . self::ACCEPT_BETA,
            'Content-Type: ' . $contentType,
            'User-Agent: PrestaShop-AllegroCustomerSupport/0.1',
        ];
        $ch = curl_init($uploadUrl);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'PUT');
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, self::CONNECT_TIMEOUT);
        curl_setopt($ch, CURLOPT_TIMEOUT, self::REQUEST_TIMEOUT);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $contents);

        $raw = curl_exec($ch);
        $status = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        if ($raw === false) {
            $error = curl_error($ch);
            curl_close($ch);
            throw new \RuntimeException('cURL error: ' . $error);
        }
        curl_close($ch);

        if ($status >= 400) {
            throw new \RuntimeException('Allegro API attachment upload error (' . $status . '): ' . $raw);
        }

        $decoded = json_decode($raw, true);

        return is_array($decoded) ? $decoded : [];
    }

    public function sendMessage(string $recipientLogin, string $text, ?string $orderId = null, array $attachments = []): array
    {
        $orderId = $this->normalizeOptionalString($orderId);
        $payload = [
            'recipient' => [
                'login' => $recipientLogin,
            ],
            'text' => $text,
            'attachments' => $attachments,
        ];

        if ($orderId !== '') {
            $payload['order'] = [
                'id' => $orderId,
            ];
        }

        return $this->request('POST', '/messaging/messages', $payload);
    }

    public function sendMessageToThread(string $threadId, string $text, array $attachments = []): array
    {
        return $this->request('POST', '/messaging/threads/' . rawurlencode($threadId) . '/messages', [
            'text' => $text,
            'attachments' => $attachments,
        ]);
    }

    private function normalizeOptionalString(?string $value): string
    {
        $value = trim((string) $value);
        if ($value === '' || mb_strtolower($value) === 'null') {
            return '';
        }

        return $value;
    }

    public function markThreadRead(string $threadId): array
    {
        return $this->request('PUT', '/messaging/threads/' . rawurlencode($threadId) . '/read', [
            'read' => true,
        ]);
    }

    public function getAuthorizationUrl(): string
    {
        return '';
    }

    public function request(string $method, string $path, ?array $payload = null, ?string $accept = null, ?string $contentType = null): array
    {
        $token = $this->tokenManager->getValidAccessToken();
        $url = self::API_URL . $path;
        $accept = $accept ?: self::ACCEPT;
        $contentType = $contentType ?: $accept;

        $headers = [
            'Authorization: Bearer ' . $token,
            'Accept: ' . $accept,
            'Content-Type: ' . $contentType,
            'User-Agent: PrestaShop-AllegroCustomerSupport/0.1',
        ];

        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $method);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, self::CONNECT_TIMEOUT);
        curl_setopt($ch, CURLOPT_TIMEOUT, self::REQUEST_TIMEOUT);

        if ($payload !== null) {
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
        }

        $raw = curl_exec($ch);
        $status = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);

        if ($raw === false) {
            $error = curl_error($ch);
            curl_close($ch);
            throw new \RuntimeException('cURL error: ' . $error);
        }

        curl_close($ch);

        $decoded = json_decode($raw, true);
        if ($status >= 400) {
            if ($status === 403) {
                throw new \RuntimeException('Allegro API access denied for ' . $method . ' ' . $path . '. Sprawdź uprawnienia aplikacji i ponownie połącz konto Allegro. Response: ' . $raw);
            }

            throw new \RuntimeException('Allegro API error (' . $status . '): ' . $raw);
        }

        return is_array($decoded) ? $decoded : [];
    }
}
}

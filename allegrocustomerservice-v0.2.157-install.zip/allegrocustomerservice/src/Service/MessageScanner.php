<?php
namespace PrestaShop\Module\AllegroCustomerService\Service;

if (!class_exists(__NAMESPACE__ . '\\MessageScanner', false)) {
class MessageScanner
{
    private $apiClient;
    private $ruleEngine;
    private $responder;
    private $logger;

    public function __construct(AllegroApiClient $apiClient, RuleEngine $ruleEngine, Responder $responder, Logger $logger)
    {
        $this->apiClient = $apiClient;
        $this->ruleEngine = $ruleEngine;
        $this->responder = $responder;
        $this->logger = $logger;
    }

    public function scan(int $limit): void
    {
        $threadsResponse = $this->apiClient->getThreads($limit);
        $threads = $threadsResponse['threads'] ?? $threadsResponse['items'] ?? [];

        foreach ($threads as $thread) {
            $threadId = (string) ($thread['id'] ?? '');
            if ($threadId === '') {
                continue;
            }

            $messagesResponse = $this->apiClient->getThreadMessages($threadId);
            $messages = $messagesResponse['messages'] ?? $messagesResponse['items'] ?? [];
            if (!$messages) {
                continue;
            }

            $lastMessage = $this->getNewestMessage($messages);
            if (!is_array($lastMessage)) {
                continue;
            }

            $messageId = (string) ($lastMessage['id'] ?? '');
            $text = html_entity_decode((string) ($lastMessage['text'] ?? $lastMessage['content'] ?? ''), ENT_QUOTES | ENT_HTML5, 'UTF-8');

            if (!$this->isCustomerMessage($lastMessage)) {
                $this->markThreadSeen($threadId, $messageId);
                continue;
            }

            if ($this->isAlreadyProcessed($threadId, $messageId)) {
                continue;
            }

            $rule = $this->ruleEngine->findMatchingRule($text);
            if (!$rule) {
                $this->logger->log('no_match', $threadId, $messageId, '', ['text' => $text], ['reason' => 'No rule matched'], true);
                $this->markThreadSeen($threadId, $messageId);
                continue;
            }

            if ((int) $rule['only_first_message'] && $this->hasAlreadyReplied($threadId)) {
                $this->logger->log('first_message_skip', $threadId, $messageId, (string) $rule['name'], ['text' => $text], ['reason' => 'Thread already received an auto reply'], true);
                $this->markThreadSeen($threadId, $messageId);
                continue;
            }

            if (!$this->passesCooldown($threadId, (int) $rule['cooldown_minutes'])) {
                $this->logger->log('cooldown_skip', $threadId, $messageId, (string) $rule['name'], ['text' => $text], ['reason' => 'Cooldown active'], true);
                $this->markThreadSeen($threadId, $messageId);
                continue;
            }

            try {
                $this->responder->respond($threadId, $messageId, $text, $rule, $this->buildResponseContext($thread, $lastMessage));
                $this->markThreadSeen($threadId, $messageId, true);
                $this->markThreadRead($threadId);
            } catch (\Throwable $e) {
                $this->logger->log('reply_failed', $threadId, $messageId, (string) $rule['name'], ['text' => $text], ['error' => $e->getMessage()], false);
            }
        }
    }

    private function getNewestMessage(array $messages): ?array
    {
        $newest = null;
        $newestTime = 0;

        foreach ($messages as $message) {
            if (!is_array($message)) {
                continue;
            }

            $createdAt = (string) ($message['createdAt'] ?? $message['created_at'] ?? '');
            $createdTime = $createdAt !== '' ? strtotime($createdAt) : 0;
            if ($newest === null || $createdTime >= $newestTime) {
                $newest = $message;
                $newestTime = $createdTime;
            }
        }

        return $newest;
    }

    private function isCustomerMessage(array $message): bool
    {
        if (isset($message['author']['isInterlocutor'])) {
            return (bool) $message['author']['isInterlocutor'];
        }

        $author = mb_strtolower((string) ($message['author']['login'] ?? $message['author']['name'] ?? ''));
        $account = \Db::getInstance()->getRow('SELECT login FROM `' . _DB_PREFIX_ . 'allegro_ar_account` ORDER BY id_account ASC');
        $login = mb_strtolower((string) ($account['login'] ?? ''));

        return $author !== '' && ($login === '' || $author !== $login);
    }

    private function buildResponseContext(array $thread, array $message): array
    {
        return [
            'recipient_login' => (string) ($thread['interlocutor']['login'] ?? $message['author']['login'] ?? ''),
            'order_id' => (string) ($message['relatesTo']['order']['id'] ?? ''),
            'offer_id' => (string) ($message['relatesTo']['offer']['id'] ?? ''),
            'message_created_at' => (string) ($message['createdAt'] ?? ''),
        ];
    }

    private function isAlreadyProcessed(string $threadId, string $messageId): bool
    {
        $row = \Db::getInstance()->getRow('SELECT id_thread, allegro_last_message_id FROM `' . _DB_PREFIX_ . 'allegro_ar_thread` WHERE allegro_thread_id = "' . pSQL($threadId) . '"');
        return is_array($row) && (string) $row['allegro_last_message_id'] === $messageId;
    }

    private function passesCooldown(string $threadId, int $cooldownMinutes): bool
    {
        $row = \Db::getInstance()->getRow('SELECT last_auto_reply_at FROM `' . _DB_PREFIX_ . 'allegro_ar_thread` WHERE allegro_thread_id = "' . pSQL($threadId) . '"');
        if (!$row || empty($row['last_auto_reply_at'])) {
            return true;
        }

        return strtotime((string) $row['last_auto_reply_at']) <= time() - ($cooldownMinutes * 60);
    }

    private function hasAlreadyReplied(string $threadId): bool
    {
        $row = \Db::getInstance()->getRow('SELECT auto_replied_count FROM `' . _DB_PREFIX_ . 'allegro_ar_thread` WHERE allegro_thread_id = "' . pSQL($threadId) . '"');
        return is_array($row) && (int) $row['auto_replied_count'] > 0;
    }

    private function markThreadSeen(string $threadId, string $messageId, bool $replied = false): void
    {
        $existing = \Db::getInstance()->getRow('SELECT * FROM `' . _DB_PREFIX_ . 'allegro_ar_thread` WHERE allegro_thread_id = "' . pSQL($threadId) . '"');
        $data = [
            'allegro_thread_id' => pSQL($threadId),
            'allegro_last_message_id' => pSQL($messageId),
            'last_seen_at' => date('Y-m-d H:i:s'),
            'date_upd' => date('Y-m-d H:i:s'),
        ];

        if ($replied) {
            $data['last_auto_reply_at'] = date('Y-m-d H:i:s');
        }

        if ($existing) {
            if ($replied) {
                $data['auto_replied_count'] = (int) $existing['auto_replied_count'] + 1;
            }
            \Db::getInstance()->update('allegro_ar_thread', $data, 'id_thread=' . (int) $existing['id_thread']);
            return;
        }

        $data['auto_replied_count'] = $replied ? 1 : 0;
        $data['status'] = 'active';
        $data['date_add'] = date('Y-m-d H:i:s');
        \Db::getInstance()->insert('allegro_ar_thread', $data);
    }

    private function markThreadRead(string $threadId): void
    {
        try {
            $this->apiClient->markThreadRead($threadId);
        } catch (\Throwable $e) {
            $this->logger->log('mark_read_failed', $threadId, '', '', [], ['error' => $e->getMessage()], false);
        }
    }
}
}

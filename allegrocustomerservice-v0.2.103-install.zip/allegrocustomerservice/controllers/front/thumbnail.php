<?php

class AllegroCustomerServiceThumbnailModuleFrontController extends ModuleFrontController
{
    public $display_header = false;
    public $display_footer = false;

    public function initContent()
    {
        parent::initContent();

        $token = trim((string) Tools::getValue('token'));
        $expected = trim((string) Configuration::get(AllegroCustomerService::CONFIG_PREFIX . 'CRON_TOKEN'));
        if ($expected === '' || !hash_equals($expected, $token)) {
            $this->respondError(403, 'Invalid token');
        }

        $offerId = trim((string) Tools::getValue('offer_id'));
        $productId = trim((string) Tools::getValue('product_id'));
        $checkoutFormId = trim((string) Tools::getValue('checkout_form_id'));
        $issueId = trim((string) Tools::getValue('issue_id'));
        $mode = trim((string) Tools::getValue('mode'));

        if ($offerId === '' && $productId === '' && $checkoutFormId === '' && $issueId === '') {
            $this->respondError(400, 'Missing identifiers');
        }

        try {
            if ($mode !== 'image' || (int) Tools::getValue('debug') === 1) {
                header('Content-Type: application/json; charset=utf-8');
                die(json_encode(
                    $this->module->debugIssueThumbnailLookup(
                        $offerId,
                        $productId,
                        $checkoutFormId,
                        $issueId,
                        (int) Tools::getValue('refresh') === 1 || (int) Tools::getValue('nocache') === 1
                    ),
                    JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE
                ));
            }

            $url = $this->module->warmIssueThumbnailCache($offerId, $productId, $checkoutFormId, $issueId);

            if ($mode === 'image') {
                if ($url === '') {
                    http_response_code(404);
                    exit;
                }

                Tools::redirectLink($url);
            }

            header('Content-Type: application/json; charset=utf-8');
            die(json_encode([
                'ok' => $url !== '',
                'url' => $url,
            ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE));
        } catch (Throwable $e) {
            $this->respondError(500, $e->getMessage());
        }
    }

    protected function respondError(int $statusCode, string $message): void
    {
        if (trim((string) Tools::getValue('mode')) === 'image') {
            http_response_code($statusCode);
            exit;
        }

        header('Content-Type: application/json; charset=utf-8');
        http_response_code($statusCode);
        die(json_encode([
            'ok' => false,
            'message' => $message,
        ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE));
    }
}

if (!class_exists('AllegroAutoresponderThumbnailModuleFrontController', false)) {
    class AllegroAutoresponderThumbnailModuleFrontController extends AllegroCustomerServiceThumbnailModuleFrontController
    {
    }
}

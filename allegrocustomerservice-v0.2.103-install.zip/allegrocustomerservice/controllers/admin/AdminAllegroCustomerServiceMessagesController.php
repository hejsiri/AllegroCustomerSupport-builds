<?php

class AdminAllegroCustomerServiceMessagesController extends ModuleAdminController
{
    public function __construct()
    {
        $this->bootstrap = true;
        parent::__construct();
    }

    public function initPageHeaderToolbar()
    {
        $params = [
            'aar_refresh' => 1,
            '_refresh' => time(),
        ];

        $threadId = trim((string) Tools::getValue('thread_id'));
        if ($threadId !== '') {
            $params['thread_id'] = $threadId;
        }

        $this->page_header_toolbar_btn['refresh_allegro_messages'] = [
            'href' => method_exists($this->module, 'getAdminLinkFor')
                ? $this->module->getAdminLinkFor('AdminAllegroCustomerServiceMessages', $params)
                : $this->context->link->getAdminLink('AdminAllegroCustomerServiceMessages', true, [], $params),
            'desc' => $this->trans('Odśwież', [], 'Modules.Allegrocustomerservice.Admin'),
            'icon' => 'process-icon-refresh',
        ];

        parent::initPageHeaderToolbar();
    }

    public function initContent()
    {
        if (!headers_sent()) {
            header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
            header('Pragma: no-cache');
            header('Expires: 0');
        }

        parent::initContent();

        $this->content .= $this->module->getMessagesContent();
        $this->context->smarty->assign('content', $this->content);
    }
}

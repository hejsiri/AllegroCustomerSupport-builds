<?php

class AdminAllegroCustomerServiceController extends ModuleAdminController
{
    public function init()
    {
        parent::init();

        $url = method_exists($this->module, 'getAdminLinkFor')
            ? $this->module->getAdminLinkFor('AdminAllegroCustomerServiceMessages')
            : $this->context->link->getAdminLink('AdminAllegroCustomerServiceMessages');

        Tools::redirectAdmin($url);
    }
}

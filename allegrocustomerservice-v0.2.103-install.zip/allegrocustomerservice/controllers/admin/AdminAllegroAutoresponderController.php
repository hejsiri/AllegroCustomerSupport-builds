<?php

require_once __DIR__ . '/AdminAllegroCustomerServiceController.php';

if (!class_exists('AdminAllegroAutoresponderController', false)) {
    class AdminAllegroAutoresponderController extends AdminAllegroCustomerServiceController
    {
    }
}

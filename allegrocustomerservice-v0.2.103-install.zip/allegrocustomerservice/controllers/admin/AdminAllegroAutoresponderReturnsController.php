<?php

require_once __DIR__ . '/AdminAllegroCustomerServiceReturnsController.php';

if (!class_exists('AdminAllegroAutoresponderReturnsController', false)) {
    class AdminAllegroAutoresponderReturnsController extends AdminAllegroCustomerServiceReturnsController
    {
    }
}

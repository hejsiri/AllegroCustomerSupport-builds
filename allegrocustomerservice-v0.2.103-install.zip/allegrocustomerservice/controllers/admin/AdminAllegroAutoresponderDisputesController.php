<?php

require_once __DIR__ . '/AdminAllegroCustomerServiceDisputesController.php';

if (!class_exists('AdminAllegroAutoresponderDisputesController', false)) {
    class AdminAllegroAutoresponderDisputesController extends AdminAllegroCustomerServiceDisputesController
    {
    }
}

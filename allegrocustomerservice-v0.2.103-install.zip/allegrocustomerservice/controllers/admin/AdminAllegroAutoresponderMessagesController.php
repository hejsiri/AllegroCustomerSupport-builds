<?php

require_once __DIR__ . '/AdminAllegroCustomerServiceMessagesController.php';

if (!class_exists('AdminAllegroAutoresponderMessagesController', false)) {
    class AdminAllegroAutoresponderMessagesController extends AdminAllegroCustomerServiceMessagesController
    {
    }
}

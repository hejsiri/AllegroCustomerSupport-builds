<?php

require_once __DIR__ . '/AdminAllegroCustomerServiceSettingsController.php';

if (!class_exists('AdminAllegroAutoresponderSettingsController', false)) {
    class AdminAllegroAutoresponderSettingsController extends AdminAllegroCustomerServiceSettingsController
    {
    }
}

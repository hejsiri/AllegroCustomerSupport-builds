<?php

require_once __DIR__ . '/AdminAllegroCustomerServiceComplaintsController.php';

if (!class_exists('AdminAllegroAutoresponderComplaintsController', false)) {
    class AdminAllegroAutoresponderComplaintsController extends AdminAllegroCustomerServiceComplaintsController
    {
    }
}

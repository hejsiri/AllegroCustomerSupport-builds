<?php

class AllegroCustomerServiceUpdater
{
    private const CONFIG_FILE = 'distribution.php';
    private const PUBLIC_KEY_FILE = 'keys/update_public.pem';
    private const RUNTIME_VERSION_CONFIG = 'AAR_RUNTIME_VERSION';
    public const CONFIG_UPDATE_CHANNEL = 'AAR_UPDATE_CHANNEL';
    public const UPDATE_CHANNEL_PUBLIC = 'public';
    public const UPDATE_CHANNEL_BETA = 'beta';

    private $modulePath;
    private $module;
    private $cachedStatus = null;

    public function __construct(string $modulePath, Module $module)
    {
        $this->modulePath = rtrim($modulePath, '/') . '/';
        $this->module = $module;
    }

    public function isConfigured(): bool
    {
        return $this->resolveManifestUrl($this->loadConfig()) !== '';
    }

    public function checkForUpdates(?string $channelOverride = null): array
    {
        $channelOverride = $channelOverride !== null ? trim($channelOverride) : null;
        if ($channelOverride !== null && !in_array($channelOverride, self::getAvailableChannels(), true)) {
            throw new InvalidArgumentException('Nieprawidłowy kanał aktualizacji.');
        }

        if ($channelOverride === null && $this->cachedStatus !== null) {
            return $this->cachedStatus;
        }

        $config = $this->loadConfig();
        $manifestUrl = $this->resolveManifestUrl($config, $channelOverride);
        $currentVersion = $this->resolveCurrentVersion();
        if ($manifestUrl === '') {
            return [
                'configured' => false,
                'available' => false,
                'current_version' => $currentVersion,
            ];
        }

        $manifest = $this->fetchManifestWithFallback($config, $channelOverride, $manifestUrl);
        if (!$this->isValidManifestShape($manifest) || !$this->verifyManifest($manifest)) {
            throw new RuntimeException('Nie udało się sprawdzić aktualizacji: manifest ma nieprawidłowy format albo podpis.');
        }

        $channel = $channelOverride ?? $this->getConfiguredChannel();
        $apiManifestUrl = $this->resolveGitHubApiManifestUrl($config, $channelOverride);
        if ($apiManifestUrl !== '') {
            try {
                $apiManifest = $this->fetchManifestFromUrl($apiManifestUrl);
                if (
                    $this->isValidManifestShape($apiManifest)
                    && $this->verifyManifest($apiManifest)
                    && version_compare((string) $apiManifest['version'], (string) $manifest['version'], '>')
                ) {
                    $manifest = $apiManifest;
                }
            } catch (Throwable $e) {
                // GitHub API fallback is best-effort; the signed raw manifest remains authoritative.
            }
        }

        $status = [
            'configured' => true,
            'available' => version_compare((string) $manifest['version'], $currentVersion, '>'),
            'channel' => $channel,
            'current_version' => $currentVersion,
            'version' => (string) $manifest['version'],
            'url' => (string) $manifest['url'],
            'sha256' => strtolower((string) $manifest['sha256']),
            'signature' => (string) $manifest['signature'],
            'published_at' => (string) ($manifest['published_at'] ?? ''),
            'notes' => (string) ($manifest['notes'] ?? ''),
        ];

        if ($channelOverride === null) {
            $this->cachedStatus = $status;
        }

        return $status;
    }

    public function getChangelogForUpdate(?string $channelOverride = null): array
    {
        $channelOverride = $channelOverride !== null ? trim($channelOverride) : null;
        if ($channelOverride !== null && !in_array($channelOverride, self::getAvailableChannels(), true)) {
            throw new InvalidArgumentException('Nieprawidłowy kanał aktualizacji.');
        }

        $status = $this->checkForUpdates($channelOverride);
        $currentVersion = (string) ($status['current_version'] ?? $this->resolveCurrentVersion());
        $targetVersion = (string) ($status['version'] ?? $currentVersion);
        $range = [
            'from_version' => $currentVersion,
            'to_version' => $targetVersion,
            'entries' => [],
        ];

        if (empty($status['configured']) || empty($status['available'])) {
            return $range;
        }

        try {
            return $this->getChangelogRange($this->loadConfig(), $currentVersion, $targetVersion);
        } catch (Throwable $e) {
            return $range;
        }
    }

    public function installAvailableUpdate(?string $channelOverride = null): array
    {
        $status = $this->checkForUpdates($channelOverride);
        if (empty($status['available'])) {
            throw new RuntimeException('Brak dostępnej aktualizacji.');
        }

        $zipContents = $this->fetchUrl((string) $status['url'], true);
        $tempBase = rtrim(sys_get_temp_dir(), '/') . '/aar_update_' . bin2hex(random_bytes(8));
        $zipPath = $tempBase . '.zip';
        $extractPath = $tempBase . '_extract';

        file_put_contents($zipPath, $zipContents);
        if (hash_file('sha256', $zipPath) !== (string) $status['sha256']) {
            @unlink($zipPath);
            throw new RuntimeException('Nie udało się zweryfikować pobranej paczki aktualizacji.');
        }

        $zip = new ZipArchive();
        if ($zip->open($zipPath) !== true) {
            @unlink($zipPath);
            throw new RuntimeException('Nie udało się otworzyć paczki aktualizacji.');
        }

        if (!is_dir($extractPath) && !mkdir($extractPath, 0775, true) && !is_dir($extractPath)) {
            $zip->close();
            @unlink($zipPath);
            throw new RuntimeException('Nie udało się przygotować katalogu tymczasowego aktualizacji.');
        }

        $zip->extractTo($extractPath);
        $zip->close();

        $sourceRoot = $this->resolveExtractedModuleRoot($extractPath);
        if ($sourceRoot === null) {
            $this->cleanupTemp($zipPath, $extractPath);
            throw new RuntimeException('Paczka aktualizacji nie zawiera katalogu modułu.');
        }

        $this->copyDirectory($sourceRoot, rtrim($this->modulePath, '/'), [
            'config.local.php',
        ]);

        if (function_exists('opcache_reset')) {
            opcache_reset();
        }
        $this->clearRuntimeCaches();

        $newVersion = (string) ($status['version'] ?? '');
        Configuration::updateValue(self::RUNTIME_VERSION_CONFIG, $newVersion);
        if ($newVersion !== '') {
            Db::getInstance()->update(
                'module',
                ['version' => pSQL($newVersion)],
                'name = \'' . pSQL($this->module->name) . '\''
            );
        }

        $this->cleanupTemp($zipPath, $extractPath);
        $this->cachedStatus = null;

        return [
            'ok' => true,
            'version' => $newVersion,
        ];
    }

    public function getConfiguredChannel(): string
    {
        $stored = trim((string) Configuration::get(self::CONFIG_UPDATE_CHANNEL));

        return in_array($stored, self::getAvailableChannels(), true)
            ? $stored
            : self::UPDATE_CHANNEL_PUBLIC;
    }

    public function saveConfiguredChannel(string $channel): void
    {
        $normalized = trim($channel);
        if (!in_array($normalized, self::getAvailableChannels(), true)) {
            throw new InvalidArgumentException('Nieprawidłowy kanał aktualizacji.');
        }

        Configuration::updateValue(self::CONFIG_UPDATE_CHANNEL, $normalized);
        $this->cachedStatus = null;
    }

    public static function getAvailableChannels(): array
    {
        return [
            self::UPDATE_CHANNEL_PUBLIC,
            self::UPDATE_CHANNEL_BETA,
        ];
    }

    private function clearRuntimeCaches(): void
    {
        try {
            if (class_exists('Tools')) {
                if (method_exists('Tools', 'clearSmartyCache')) {
                    Tools::clearSmartyCache();
                }
                if (method_exists('Tools', 'clearXMLCache')) {
                    Tools::clearXMLCache();
                }
            }
            if (class_exists('Media') && method_exists('Media', 'clearCache')) {
                Media::clearCache();
            }
            if (class_exists('Cache') && method_exists('Cache', 'clean')) {
                Cache::clean('*');
            }
        } catch (Throwable $e) {
            // Cache refresh is best-effort.
        }
    }

    private function resolveCurrentVersion(): string
    {
        $dbVersion = (string) Db::getInstance()->getValue(
            'SELECT `version` FROM `' . _DB_PREFIX_ . 'module` WHERE `name` = \'' . pSQL($this->module->name) . '\''
        );

        return $dbVersion !== '' ? $dbVersion : (string) $this->module->version;
    }

    private function loadConfig(): array
    {
        $configPath = $this->modulePath . self::CONFIG_FILE;
        if (!is_file($configPath)) {
            return [];
        }

        $config = require $configPath;

        return is_array($config) ? $config : [];
    }

    private function resolveManifestUrl(array $config, ?string $channelOverride = null): string
    {
        $channel = $channelOverride ?? $this->getConfiguredChannel();
        $manifestUrl = trim((string) ($config['manifest_url'] ?? ''));
        if ($manifestUrl !== '') {
            return $manifestUrl;
        }

        $repository = trim((string) ($config['github_repository'] ?? ''));
        if ($repository === '') {
            return '';
        }

        $branch = trim((string) ($config['github_branch'] ?? 'main'));
        $manifestPath = $this->resolveManifestPath($config, $channel);
        $owner = $this->trimRepositoryOwner($repository);
        $name = $this->trimRepositoryName($repository);
        if ($owner === '' || $name === '') {
            return '';
        }

        return sprintf(
            'https://raw.githubusercontent.com/%s/%s/%s/%s',
            rawurlencode($owner),
            rawurlencode($name),
            rawurlencode($branch !== '' ? $branch : 'main'),
            implode('/', array_map('rawurlencode', explode('/', $manifestPath)))
        );
    }

    private function resolveGitHubApiManifestUrl(array $config, ?string $channelOverride = null): string
    {
        $channel = $channelOverride ?? $this->getConfiguredChannel();
        $repository = trim((string) ($config['github_repository'] ?? ''));
        if ($repository === '') {
            return '';
        }

        $branch = trim((string) ($config['github_branch'] ?? 'main'));
        $manifestPath = $this->resolveManifestPath($config, $channel);
        $owner = $this->trimRepositoryOwner($repository);
        $name = $this->trimRepositoryName($repository);
        if ($owner === '' || $name === '') {
            return '';
        }

        return sprintf(
            'https://api.github.com/repos/%s/%s/contents/%s?ref=%s',
            rawurlencode($owner),
            rawurlencode($name),
            implode('/', array_map('rawurlencode', explode('/', $manifestPath))),
            rawurlencode($branch !== '' ? $branch : 'main')
        );
    }

    private function resolveGitHubRawUrl(array $config, string $path): string
    {
        $repository = trim((string) ($config['github_repository'] ?? ''));
        if ($repository === '') {
            return '';
        }

        $branch = trim((string) ($config['github_branch'] ?? 'main'));
        if ($branch === '') {
            $branch = 'main';
        }

        $path = ltrim(trim($path), '/');
        if ($path === '') {
            return '';
        }

        $owner = $this->trimRepositoryOwner($repository);
        $name = $this->trimRepositoryName($repository);
        if ($owner === '' || $name === '') {
            return '';
        }

        return sprintf(
            'https://raw.githubusercontent.com/%s/%s/%s/%s',
            rawurlencode($owner),
            rawurlencode($name),
            rawurlencode($branch),
            implode('/', array_map('rawurlencode', explode('/', $path)))
        );
    }

    private function resolveManifestPath(array $config, string $channel): string
    {
        $manifestPaths = $config['manifest_paths'] ?? null;
        $manifestPath = '';
        if (is_array($manifestPaths)) {
            $manifestPath = trim((string) ($manifestPaths[$channel] ?? ''));
        }
        if ($manifestPath === '') {
            $manifestPath = trim((string) ($config['manifest_path'] ?? 'latest.json'));
        }

        $manifestPath = ltrim($manifestPath, '/');

        return $manifestPath !== '' ? $manifestPath : 'latest.json';
    }

    private function trimRepositoryOwner(string $repository): string
    {
        $parts = explode('/', trim($repository), 2);

        return trim($parts[0] ?? '');
    }

    private function trimRepositoryName(string $repository): string
    {
        $parts = explode('/', trim($repository), 2);

        return trim($parts[1] ?? '');
    }

    private function getChangelogRange(array $config, string $currentVersion, string $targetVersion): array
    {
        $range = [
            'from_version' => $currentVersion,
            'to_version' => $targetVersion,
            'entries' => [],
        ];

        $changelogUrl = $this->resolveGitHubRawUrl($config, 'CHANGELOG.md');
        if ($changelogUrl === '') {
            return $range;
        }

        try {
            $raw = $this->fetchUrl($this->withCacheBuster($changelogUrl));
        } catch (Throwable $e) {
            return $range;
        }

        $range['entries'] = $this->parseChangelogRange($raw, $currentVersion, $targetVersion);
        if (empty($range['entries'])) {
            $latestEntry = $this->parseLatestChangelogEntry($raw);
            if ($latestEntry !== null) {
                $range['entries'] = [$latestEntry];
            }
        }

        return $range;
    }

    private function parseLatestChangelogEntry(string $raw): ?array
    {
        $current = null;
        $raw = $this->normalizeRawTextEncoding($raw);
        $lines = preg_split('/\R/u', $raw);

        if (!is_array($lines)) {
            return null;
        }

        foreach ($lines as $line) {
            if (preg_match('/^##\s+\[?v?([0-9]+(?:\.[0-9]+){1,3})\]?(?:\s*-\s*(.*))?$/', trim($line), $matches)) {
                if ($current !== null) {
                    break;
                }

                $current = [
                    'version' => (string) $matches[1],
                    'date' => trim((string) ($matches[2] ?? '')),
                    'items' => [],
                ];
                continue;
            }

            if ($current === null) {
                continue;
            }

            $trimmed = trim($line);
            if ($trimmed === '') {
                continue;
            }

            if (substr($trimmed, 0, 2) === '- ') {
                $current['items'][] = trim(substr($trimmed, 2));
            } elseif (!empty($current['items'])) {
                $lastIndex = count($current['items']) - 1;
                $current['items'][$lastIndex] .= ' ' . $trimmed;
            }
        }

        return $current !== null ? $this->normalizeChangelogEntry($current) : null;
    }

    private function parseChangelogRange(string $raw, string $currentVersion, string $targetVersion): array
    {
        $entries = [];
        $current = null;
        $raw = $this->normalizeRawTextEncoding($raw);
        $lines = preg_split('/\R/u', $raw);

        if (!is_array($lines)) {
            return [];
        }

        foreach ($lines as $line) {
            if (preg_match('/^##\s+\[?v?([0-9]+(?:\.[0-9]+){1,3})\]?(?:\s*-\s*(.*))?$/', trim($line), $matches)) {
                if ($current !== null) {
                    $this->appendChangelogEntryIfInRange($entries, $current, $currentVersion, $targetVersion);
                }

                $current = [
                    'version' => (string) $matches[1],
                    'date' => trim((string) ($matches[2] ?? '')),
                    'items' => [],
                ];
                continue;
            }

            if ($current === null) {
                continue;
            }

            $trimmed = trim($line);
            if ($trimmed === '') {
                continue;
            }

            if (substr($trimmed, 0, 2) === '- ') {
                $current['items'][] = trim(substr($trimmed, 2));
            } elseif (!empty($current['items'])) {
                $lastIndex = count($current['items']) - 1;
                $current['items'][$lastIndex] .= ' ' . $trimmed;
            }
        }

        if ($current !== null) {
            $this->appendChangelogEntryIfInRange($entries, $current, $currentVersion, $targetVersion);
        }

        return $entries;
    }

    private function appendChangelogEntryIfInRange(array &$entries, array $entry, string $currentVersion, string $targetVersion): void
    {
        $version = (string) ($entry['version'] ?? '');
        if (
            $version !== ''
            && version_compare($version, $currentVersion, '>')
            && version_compare($version, $targetVersion, '<=')
        ) {
            $entries[] = $this->normalizeChangelogEntry($entry);
        }
    }

    private function normalizeChangelogEntry(array $entry): array
    {
        return [
            'version' => (string) ($entry['version'] ?? ''),
            'date' => $this->normalizeTextEncoding((string) ($entry['date'] ?? '')),
            'items' => array_values(array_filter(array_map(function ($item): string {
                return $this->normalizeTextEncoding((string) $item);
            }, (array) ($entry['items'] ?? [])), static function ($item): bool {
                return trim((string) $item) !== '';
            })),
        ];
    }

    private function normalizeRawTextEncoding(string $value): string
    {
        if ($value === '') {
            return $value;
        }

        if (preg_match('//u', $value) === 1) {
            return $value;
        }

        if (function_exists('iconv')) {
            foreach (['Windows-1250', 'ISO-8859-2', 'ISO-8859-1'] as $encoding) {
                $converted = @iconv($encoding, 'UTF-8//IGNORE', $value);
                if (is_string($converted) && preg_match('//u', $converted) === 1) {
                    return $converted;
                }
            }
        }

        return preg_replace('/[^\x09\x0A\x0D\x20-\x7E]/', '', $value) ?? '';
    }

    private function normalizeTextEncoding(string $value): string
    {
        if ($value === '') {
            return $value;
        }

        if (preg_match('//u', $value) === 1) {
            return $this->repairMojibakeText($value);
        }

        if (function_exists('iconv')) {
            foreach (['Windows-1250', 'ISO-8859-2', 'ISO-8859-1'] as $encoding) {
                $converted = @iconv($encoding, 'UTF-8//IGNORE', $value);
                if (is_string($converted) && preg_match('//u', $converted) === 1) {
                    return $converted;
                }
            }
        }

        return preg_replace('/[^\x09\x0A\x0D\x20-\x7E]/', '', $value) ?? '';
    }

    private function repairMojibakeText(string $value): string
    {
        if (!function_exists('iconv') || preg_match('/(?:Ã.|Â.|Ä.|Å.|Ă.|Ĺ.|â[^\s]?|ï¿½)/u', $value) !== 1) {
            return $value;
        }

        $best = $value;
        $bestScore = $this->getMojibakeScore($value);
        $replaced = $this->repairDanglingPolishMojibakeMarkers($this->replacePolishMojibakeSequences($value));
        $replacedScore = $this->getMojibakeScore($replaced);
        if ($replacedScore < $bestScore) {
            $best = $replaced;
            $bestScore = $replacedScore;
        }

        foreach (['Windows-1250', 'ISO-8859-2', 'Windows-1252', 'ISO-8859-1'] as $encoding) {
            $converted = @iconv('UTF-8', $encoding . '//IGNORE', $value);
            if (!is_string($converted) || $converted === '' || preg_match('//u', $converted) !== 1) {
                continue;
            }

            $converted = $this->repairDanglingPolishMojibakeMarkers($this->replacePolishMojibakeSequences($converted));
            $score = $this->getMojibakeScore($converted);
            if ($score < $bestScore) {
                $best = $converted;
                $bestScore = $score;
            }
        }

        return $best;
    }

    private function replacePolishMojibakeSequences(string $value): string
    {
        $pairs = [
            ['\\u00c4\\u2026', 'ą'], ['\\u00c4\\u0085', 'ą'],
            ['\\u00c4\\u201e', 'Ą'], ['\\u00c4\\u0084', 'Ą'],
            ['\\u00c4\\u2021', 'ć'], ['\\u00c4\\u0087', 'ć'],
            ['\\u00c4\\u2020', 'Ć'], ['\\u00c4\\u0086', 'Ć'],
            ['\\u00c4\\u2122', 'ę'], ['\\u00c4\\u0099', 'ę'],
            ['\\u00c4\\u02dc', 'Ę'], ['\\u00c4\\u0098', 'Ę'],
            ['\\u00c5\\u201a', 'ł'], ['\\u0139\\u201a', 'ł'], ['\\u00c5\\u0082', 'ł'],
            ['\\u00c5\\u0081', 'Ł'], ['\\u0139\\u0081', 'Ł'],
            ['\\u00c5\\u201e', 'ń'], ['\\u0139\\u201e', 'ń'],
            ['\\u00c5\\u0192', 'Ń'], ['\\u0139\\u0083', 'Ń'],
            ['\\u00c3\\u00b3', 'ó'], ['\\u0102\\u0142', 'ó'],
            ['\\u00c3\\u201c', 'Ó'], ['\\u0102\\u201c', 'Ó'],
            ['\\u00c5\\u203a', 'ś'], ['\\u0139\\u203a', 'ś'], ['\\u00c5\\u009b', 'ś'],
            ['\\u00c5\\u0160', 'Ś'], ['\\u0139\\u0160', 'Ś'],
            ['\\u00c5\\u00ba', 'ź'], ['\\u0139\\u015f', 'ź'],
            ['\\u00c5\\u00b9', 'Ź'], ['\\u0139\\u0179', 'Ź'],
            ['\\u00c5\\u00bc', 'ż'], ['\\u0139\\u017a', 'ż'], ['\\u0139\\u013d', 'ż'],
            ['\\u00c5\\u00bb', 'Ż'], ['\\u0139\\u00bb', 'Ż'],
        ];

        foreach ($pairs as $pair) {
            $needle = json_decode('"' . $pair[0] . '"');
            if (is_string($needle) && $needle !== '') {
                $value = str_replace($needle, $pair[1], $value);
            }
        }

        return $value;
    }

    private function repairDanglingPolishMojibakeMarkers(string $value): string
    {
        // Fallback for trailing broken marker (e.g. "osobnÄ ").
        $fixed = preg_replace('/([A-Za-ząćęłńóśźżĄĆĘŁŃÓŚŹŻ])Ä(?=[\s\]\)\.,;:!?]|$)/u', '$1ą', $value);

        return is_string($fixed) ? $fixed : $value;
    }

    private function getMojibakeScore(string $value): int
    {
        preg_match_all('/(?:Ã|Â|Ä|Å|Ă|Ĺ|â€|â„|ï¿½)/u', $value, $matches);

        return count($matches[0] ?? []);
    }

    private function verifyManifest(array $manifest): bool
    {
        $publicKeyPath = $this->modulePath . self::PUBLIC_KEY_FILE;
        if (!is_file($publicKeyPath)) {
            return false;
        }

        $publicKey = (string) file_get_contents($publicKeyPath);
        $signature = base64_decode((string) $manifest['signature'], true);
        if ($signature === false) {
            return false;
        }

        return openssl_verify($this->buildSignaturePayload($manifest), $signature, $publicKey, OPENSSL_ALGO_SHA256) === 1;
    }

    private function fetchManifestFromUrl(string $url): array
    {
        $manifestRaw = $this->fetchUrl($url);
        $decoded = json_decode($manifestRaw, true);
        if (!is_array($decoded)) {
            throw new RuntimeException('Nie udało się odczytać manifestu aktualizacji.');
        }

        if (isset($decoded['content'], $decoded['encoding']) && strtolower((string) $decoded['encoding']) === 'base64') {
            $content = base64_decode(str_replace(["\r", "\n", ' '], '', (string) $decoded['content']), true);
            if (!is_string($content)) {
                throw new RuntimeException('Nie udało się odczytać manifestu aktualizacji.');
            }
            $decoded = json_decode($content, true);
            if (!is_array($decoded)) {
                throw new RuntimeException('Nie udało się odczytać manifestu aktualizacji.');
            }
        }

        return $decoded;
    }

    private function fetchManifestWithFallback(array $config, ?string $channelOverride, string $manifestUrl): array
    {
        try {
            return $this->fetchManifestFromUrl($this->withCacheBuster($manifestUrl));
        } catch (Throwable $rawError) {
            $apiManifestUrl = $this->resolveGitHubApiManifestUrl($config, $channelOverride);
            if ($apiManifestUrl !== '') {
                try {
                    return $this->fetchManifestFromUrl($apiManifestUrl);
                } catch (Throwable $apiError) {
                    throw new RuntimeException(
                        'Nie udało się sprawdzić aktualizacji. Raw: '
                        . $rawError->getMessage()
                        . ' API: '
                        . $apiError->getMessage()
                    );
                }
            }

            throw $rawError;
        }
    }

    private function isValidManifestShape(array $manifest): bool
    {
        foreach (['version', 'url', 'sha256', 'signature'] as $field) {
            if (empty($manifest[$field]) || !is_string($manifest[$field])) {
                return false;
            }
        }

        return true;
    }

    private function buildSignaturePayload(array $manifest): string
    {
        return implode("\n", [
            (string) $manifest['version'],
            (string) $manifest['url'],
            strtolower((string) $manifest['sha256']),
        ]);
    }

    private function fetchUrl(string $url, bool $binary = false): string
    {
        if (function_exists('curl_init')) {
            $ch = curl_init($url);
            curl_setopt_array($ch, [
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_FOLLOWLOCATION => true,
                CURLOPT_CONNECTTIMEOUT => 10,
                CURLOPT_TIMEOUT => 30,
                CURLOPT_USERAGENT => 'AllegroCustomerSupport/' . (string) $this->module->version,
            ]);
            $content = curl_exec($ch);
            $status = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
            $curlError = (string) curl_error($ch);
            curl_close($ch);

            if (!is_string($content) || $status >= 400 || $status === 0) {
                $message = $binary ? 'Nie udało się pobrać paczki aktualizacji.' : 'Nie udało się sprawdzić aktualizacji.';
                $details = [];
                if ($status !== 0) {
                    $details[] = 'HTTP ' . $status;
                }
                if ($curlError !== '') {
                    $details[] = $curlError;
                }
                $details[] = $url;

                throw new RuntimeException($message . ' ' . implode(' | ', $details));
            }

            return $content;
        }

        $context = stream_context_create([
            'http' => [
                'timeout' => 30,
                'follow_location' => 1,
                'user_agent' => 'AllegroCustomerSupport/' . (string) $this->module->version,
            ],
        ]);
        $content = @file_get_contents($url, false, $context);
        if (!is_string($content)) {
            throw new RuntimeException($binary ? 'Nie udało się pobrać paczki aktualizacji.' : 'Nie udało się sprawdzić aktualizacji.');
        }

        return $content;
    }

    private function withCacheBuster(string $url): string
    {
        $separator = strpos($url, '?') !== false ? '&' : '?';

        return $url . $separator . '_ts=' . rawurlencode((string) time());
    }

    private function resolveExtractedModuleRoot(string $extractPath): ?string
    {
        $directRoot = rtrim($extractPath, '/') . '/' . $this->module->name;
        if (is_dir($directRoot)) {
            return $directRoot;
        }

        $entries = array_values(array_filter(scandir($extractPath) ?: [], function ($entry) use ($extractPath) {
            return $entry !== '.' && $entry !== '..' && is_dir($extractPath . '/' . $entry);
        }));

        if (count($entries) === 1) {
            return $extractPath . '/' . $entries[0];
        }

        return null;
    }

    private function copyDirectory(string $source, string $target, array $excludedBasenames = []): void
    {
        $iterator = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($source, FilesystemIterator::SKIP_DOTS),
            RecursiveIteratorIterator::SELF_FIRST
        );

        foreach ($iterator as $item) {
            $relativePath = substr($item->getPathname(), strlen($source) + 1);
            if ($relativePath === false || $relativePath === '') {
                continue;
            }

            $basename = basename($relativePath);
            if (in_array($basename, $excludedBasenames, true)) {
                continue;
            }

            $destinationPath = $target . '/' . $relativePath;
            if ($item->isDir()) {
                if (!is_dir($destinationPath) && !mkdir($destinationPath, 0775, true) && !is_dir($destinationPath)) {
                    throw new RuntimeException('Nie udało się utworzyć katalogu aktualizacji.');
                }
                continue;
            }

            $destinationDir = dirname($destinationPath);
            if (!is_dir($destinationDir) && !mkdir($destinationDir, 0775, true) && !is_dir($destinationDir)) {
                throw new RuntimeException('Nie udało się utworzyć katalogu aktualizacji.');
            }

            if (!copy($item->getPathname(), $destinationPath)) {
                throw new RuntimeException('Nie udało się skopiować pliku aktualizacji.');
            }
        }
    }

    private function cleanupTemp(string $zipPath, string $extractPath): void
    {
        @unlink($zipPath);

        if (!is_dir($extractPath)) {
            return;
        }

        $iterator = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($extractPath, FilesystemIterator::SKIP_DOTS),
            RecursiveIteratorIterator::CHILD_FIRST
        );

        foreach ($iterator as $item) {
            if ($item->isDir()) {
                @rmdir($item->getPathname());
            } else {
                @unlink($item->getPathname());
            }
        }

        @rmdir($extractPath);
    }
}

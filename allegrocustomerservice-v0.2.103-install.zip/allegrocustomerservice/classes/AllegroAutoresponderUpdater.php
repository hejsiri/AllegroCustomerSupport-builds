<?php

require_once __DIR__ . '/AllegroCustomerServiceUpdater.php';

if (!class_exists('AllegroAutoresponderUpdater', false)) {
    class AllegroAutoresponderUpdater extends AllegroCustomerServiceUpdater
    {
    }
}

<?php
namespace PrestaShop\Module\AllegroCustomerService\Service;

class Logger
{
    public function log(string $action, string $threadId, string $messageId, string $matchedRule, array $requestPayload, array $responsePayload, bool $success): void
    {
        \Db::getInstance()->insert('allegro_ar_log', [
            'thread_id' => pSQL($threadId),
            'message_id' => pSQL($messageId),
            'action' => pSQL($action),
            'matched_rule' => pSQL($matchedRule),
            'request_payload' => pSQL(json_encode($requestPayload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), true),
            'response_payload' => pSQL(json_encode($responsePayload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), true),
            'success' => (int) $success,
            'created_at' => date('Y-m-d H:i:s'),
        ]);
    }
}

<?php
namespace PrestaShop\Module\AllegroCustomerService\Service;

class Responder
{
    private $apiClient;
    private $logger;
    private $testMode;

    public function __construct(AllegroApiClient $apiClient, Logger $logger, bool $testMode)
    {
        $this->apiClient = $apiClient;
        $this->logger = $logger;
        $this->testMode = $testMode;
    }

    public function respond(string $threadId, string $messageId, string $incomingText, array $rule, array $context = []): void
    {
        $text = $this->renderTemplate((string) $rule['response_template'], [
            '{message}' => $incomingText,
            '{shop_name}' => (string) \Configuration::get('PS_SHOP_NAME'),
            '{buyer_login}' => (string) ($context['recipient_login'] ?? ''),
            '{order_id}' => (string) ($context['order_id'] ?? ''),
            '{offer_id}' => (string) ($context['offer_id'] ?? ''),
        ]);

        $requestPayload = [
            'incoming' => $incomingText,
            'context' => $context,
            'rule' => [
                'id' => (int) ($rule['id_rule'] ?? 0),
                'name' => (string) ($rule['name'] ?? ''),
                'template' => (string) ($rule['response_template'] ?? ''),
            ],
        ];

        if ($this->testMode) {
            $this->logger->log('test_reply', $threadId, $messageId, (string) $rule['name'], $requestPayload, [
                'mode' => 'test',
                'outgoing' => $text,
            ], true);
            return;
        }

        $response = $this->apiClient->sendMessageToThread($threadId, $text);
        $this->logger->log('reply_sent', $threadId, $messageId, (string) $rule['name'], $requestPayload, [
            'mode' => 'sent',
            'outgoing' => $text,
            'allegro_response' => $response,
        ], true);
    }

    private function renderTemplate(string $template, array $replacements): string
    {
        return strtr($template, $replacements);
    }
}

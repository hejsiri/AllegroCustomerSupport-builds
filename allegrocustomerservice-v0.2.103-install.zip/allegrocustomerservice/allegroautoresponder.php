<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

require_once __DIR__ . '/allegrocustomerservice.php';

if (!class_exists('AllegroAutoresponder', false)) {
    class AllegroAutoresponder extends AllegroCustomerService
    {
        protected function getTechnicalModuleName(): string
        {
            return 'allegroautoresponder';
        }
    }
}

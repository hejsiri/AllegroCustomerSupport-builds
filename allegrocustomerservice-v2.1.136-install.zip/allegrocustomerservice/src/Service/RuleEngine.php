<?php
/**
 * Copyright (c) 2026 Prestino. All rights reserved.
 *
 * This file is proprietary software. Copying, modification, distribution,
 * or use outside the terms of a valid Prestino license is prohibited.
 *
 * @author Prestino
 * @copyright 2026 Prestino
 * @license Proprietary
 */

namespace PrestaShop\Module\AllegroCustomerService\Service;

if (!defined('_PS_VERSION_')) {
    exit;
}

if (!class_exists(__NAMESPACE__ . '\\RuleEngine', false)) {
    class RuleEngine
    {
        public function findMatchingRule(string $messageText): ?array
        {
            $rules = \Db::getInstance()->executeS('SELECT * FROM `' . _DB_PREFIX_ . 'allegro_ar_rule` WHERE enabled = 1 ORDER BY priority ASC, id_rule ASC');
            $normalized = mb_strtolower(trim($messageText));

            foreach ($rules as $rule) {
                $matchType = (string) $rule['match_type'];
                $keywords = trim((string) $rule['keywords']);

                if ($matchType === 'contains' && $this->matchesContains($normalized, $keywords)) {
                    return $rule;
                }

                if ($matchType === 'exact' && $normalized === mb_strtolower($keywords)) {
                    return $rule;
                }

                if ($matchType === 'regex' && @preg_match('~' . $keywords . '~iu', $messageText)) {
                    return $rule;
                }
            }

            return null;
        }

        private function matchesContains(string $normalized, string $keywords): bool
        {
            $parts = preg_split('/[,\n\r]+/', $keywords);
            foreach ($parts as $part) {
                $part = trim(mb_strtolower($part));
                if ($part !== '' && mb_strpos($normalized, $part) !== false) {
                    return true;
                }
            }

            return false;
        }
    }
}

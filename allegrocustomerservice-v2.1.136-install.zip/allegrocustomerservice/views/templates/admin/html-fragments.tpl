{*
 * Copyright (c) 2026 Prestino. All rights reserved.
 *
 * This file is proprietary software. Copying, modification, distribution,
 * or use outside the terms of a valid Prestino license is prohibited.
 *
 * @author Prestino
 * @copyright 2026 Prestino
 * @license Proprietary
 *}
@@AAR_FRAGMENT:71f2979a09205307aa84@@{literal}<!-- AAR_LICENSE_STATUS_PANEL -->{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:98f96509656c0ad763a7@@{literal}<!-- AAR_UPDATE_PANEL -->{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:bd53d5e40752c33b7ee0@@{literal}<!-- AAR_SETTINGS_FORM -->{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:5ebdedc494efc273c4cd@@{literal}<!-- AAR_QUICK_REPLIES_PANEL -->{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:9e699b951b181018037e@@{literal}<!-- AAR_RULE_FORM -->{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:8ef41bf45ff4384053c9@@{literal}<!-- AAR_RULES_TABLE -->{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:6eac8c921802f22d4506@@{literal}<!-- AAR_LOGS_TABLE -->{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:389bc1a93a22a94284fa@@{literal}<div class="panel">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:aac32651b10f567c461b@@{literal}</div>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:5d67e76860c75451f93a@@{literal}<div class="alert alert-danger"><strong>Wymagana licencja:</strong> {/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:b095e92ffb26d02dae5f@@{literal}<div class="alert alert-danger aar-prestino-license-alert"><strong>Wymagana licencja:</strong> {/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:904931f3134670ead633@@{literal}<div class="alert alert-warning aar-prestino-license-alert"><strong>Demo aktywne.</strong> {/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:1bd22b865dbe5cfd8406@@{literal}<div class="alert alert-info aar-prestino-license-alert"><strong>Pełna wersja modułu aktywna.</strong> {/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:f299a9f61886f6ca091d@@{literal}<script>
            (function () {
                var config = {/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:9b3d9fae41578f12f055@@{literal};

                function textOf(element) {
                    return (element && element.textContent ? element.textContent : "").replace(/\s+/g, " ").trim();
                }

                function hasController(link, controller) {
                    var href = String(link && link.getAttribute("href") || "");
                    return href.indexOf("controller=" + controller) !== -1
                        || href.indexOf("_legacy_controller=" + controller) !== -1
                        || href.indexOf(controller) !== -1;
                }

                function hasAnyLabel(link, labels) {
                    var label = textOf(link);
                    for (var i = 0; i < labels.length; i++) {
                        if (label.indexOf(labels[i]) !== -1) {
                            return true;
                        }
                    }
                    return false;
                }

                function closestMenuItem(element) {
                    return element && element.closest
                        ? element.closest("li, .link-levelone, .link-leveltwo, .menu-item, .nav-item, [data-submenu]")
                        : null;
                }

                function renameMenuLabel(link) {
                    if (!link) {
                        return;
                    }

                    var oldLabel = textOf(link);
                    if (!config.renameLabels[oldLabel]) {
                        return;
                    }

                    var replacement = config.renameLabels[oldLabel];
                    var walker = document.createTreeWalker(link, NodeFilter.SHOW_TEXT, null);
                    var node;
                    while ((node = walker.nextNode())) {
                        if (node.nodeValue && node.nodeValue.indexOf(oldLabel) !== -1) {
                            node.nodeValue = node.nodeValue.replace(oldLabel, replacement);
                            return;
                        }
                    }
                }

                function findMenuLink(controller, labels) {
                    var tab = document.querySelector("[data-submenu='" + controller + "']");
                    if (tab) {
                        var tabLink = tab.tagName && tab.tagName.toLowerCase() === "a" ? tab : tab.querySelector("a");
                        if (tabLink) {
                            return tabLink;
                        }
                    }

                    var links = Array.prototype.slice.call(document.querySelectorAll(
                        "#nav-sidebar a, #main-div a, .nav-bar a, .sidebar a, nav a, a"
                    ));
                    for (var i = 0; i < links.length; i++) {
                        if (hasController(links[i], controller) || hasAnyLabel(links[i], labels || [])) {
                            return links[i];
                        }
                    }

                    return null;
                }

                function activateMenu() {
                    var parentLink = findMenuLink(config.parentController, config.parentLabels);
                    var currentLabels = config.labelsByController[config.currentController] || [];
                    var currentLink = findMenuLink(config.currentController, currentLabels);
                    var complaintsLink = findMenuLink("AdminAllegroCustomerServiceComplaints", config.labelsByController.AdminAllegroCustomerServiceComplaints || []);
                    renameMenuLabel(complaintsLink);

                    if (!parentLink && !currentLink) {
                        return false;
                    }

                    var parentItem = closestMenuItem(parentLink) || closestMenuItem(currentLink);
                    var currentItem = closestMenuItem(currentLink);

                    if (parentItem) {
                        parentItem.classList.add("active", "current", "open", "menu-open");
                        parentItem.setAttribute("aria-expanded", "true");
                        Array.prototype.slice.call(parentItem.querySelectorAll("ul, .submenu, .collapse")).forEach(function (submenu) {
                            submenu.classList.add("show", "in");
                            submenu.style.display = "";
                        });
                        Array.prototype.slice.call(parentItem.querySelectorAll("[aria-expanded]")).forEach(function (toggle) {
                            toggle.setAttribute("aria-expanded", "true");
                            toggle.classList.remove("collapsed");
                        });
                    }

                    if (currentItem) {
                        currentItem.classList.add("active", "current");
                    }
                    if (currentLink) {
                        currentLink.classList.add("active", "current");
                    }

                    return true;
                }

                function boot() {
                    if (activateMenu()) {
                        return;
                    }
                    window.setTimeout(activateMenu, 300);
                }

                if (document.readyState === "loading") {
                    document.addEventListener("DOMContentLoaded", boot);
                } else {
                    boot();
                }

                if ("MutationObserver" in window) {
                    var attempts = 0;
                    var observer = new MutationObserver(function () {
                        attempts++;
                        if (activateMenu() || attempts > 20) {
                            observer.disconnect();
                        }
                    });
                    observer.observe(document.documentElement, { childList: true, subtree: true });
                    window.setTimeout(function () { observer.disconnect(); }, 5000);
                }
            })();
        </script>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:b4dd43801b7431731b7d@@{literal}<script>
                document.addEventListener("DOMContentLoaded", function () {
                    Array.prototype.slice.call(document.querySelectorAll(".allegrocustomerservice-menu-badge-unread")).forEach(function (badge) {
                        if (badge.parentNode) {
                            badge.parentNode.removeChild(badge);
                        }
                    });
                });
            </script>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:fd88dc82c7734e348e42@@{literal}<style>
            .allegrocustomerservice-menu-badge {
                font-size: 10px;
                color: #fff;
                padding: 0 5px !important;
                margin-left: 2px !important;
                border-radius: 10px;
                background: #f54c3e;
                height: 15px;
                min-width: 5px;
                display: inline-block;
                text-align: center;
                line-height: 14px;
                vertical-align: middle;
                text-indent: 0;
            }
        </style>
        <script>
            (function () {
                var config = {/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:d34e9e0449a6508498ba@@{literal};
                var badgeClass = "allegrocustomerservice-menu-badge allegrocustomerservice-menu-badge-unread";

                function textOf(element) {
                    return (element && element.textContent ? element.textContent : "").replace(/\s+/g, " ").trim();
                }

                function linkMatches(link) {
                    if (!link) {
                        return false;
                    }

                    var href = String(link.getAttribute("href") || "");
                    if (href.indexOf(config.controller) !== -1) {
                        return true;
                    }

                    var label = textOf(link);
                    for (var i = 0; i < config.labels.length; i++) {
                        if (label.indexOf(config.labels[i]) !== -1) {
                            return true;
                        }
                    }

                    return false;
                }

                function getMenuAnchor(container) {
                    if (!container) {
                        return null;
                    }

                    if (container.tagName && container.tagName.toLowerCase() === "a") {
                        return container;
                    }

                    return container.querySelector("a");
                }

                function findMenuLink() {
                    var tab = document.querySelector("[data-submenu='" + config.controller + "']");
                    var tabLink = getMenuAnchor(tab);
                    if (linkMatches(tabLink)) {
                        return tabLink;
                    }

                    var candidates = Array.prototype.slice.call(document.querySelectorAll(
                        "a[href*='controller=" + config.controller + "']," +
                        "a[href*='_legacy_controller=" + config.controller + "']," +
                        "a[href*='" + config.controller + "']," +
                        "#nav-sidebar a,.nav-bar a,.sidebar a,nav a"
                    ));

                    for (var i = 0; i < candidates.length; i++) {
                        if (linkMatches(candidates[i])) {
                            return candidates[i];
                        }
                    }

                    return null;
                }

                function attachBadge() {
                    var link = findMenuLink();
                    if (!link) {
                        return false;
                    }

                    Array.prototype.slice.call(document.querySelectorAll(".allegrocustomerservice-menu-badge-unread")).forEach(function (badge) {
                        if (badge.parentNode) {
                            badge.parentNode.removeChild(badge);
                        }
                    });

                    var badge = document.createElement("span");
                    badge.className = badgeClass;
                    badge.textContent = String(config.count);
                    badge.setAttribute("aria-label", config.label + ": " + String(config.count));
                    link.appendChild(badge);

                    return true;
                }

                if (!attachBadge()) {
                    document.addEventListener("DOMContentLoaded", function () {
                        if (attachBadge()) {
                            return;
                        }
                        window.setTimeout(attachBadge, 300);
                    });
                }

                if ("MutationObserver" in window) {
                    var attempts = 0;
                    var observer = new MutationObserver(function () {
                        attempts++;
                        if (attachBadge() || attempts > 20) {
                            observer.disconnect();
                        }
                    });
                    observer.observe(document.documentElement, { childList: true, subtree: true });
                    window.setTimeout(function () { observer.disconnect(); }, 5000);
                }
            })();
        </script>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:f6b5a70e04b023f390d4@@{literal}<script>
                document.addEventListener("DOMContentLoaded", function () {
                    Array.prototype.slice.call(document.querySelectorAll(".allegrocustomerservice-menu-badge-returns")).forEach(function (badge) {
                        if (badge.parentNode) {
                            badge.parentNode.removeChild(badge);
                        }
                    });
                });
            </script>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:579fe501e9a2bd5d3921@@{literal};
                var badgeClass = "allegrocustomerservice-menu-badge allegrocustomerservice-menu-badge-returns";

                function textOf(element) {
                    return (element && element.textContent ? element.textContent : "").replace(/\s+/g, " ").trim();
                }

                function linkMatches(link) {
                    if (!link) {
                        return false;
                    }

                    var href = String(link.getAttribute("href") || "");
                    if (href.indexOf(config.controller) !== -1) {
                        return true;
                    }

                    var label = textOf(link);
                    for (var i = 0; i < config.labels.length; i++) {
                        if (label.indexOf(config.labels[i]) !== -1) {
                            return true;
                        }
                    }

                    return false;
                }

                function getMenuAnchor(container) {
                    if (!container) {
                        return null;
                    }

                    if (container.tagName && container.tagName.toLowerCase() === "a") {
                        return container;
                    }

                    return container.querySelector("a");
                }

                function findMenuLink() {
                    var tab = document.querySelector("[data-submenu='" + config.controller + "']");
                    var tabLink = getMenuAnchor(tab);
                    if (linkMatches(tabLink)) {
                        return tabLink;
                    }

                    var candidates = Array.prototype.slice.call(document.querySelectorAll(
                        "a[href*='controller=" + config.controller + "']," +
                        "a[href*='_legacy_controller=" + config.controller + "']," +
                        "a[href*='" + config.controller + "']," +
                        "#nav-sidebar a,.nav-bar a,.sidebar a,nav a"
                    ));

                    for (var i = 0; i < candidates.length; i++) {
                        if (linkMatches(candidates[i])) {
                            return candidates[i];
                        }
                    }

                    return null;
                }

                function attachBadge() {
                    var link = findMenuLink();
                    if (!link) {
                        return false;
                    }

                    Array.prototype.slice.call(document.querySelectorAll(".allegrocustomerservice-menu-badge-returns")).forEach(function (badge) {
                        if (badge.parentNode) {
                            badge.parentNode.removeChild(badge);
                        }
                    });

                    var badge = document.createElement("span");
                    badge.className = badgeClass;
                    badge.textContent = String(config.count);
                    badge.setAttribute("aria-label", config.label + ": " + String(config.count));
                    link.appendChild(badge);

                    return true;
                }

                if (!attachBadge()) {
                    document.addEventListener("DOMContentLoaded", function () {
                        if (attachBadge()) {
                            return;
                        }
                        window.setTimeout(attachBadge, 300);
                    });
                }

                if ("MutationObserver" in window) {
                    var attempts = 0;
                    var observer = new MutationObserver(function () {
                        attempts++;
                        if (attachBadge() || attempts > 20) {
                            observer.disconnect();
                        }
                    });
                    observer.observe(document.documentElement, { childList: true, subtree: true });
                    window.setTimeout(function () { observer.disconnect(); }, 5000);
                }
            })();
        </script>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:cefba4c147d4c19fa680@@{literal}<div class="panel"><h3>Obsługa Klienta Allegro</h3><p>Najpierw połącz konto Allegro, potem w tym miejscu pojawi się lista wątków.</p></div>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:75556412c0c0d3fe1a06@@{literal}<div class="panel"><h3>Obsługa Klienta Allegro</h3><div class="alert alert-danger">Nie udało się pobrać wiadomości z Allegro: {/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:862310c6baa51befea35@@{literal}</div></div>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:cacaf39098ac06f3a603@@{literal}<div class="panel"><h3>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:632dd6d19630c2ee78ac@@{literal}</h3><p>Najpierw połącz konto Allegro, potem w tym miejscu pojawi się lista zgłoszeń.</p></div>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:5c401c3c836fbed23a55@@{literal}</h3><p>Nie znaleziono zgłoszeń dla wybranego filtra.</p></div>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:d2c9d220fb09364e73a4@@{literal}</h3><div class="alert alert-danger">Nie udało się pobrać danych z Allegro: {/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:3ead645154982c81131e@@{literal}<div class="panel"><h3>Zwroty towarów</h3><p>Najpierw połącz konto Allegro, potem w tym miejscu pojawi się lista zwrotów.</p></div>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:87feb3e4e2d9fb130d87@@{literal}<div class="panel"><h3>Zwroty towarów</h3><p>Nie znaleziono zwrotów dla wybranych filtrów.</p></div>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:906267be76758ee514b4@@{literal}<div class="panel"><h3>Zwroty towarów</h3><div class="alert alert-danger">Nie udało się pobrać zwrotów z Allegro: {/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:3b5b56a39639fa6a2966@@{literal}<div class="panel aar-inbox-panel aar-messages-panel">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:80d19d6c9845e63312b1@@{literal}<div class="row aar-inbox">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:903e00c1a53060879d98@@{literal}<div class="col-lg-4 aar-inbox-col aar-inbox-col-list">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:9c1f3d8d4941f3c9b071@@{literal}<div class="list-group aar-thread-list">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:aec0e868c14c32209a48@@{literal}<div class="aar-message-filter-empty">Nie znaleziono wiadomości dla wybranych filtrów.</div>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:3da56e3ab29e7b919153@@{literal}<a class="list-group-item aar-thread-item{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:a2d2fcd252f1e6a9e659@@{literal}<div class="aar-message-thread-row">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:c0f94042584e5e06a73c@@{literal}<span class="aar-user-avatar">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:6f722b80156fb8ac7f43@@{literal}<img src="{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:e8841256670daa42a437@@{literal}<span class="aar-user-avatar-fallback"{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:411fdb22d8d9298e5d32@@{literal}</span>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:3e821330d4ea17f4441e@@{literal}<span class="aar-message-thread-content">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:09a4488603d56538c20e@@{literal}<div class="aar-thread-head">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:6bcb3a7eedceb230324f@@{literal}<strong class="aar-thread-login">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:b2f69f8100b2a95949ee@@{literal}</strong>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:5b9eea029683923affeb@@{literal}<span class="badge aar-badge">nowa</span>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:fddbd869b27cf4dae3c3@@{literal}<span class="badge aar-reply-required-badge">wymaga odpowiedzi</span>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:ef5ccf65c6838d586699@@{literal}<small class="aar-thread-date">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:3f0e243eb74ef9d8ab22@@{literal}</small>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:a125842269cef80d210e@@{literal}<div class="aar-thread-preview">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:ecd5b806462c7dfdf078@@{literal}</a>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:ad70b9e0a22f6f75cff8@@{literal}<div class="aar-load-more-wrap">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:616327b278e6aa304ebe@@{literal}<a class="btn btn-default aar-load-more" data-aar-messages-load-more href="{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:4358d93eb5f182ca1f90@@{literal}">Wczytaj więcej</a>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:76188d09923e295b39a8@@{literal}<div class="col-lg-8 aar-inbox-col aar-inbox-col-conversation">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:a8fa13476adf6e5b9252@@{literal}<div class="aar-conversation-shell">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:bed8cccb6be290d6dc7a@@{literal}<div class="aar-conversation-empty">Wybierz wątek z listy, aby zobaczyć rozmowę.</div>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:20be10fabab37f35e1da@@{literal}<div class="aar-conversation-header">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:83e45be88f9fa6c65988@@{literal}<div class="aar-conversation-title">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:a0dd9b5c80c6db31455b@@{literal}<h4><a href="{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:cbf6a5a1c16cb26c1831@@{literal} <i class="icon-external-link" aria-hidden="true"></i></a></h4>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:3fc514f9de2c6a8185a6@@{literal}<div class="aar-message-window">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:7675a37cfe5b35a169c0@@{literal}<div class="aar-conversation-empty">Brak wiadomości w tym wątku.</div>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:a2912fe0649a9644d4c9@@{literal}<div class="aar-message-row {/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:749fbd88e7bb20f2ac0a@@{literal}<div class="aar-message-bubble {/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:0e4fb2ce9d9a198ee66e@@{literal}<div class="aar-message-head"><strong>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:1c1d28f3add65937d6f1@@{literal}</strong> <small>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:b682f1d98bd2dbdf3ff4@@{literal}</small></div>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:027c433fe4bd801fc5d0@@{literal}<div class="aar-message-text">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:fa06e02186365ec4f7a9@@{literal}<div class="aar-message-offer-context">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:df4d436c5c55b795de17@@{literal}<span><small>Oferta</small><strong>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:20d9389126097e1d3cbd@@{literal}</strong></span>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:219fd589fc1d4c98603c@@{literal}<small class="aar-message-meta">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:b74c5d85cbd75cca8b08@@{literal}<form method="post" class="aar-reply-form">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:80a4d1f37288943c32ce@@{literal}<input type="hidden" name="thread_id" value="{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:0f184e39d8fef1803bb4@@{literal}<div class="form-group">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:535bb9cb52d71fb724e6@@{literal}<div class="aar-reply-compose">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:8aa80c8e7b350b1b8443@@{literal}<div class="aar-reply-input-wrap">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:169af330b464215def4e@@{literal}<textarea class="form-control" name="reply_text" rows="2" placeholder="Napisz odpowiedź do klienta..." required></textarea>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:205ab5a60c10858ba5da@@{literal}<button class="btn btn-primary aar-send-button" name="submitAarSendMessage" type="submit">Wyślij</button>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:e0c7bb7b72eeecfc0734@@{literal}</form>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:fc9fe45305b3aa327d1b@@{literal}<div class="alert alert-warning aar-issue-history-warning"><i class="icon-warning-sign" aria-hidden="true"></i> {/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:cab50334c7034cd74876@@{literal}<div class="aar-message-attachments">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:627c3ca5b6eb300e19d6@@{literal}<button type="button" class="aar-issue-attachment-image" aria-label="Podgląd załącznika {/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:94bbd51b2ac775994104@@{literal}<span class="aar-issue-attachment-image-fallback" style="display:none;"><i class="icon-picture" aria-hidden="true"></i></span>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:d8de48c79715e8f2762e@@{literal}</button>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:1f3d44626d1c23654e86@@{literal}<a class="aar-issue-attachment-file" href="{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:26e5765da6e33399f653@@{literal}<i class="icon-paperclip" aria-hidden="true"></i><span>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:99ff1f4a5980a962ed2c@@{literal}</span><i class="icon-download" aria-hidden="true"></i>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:36fa6902daae32935922@@{literal}<div class="modal fade aar-issue-attachment-preview-modal" id="aar-issue-attachment-preview-modal" tabindex="-1" role="dialog" aria-label="Podgląd zdjęcia">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:6f9e5ef8a33410af2064@@{literal}<div class="modal-dialog" role="document"><div class="modal-content">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:9d20f6214d62a8ec9896@@{literal}<button type="button" class="aar-issue-attachment-preview-close" data-dismiss="modal" aria-label="Zamknij"><span aria-hidden="true">&times;</span></button>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:c88cc0047ef45e60fdd5@@{literal}<div class="modal-body"><div class="aar-issue-attachment-preview-stage"><img src="" alt="" data-aar-issue-attachment-preview-image><a class="aar-issue-attachment-preview-download" href="#" data-aar-issue-attachment-download aria-label="Pobierz zdjęcie" title="Pobierz"><i class="icon-download" aria-hidden="true"></i></a></div></div>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:bd1770902d0bb0db962c@@{literal}</div></div></div>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:8dc8bcd6b4b7effccf44@@{literal}<div class="panel aar-inbox-panel aar-issues-panel">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:5482b524c3b0c8ec82ce@@{literal}<div class="aar-thread-body">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:e9416126fc8d7aa0f4c8@@{literal}<div class="aar-thread-media">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:66d7f4a82e158e98ae1f@@{literal}<div class="aar-thread-thumb"{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:9b0a54aa00a68e4f68dc@@{literal}<span class="aar-thread-thumb-placeholder"{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:0fc315b339d1eab21a33@@{literal}></span>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:8685167a760ac942054a@@{literal}<div class="aar-thread-thumb-meta">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:17f1151a5c5e3ec19d62@@{literal}<span class="badge aar-type-badge {/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:4a361d654e46bef5dcb9@@{literal}<div class="aar-thread-content">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:ca0274419e562106044b@@{literal}<div class="aar-thread-meta">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:8a478e1112962b7150fa@@{literal}<span class="badge aar-status-badge aar-status-badge-{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:5c8e08f3b41c236e86e0@@{literal}<a class="btn btn-default aar-load-more" href="{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:631d94406b733cdfa687@@{literal}<div class="aar-conversation-empty">Wybierz zgłoszenie z listy, aby zobaczyć rozmowę.</div>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:dfd587e883b672c87064@@{literal}</a></h4>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:573000717bf3cb25938a@@{literal}<h4>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:167241b96f2b077c0273@@{literal}</h4>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:53af437bbd88794d1959@@{literal}<small>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:5dfcd99fa233d2dd8fc0@@{literal}<div class="aar-conversation-empty">Brak wiadomości w tym zgłoszeniu.</div>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:b4b297088fabe576640a@@{literal}<small class="aar-message-meta">Typ: {/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:3c6bfa2df1e24221dfc1@@{literal}<input type="hidden" name="issue_id" value="{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:6882e25eb85cc4f8c54b@@{literal}<textarea class="form-control" name="reply_text" rows="2" placeholder="Napisz odpowiedź..." required></textarea>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:47a019fe750e543df314@@{literal}<button class="btn btn-primary aar-send-button" name="submitAarSendIssueMessage" type="submit">Wyślij</button>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:fec4c8b7c880e0b7bdec@@{literal}<div class="panel aar-inbox-panel aar-issues-panel aar-returns-panel">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:09adf6e802ab0cd30639@@{literal}<div class="aar-thread-thumb">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:83212e4aa8c1c9f0effd@@{literal}<span class="badge aar-type-badge is-neutral">Zwrot</span>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:ead35bb591e85c729e5c@@{literal}<div class="aar-conversation-empty">Wybierz zwrot z listy, aby zobaczyć szczegóły.</div>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:d0215eb3aa823aa1ff8c@@{literal}<div class="aar-thread-deadline {/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:394adc88e1c1778e7f6f@@{literal}<div class="aar-thread-deadline-row">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:346c9f216796b8c7e533@@{literal}<span class="aar-thread-deadline-label">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:b909d90bf0d833f6168e@@{literal}<strong class="aar-thread-deadline-date">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:f0376987d932f481e68f@@{literal}<div class="aar-thread-deadline-subline">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:b068c232d929bc09d011@@{literal}<div class="aar-claim-summary">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:2e907e3455a3643241c5@@{literal}<div class="aar-claim-deadline {/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:744f57556647a0e5899c@@{literal}<div class="aar-claim-deadline-head">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:9e4527fb137f0b371f78@@{literal}<div>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:a90204ddb3c9cc647d69@@{literal}<strong>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:a19fa9bb29b6423d2150@@{literal}<div class="aar-claim-deadline-sub">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:07f64419ae27959e82d8@@{literal}<div class="aar-claim-deadline-date">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:01b872817d1447242f45@@{literal}<span>Termin decyzji</span>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:008754a00056d50396a3@@{literal}<div class="aar-claim-grid">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:2d288d251aee41a717dc@@{literal}<section class="aar-claim-workflow">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:ab4c1e74156977dd6195@@{literal}<h4>Przebieg reklamacji</h4>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:8c60d89c6de49fdc2eff@@{literal}<div class="aar-claim-workflow-step">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:083305ad31663b5a40a8@@{literal}<div class="aar-claim-workflow-step-head"><strong>Krok 1. Odesłanie reklamowanego towaru</strong>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:b55f706c7ef1117edcb6@@{literal}<span>Termin: {/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:63322d5586e9b8f56f17@@{literal}<div class="aar-claim-workflow-return-state is-required">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:7508f1d0f9024aa4d8da@@{literal}<span class="aar-claim-workflow-return-icon" aria-hidden="true"><i class="icon-check"></i></span>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:c9f973f8841179123cfb@@{literal}<span class="aar-claim-workflow-return-copy"><strong>Odesłanie towaru jest wymagane</strong><span>Kupujący powinien odesłać lub udostępnić reklamowany towar do rozpatrzenia reklamacji.</span></span>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:1680888e1cf1f0f0d8d0@@{literal}<div class="aar-claim-workflow-return-state is-not-required">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:86a9888b584f4bbe0a17@@{literal}<span class="aar-claim-workflow-return-copy"><strong>Odesłanie towaru nie jest wymagane</strong><span>Reklamacja zostanie rozpatrzona na podstawie informacji przekazanych przez kupującego.</span></span>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:8d3cd24950086c63b466@@{literal}<p>Określ, czy kupujący ma odesłać lub udostępnić towar do rozpatrzenia reklamacji.</p>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:3970af0e6180c34a4055@@{literal}<div class="aar-claim-workflow-actions">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:ef06db0162fe568a2efb@@{literal}<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:aaa46baa403508912e5f@@{literal}">Bez odesłania</button>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:20f7c45e7da7afb21969@@{literal}">Zaplanuj odesłanie</button>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:69d29400075d2120cd6a@@{literal}<p class="text-muted">Decyzja o odesłaniu nie jest już dostępna dla zakończonej reklamacji.</p>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:861e13aeb504efc92afe@@{literal}<div class="aar-claim-workflow-step-head"><strong>Krok 2. Decyzja reklamacyjna</strong>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:a1d9ff4d0fdbfcc9b9c2@@{literal}<p>Uznaj reklamację albo odrzuć ją, wybierając formalny powód i przekazując uzasadnienie kupującemu.</p>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:37f7eb0e951bd522ebcc@@{literal}<button type="button" class="btn btn-success" data-toggle="modal" data-target="#{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:00138ebb0f5babfda925@@{literal}">Uznaj reklamację</button>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:9f9ab6222b3d8c471403@@{literal}<button type="button" class="btn btn-danger" data-toggle="modal" data-target="#{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:975df65329c4e521d420@@{literal}">Odrzuć reklamację</button>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:bc55c99d9719d85d39fc@@{literal}<p class="aar-claim-workflow-state is-set">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:75276f3cd0194a647ce8@@{literal}</p>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:195fde57a5eb9165a3ce@@{literal}</section>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:9e5db7545417154438f8@@{literal}<div class="modal fade aar-claim-action-modal" id="{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:b62c1a34c0e3ea7baef3@@{literal}<div class="modal-dialog modal-lg" role="document"><div class="modal-content">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:5b361f9289120a6411bc@@{literal}<div class="modal-header"><button type="button" class="close" data-dismiss="modal" aria-label="Zamknij"><span aria-hidden="true">&times;</span></button><h4 class="modal-title" id="{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:a53cc4c7fe605e978ec8@@{literal}">Rozpatrzenie reklamacji bez odesłania towaru</h4></div>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:6a8a07b8e5e1ca4ee4e1@@{literal}<form method="post"><div class="modal-body">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:47aa17c3b21447e0b6b8@@{literal}"><input type="hidden" name="claim_return_choice" value="NOT_REQUIRED"><input type="hidden" name="claim_return_message" value="Reklamacja zostanie rozpatrzona bez konieczności odsyłania towaru.">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:92cb39851bf2397957b1@@{literal}<div class="alert alert-info"><p>Kupujący otrzyma wiadomość, że nie musi odsyłać towaru, a reklamacja zostanie rozpatrzona na podstawie informacji z formularza.</p><p>Wiadomość zobaczysz w Przebiegu reklamacji.</p></div>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:52e61d1c5afd59cd4e58@@{literal}<label class="aar-claim-confirm"><input type="checkbox" name="claim_return_confirm" value="1" required> Potwierdzam, że rezygnuje z prawa do odebrania reklamowanego towaru i tym samym rozpatruję reklamację na podstawie informacji z formularza reklamacyjnego, który został przesłany przez kupującego.</label>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:0feb2ea8d0bc9fed1b2c@@{literal}</div><div class="modal-footer"><button type="button" class="btn btn-default" data-dismiss="modal">Anuluj</button><button type="submit" class="btn btn-primary" name="submitAarSetClaimReturn">Zatwierdź</button></div></form>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:a03e2f603b4d712835a9@@{literal}<div class="modal fade aar-claim-action-modal aar-claim-return-modal" id="{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:a6eaaae63329336ba68e@@{literal}">Zaplanuj odesłanie lub odbiór towaru</h4></div>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:aaef73e8b1369899fddd@@{literal}<form method="post" enctype="multipart/form-data" class="aar-claim-return-method-form"><div class="modal-body">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:129d605fde6f2485b4dc@@{literal}"><input type="hidden" name="MAX_FILE_SIZE" value="2097152"><input type="hidden" name="claim_return_confirm" value="1">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:ee20e7bb00bfae99a813@@{literal}<div class="aar-claim-return-intro">Sprzedający jest zobowiązany odebrać towar na własny koszt.<br>Napisz kupującemu, jak zwrócić towar (np. załącz etykietę wysyłkową lub umów odbiór osobisty).</div>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:b6b2a1f76cdcbe2a1d87@@{literal}<div class="aar-claim-return-methods">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:cf2732c21bea96594af4@@{literal}<label class="aar-claim-return-method aar-claim-return-method-smart" for="{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:344fe1b5977e7c06c157@@{literal}<input id="{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:3a5b3094d41d72bff961@@{literal}<span class="aar-claim-return-method-body"><strong>Bezpłatny zwrot w ramach Allegro <span class="aar-claim-smart-label">SMART!</span></strong><span>Moduł nie tworzy etykiety. Zaznacz tę opcję i przejdź do reklamacji w Sales Center, aby przekazać Allegro wybrany sposób odesłania. Kupujący samodzielnie wygeneruje darmową etykietę zwrotną. Obecnie publiczne API Allegro nie pozwala zatwierdzić tej opcji bezpośrednio w module, jednak Allegro pracuje już nad udostępnieniem takiej możliwości.</span></span>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:3fc95dda2fe9090067ea@@{literal}</label>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:9411f08f7f4099fcc9c4@@{literal}<label class="aar-claim-return-method is-disabled" for="{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:2e320230d1a94de2e500@@{literal}<span class="aar-claim-return-method-body"><strong>Bezpłatny zwrot w ramach Allegro <span class="aar-claim-smart-label">SMART!</span></strong><span>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:7007cea0c7a30adb4076@@{literal} Bezpłatny zwrot jest dostępny tylko wtedy, gdy potwierdzi go Allegro. <a class="aar-claim-help-link" href="https://allegro.pl/pomoc/dla-kupujacych/zwroty-i-reklamacje" target="_blank" rel="noopener noreferrer">Więcej o etykiecie Allegro.</a></span></span>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:e4c67e7231caef084086@@{literal}<label class="aar-claim-return-method" for="{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:9bc21cd6326301b404cc@@{literal}<span class="aar-claim-return-method-body"><strong>Załącz własną etykietę</strong><span>Kupujący otrzyma załadowaną przez Ciebie etykietę wysyłkową oraz automatyczne powiadomienie o obowiązkowej wysyłce towaru.</span></span>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:2be2e6bf4cf38155f391@@{literal}<div class="aar-claim-return-method-fields" data-aar-return-fields="SELLER_LABEL" style="display:none;">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:3cd1f8e4f20dd894fe34@@{literal}<div class="form-group"><label class="aar-claim-label-dropzone" for="{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:de04b92087e663bf2edf@@{literal}"><input id="{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:2d825a3a2237bf7c6b92@@{literal}" type="file" name="claim_return_label" accept="application/pdf,image/png,image/jpeg,image/gif,image/bmp,image/tiff"><span class="aar-claim-label-dropzone-title">Przeciągnij lub załącz etykietę</span><span class="aar-claim-label-file-name" data-aar-label-file-name>PDF lub obraz, maksymalnie 2 MB</span></label></div>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:b4c7156cec58e5679b00@@{literal}<div class="form-group aar-claim-return-message-wrap"><textarea id="{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:0031acd07775327ec8a4@@{literal}" class="form-control" name="claim_return_label_message" rows="4" maxlength="700" placeholder="Napisz wiadomość do kupującego o sposobie przekazania przesyłki (np. nazwa przewoźnika, instrukcja nadania)"></textarea><div class="aar-claim-char-counter"><span data-aar-count-for="{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:3249e490dcf36e4d4e6f@@{literal}">0</span> / 700</div></div>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:12b3614bb9c6fee88365@@{literal}<span class="aar-claim-return-method-body"><strong>Inna metoda odbioru (np. odbiór własny, przyjazd kuriera)</strong><span>Wybierz, jeśli musisz zaplanować odbiór własny, przyjazd serwisu lub inną metodę odbioru towaru. Zaproponuj datę, w której możesz zrealizować odbiór. Kupujący otrzyma automatyczne powiadomienie z Twoją propozycją.</span></span>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:b1f8dd0034609c3ba909@@{literal}<div class="aar-claim-return-method-fields" data-aar-return-fields="CUSTOM" style="display:none;">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:3643f5438abeee0b9fbb@@{literal}" class="form-control" name="claim_return_custom_message" rows="5" maxlength="700" placeholder="Napisz wiadomość z opisem odbioru"></textarea><div class="aar-claim-char-counter"><span data-aar-count-for="{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:bb1f27fbf382688a3ec7@@{literal}</div><div class="modal-footer"><button type="button" class="btn btn-default" data-dismiss="modal">Anuluj</button><button type="submit" class="btn btn-primary aar-claim-return-submit" name="submitAarSetClaimReturn" disabled>Wyślij</button></div></form>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:5dea455128320f6fbab1@@{literal}</h4></div>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:422f1cb140d2aa51f505@@{literal}<p class="aar-claim-status-description">Kupujący otrzyma decyzję reklamacyjną wraz z uzasadnieniem na majla oraz w Przebiegu reklamacji.</p>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:0dfd4c10121853c80a5a@@{literal}<p class="aar-claim-status-heading">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:b438f972c9858f3e54b6@@{literal}<div class="aar-claim-status-options">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:e9a5900706ce8f4bb3f0@@{literal}<label class="aar-claim-status-option"><input type="radio" name="claim_status" value="{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:6cd14378d6c7a129dad7@@{literal} required><span>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:776b32bc638deda8a74f@@{literal}</span></label>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:27611dbd2d2e8a6b9dea@@{literal}<div class="aar-claim-partial-refund"><h5>Częściowy zwrot płatności</h5><p class="text-muted">Uzupełnij tylko wtedy, gdy wybierzesz „Częściowy zwrot płatności”.</p><div class="row"><div class="col-sm-8"><input class="form-control" type="number" min="0.01" step="0.01" name="claim_partial_refund_amount" placeholder="Kwota"></div><div class="col-sm-4"><input class="form-control" type="text" maxlength="3" name="claim_partial_refund_currency" value="{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:3fc4185eb3374968b5e1@@{literal}" aria-label="Waluta"></div></div></div>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:7ab0b7628ec58a3da85f@@{literal}<div class="form-group aar-claim-status-message"><label>Uzasadnienie decyzji <span class="text-danger">*</span></label><textarea class="form-control" name="claim_status_message" rows="6" maxlength="1500" placeholder="Kupujący otrzyma tę treść w decyzji reklamacyjnej" required></textarea><small class="help-block">Maksymalnie 1500 znaków.</small></div>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:5d653417ba1e49ee253f@@{literal}<div class="alert alert-warning">Zatwierdzenie zmieni formalny status reklamacji w Allegro. Tej operacji nie należy wykonywać testowo.</div>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:ce403747ba3174515fae@@{literal}</div><div class="modal-footer"><button type="button" class="btn btn-default" data-dismiss="modal">Anuluj</button><button type="submit" class="btn {/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:73220861342631e398bb@@{literal}" name="submitAarChangeClaimStatus">Zatwierdź decyzję</button></div></form>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:6ffca28fc000c21f0f60@@{literal}<div class="aar-claim-summary aar-issue-order-summary">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:798d468a761f0b067889@@{literal}<div class="aar-return-decision-panel">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:c1e5ec9cb79ffff71230@@{literal}<div class="aar-return-decision-panel-head">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:03d7d7ce5a21c86d54fa@@{literal}<div class="btn-group aar-return-decision-dropdown">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:f44ff6fed10e654e0537@@{literal}<button type="button" class="btn btn-primary dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Decyzja zwrotowa <span class="caret"></span></button>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:48ee9a597c85fbb2a916@@{literal}<ul class="dropdown-menu aar-return-decision-menu">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:aa838190baba9cb5b773@@{literal}<li><a href="#" data-toggle="modal" data-target="#{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:a81a722318fdf6762712@@{literal}">Zwróć wybraną kwotę</a></li>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:b6b9a2f9adc476606a2c@@{literal}<li class="disabled"><a href="#" tabindex="-1">Zwróć wybraną kwotę</a></li>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:0874fd92f2325e1ce731@@{literal}">Odmowa zwrotu pieniędzy</a></li>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:5ae39f8391e09620c8b5@@{literal}<li class="disabled"><a href="#" tabindex="-1">Odmowa zwrotu pieniędzy</a></li>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:348845d8804b5c895e2a@@{literal}</ul>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:f9c09dc18722339b27f6@@{literal}<div class="aar-return-decision-total"><span>Razem</span><strong>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:0e1a4d58742cfc31cdde@@{literal}</strong></div>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:2999732c77c89b69cd5b@@{literal}<div class="aar-claim-summary aar-return-summary">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:9b50c3acec6d00bb2648@@{literal}<div class="aar-return-products">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:f0df5d156f15599a2781@@{literal}<div class="aar-return-simple-grid">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:2a94ebc16196e0ca7ada@@{literal}<section class="aar-return-simple-section aar-return-status-section">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:7aaf601393c59989b35a@@{literal}<h5>Status zwrotu towaru</h5>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:f6d238b312aa9654ace5@@{literal}<section class="aar-return-simple-section">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:5f0bcfe10a4bbfe11bfa@@{literal}<h5>Dane kupującego</h5>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:4974c1aa3d15fb468350@@{literal}<div>login: {/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:7b71bf048cbfeb66f730@@{literal}<div><a href="mailto:{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:545b719c5aa06983a1e6@@{literal}</a></div>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:9625c9f6d3b5664a904a@@{literal}<div>tel. {/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:bfaa060997c5ca9c57be@@{literal}<div><span class="aar-return-invoice-flag {/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:8dad793c25981e398e7a@@{literal}</span></div>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:8f5f15192c009c3f51ba@@{literal}<h5>Metoda dostawy</h5>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:fe41e29de37559edc8d7@@{literal}<div><button type="button" class="btn btn-link aar-return-tracking-link" data-toggle="modal" data-target="#{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:fb0f2e9f534ca03a2975@@{literal}</button></div>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:50e28d916f2722ef0109@@{literal}<div><a href="{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:84a1ef8aa95210dc3fff@@{literal}<h5 class="aar-return-subheading">Adres zwrotu</h5>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:966507249d91544f5646@@{literal}<section class="aar-return-simple-section aar-return-refund-section">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:7e639e7dfcdc7a1efabd@@{literal}<h5>Zwrot środków</h5>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:d70b8e28e0ce87164f95@@{literal}<div{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:43f61dd14734a67ae01f@@{literal}<div class="text-muted">Brak danych do zwrotu środków w danych Allegro.</div>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:436f07bad56985b79346@@{literal}<div class="modal fade aar-return-debug-modal" id="{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:a04acc39bbf01025ebbd@@{literal}<div class="modal-dialog modal-lg" role="document">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:d91ec07885dee8fb2180@@{literal}<div class="modal-content">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:d53c52f4f898f8ed293c@@{literal}<div class="modal-header">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:1ffc2c2a9b34fd8df40e@@{literal}<button type="button" class="close" data-dismiss="modal" aria-label="Zamknij"><span aria-hidden="true">&times;</span></button>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:eec8c139fec0bb69cdb2@@{literal}<h4 class="modal-title" id="{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:283d51335246153e5c7b@@{literal}">Diagnostyka API zwrotu</h4>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:6416b918eef22c892aee@@{literal}<div class="modal-body">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:a2a7951e7d4b8e95dadf@@{literal}<div class="aar-return-debug-head">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:f858169656616e48df49@@{literal}<button type="button" class="btn btn-primary btn-sm" data-aar-copy-return-json>Kopiuj JSON</button>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:93ec083ffba5d004a38d@@{literal}<a class="btn btn-default btn-sm" href="{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:5a9b72848822eb5e2167@@{literal}">Odśwież debug</a>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:278e4ecb1e30d1398390@@{literal}<pre class="aar-return-debug-json">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:485b0c2c3b23c2f8e61e@@{literal}</pre>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:5b94a554b4af4f48d3c5@@{literal}<div class="modal-footer">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:745c5e36a882adc8902a@@{literal}<button type="button" class="btn btn-default" data-dismiss="modal">Zamknij</button>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:5798c622726ee17b28ff@@{literal}<div class="modal fade aar-return-tracking-modal" id="{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:a42a4bae2f7f585c52bf@@{literal}<div class="modal-header aar-return-tracking-header">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:9cd32f1b7fa2efc3ba22@@{literal}<div class="aar-return-tracking-header-main">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:1a696990823019632780@@{literal}">Tracking przesyłki</h4>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:38846a2aecf7305a8f79@@{literal}<div class="aar-return-tracking-header-meta">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:f0a8ebd68c47ad5549c3@@{literal}<span>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:b254b1ed2055c07f7ab9@@{literal}<div class="aar-return-tracking-timeline" aria-label="Historia trackingu przesyłki">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:834e25fc21c57c69258d@@{literal}<div class="{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:e5c2c2aea0ea9f13a316@@{literal}<div class="aar-return-tracking-marker"></div>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:bfac32c15a71882292af@@{literal}<div class="aar-return-tracking-label">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:6c2a4f56779dcd1b2d3e@@{literal}<div class="aar-return-tracking-date">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:7a6ba052d3cbf1e697ba@@{literal}<div class="aar-return-tracking-code">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:c405171c6a17c0cf7aef@@{literal}<div class="alert alert-info">API Allegro nie zwróciło historii statusów dla tej przesyłki.</div>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:05c074c4f3fe221a2f75@@{literal}<a class="btn btn-primary aar-return-tracking-external-button" href="{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:52eb511f8687c7d2d725@@{literal}" target="_blank" rel="noopener noreferrer">Śledź na stronie przewoźnika</a>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:a3763de88a8ba0217b45@@{literal}<div class="aar-return-timeline" aria-label="Status zwrotu towaru">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:1f76f94889e147abccb0@@{literal}<div class="aar-return-timeline-marker"></div>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:59b19231ae6b302f689f@@{literal}<div class="aar-return-timeline-label">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:ae6c506e7de94d7c2b4e@@{literal}<div class="aar-return-timeline-date">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:528a00dfe2e31c7e5ebd@@{literal}<div class="aar-return-debug-link-wrap"><button type="button" class="btn btn-link aar-return-debug-link" data-toggle="modal" data-target="#{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:561275aa984856b9bab7@@{literal}">Pokaż API</button></div>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:c962beffeeaafb856db8@@{literal}<div class="aar-return-items-simple">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:ef24562fcccae7d70df0@@{literal}<div class="aar-return-product-row has-thumb">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:758b1d91242bee152a59@@{literal}<div class="aar-return-product-thumb"><img src="{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:979f5c37282c6b5c420c@@{literal}" alt="" loading="lazy"></div>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:a8a5b808eedea3034be1@@{literal}<div class="aar-return-product-row">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:1271e2feed0f73eed55c@@{literal}<div class="aar-return-product-main">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:2dbc18d3f996ed3f37d8@@{literal}<strong><a href="{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:ab39ff5eec6f459ac1f5@@{literal}</a></strong>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:e1dbd793b19311df29d5@@{literal}<div class="text-muted">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:eab7fa7aefacc1837f33@@{literal}<div class="aar-return-reason"><span>Powód zwrotu:</span> {/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:2166c24ecf5767767fe8@@{literal}<div class="aar-return-product-side">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:a0271bac8a2cdb1ac3ee@@{literal}<div class="aar-return-parcels">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:1bd10b905cc8a35cd6a9@@{literal}<div class="aar-claim-link-meta">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:1727b1ec81bbc251c160@@{literal}<div class="modal fade aar-return-refund-modal" id="{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:77a30cf9615e5cba5ef2@@{literal}">Zwrot pieniędzy</h4>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:e6d2a075d85390218b94@@{literal}<div class="modal fade aar-return-rejection-modal" id="{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:da7f23bd6913704ba886@@{literal}">Odmowa zwrotu pieniędzy</h4>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:0c3c1d22f75da4b050ba@@{literal}<form method="post" class="aar-reply-form aar-return-rejection-form{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:0eb620b3a2b5c23fc019@@{literal}<input type="hidden" name="return_id" value="{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:3d713f74d86b24469744@@{literal}<div class="aar-return-rejection-head">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:d0dd3ad23d7b77b69e9c@@{literal}<h5>Powód odmowy <span class="text-danger">*</span></h5>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:2db067f894b0cea2f182@@{literal}<p>Wybierz powód, który przekażemy kupującemu w decyzji.</p>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:e1f6ea5762471adce1ca@@{literal}<div class="aar-return-rejection-reasons">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:4827157d7858244ddc41@@{literal}<label class="aar-return-rejection-option">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:bd98b899e5e6edfb58fa@@{literal}<input type="radio" name="return_rejection_code" value="{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:e8dd0d7eb65fa62ebbd4@@{literal}<span class="aar-return-rejection-option-body">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:d92ea4abedf76a0363be@@{literal}<span class="aar-return-rejection-option-label">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:ea988115564831b86382@@{literal}<span class="aar-return-rejection-option-desc">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:43397482431861dd915c@@{literal}<div class="aar-return-rejection-comment">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:4cf72b52bd0218c5dc9e@@{literal}<label for="aar-return-rejection-reason-{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:3d27ac68645bcb64a36d@@{literal}">Uzasadnienie decyzji</label>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:f30c42939a8fc447f345@@{literal}<textarea id="aar-return-rejection-reason-{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:82fbb0601bbca2a5e13b@@{literal}" class="form-control" name="return_rejection_reason" rows="4" maxlength="250" placeholder="Podaj szczegóły (wymagane dla: Inny powód)"></textarea>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:c78684adf88f6682b695@@{literal}<div class="aar-return-rejection-actions">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:9ce180345c7993cc96eb@@{literal}<button class="btn btn-danger aar-send-button" name="submitAarRejectReturn" type="submit">Wyślij decyzję</button>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:44b906540844055f31dc@@{literal}<form method="post" class="aar-reply-form aar-return-refund-form{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:b8a1c39db64984d1b80b@@{literal}<div class="aar-return-refund-grid">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:16dbe614521ea98bdabf@@{literal}<div class="aar-return-refund-reasons-wrap">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:ae07b10cc0519aad92ce@@{literal}<h5>Powód zwrotu pieniędzy</h5>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:12ba2e59af45a5404386@@{literal}<div class="aar-return-refund-reasons-hint">Wybierz powód zwrotu</div>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:748510cd46401eda7ccf@@{literal}<div class="aar-return-refund-reasons">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:8d8de19869d6517655d1@@{literal}<label class="aar-return-refund-option">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:2ce97cae2b6ea30ed7b5@@{literal}<input type="radio" name="return_refund_reason" value="{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:dd95f5b6e1bc145ac6cf@@{literal}<div class="aar-return-refund-line">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:5e78511c56961b786e5f@@{literal}<input type="hidden" name="return_refund_lines[{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:b18eea6fa4787fb49764@@{literal}<label>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:9099303c133b44f25914@@{literal}<div class="input-group">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:3fee403c4d103c96b4d0@@{literal}<input class="form-control" type="text" name="return_refund_lines[{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:6cfed9c569a109006cae@@{literal}<span class="input-group-addon">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:a966ffbeb5ee2b7b74fe@@{literal}<div class="aar-return-refund-line aar-return-refund-delivery">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:08842b15e6f7bb1d1edf@@{literal}<input type="hidden" name="return_refund_delivery_currency" value="{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:061325503e9e439ead12@@{literal}<label>Dostawa<span>opcjonalnie</span></label>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:894f08811d725af93536@@{literal}<input class="form-control" type="text" name="return_refund_delivery_amount" value="" placeholder="0.00">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:ac710686d03489e81abc@@{literal}<textarea class="form-control" name="return_refund_comment" rows="2" maxlength="250" placeholder="Uzasadnienie decyzji (opcjonalnie)"></textarea>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:4dae09f3b7809ce7fb89@@{literal}<button class="btn btn-primary aar-send-button" name="submitAarRefundReturn" type="submit">Zwróć pieniądze</button>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:e4b14f9183fdee44984c@@{literal}<div class="aar-claim-card aar-checkout-card">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:dd9be0b7db1ed89d51e5@@{literal}<div class="aar-checkout-details">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:677ac9c437543c83a022@@{literal}<div class="aar-checkout-details-section">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:9dd3f2e6e229188553a1@@{literal}<h5>Kupujący</h5>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:9d71cb9498a7726a994d@@{literal}<h5>Dane dostawy</h5>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:f04f1c3ba4acc09612f1@@{literal}<div class="aar-claim-card">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:677dfc8a2943b6c313cb@@{literal}<h5>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:60cd30ffe1b2da73e413@@{literal}</h5>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:c873ba64798050fd5735@@{literal}<dl>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:15dd8048be0b8dbc2807@@{literal}<div class="aar-claim-row">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:cfdbcaad3482a329281e@@{literal}<dt>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:96d6798589dad89b3a5b@@{literal}</dt>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:65f513a10558ac9cbfeb@@{literal}<dd><a href="{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:e9a829f035777fbc1fe0@@{literal}</dd>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:8657c55c257c3a365d41@@{literal}<dd>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:5190f9c0a1366612a15d@@{literal}</dl>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:37002add42c563d0dd39@@{literal}<div class="aar-claim-body">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:e4d9ab8fe3593342bf7c@@{literal}<div class="aar-claim-order-link">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:f125a12fe59dc5f93b9f@@{literal}<a class="btn btn-default aar-inline-order-button" href="{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:9438523e1e1ee32fc2ef@@{literal}" target="_blank" rel="noopener noreferrer">Otwórz zamówienie w PrestaShop</a>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:4f91e65e228f8054babd@@{literal}<div class="aar-claim-link-meta">Powiązano przez: {/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:02c400f14d7569ede879@@{literal}<a href="{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:64bdd196d26804558c41@@{literal}<form method="get" action="{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:6e7807eefa9e72e6a446@@{literal}<input type="hidden" name="controller" value="{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:dd58843e653862574331@@{literal}<input type="hidden" name="token" value="{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:3091c38a80ab56aee236@@{literal}<input type="hidden" name="issue_pages" value="1">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:eb70306f1258d3def421@@{literal}<select id="aar-issue-kind-filter" name="issue_kind" class="form-control" onchange="this.form.submit()">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:5f0ccbf50845efd83670@@{literal}<option value="{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:620f24ad3a01b0d2fe67@@{literal}</option>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:8f6159402823c46958a7@@{literal}</select>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:92c005e0de148d29f20b@@{literal}<input type="hidden" name="issue_kind" value="{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:730b740402eb0c7fae6f@@{literal}<select id="aar-status-filter" name="status_filter" class="form-control" onchange="this.form.submit()">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:97603ae8fb4d63b13987@@{literal}<input type="search" name="issue_query" class="form-control" value="{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:dd52e3ab8be937ed29cf@@{literal}<button class="btn btn-default" type="submit">Filtruj</button>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:3c28f24a1d95ba50668f@@{literal}<a class="btn btn-default aar-clear-button" href="{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:da7197316644ff6075fc@@{literal}">Wyczyść</a>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:3032253a1eb28a11d114@@{literal}<style>
            .aar-messages-toolbar { flex:0 0 auto; padding:8px 10px; background:#fff; border-bottom:1px solid #d8dde0; }
            .aar-messages-filters { display:flex; flex-wrap:wrap; align-items:center; gap:9px 14px; margin:0; }
            .aar-messages-search { position:relative; flex:1 1 100%; max-width:none; }
            .aar-messages-search .form-control { width:100%; height:32px; padding-right:34px; border-radius:5px; box-shadow:none; }
            .aar-messages-search i { position:absolute; right:11px; top:8px; color:#7a8288; }
            .aar-messages-check { display:inline-flex; flex:0 0 auto; align-items:center; justify-content:flex-start; gap:8px; min-height:22px; margin:0 !important; padding:0; white-space:nowrap; color:#53636a; font-size:14px; line-height:22px; font-weight:400 !important; cursor:pointer; transition:color .15s ease; }
            .aar-messages-check:hover { color:#2f3b46; }
            .aar-messages-check input { position:relative; flex:0 0 18px; width:18px; height:18px; margin:0 !important; border:2px solid #25b9d7; border-radius:5px; background:#fff; box-shadow:none; vertical-align:middle; appearance:none; -webkit-appearance:none; cursor:pointer; transition:background-color .15s ease,border-color .15s ease,box-shadow .15s ease; }
            .aar-messages-check input:checked { border-color:#25b9d7; background:#25b9d7; }
            .aar-messages-check input:checked:after { content:""; position:absolute; top:1px; left:5px; width:5px; height:9px; border:solid #fff; border-width:0 2px 2px 0; transform:rotate(45deg); }
            .aar-messages-check input:focus { outline:0; box-shadow:0 0 0 3px rgba(37,185,215,.18); }
            .aar-messages-toolbar .btn { height:32px; padding:5px 12px; border-radius:5px; font-weight:700; }
            @media(max-width:767px){.aar-messages-check{white-space:normal}}
        </style>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:780dd26be5e883ee2c7f@@{literal}<div class="aar-messages-toolbar" data-aar-message-filter-active="{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:ab98d2cdc57dfa7d5c0f@@{literal}"><form method="get" action="{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:2e6f1522a5e010c39da0@@{literal}<input type="hidden" name="controller" value="AdminAllegroCustomerServiceMessages">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:9bf294c9aecb0594bcd9@@{literal}<input type="hidden" name="thread_pages" value="1">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:8e3830c6b014e5c4c630@@{literal}<div class="aar-messages-search"><input type="search" name="message_query" class="form-control" value="{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:33baa1625b7bd0d6e8ac@@{literal}" placeholder="Szukaj odbiorcy" autocomplete="one-time-code" autocorrect="off" autocapitalize="none" spellcheck="false" enterkeyhint="search" inputmode="search" data-form-type="other" data-lpignore="true" data-1p-ignore="true" data-bwignore="true"><i class="icon-search"></i></div>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:f1e2d4dba43078ece19c@@{literal}<label class="aar-messages-check"><input type="checkbox" name="message_unread" value="1"{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:c3922907f2f7a78566d0@@{literal}"> Nieprzeczytane</label>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:71c96e548f74377c11b3@@{literal}<label class="aar-messages-check"><input type="checkbox" name="message_without_reply" value="1"{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:7a93a2fade92a23c96b1@@{literal}"> Wymaga odpowiedzi</label>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:7eab0e9ceacc44cc703e@@{literal}</form></div>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:0eea05e54e7937b7a97e@@{literal}<style>
            .aar-issues-toolbar {
                width: 100%;
                display: flex;
                justify-content: space-between;
                align-items: center;
                gap: 14px;
                margin: 0 0 14px;
                padding: 12px 14px;
                background: #ffffff;
                border: 1px solid #d8dde0;
                border-radius: 6px;
                box-shadow: 0 1px 2px rgba(16, 24, 40, .04);
            }
            .aar-issues-filters {
                display: grid;
                grid-template-columns: minmax(130px, 160px) minmax(260px, 1fr) auto auto;
                align-items: stretch;
                gap: 10px;
                margin: 0;
                flex: 1 1 auto;
                min-width: 0;
            }
            .aar-issues-filters.has-kind-filter {
                grid-template-columns: minmax(130px, 160px) minmax(130px, 160px) minmax(260px, 1fr) auto auto;
            }
            .aar-issues-filters .form-control {
                height: 36px;
                min-height: 0;
                border-radius: 6px;
                box-shadow: none;
            }
            .aar-issues-filters select,
            .aar-issues-filters input[type=search] {
                width: 100%;
            }
            .aar-issues-toolbar .btn {
                height: 36px;
                display: inline-flex;
                align-items: center;
                justify-content: center;
                border-radius: 6px;
                font-weight: 700;
                white-space: nowrap;
                padding-left: 14px;
                padding-right: 14px;
            }
            .aar-issues-toolbar-actions {
                display: flex;
                align-items: center;
                gap: 10px;
                flex: 0 0 auto;
            }
            .aar-issues-toolbar .aar-refresh-button {
                background: #25b9d7;
                border-color: #25b9d7;
                color: #ffffff;
                min-width: 118px;
            }
            .aar-issues-toolbar .aar-refresh-button:hover,
            .aar-issues-toolbar .aar-refresh-button:focus {
                background: #178ca6;
                border-color: #178ca6;
                color: #ffffff;
            }
            .aar-issues-toolbar .aar-clear-button {
                color: #6b7280;
            }
            @media (max-width: 1199px) {
                .aar-issues-toolbar {
                    align-items: stretch;
                    flex-direction: column;
                }
                .aar-issues-filters,
                .aar-issues-filters.has-kind-filter {
                    grid-template-columns: minmax(140px, 1fr) minmax(140px, 1fr) minmax(220px, 2fr) auto auto;
                    width: 100%;
                }
                .aar-issues-filters:not(.has-kind-filter) {
                    grid-template-columns: minmax(140px, 1fr) minmax(220px, 2fr) auto auto;
                }
                .aar-issues-toolbar-actions {
                    justify-content: flex-end;
                }
            }
            @media (max-width: 767px) {
                .aar-issues-filters,
                .aar-issues-filters.has-kind-filter {
                    grid-template-columns: 1fr;
                }
                .aar-issues-toolbar-actions,
                .aar-issues-toolbar-actions .btn,
                .aar-issues-toolbar .btn {
                    width: 100%;
                }
            }
        </style>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:ab85734bd630f53d7e91@@{literal}<div class="aar-issues-toolbar">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:10e3e14c7b7eb26d2433@@{literal}<div class="aar-issues-toolbar-actions">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:a5aea34f23198ff9c7ee@@{literal}<a class="btn aar-refresh-button" href="{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:6b47578f28c890359709@@{literal}"><i class="icon-refresh"></i> Odśwież</a>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:fdf0bb91d76f95129689@@{literal}<style>
            .aar-returns-toolbar {
                width: 100%;
                display: flex;
                justify-content: space-between;
                align-items: center;
                gap: 14px;
                margin: 0 0 14px;
                padding: 12px 14px;
                background: #ffffff;
                border: 1px solid #d8dde0;
                border-radius: 6px;
                box-shadow: 0 1px 2px rgba(16, 24, 40, .04);
            }
            .aar-returns-filters {
                display: grid;
                grid-template-columns: minmax(130px, 160px) minmax(130px, 160px) minmax(260px, 1fr) auto auto;
                align-items: stretch;
                gap: 10px;
                margin: 0;
                flex: 1 1 auto;
                min-width: 0;
            }
            .aar-returns-filters .form-control {
                height: 36px;
                min-height: 0;
                border-radius: 6px;
                box-shadow: none;
            }
            .aar-returns-filters select {
                width: 100%;
            }
            .aar-returns-filters input[type=search] {
                width: 100%;
            }
            .aar-returns-toolbar .btn {
                height: 36px;
                display: inline-flex;
                align-items: center;
                justify-content: center;
                border-radius: 6px;
                font-weight: 700;
                white-space: nowrap;
                padding-left: 14px;
                padding-right: 14px;
            }
            .aar-returns-toolbar-actions {
                display: flex;
                align-items: center;
                gap: 10px;
                flex: 0 0 auto;
            }
            .aar-returns-toolbar .aar-refresh-button {
                background: #25b9d7;
                border-color: #25b9d7;
                color: #ffffff;
                min-width: 118px;
            }
            .aar-returns-toolbar .aar-refresh-button:hover,
            .aar-returns-toolbar .aar-refresh-button:focus {
                background: #178ca6;
                border-color: #178ca6;
                color: #ffffff;
            }
            .aar-returns-toolbar .aar-clear-button {
                color: #6b7280;
            }
            @media (max-width: 1199px) {
                .aar-returns-toolbar {
                    align-items: stretch;
                    flex-direction: column;
                }
                .aar-returns-filters {
                    grid-template-columns: minmax(140px, 1fr) minmax(140px, 1fr) minmax(220px, 2fr) auto auto;
                    width: 100%;
                }
                .aar-returns-toolbar-actions {
                    justify-content: flex-end;
                }
            }
            @media (max-width: 767px) {
                .aar-returns-filters {
                    grid-template-columns: 1fr;
                }
                .aar-returns-toolbar-actions {
                    flex-direction: column;
                }
                .aar-returns-toolbar .btn,
                .aar-returns-toolbar-actions,
                .aar-returns-toolbar-actions .btn {
                    width: 100%;
                }
            }
        </style>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:bae47717eff43eb5e676@@{literal}<div class="aar-returns-toolbar">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:235bf9443b8f750f787d@@{literal}<input type="hidden" name="return_pages" value="1">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:16856c27d3b294611f93@@{literal}<select name="return_status" class="form-control" onchange="this.form.submit()" aria-label="Status zwrotu">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:2c3117992c36c675405d@@{literal}<select name="return_date_range" class="form-control" onchange="this.form.submit()" aria-label="Zakres dat">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:1b9d75988ec88953de61@@{literal}<input type="search" name="return_query" class="form-control" value="{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:f0244430c3e8f8e7f9ac@@{literal}<div class="aar-returns-toolbar-actions">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:12500825435037f5f88f@@{literal}<span>Zamówienie Allegro: <a href="{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:030d4238cba6a61e9eaa@@{literal}</a></span>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:9eb12d615f8f2e148d1c@@{literal}<span>Zamówienie Allegro: {/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:ab541aeec2d7c1c49a84@@{literal}<span>Zamówienie w sklepie: <a href="{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:48226d9ce963387febd9@@{literal}<span>Zamówienie w sklepie: {/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:474cdbb2f6a135794e9d@@{literal}<small>Zwrot kliencki Allegro</small>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:cdb6a41090dfe370856f@@{literal}<small class="aar-return-header-meta">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:e390477c81c44118626d@@{literal} <span class="aar-return-header-separator">•</span> {/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:c12899cfd4c54f64a7f1@@{literal}<div class="aar-claim-badges aar-header-claim-badges">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:1c6cd79dff123b375a24@@{literal}<span class="aar-claim-badge aar-claim-status aar-status-badge aar-status-badge-{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:bcb3f514a2916e3f2e7e@@{literal}<span class="aar-claim-badge">One Fulfillment</span>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:3e23d75fa4bb7dbb6bbc@@{literal}<span style="width:{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:30f8b6654321dabfda39@@{literal}%"></span>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:c858412745e39ff4a947@@{literal}<i class="aar-claim-progress-marker" style="left:{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:30d0d76b3390675e4ec9@@{literal}%"></i>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:267c33ddd05021a7fbe8@@{literal}<b class="aar-claim-progress-flag{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:5a173609876c90d5f22b@@{literal}</b>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:79865ea0a512dbb7810f@@{literal}<style>
            .aar-inbox-panel .btn > i[class^="icon-"],
            .aar-inbox-panel .btn > i[class*=" icon-"],
            .aar-refresh-button > i[class^="icon-"],
            .aar-refresh-button > i[class*=" icon-"] {
                margin-right: 8px !important;
            }
            .aar-inbox-panel {
                padding: 0 !important;
                margin: var(--aar-inbox-top-gap, 10px) 0 0 !important;
                overflow: hidden;
                height: var(--aar-inbox-height, auto);
                max-height: var(--aar-inbox-height, none);
                min-height: 320px;
                display: flex;
                flex-direction: column;
            }
            .aar-inbox-panel.panel {
                padding: 0 !important;
            }
            .aar-inbox {
                display: flex;
                flex-wrap: nowrap;
                background: #eef2f4;
                min-height: 0;
                flex: 1 1 auto;
                margin: 0 !important;
            }
            .aar-inbox .aar-inbox-col {
                padding-left: 0;
                padding-right: 0;
                min-height: 0;
            }
            .aar-inbox .aar-inbox-col-list {
                border-right: 1px solid #d8dde0;
                background: #f7f8f9;
            }
            .aar-messages-panel .aar-inbox-col-list {
                display: flex;
                flex-direction: column;
            }
            .aar-inbox-panel .aar-issues-filters {
                display: flex;
                justify-content: flex-end;
                align-items: center;
                gap: 12px;
                margin: 0;
                flex: 0 0 auto;
            }
            .aar-inbox-panel .aar-filter-group {
                display: flex;
                align-items: center;
                gap: 10px;
            }
            .aar-inbox-panel .aar-filter-group label {
                margin: 0;
                font-size: 12px;
                font-weight: 700;
                color: #7a8288;
                text-transform: uppercase;
                letter-spacing: .04em;
            }
            .aar-inbox-panel .aar-filter-group .form-control {
                width: 190px;
                height: 36px;
                border-radius: 6px;
                box-shadow: none;
            }
            .aar-inbox .aar-thread-list {
                height: 100%;
                overflow: auto;
                overscroll-behavior: contain;
                border: 0;
                background: #f7f8f9;
                margin-bottom: 0;
            }
            .aar-messages-panel .aar-thread-list {
                min-height: 0;
                flex: 1 1 auto;
            }
            .aar-messages-panel .aar-message-filter-empty {
                padding: 20px 16px;
                color: #7a8288;
                text-align: center;
            }
            .aar-inbox .aar-load-more-wrap {
                padding: 12px 16px 16px;
                background: #f7f8f9;
                text-align: center;
            }
            .aar-inbox .aar-load-more {
                width: 100%;
                border-radius: 6px;
                font-weight: 700;
            }
            .aar-inbox .aar-thread-item {
                border: 0;
                border-bottom: 1px solid #e1e6ea;
                color: #3a3f44;
                background: #f7f8f9;
                margin: 0;
                position: relative;
                padding: 12px 16px 10px;
            }
            .aar-inbox .aar-message-thread-row {
                display: flex;
                align-items: center;
                gap: 12px;
                min-width: 0;
            }
            .aar-inbox .aar-message-thread-content {
                display: block;
                flex: 1 1 auto;
                min-width: 0;
            }
            .aar-inbox .aar-user-avatar {
                width: 42px;
                min-width: 42px;
                height: 42px;
                border-radius: 50%;
                overflow: hidden;
                background: transparent;
                border: 1px solid #cbd6dc;
                display: flex;
                align-items: center;
                justify-content: center;
            }
            .aar-inbox .aar-user-avatar img,
            .aar-inbox .aar-user-avatar-fallback {
                width: 100%;
                height: 100%;
            }
            .aar-inbox .aar-user-avatar img {
                display: block;
                object-fit: cover;
            }
            .aar-inbox .aar-user-avatar-fallback {
                display: flex;
                align-items: center;
                justify-content: center;
                color: #53636d;
                font-size: 16px;
                font-weight: 700;
            }
            .aar-inbox .aar-thread-item.active .aar-user-avatar {
                border-color: rgba(255,255,255,.55);
            }
            .aar-inbox .aar-thread-item.active .aar-user-avatar-fallback {
                background: transparent;
                color: #fff;
            }
            .aar-inbox .aar-thread-body {
                display: flex;
                align-items: flex-start;
                gap: 12px;
                min-width: 0;
            }
            .aar-inbox .aar-thread-media {
                width: 66px;
                min-width: 66px;
                display: flex;
                flex-direction: column;
                align-items: center;
                gap: 5px;
            }
            .aar-inbox .aar-thread-thumb {
                width: 56px;
                min-width: 56px;
                height: 56px;
                border-radius: 6px;
                overflow: hidden;
                background: #e7edf1;
                border: 1px solid #d8dde0;
                display: flex;
                align-items: center;
                justify-content: center;
                position: relative;
            }
            .aar-inbox .aar-thread-thumb img {
                width: 100%;
                height: 100%;
                object-fit: cover;
                display: block;
            }
            .aar-inbox .aar-thread-thumb-placeholder {
                width: 22px;
                height: 22px;
                border-radius: 5px;
                background: #c7d2da;
                display: block;
            }
            .aar-inbox .aar-thread-thumb-meta {
                display: flex;
                flex-direction: column;
                align-items: center;
                gap: 4px;
                width: 100%;
            }
            .aar-inbox .aar-thread-thumb-meta .aar-type-badge {
                max-width: 66px;
                min-height: 18px;
                padding: 2px 5px;
                justify-content: center;
                font-size: 9px;
                white-space: nowrap;
            }
            .aar-inbox .aar-thread-content {
                min-width: 0;
                flex: 1 1 auto;
            }
            .aar-inbox .aar-thread-head {
                display: flex;
                align-items: baseline;
                justify-content: space-between;
                gap: 10px;
            }
            .aar-inbox .aar-thread-login {
                display: block;
                min-width: 0;
                font-size: 15px;
                line-height: 1.3;
                font-weight: 400;
            }
            .aar-inbox .aar-thread-date {
                color: #7a8288;
                white-space: nowrap;
                flex-shrink: 0;
                font-size: 12px;
            }
            .aar-inbox .aar-thread-preview {
                margin-top: 4px;
                color: #7a8288;
                font-size: 12px;
                line-height: 1.35;
                padding-right: 54px;
            }
            .aar-inbox .aar-thread-meta {
                margin-top: 6px;
                display: flex;
                flex-wrap: wrap;
                gap: 6px;
                align-items: center;
            }
            .aar-inbox .aar-thread-deadline {
                margin-top: 10px;
                padding: 0;
                border-radius: 0;
                background: transparent;
                border: 0;
            }
            .aar-inbox .aar-thread-deadline.is-warning {
                background: transparent;
                border-color: transparent;
            }
            .aar-inbox .aar-thread-deadline.is-overdue {
                background: transparent;
                border-color: transparent;
            }
            .aar-inbox .aar-thread-deadline-row {
                display: flex;
                align-items: baseline;
                justify-content: space-between;
                gap: 10px;
            }
            .aar-inbox .aar-thread-deadline-label {
                color: #2d3033;
                font-size: 11px;
                font-weight: 700;
                line-height: 1.3;
            }
            .aar-inbox .aar-thread-deadline-date {
                color: #4f5a64;
                font-size: 11px;
                font-weight: 700;
                white-space: nowrap;
            }
            .aar-inbox .aar-thread-deadline-subline {
                margin-top: 3px;
                color: #7a8288;
                font-size: 11px;
                line-height: 1.35;
            }
            .aar-inbox .aar-thread-deadline-progress {
                position: relative;
                margin-top: 7px;
                height: 6px;
                background: #e7edf1;
                border-radius: 999px;
                overflow: visible;
            }
            .aar-inbox .aar-thread-deadline-progress span {
                display: block;
                height: 100%;
                background: linear-gradient(90deg, #25b7a8 0%, #0b7f72 100%);
                border-radius: 999px;
            }
            .aar-inbox .aar-claim-progress-marker {
                position: absolute;
                top: 50%;
                width: 22px;
                height: 22px;
                margin-left: -11px;
                transform: translateY(-50%);
                border-radius: 999px;
                background: #ffffff;
                border: 6px solid #0b7f72;
                box-shadow: none;
                z-index: 3;
            }
            .aar-inbox .aar-claim-progress-flag {
                position: absolute;
                top: -42px;
                transform: translateX(-50%);
                display: inline-flex;
                align-items: center;
                justify-content: center;
                min-height: 28px;
                padding: 5px 10px;
                border-radius: 6px;
                background: #0b7f72;
                color: #fff;
                font-size: 12px;
                font-weight: 700;
                line-height: 1;
                white-space: nowrap;
                box-shadow: 0 2px 6px rgba(16, 24, 40, .18);
                z-index: 4;
            }
            .aar-inbox .aar-claim-progress-flag:after {
                content: "";
                position: absolute;
                left: 50%;
                bottom: -5px;
                width: 10px;
                height: 10px;
                background: inherit;
                transform: translateX(-50%) rotate(45deg);
                border-radius: 2px;
            }
            .aar-inbox .aar-claim-progress-flag-right {
                transform: translateX(calc(-100% + 11px));
            }
            .aar-inbox .aar-claim-progress-flag-right:after {
                left: auto;
                right: 6px;
                transform: rotate(45deg);
            }
            .aar-inbox .aar-thread-deadline-progress .aar-claim-progress-flag {
                display: none;
            }
            .aar-inbox .aar-thread-deadline-progress .aar-claim-progress-marker {
                width: 14px;
                height: 14px;
                margin-left: -7px;
                background: #0b7f72;
                border: 0;
                box-shadow: none;
            }
            .aar-inbox .aar-thread-deadline.is-warning .aar-thread-deadline-progress span {
                background: linear-gradient(90deg, #f5b942 0%, #d68b00 100%);
            }
            .aar-inbox .aar-thread-deadline.is-overdue .aar-thread-deadline-progress span {
                background: linear-gradient(90deg, #f97066 0%, #d92d20 100%);
            }
            .aar-inbox .aar-thread-deadline.is-warning .aar-claim-progress-marker {
                border-color: #d68b00;
                background: #d68b00;
            }
            .aar-inbox .aar-thread-deadline.is-overdue .aar-claim-progress-marker {
                border-color: #d92d20;
                background: #d92d20;
            }
            .aar-inbox .aar-type-badge {
                display: inline-flex;
                align-items: center;
                min-height: 22px;
                padding: 2px 8px;
                border-radius: 6px;
                font-size: 11px;
                font-weight: 700;
                line-height: 1;
                border: 0;
                box-shadow: none;
            }
            .aar-inbox .aar-type-badge.is-dispute {
                background: #f4a261;
                color: #fff;
            }
            .aar-inbox .aar-type-badge.is-claim {
                background: #4a4a4a;
                color: #fff;
            }
            .aar-inbox .aar-type-badge.is-neutral {
                background: #eef2f4;
                color: #4f5a64;
            }
            .aar-inbox .aar-status-badge {
                display: inline-flex;
                align-items: center;
                min-height: 22px;
                padding: 2px 8px;
                border-radius: 6px;
                font-size: 11px;
                font-weight: 700;
                line-height: 1;
                border: 0;
                box-shadow: none;
            }
            .aar-inbox .aar-status-badge.aar-status-badge-is-warning {
                background: #f4a261;
                color: #fff;
            }
            .aar-inbox .aar-status-badge.aar-status-badge-is-ok {
                background: #1f9d68;
                color: #fff;
            }
            .aar-inbox .aar-status-badge.aar-status-badge-is-overdue {
                background: #d64545;
                color: #fff;
            }
            .aar-inbox .aar-status-badge.aar-status-badge-is-neutral {
                background: #6b7280;
                color: #fff;
            }
            .aar-inbox .aar-thread-unread .aar-thread-login,
            .aar-inbox .aar-thread-unread .aar-thread-date,
            .aar-inbox .aar-thread-unread .aar-thread-preview {
                font-weight: 700;
            }
            .aar-inbox .aar-thread-unread .aar-thread-date {
                color: #3a3f44;
            }
            .aar-messages-panel .aar-reply-required-badge {
                background: #f59e0b;
                color: #fff;
                font-size: 9px;
                white-space: nowrap;
            }
            .aar-inbox .aar-thread-item:hover,
            .aar-inbox .aar-thread-item:focus {
                color: #0b7f72;
                background: #edf4f3;
            }
            .aar-inbox .aar-thread-item.active,
            .aar-inbox .aar-thread-item.active:hover,
            .aar-inbox .aar-thread-item.active:focus {
                color: #f5f8fa;
                background: #555b63;
                border-bottom-color: #555b63;
            }
            .aar-inbox .aar-thread-item.active .aar-thread-date,
            .aar-inbox .aar-thread-item.active .aar-thread-preview {
                color: #d3dde4;
            }
            .aar-inbox .aar-thread-item.active .aar-thread-deadline {
                background: transparent;
                border-color: transparent;
            }
            .aar-inbox .aar-thread-item.active .aar-thread-deadline.is-warning {
                background: transparent;
                border-color: transparent;
            }
            .aar-inbox .aar-thread-item.active .aar-thread-deadline.is-overdue {
                background: transparent;
                border-color: transparent;
            }
            .aar-inbox .aar-thread-item.active .aar-thread-deadline-label,
            .aar-inbox .aar-thread-item.active .aar-thread-deadline-date {
                color: #f5f8fa;
            }
            .aar-inbox .aar-thread-item.active .aar-thread-deadline-subline {
                color: #d3dde4;
            }
            .aar-inbox .aar-inbox-col-conversation {
                background: #ffffff;
                display: flex;
                min-height: 0;
                position: relative;
            }
            .aar-inbox .aar-inbox-col-conversation.is-loading {
                pointer-events: none;
            }
            .aar-inbox .aar-conversation-loader {
                display: flex;
                flex: 1 1 auto;
                min-height: 360px;
                align-items: center;
                justify-content: center;
                background: #ffffff;
            }
            .aar-inbox .aar-conversation-spinner {
                width: 38px;
                height: 38px;
                border: 4px solid #d9e2e8;
                border-top-color: #25b7a8;
                border-radius: 999px;
                animation: aar-spin .75s linear infinite;
            }
            @keyframes aar-spin {
                to {
                    transform: rotate(360deg);
                }
            }
            .aar-inbox .aar-conversation-shell {
                display: flex;
                flex-direction: column;
                width: 100%;
                height: 100%;
                min-height: 0;
            }
            .aar-inbox .aar-conversation-header {
                display: flex;
                align-items: center;
                justify-content: space-between;
                gap: 18px;
                padding: 14px 20px 10px;
                border-bottom: 1px solid #d8dde0;
                background: #fbfcfc;
                flex: 0 0 auto;
            }
            .aar-inbox .aar-conversation-title {
                min-width: 0;
            }
            .aar-inbox .aar-conversation-title h4 {
                margin: 0;
                font-size: 18px;
                font-weight: 700;
                line-height: 1.25;
            }
            .aar-inbox .aar-conversation-title h4 a,
            .aar-inbox .aar-conversation-title h4 a:visited {
                color: #25b9d7;
                text-decoration: none;
            }
            .aar-inbox .aar-conversation-title h4 a:hover,
            .aar-inbox .aar-conversation-title h4 a:focus {
                color: #178ca6;
                text-decoration: none;
            }
            .aar-inbox .aar-conversation-title small {
                color: #7a8288;
                display: block;
                margin-top: 4px;
                font-size: 14px;
            }
            .aar-inbox .aar-return-header-meta a,
            .aar-inbox .aar-return-header-meta a:visited {
                color: #25b9d7;
                text-decoration: none;
            }
            .aar-inbox .aar-return-header-meta a:hover,
            .aar-inbox .aar-return-header-meta a:focus {
                color: #178ca6;
                text-decoration: none;
            }
            .aar-inbox .aar-return-header-separator {
                color: #a0a7ad;
                margin: 0 4px;
            }
            .aar-inbox .aar-message-window {
                border: 0;
                padding: 22px 20px;
                min-height: 0;
                flex: 1 1 auto;
                overflow: auto;
                overscroll-behavior: contain;
                background: #ffffff;
                margin: 0;
            }
            .aar-inbox .aar-message-row {
                margin-bottom: 18px;
            }
            .aar-inbox .aar-message-left {
                text-align: left;
            }
            .aar-inbox .aar-message-right {
                text-align: right;
            }
            .aar-inbox .aar-message-bubble {
                display: inline-block;
                max-width: 76%;
                text-align: left;
                padding: 14px 16px;
                border: 1px solid #c9d0d4;
                border-radius: 6px;
                line-height: 1.45;
                box-shadow: 0 1px 2px rgba(16, 24, 40, .04);
            }
            .aar-inbox .aar-message-customer {
                color: #2d3033;
                background: #f4f6f8;
                border-color: #bcc4ca;
            }
            .aar-inbox .aar-message-shop {
                color: #f5f8fa;
                background: #363a41;
                border-color: #363a41;
            }
            .aar-inbox .aar-message-head {
                display: flex;
                gap: 10px;
                align-items: baseline;
                justify-content: space-between;
            }
            .aar-inbox .aar-message-head small {
                white-space: nowrap;
                opacity: .9;
            }
            .aar-inbox .aar-message-shop a,
            .aar-inbox .aar-message-shop .aar-message-meta {
                color: #2cc4b3;
            }
            .aar-inbox .aar-message-text {
                white-space: pre-wrap;
                margin-top: 8px;
            }
            .aar-inbox .aar-message-meta {
                display: block;
                margin-top: 10px;
                color: #0b7f72;
            }
            .aar-inbox .aar-issue-history-warning {
                margin: 0 0 18px;
            }
            .aar-inbox .aar-message-attachments {
                display: flex;
                flex-wrap: wrap;
                gap: 10px;
                margin-top: 12px;
            }
            .aar-inbox .aar-issue-attachment-image {
                position: relative;
                display: inline-flex;
                width: auto;
                height: auto;
                min-height: 0;
                max-width: 100%;
                padding: 0;
                overflow: hidden;
                border: 1px solid #cbd3d8;
                border-radius: 8px;
                background: transparent;
                color: #2d3033;
                cursor: pointer;
            }
            .aar-inbox .aar-issue-attachment-image:hover,
            .aar-inbox .aar-issue-attachment-image:focus {
                border-color: #25b9d7;
                outline: 0;
                box-shadow: 0 0 0 3px rgba(37, 185, 215, .18);
            }
            .aar-inbox .aar-issue-attachment-image img {
                display: block;
                width: auto;
                height: auto;
                max-width: 150px;
                max-height: 150px;
                border-radius: 7px;
                object-fit: contain;
            }
            .aar-inbox .aar-issue-attachment-image-fallback {
                width: 100px;
                height: 80px;
                align-items: center;
                justify-content: center;
                background: #f4f6f8;
            }
            .aar-inbox .aar-issue-attachment-image-fallback {
                color: #7a8288;
                font-size: 30px;
            }
            .aar-inbox .aar-issue-attachment-file {
                display: inline-flex;
                min-height: 40px;
                max-width: 100%;
                padding: 8px 10px;
                align-items: center;
                gap: 8px;
                border: 1px solid #cbd3d8;
                border-radius: 6px;
                background: #fff;
                color: #0b7f72 !important;
                font-weight: 600;
                text-decoration: none !important;
            }
            .aar-inbox .aar-issue-attachment-file:hover,
            .aar-inbox .aar-issue-attachment-file:focus {
                border-color: #25b9d7;
                box-shadow: 0 0 0 3px rgba(37, 185, 215, .18);
            }
            .aar-inbox .aar-issue-attachment-file span {
                min-width: 0;
                overflow-wrap: anywhere;
            }
            .aar-inbox .aar-issue-attachment-preview-modal .modal-content {
                position: relative;
                height: calc(100vh - 20px);
                overflow: visible;
                border: 0;
                border-radius: 0;
                background: transparent;
                box-shadow: none;
            }
            .aar-inbox .aar-issue-attachment-preview-modal .modal-dialog {
                width: calc(100vw - 24px);
                max-width: none;
                height: calc(100vh - 20px);
                margin: 10px auto;
            }
            .aar-inbox .aar-issue-attachment-preview-modal .modal-body {
                display: flex;
                height: 100%;
                padding: 0 70px;
                align-items: center;
                justify-content: center;
                background: transparent;
                text-align: center;
            }
            .aar-inbox .aar-issue-attachment-preview-stage {
                position: relative;
                display: inline-block;
                max-width: 100%;
                max-height: calc(100vh - 20px);
            }
            .aar-inbox .aar-issue-attachment-preview-modal .modal-body img {
                display: block;
                max-width: 100%;
                max-height: calc(100vh - 20px);
                margin: 0 auto;
                border-radius: 8px;
                object-fit: contain;
            }
            .aar-inbox .aar-issue-attachment-preview-download {
                position: absolute;
                z-index: 2;
                right: 12px;
                bottom: 12px;
                display: flex;
                width: 46px;
                height: 46px;
                padding: 0;
                border: 0;
                border-radius: 50%;
                align-items: center;
                justify-content: center;
                background: rgba(37, 185, 215, .92);
                color: #fff !important;
                font-size: 20px;
                text-decoration: none !important;
                box-shadow: 0 4px 18px rgba(0, 0, 0, .28);
            }
            .aar-inbox .aar-issue-attachment-preview-download:hover,
            .aar-inbox .aar-issue-attachment-preview-download:focus {
                background: #25b9d7;
                color: #fff !important;
                outline: 0;
            }
            .aar-inbox .aar-issue-attachment-preview-close {
                position: absolute;
                z-index: 2;
                top: 8px;
                right: 8px;
                width: 46px;
                height: 46px;
                padding: 0;
                border: 0;
                border-radius: 50%;
                background: rgba(20, 28, 34, .72);
                color: #fff;
                font-size: 36px;
                font-weight: 300;
                line-height: 42px;
                text-align: center;
                text-shadow: none;
                cursor: pointer;
                box-shadow: 0 3px 14px rgba(0, 0, 0, .24);
            }
            .aar-inbox .aar-issue-attachment-preview-close:hover,
            .aar-inbox .aar-issue-attachment-preview-close:focus {
                background: rgba(20, 28, 34, .92);
                color: #fff;
                outline: 0;
            }
            body.aar-issue-preview-open .modal-backdrop.in {
                background: rgba(21, 30, 36, .68);
                opacity: 1;
                -webkit-backdrop-filter: blur(7px);
                backdrop-filter: blur(7px);
            }
            .aar-inbox .aar-message-offer-context {
                display: flex;
                align-items: center;
                gap: 10px;
                margin-top: 12px;
                padding-top: 10px;
                border-top: 1px solid rgba(83, 99, 106, .2);
            }
            .aar-inbox .aar-message-offer-context img {
                flex: 0 0 58px;
                width: 58px;
                height: 58px;
                border: 1px solid #d8dde0;
                border-radius: 5px;
                background: #fff;
                object-fit: contain;
            }
            .aar-inbox .aar-message-offer-context span {
                display: flex;
                min-width: 0;
                flex-direction: column;
                line-height: 1.3;
            }
            .aar-inbox .aar-message-offer-context small {
                margin-bottom: 3px;
                color: #6c757d;
            }
            .aar-inbox .aar-message-offer-context strong {
                color: #363a41;
                font-weight: 600;
                overflow-wrap: anywhere;
            }
            .aar-inbox .aar-claim-summary {
                margin-bottom: 18px;
            }
            .aar-inbox .aar-claim-topbar {
                display: flex;
                align-items: flex-start;
                justify-content: space-between;
                gap: 14px;
                margin-bottom: 14px;
            }
            .aar-inbox .aar-claim-topbar-badges {
                justify-content: flex-end;
            }
            .aar-inbox .aar-claim-label {
                font-size: 12px;
                color: #7a8288;
                text-transform: uppercase;
                letter-spacing: .04em;
            }
            .aar-inbox .aar-claim-badges {
                display: flex;
                flex-wrap: wrap;
                justify-content: flex-end;
                gap: 8px;
            }
            .aar-inbox .aar-header-claim-badges {
                flex: 0 0 auto;
                align-self: center;
            }
            .aar-inbox .aar-claim-badge {
                display: inline-flex;
                align-items: center;
                min-height: 28px;
                padding: 4px 10px;
                background: #fff;
                border: 1px solid #d8dde0;
                border-radius: 6px;
                color: #4f5a64;
                font-size: 12px;
                font-weight: 700;
            }
            .aar-inbox .aar-claim-status.is-ok {
                background: #1f9d68;
                border-color: #1f9d68;
                color: #fff;
            }
            .aar-inbox .aar-claim-status.is-warning {
                background: #d89a28;
                border-color: #d89a28;
                color: #fff;
            }
            .aar-inbox .aar-claim-status.is-overdue {
                background: #d64545;
                border-color: #d64545;
                color: #fff;
            }
            .aar-inbox .aar-claim-status.is-neutral {
                background: #6b7280;
                border-color: #6b7280;
                color: #fff;
            }
            .aar-inbox .aar-claim-deadline {
                padding: 16px 18px;
                background: #fff;
                border: 1px solid #d8dde0;
                border-radius: 6px;
                margin-bottom: 16px;
            }
            .aar-inbox .aar-claim-deadline.is-warning {
                border-color: #ffd597;
                background: #fffaf1;
            }
            .aar-inbox .aar-claim-deadline.is-overdue {
                border-color: #f2b8b8;
                background: #fff4f4;
            }
            .aar-inbox .aar-claim-deadline-head {
                display: flex;
                align-items: flex-start;
                justify-content: space-between;
                gap: 16px;
                margin-bottom: 12px;
            }
            .aar-inbox .aar-claim-deadline-head strong {
                display: block;
                color: #2d3033;
                font-size: 18px;
                margin-bottom: 4px;
            }
            .aar-inbox .aar-claim-deadline-sub,
            .aar-inbox .aar-claim-deadline-date span {
                color: #7a8288;
                font-size: 12px;
            }
            .aar-inbox .aar-claim-deadline-date {
                display: flex;
                flex-direction: column;
                align-items: flex-end;
                gap: 4px;
            }
            .aar-inbox .aar-claim-deadline-date strong {
                font-size: 16px;
                margin: 0;
            }
            .aar-inbox .aar-claim-progress {
                position: relative;
                height: 10px;
                background: #e7edf1;
                border-radius: 999px;
                overflow: visible;
            }
            .aar-inbox .aar-claim-progress span {
                display: block;
                height: 100%;
                background: linear-gradient(90deg, #25b7a8 0%, #0b7f72 100%);
                border-radius: 999px;
            }
            .aar-inbox .aar-claim-deadline.is-warning .aar-claim-progress span {
                background: linear-gradient(90deg, #f5b942 0%, #d68b00 100%);
            }
            .aar-inbox .aar-claim-deadline.is-overdue .aar-claim-progress span {
                background: linear-gradient(90deg, #f97066 0%, #d92d20 100%);
            }
            .aar-inbox .aar-claim-deadline.is-warning .aar-claim-progress-marker {
                border-color: #d68b00;
            }
            .aar-inbox .aar-claim-deadline.is-overdue .aar-claim-progress-marker {
                border-color: #d92d20;
            }
            .aar-inbox .aar-claim-deadline.is-warning .aar-claim-progress-flag {
                background: #d68b00;
            }
            .aar-inbox .aar-claim-deadline.is-overdue .aar-claim-progress-flag {
                background: #d92d20;
            }
            .aar-inbox .aar-claim-grid {
                display: grid;
                grid-template-columns: repeat(2, minmax(0, 1fr));
                gap: 14px;
                margin-bottom: 18px;
            }
            .aar-inbox .aar-claim-card {
                padding: 16px 18px;
                background: #fff;
                border: 1px solid #d8dde0;
                border-radius: 6px;
            }
            .aar-inbox .aar-claim-card h5 {
                margin: 0 0 12px;
                font-size: 15px;
                font-weight: 700;
                color: #2d3033;
            }
            .aar-inbox .aar-claim-card dl {
                margin: 0;
            }
            .aar-inbox .aar-claim-row + .aar-claim-row {
                margin-top: 8px;
                padding-top: 8px;
                border-top: 1px solid #eef2f4;
            }
            .aar-inbox .aar-claim-row {
                display: grid;
                grid-template-columns: max-content minmax(0, 1fr);
                column-gap: 6px;
                align-items: baseline;
            }
            .aar-inbox .aar-claim-row dt {
                margin: 0;
                font-size: 13px;
                color: #7a8288;
                font-weight: 700;
                white-space: nowrap;
            }
            .aar-inbox .aar-claim-row dt::after {
                content: ":";
            }
            .aar-inbox .aar-claim-row dd {
                margin: 0;
                font-size: 14px;
                color: #2d3033;
                font-weight: 600;
                min-width: 0;
                overflow-wrap: anywhere;
            }
            .aar-inbox .aar-claim-body {
                margin-top: 12px;
                padding-top: 12px;
                border-top: 1px solid #eef2f4;
                color: #2d3033;
                line-height: 1.55;
            }
            .aar-inbox .aar-claim-card dl + .aar-claim-body {
                margin-top: 12px;
                padding-top: 12px;
            }
            .aar-inbox .aar-claim-card > h5 + .aar-claim-body {
                margin-top: 0;
                padding-top: 0;
                border-top: 0;
            }
            .aar-inbox .aar-checkout-details {
                display: grid;
                grid-template-columns: repeat(2, minmax(0, 1fr));
                gap: 28px;
                align-items: start;
            }
            .aar-inbox .aar-checkout-details-section {
                min-width: 0;
            }
            .aar-inbox .aar-checkout-details-section:first-child {
                padding-top: 0;
            }
            .aar-inbox .aar-checkout-details-section span {
                display: block;
                color: #2d3033;
                font-size: 14px;
                font-weight: 600;
                overflow-wrap: anywhere;
            }
            .aar-inbox .aar-checkout-details-section span + span {
                margin-top: 4px;
            }
            .aar-inbox .aar-claim-order-link {
                margin-top: 14px;
                padding-top: 14px;
                border-top: 1px solid #eef2f4;
                display: flex;
                flex-direction: column;
                gap: 8px;
                color: #2d3033;
            }
            .aar-inbox .aar-inline-order-button {
                align-self: flex-start;
                border-radius: 6px;
            }
            .aar-inbox .aar-claim-link-meta {
                font-size: 12px;
                color: #7a8288;
            }
            .aar-inbox .aar-claim-workflow {
                margin: 20px 0 24px;
                padding: 20px;
                border: 1px solid #d8dde0;
                border-radius: 8px;
                background: #f7f9fa;
            }
            .aar-inbox .aar-claim-workflow > h4 {
                margin: 0 0 16px;
                color: #2d3033;
                font-size: 20px;
                font-weight: 700;
            }
            .aar-inbox .aar-claim-workflow-step {
                padding: 18px;
                border: 1px solid #e1e6ea;
                border-radius: 6px;
                background: #fff;
            }
            .aar-inbox .aar-claim-workflow-step + .aar-claim-workflow-step {
                margin-top: 14px;
            }
            .aar-inbox .aar-claim-workflow-step-head {
                display: flex;
                align-items: baseline;
                justify-content: space-between;
                gap: 18px;
                margin-bottom: 10px;
            }
            .aar-inbox .aar-claim-workflow-step-head strong {
                color: #2d3033;
                font-size: 16px;
            }
            .aar-inbox .aar-claim-workflow-step-head span {
                color: #7a8288;
                font-size: 12px;
                white-space: nowrap;
            }
            .aar-inbox .aar-claim-workflow-step p {
                margin: 0 0 14px;
                color: #4f5a64;
                line-height: 1.45;
            }
            .aar-inbox .aar-claim-workflow-step p:last-child {
                margin-bottom: 0;
            }
            .aar-inbox .aar-claim-workflow-state.is-set {
                color: #198754;
                font-weight: 700;
            }
            .aar-inbox .aar-claim-workflow-return-state {
                display: flex;
                align-items: flex-start;
                gap: 12px;
                padding: 14px 16px;
                border: 1px solid #c8e3d1;
                border-radius: 8px;
                background: #f0f8f3;
                color: #245c38;
            }
            .aar-inbox .aar-claim-workflow-return-icon {
                display: inline-flex;
                align-items: center;
                justify-content: center;
                width: 26px;
                height: 26px;
                flex: 0 0 26px;
                border-radius: 50%;
                background: #3f8f5b;
                color: #fff;
                font-size: 13px;
                line-height: 1;
            }
            .aar-inbox .aar-claim-workflow-return-copy {
                display: flex;
                min-width: 0;
                flex-direction: column;
                gap: 2px;
            }
            .aar-inbox .aar-claim-workflow-return-copy strong {
                color: #245c38;
                font-size: 14px;
                font-weight: 700;
                line-height: 1.35;
            }
            .aar-inbox .aar-claim-workflow-return-copy span {
                color: #4f6f5a;
                font-size: 13px;
                font-weight: 400;
                line-height: 1.45;
            }
            .aar-inbox .aar-claim-workflow-actions {
                display: flex;
                flex-wrap: wrap;
                gap: 10px;
            }
            .aar-inbox .aar-claim-workflow-actions .btn {
                min-width: 160px;
                border-radius: 6px;
                font-weight: 700;
            }
            .aar-inbox .aar-claim-action-modal .modal-dialog {
                width: min(820px, calc(100vw - 40px));
            }
            .aar-inbox .aar-claim-return-modal .modal-dialog {
                width: min(1100px, calc(100vw - 40px));
            }
            .aar-inbox .aar-claim-action-modal .modal-content {
                overflow: hidden;
                border-top: 6px solid #25b9d7;
                border-radius: 8px;
            }
            .aar-inbox .aar-claim-action-modal .modal-header {
                padding: 22px;
                border-bottom: 1px solid #d8dde0;
                background: #fff;
            }
            .aar-inbox .aar-claim-action-modal .modal-header .close {
                margin-top: 0;
                font-size: 30px;
                line-height: 1;
            }
            .aar-inbox .aar-claim-action-modal .modal-title {
                margin: 0;
                color: #2d3033;
                font-size: 26px;
                font-weight: 700;
                line-height: 1.25;
            }
            .aar-inbox .aar-claim-action-modal .modal-body {
                padding: 22px;
                color: #2d3033;
                font-size: 16px;
                line-height: 1.5;
            }
            .aar-inbox .aar-claim-action-modal .modal-body p,
            .aar-inbox .aar-claim-action-modal .modal-body .alert,
            .aar-inbox .aar-claim-action-modal .modal-body label {
                font-size: 16px;
                line-height: 1.5;
            }
            .aar-inbox .aar-claim-action-modal .modal-footer {
                padding: 18px 22px;
                border-top: 1px solid #d8dde0;
                background: #fff;
            }
            .aar-inbox .aar-claim-action-modal h5 {
                margin: 0 0 12px;
                color: #2d3033;
                font-size: 16px;
                font-weight: 700;
            }
            .aar-inbox .aar-claim-return-intro {
                margin-bottom: 20px;
                color: #2d3033;
                font-size: 16px;
                line-height: 1.5;
            }
            .aar-inbox .aar-claim-return-methods {
                margin-bottom: 20px;
            }
            .aar-inbox .aar-claim-return-method {
                display: flex;
                align-items: flex-start;
                gap: 14px;
                margin: 0;
                padding: 16px 0;
                color: #2d3033;
                cursor: pointer;
                font-weight: 400;
            }
            .aar-inbox .aar-claim-return-method + .aar-claim-return-method,
            .aar-inbox .aar-claim-return-method-fields + .aar-claim-return-method {
                border-top: 1px solid #eef2f4;
            }
            .aar-inbox .aar-claim-return-method > input {
                width: 20px;
                height: 20px;
                margin: 2px 0 0;
                flex: 0 0 auto;
            }
            .aar-inbox .aar-claim-return-method-radio {
                width: 20px;
                height: 20px;
                margin-top: 2px;
                border: 2px solid #7a8288;
                border-radius: 50%;
                flex: 0 0 auto;
            }
            .aar-inbox .aar-claim-return-method-body {
                display: block;
                min-width: 0;
            }
            .aar-inbox .aar-claim-return-method-body strong,
            .aar-inbox .aar-claim-return-method-body span {
                display: block;
            }
            .aar-inbox .aar-claim-return-method-body strong {
                margin-bottom: 5px;
                font-size: 16px;
                font-weight: 700;
            }
            .aar-inbox .aar-claim-return-method-body span {
                color: #7a8288;
                font-size: 16px;
                line-height: 1.5;
            }
            .aar-inbox .aar-claim-return-method.is-disabled {
                color: #a8afb5;
                cursor: not-allowed;
            }
            .aar-inbox .aar-claim-return-method.is-disabled .aar-claim-return-method-body span {
                color: #a8afb5;
            }
            .aar-inbox .aar-claim-return-method-body .aar-claim-smart-label {
                display: inline;
                color: #47257f;
                font-weight: 800;
            }
            .aar-inbox .aar-claim-return-method-body .aar-claim-help-link,
            .aar-inbox .aar-claim-return-method-body .aar-claim-help-link:visited {
                color: #0b7f72;
                font-weight: 600;
                text-decoration: underline;
            }
            .aar-inbox .aar-claim-return-method-body .aar-claim-smart-open {
                display: inline-block;
                margin-top: 12px;
                color: #fff;
                font-size: 14px;
                line-height: 1.4;
                text-decoration: none;
            }
            .aar-inbox .aar-claim-return-method-body .aar-claim-smart-open:hover,
            .aar-inbox .aar-claim-return-method-body .aar-claim-smart-open:focus,
            .aar-inbox .aar-claim-return-method-body .aar-claim-smart-open:visited {
                color: #fff;
                text-decoration: none;
            }
            .aar-inbox .aar-claim-return-method-fields {
                margin: 0 0 10px 34px;
                padding: 16px;
                border-radius: 6px;
                background: #f7f9fa;
            }
            .aar-inbox .aar-claim-return-method-fields .form-group {
                margin-bottom: 0;
            }
            .aar-inbox .aar-claim-return-method-fields .form-group + .form-group {
                margin-top: 14px;
            }
            .aar-inbox .aar-claim-label-dropzone {
                position: relative;
                display: flex;
                min-height: 74px;
                margin: 0;
                padding: 14px;
                border: 2px dashed #8b9298;
                border-radius: 6px;
                background: #fff;
                align-items: center;
                justify-content: center;
                flex-direction: column;
                gap: 5px;
                overflow: hidden;
                cursor: pointer;
                text-align: center;
            }
            .aar-inbox .aar-claim-label-dropzone:hover,
            .aar-inbox .aar-claim-label-dropzone:focus-within {
                border-color: #25b9d7;
                background: #f9fdfe;
            }
            .aar-inbox .aar-claim-label-dropzone input[type="file"] {
                position: absolute;
                inset: 0;
                width: 100%;
                height: 100%;
                opacity: 0;
                cursor: pointer;
            }
            .aar-inbox .aar-claim-label-dropzone-title {
                color: #218f83;
                font-size: 15px;
                font-weight: 800;
                letter-spacing: 2px;
                text-transform: uppercase;
            }
            .aar-inbox .aar-claim-label-file-name {
                color: #7a8288;
                font-size: 12px;
                font-weight: 600;
            }
            .aar-inbox .aar-claim-return-message-wrap textarea {
                resize: vertical;
            }
            .aar-inbox .aar-claim-char-counter {
                margin-top: 5px;
                color: #7a8288;
                font-size: 12px;
                text-align: right;
            }
            .aar-inbox .aar-claim-confirm {
                display: flex;
                align-items: flex-start;
                gap: 10px;
                color: #2d3033;
                font-size: 16px;
                font-weight: 400;
                line-height: 1.5;
            }
            .aar-inbox .aar-claim-confirm input[type="checkbox"] {
                -webkit-appearance: none;
                appearance: none;
                width: 24px;
                height: 24px;
                margin-top: 3px;
                border: 2px solid #b3c8ce;
                border-radius: 4px;
                background-color: #fff;
                background-position: center;
                background-repeat: no-repeat;
                background-size: 16px 16px;
                flex: 0 0 auto;
                cursor: pointer;
                transition: border-color .15s ease, background-color .15s ease, box-shadow .15s ease;
            }
            .aar-inbox .aar-claim-confirm input[type="checkbox"]:hover {
                border-color: #25b9d7;
            }
            .aar-inbox .aar-claim-confirm input[type="checkbox"]:focus {
                border-color: #25b9d7;
                outline: 0;
                box-shadow: 0 0 0 3px rgba(37, 185, 215, .2);
            }
            .aar-inbox .aar-claim-confirm input[type="checkbox"]:checked {
                border-color: #25b9d7;
                background-color: #25b9d7;
                background-image: url("data:image/svg+xml,%3Csvg xmlns=%27http://www.w3.org/2000/svg%27 viewBox=%270 0 16 16%27%3E%3Cpath fill=%27none%27 stroke=%27%23fff%27 stroke-linecap=%27round%27 stroke-linejoin=%27round%27 stroke-width=%273%27 d=%27M2.5 8.5 6 12l7.5-8%27/%3E%3C/svg%3E");
            }
            .aar-inbox .aar-claim-status-options {
                display: flex;
                flex-direction: column;
                gap: 0;
                margin-bottom: 22px;
            }
            .aar-inbox .aar-claim-status-description,
            .aar-inbox .aar-claim-status-heading {
                margin: 0 0 14px;
                color: #2d3033;
                font-size: 16px;
                font-weight: 400;
                line-height: 1.5;
            }
            .aar-inbox .aar-claim-status-heading {
                margin-bottom: 8px;
            }
            .aar-inbox .aar-claim-status-option {
                display: flex;
                align-items: center;
                gap: 10px;
                margin: 0;
                padding: 8px 0;
                border: 0;
                border-radius: 0;
                background: transparent;
                color: #2d3033;
                cursor: pointer;
                font-size: 16px;
                font-weight: 400;
                line-height: 1.5;
            }
            .aar-inbox .aar-claim-status-option input {
                margin: 0;
                flex: 0 0 auto;
            }
            .aar-inbox .aar-claim-status-option span,
            .aar-inbox .aar-claim-status-message > label {
                font-weight: 400;
            }
            .aar-inbox .aar-claim-partial-refund {
                margin: 0 0 22px;
                padding: 16px;
                border-radius: 6px;
                background: #f7f9fa;
            }
            .aar-inbox .aar-claim-partial-refund p {
                margin-bottom: 10px;
            }
            .aar-inbox .aar-claim-status-message {
                margin-top: 18px;
            }
            .aar-inbox .aar-return-products {
                padding: 0 0 18px;
                margin: 0 0 18px;
                border-bottom: 1px solid #e1e6ea;
            }
            .aar-inbox .aar-return-product-row {
                display: grid;
                grid-template-columns: minmax(0, 1fr) minmax(120px, auto);
                gap: 18px;
                padding: 14px 0;
                border-bottom: 1px solid #eef2f4;
            }
            .aar-inbox .aar-return-product-row.has-thumb {
                grid-template-columns: 76px minmax(0, 1fr) minmax(120px, auto);
            }
            .aar-inbox .aar-return-product-thumb {
                width: 76px;
                height: 76px;
                border: 1px solid #d8dde0;
                border-radius: 6px;
                background: #f4f6f8;
                overflow: hidden;
            }
            .aar-inbox .aar-return-product-thumb img {
                width: 100%;
                height: 100%;
                object-fit: cover;
                display: block;
            }
            .aar-inbox .aar-return-product-row:last-child {
                border-bottom: 0;
                padding-bottom: 0;
            }
            .aar-inbox .aar-return-product-main {
                min-width: 0;
            }
            .aar-inbox .aar-return-product-main strong {
                display: block;
                color: #2d3033;
                font-size: 15px;
                line-height: 1.35;
            }
            .aar-inbox .aar-return-product-main a {
                color: #2d3033;
                text-decoration: none;
            }
            .aar-inbox .aar-return-product-main a:hover {
                color: #25b9d7;
            }
            .aar-inbox .aar-return-reason {
                margin-top: 10px;
                color: #2d3033;
                font-size: 14px;
            }
            .aar-inbox .aar-return-reason span {
                color: #7a8288;
            }
            .aar-inbox .aar-return-product-side {
                text-align: right;
                color: #2d3033;
                white-space: nowrap;
            }
            .aar-inbox .aar-return-product-side strong {
                display: block;
                margin-top: 8px;
                color: #4f5a64;
                font-size: 15px;
            }
            .aar-inbox .aar-return-simple-grid {
                display: grid;
                grid-template-columns: 1.2fr 1fr 1fr 1.15fr;
                gap: 26px;
                align-items: start;
            }
            .aar-inbox .aar-return-simple-section {
                min-width: 0;
            }
            .aar-inbox .aar-return-simple-section h5 {
                margin: 0 0 14px;
                color: #2d3033;
                font-size: 16px;
                font-weight: 700;
            }
            .aar-inbox .aar-return-debug-link-wrap {
                margin: 14px 0 0 36px;
            }
            .aar-inbox .aar-return-debug-link {
                color: #25b9d7;
                font-size: 12px;
                font-weight: 700;
                text-transform: uppercase;
                letter-spacing: 0;
                padding: 0;
                border: 0;
                background: transparent;
            }
            .aar-inbox .aar-return-debug-link:hover,
            .aar-inbox .aar-return-debug-link:focus {
                color: #1b90a8;
                text-decoration: none;
            }
            .aar-inbox .aar-return-tracking-link {
                padding: 0;
                border: 0;
                background: transparent;
                color: #25b9d7;
                font-size: 14px;
                line-height: 1.45;
            }
            .aar-inbox .aar-return-tracking-link:hover,
            .aar-inbox .aar-return-tracking-link:focus {
                color: #1b90a8;
                text-decoration: none;
            }
            .aar-inbox .aar-return-tracking-modal .modal-dialog,
            .aar-inbox .aar-return-refund-modal .modal-dialog,
            .aar-inbox .aar-return-rejection-modal .modal-dialog,
            .aar-inbox .aar-return-debug-modal .modal-dialog {
                width: min(1100px, calc(100vw - 40px));
            }
            .aar-inbox .aar-return-tracking-modal .modal-dialog {
                width: min(720px, calc(100vw - 40px));
            }
            .aar-inbox .aar-return-refund-modal .modal-dialog {
                width: min(900px, calc(100vw - 40px));
            }
            .aar-inbox .aar-return-rejection-modal .modal-dialog {
                width: min(760px, calc(100vw - 40px));
            }
            .aar-inbox .aar-return-tracking-modal .modal-content,
            .aar-inbox .aar-return-refund-modal .modal-content,
            .aar-inbox .aar-return-rejection-modal .modal-content,
            .aar-inbox .aar-return-debug-modal .modal-content {
                border-radius: 6px;
            }
            .aar-inbox .aar-return-tracking-header {
                display: flex;
                align-items: center;
                justify-content: space-between;
                gap: 16px;
            }
            .aar-inbox .aar-return-tracking-header > .close {
                margin: 0 0 0 auto;
                float: none;
                flex: 0 0 auto;
                align-self: flex-start;
            }
            .aar-inbox .aar-return-tracking-header-main {
                display: flex;
                align-items: baseline;
                flex-wrap: wrap;
                gap: 12px;
                min-width: 0;
            }
            .aar-inbox .aar-return-tracking-header-main .modal-title {
                margin: 0;
                flex: 0 0 auto;
            }
            .aar-inbox .aar-return-tracking-header-meta {
                display: inline-flex;
                align-items: baseline;
                flex-wrap: wrap;
                gap: 12px;
                min-width: 0;
                color: #4f5a64;
            }
            .aar-inbox .aar-return-tracking-header-meta strong {
                color: #2d3033;
                font-size: 16px;
                line-height: 1.3;
            }
            .aar-inbox .aar-return-tracking-modal .modal-body,
            .aar-inbox .aar-return-refund-modal .modal-body,
            .aar-inbox .aar-return-rejection-modal .modal-body,
            .aar-inbox .aar-return-debug-modal .modal-body {
                padding: 16px 18px 18px;
            }
            .aar-inbox .aar-return-tracking-timeline {
                display: block;
                margin: 0;
                padding: 0;
            }
            .aar-inbox .aar-return-tracking-step {
                position: relative;
                min-width: 0;
                min-height: 56px;
                padding: 0 0 18px 34px;
                color: #7a8288;
            }
            .aar-inbox .aar-return-tracking-step:last-child {
                min-height: 0;
                padding-bottom: 0;
            }
            .aar-inbox .aar-return-tracking-step:before,
            .aar-inbox .aar-return-tracking-step:after {
                content: "";
                position: absolute;
                left: 6px;
                width: 6px;
                background: #e3e7ea;
                z-index: 1;
            }
            .aar-inbox .aar-return-tracking-step:before {
                top: 0;
                height: 8px;
            }
            .aar-inbox .aar-return-tracking-step:after {
                top: 16px;
                bottom: 0;
            }
            .aar-inbox .aar-return-tracking-step:first-child:before,
            .aar-inbox .aar-return-tracking-step:last-child:after {
                display: none;
            }
            .aar-inbox .aar-return-tracking-step.is-completed:before,
            .aar-inbox .aar-return-tracking-step.has-next-completed:after,
            .aar-inbox .aar-return-tracking-step.is-active:before {
                background: #25b9d7;
            }
            .aar-inbox .aar-return-tracking-step.is-active:after {
                background: #e3e7ea;
            }
            .aar-inbox .aar-return-tracking-marker {
                position: absolute;
                top: 1px;
                left: 8px;
                width: 16px;
                height: 16px;
                margin-left: -8px;
                border-radius: 999px;
                background: #d9dde1;
                box-shadow: 0 0 0 4px #fff;
                z-index: 2;
            }
            .aar-inbox .aar-return-tracking-step.is-completed .aar-return-tracking-marker {
                background: #25b9d7;
            }
            .aar-inbox .aar-return-tracking-step.is-active .aar-return-tracking-marker {
                width: 18px;
                height: 18px;
                top: 0;
                margin-left: -9px;
                background: #25b9d7;
            }
            .aar-inbox .aar-return-tracking-label {
                color: #2d3033;
                font-size: 15px;
                font-weight: 600;
                line-height: 1.35;
            }
            .aar-inbox .aar-return-tracking-step.is-active .aar-return-tracking-label {
                font-weight: 800;
                color: #25b9d7;
            }
            .aar-inbox .aar-return-tracking-date {
                margin-top: 4px;
                color: #2d3033;
                font-size: 14px;
                font-weight: 600;
            }
            .aar-inbox .aar-return-tracking-code {
                margin-top: 4px;
                color: #7a8288;
                font-size: 12px;
                line-height: 1.35;
            }
            .aar-inbox .aar-return-debug-head {
                display: flex;
                align-items: center;
                justify-content: flex-end;
                gap: 12px;
                margin-bottom: 10px;
            }
            .aar-inbox .aar-return-debug-json {
                margin: 0;
                max-height: min(70vh, 760px);
                overflow: auto;
                padding: 12px;
                background: #f7f9fa;
                border: 1px solid #e3e7ea;
                border-radius: 4px;
                color: #2d3033;
                font-size: 12px;
                line-height: 1.45;
                white-space: pre-wrap;
                word-break: break-word;
            }
            .aar-inbox .aar-return-simple-section div {
                color: #2d3033;
                font-size: 14px;
                line-height: 1.45;
                overflow-wrap: anywhere;
            }
            .aar-inbox .aar-return-simple-section .text-muted {
                color: #7a8288;
            }
            .aar-inbox .aar-return-refund-section {
                min-width: 260px;
            }
            .aar-inbox .aar-return-refund-account {
                white-space: nowrap;
                overflow-wrap: normal !important;
                word-break: keep-all;
            }
            .aar-inbox .aar-return-invoice-flag {
                display: inline-flex;
                align-items: center;
                min-height: 22px;
                margin-top: 8px;
                padding: 2px 8px;
                border-radius: 6px;
                font-size: 12px;
                font-weight: 700;
                line-height: 1.2;
            }
            .aar-inbox .aar-return-invoice-flag.is-invoice {
                background: #2d3033;
                color: #fff;
            }
            .aar-inbox .aar-return-invoice-flag.is-no-invoice {
                background: #eef2f4;
                color: #4f5a64;
            }
            .aar-inbox .aar-return-subheading {
                margin-top: 22px !important;
            }
            .aar-inbox .aar-return-total {
                margin-top: 28px;
                text-align: right;
            }
            .aar-inbox .aar-return-total span {
                display: block;
                color: #2d3033;
                font-size: 13px;
                text-transform: uppercase;
            }
            .aar-inbox .aar-return-total strong {
                display: block;
                color: #4f5a64;
                font-size: 16px;
            }
            .aar-inbox .aar-return-decision-panel {
                padding: 14px 20px 18px;
                background: #fbfcfc;
                border-top: 1px solid #d8dde0;
                flex: 0 0 auto;
            }
            .aar-inbox .aar-return-decision-panel-head {
                display: flex;
                align-items: center;
                justify-content: space-between;
                gap: 18px;
            }
            .aar-inbox .aar-return-decision-dropdown {
                position: relative;
            }
            .aar-inbox .aar-return-decision-total {
                margin-left: auto;
                text-align: right;
                flex: 0 0 auto;
            }
            .aar-inbox .aar-return-decision-total span {
                display: block;
                color: #2d3033;
                font-size: 13px;
                text-transform: uppercase;
            }
            .aar-inbox .aar-return-decision-total strong {
                display: block;
                color: #4f5a64;
                font-size: 16px;
            }
            .aar-inbox .aar-return-decision-menu {
                top: auto;
                bottom: calc(100% + 4px);
                min-width: 230px;
            }
            .aar-inbox .aar-return-timeline {
                display: block;
                margin: 0;
                padding: 0;
                background: transparent;
                border: 0;
                border-radius: 0;
            }
            .aar-inbox .aar-return-timeline-step {
                position: relative;
                min-width: 0;
                min-height: 52px;
                padding: 0 0 16px 34px;
                color: #7a8288;
            }
            .aar-inbox .aar-return-timeline-step:last-child {
                min-height: 0;
                padding-bottom: 0;
            }
            .aar-inbox .aar-return-timeline-step:before,
            .aar-inbox .aar-return-timeline-step:after {
                content: "";
                position: absolute;
                left: 6px;
                width: 6px;
                background: #e3e7ea;
                z-index: 1;
            }
            .aar-inbox .aar-return-timeline-step:before {
                top: 0;
                height: 8px;
            }
            .aar-inbox .aar-return-timeline-step:after {
                top: 16px;
                bottom: 0;
            }
            .aar-inbox .aar-return-timeline-step:first-child:before,
            .aar-inbox .aar-return-timeline-step:last-child:after {
                display: none;
            }
            .aar-inbox .aar-return-timeline-step.is-completed:before,
            .aar-inbox .aar-return-timeline-step.has-next-completed:after,
            .aar-inbox .aar-return-timeline-step.is-active:before {
                background: #25b9d7;
            }
            .aar-inbox .aar-return-timeline-step.is-active:after {
                background: #e3e7ea;
            }
            .aar-inbox .aar-return-timeline-marker {
                position: absolute;
                top: 1px;
                left: 8px;
                width: 16px;
                height: 16px;
                margin-left: -8px;
                border-radius: 999px;
                background: #d9dde1;
                border: 0;
                box-shadow: 0 0 0 4px #fff;
                z-index: 2;
            }
            .aar-inbox .aar-return-timeline-step.is-completed .aar-return-timeline-marker {
                background: #25b9d7;
                box-shadow: 0 0 0 4px #fff;
            }
            .aar-inbox .aar-return-timeline-step.is-active .aar-return-timeline-marker {
                width: 18px;
                height: 18px;
                top: 0;
                margin-left: -9px;
                background: #25b9d7;
                box-shadow: 0 0 0 4px #fff;
            }
            .aar-inbox .aar-return-timeline-label {
                padding: 0;
                text-align: left;
                color: #2d3033;
                font-size: 14px;
                font-weight: 600;
                line-height: 1.25;
                overflow-wrap: anywhere;
            }
            .aar-inbox .aar-return-timeline-step.is-completed .aar-return-timeline-label {
                color: #25b9d7;
            }
            .aar-inbox .aar-return-timeline-step.is-active .aar-return-timeline-label {
                font-weight: 800;
                color: #25b9d7;
            }
            .aar-inbox .aar-return-timeline-date {
                margin-top: 4px;
                padding: 0;
                text-align: left;
                color: #7a8288;
                font-size: 12px;
                line-height: 1.3;
            }
            .aar-inbox .aar-reply-form {
                margin-top: 0;
                margin-bottom: 0;
                padding: 12px 20px 12px;
                background: #fbfcfc;
                border-top: 1px solid #d8dde0;
                flex: 0 0 auto;
            }
            .aar-inbox .aar-return-decision-panel .aar-reply-form {
                margin-top: 14px;
                padding: 0;
                background: transparent;
                border-top: 0;
                position: static;
            }
            .aar-inbox .aar-return-decision-panel .aar-return-rejection-form.is-collapsed,
            .aar-inbox .aar-return-decision-panel .aar-return-refund-form.is-collapsed {
                display: none;
            }
            .aar-inbox .aar-return-refund-grid {
                display: grid;
                grid-template-columns: minmax(0, 1fr) auto;
                gap: 12px;
                align-items: end;
                padding: 14px 20px 18px;
                background: #fbfcfc;
                border-top: 1px solid #d8dde0;
            }
            .aar-inbox .aar-return-refund-line {
                display: grid;
                grid-template-columns: minmax(180px, 1fr) minmax(150px, 220px);
                gap: 10px;
                align-items: end;
                grid-column: 1 / -1;
            }
            .aar-inbox .aar-return-refund-reasons-wrap {
                grid-column: 1 / -1;
                margin-bottom: 4px;
            }
            .aar-inbox .aar-return-refund-reasons-wrap h5 {
                margin: 0;
                color: #2d3033;
                font-size: 28px;
                font-weight: 700;
            }
            .aar-inbox .aar-return-refund-reasons-hint {
                margin: 8px 0 12px;
                color: #6f757a;
                font-size: 15px;
            }
            .aar-inbox .aar-return-refund-reasons {
                display: block;
            }
            .aar-inbox .aar-return-refund-option {
                display: flex;
                align-items: center;
                gap: 10px;
                margin: 0 0 10px;
                cursor: pointer;
                color: #2d3033;
                font-size: 15px;
                font-weight: 500;
            }
            .aar-inbox .aar-return-refund-option input[type=radio] {
                margin: 0;
                flex: 0 0 auto;
            }
            .aar-inbox .aar-return-refund-reason {
                grid-template-columns: minmax(180px, 1fr) minmax(220px, 360px);
            }
            .aar-inbox .aar-return-refund-line label {
                margin: 0;
                color: #363a41;
                font-weight: 600;
                line-height: 1.25;
            }
            .aar-inbox .aar-return-refund-line label span {
                display: block;
                margin-top: 3px;
                color: #7a8288;
                font-size: 12px;
                font-weight: 400;
            }
            .aar-inbox .aar-return-refund-grid textarea {
                grid-column: 1 / 2;
            }
            .aar-inbox .aar-return-refund-grid textarea,
            .aar-inbox .aar-return-refund-grid select {
                min-height: 40px;
            }
            .aar-inbox .aar-return-refund-grid .aar-send-button {
                grid-column: 2 / 3;
                min-height: 56px;
            }
            .aar-inbox .aar-return-rejection-head h5 {
                margin: 0 0 6px;
                font-size: 18px;
                font-weight: 700;
                color: #2d3033;
                line-height: 1.25;
            }
            .aar-inbox .aar-return-rejection-head p {
                margin: 0 0 14px;
                color: #5d6973;
                font-size: 13px;
                line-height: 1.35;
            }
            .aar-inbox .aar-return-rejection-reasons {
                display: block;
                margin: 0;
            }
            .aar-inbox .aar-return-rejection-option {
                display: flex;
                align-items: flex-start;
                gap: 10px;
                margin: 0 0 10px;
                cursor: pointer;
            }
            .aar-inbox .aar-return-rejection-option input[type=radio] {
                margin-top: 2px;
                flex: 0 0 auto;
            }
            .aar-inbox .aar-return-rejection-option-body {
                display: block;
                min-width: 0;
            }
            .aar-inbox .aar-return-rejection-option-label {
                display: block;
                color: #2d3033;
                font-size: 15px;
                font-weight: 600;
                line-height: 1.3;
            }
            .aar-inbox .aar-return-rejection-option-desc {
                display: block;
                margin-top: 2px;
                color: #6f757a;
                font-size: 12px;
                line-height: 1.35;
            }
            .aar-inbox .aar-return-rejection-comment {
                margin-top: 12px;
            }
            .aar-inbox .aar-return-rejection-comment label {
                display: block;
                margin: 0 0 6px;
                color: #2d3033;
                font-weight: 600;
                font-size: 13px;
            }
            .aar-inbox .aar-return-rejection-comment textarea {
                min-height: 94px;
                font-size: 13px;
                line-height: 1.45;
            }
            .aar-inbox .aar-return-rejection-actions {
                display: flex;
                justify-content: flex-end;
                margin-top: 14px;
            }
            .aar-inbox .aar-return-rejection-actions .aar-send-button {
                min-width: 150px;
                min-height: 42px;
            }
            .aar-inbox .aar-reply-form .form-group {
                margin-bottom: 0;
            }
            .aar-inbox .aar-reply-compose {
                display: flex;
                align-items: flex-end;
                gap: 12px;
            }
            .aar-inbox .aar-reply-compose .form-control {
                flex: 1 1 auto;
            }
            .aar-inbox .aar-reply-input-wrap {
                position: relative;
                flex: 1 1 auto;
            }
            .aar-inbox .aar-reply-expand-toggle {
                position: absolute;
                top: -11px;
                left: 50%;
                transform: translateX(-50%);
                display: inline-flex;
                align-items: center;
                justify-content: center;
                width: 56px;
                height: 20px;
                padding: 0;
                border: 1px solid #c8d5df;
                border-radius: 999px;
                background: #ffffff;
                cursor: pointer;
                z-index: 4;
                color: #8198aa;
            }
            .aar-inbox .aar-reply-expand-toggle:hover,
            .aar-inbox .aar-reply-expand-toggle:focus {
                outline: none;
                border-color: #9fb5c4;
                background: #f4f7fa;
            }
            .aar-inbox .aar-reply-input-wrap.is-expanded .aar-reply-expand-toggle {
                border-color: #8bbdb9;
                color: #0b7f72;
                background: #eff8f7;
            }
            .aar-inbox .aar-reply-expand-dots {
                display: inline-flex;
                align-items: center;
                gap: 4px;
            }
            .aar-inbox .aar-reply-expand-dot {
                width: 4px;
                height: 4px;
                border-radius: 50%;
                background: currentColor;
                display: inline-block;
            }
            .aar-inbox .aar-reply-input-wrap .aar-quick-reply-dropup {
                position: absolute;
                right: 10px;
                bottom: 10px;
                z-index: 3;
            }
            .aar-inbox .aar-reply-compose .aar-quick-reply-button {
                width: 36px;
                height: 36px;
                min-width: 36px;
                padding: 0;
                border-radius: 6px;
                text-align: center;
                color: #363a41;
                background: #fff;
                border-color: #bbcdd8;
            }
            .aar-inbox .aar-reply-compose .aar-quick-reply-button:hover,
            .aar-inbox .aar-reply-compose .aar-quick-reply-button:focus {
                background: #f4f6f8;
                border-color: #9bb0bf;
            }
            .aar-inbox .aar-reply-compose .aar-quick-reply-button .aar-quick-reply-icon {
                display: inline-block;
                font-size: 20px;
                line-height: 1;
                margin-top: -1px;
            }
            .aar-inbox .aar-quick-reply-menu {
                width: 300px;
                max-height: 320px;
                overflow-y: auto;
                padding: 6px 0;
            }
            .aar-inbox .aar-quick-reply-option {
                display: block;
                width: 100%;
                padding: 8px 14px;
                border: 0;
                color: #363a41;
                text-align: left;
                background: transparent;
                white-space: normal;
            }
            .aar-inbox .aar-quick-reply-option:hover,
            .aar-inbox .aar-quick-reply-option:focus {
                color: #fff;
                background: #25b7a8;
            }
            .aar-inbox .aar-reply-form textarea.form-control {
                resize: none;
                min-height: 56px;
                max-height: 160px;
                padding: 12px 14px;
                padding-right: 54px;
                border-radius: 6px;
                background: #fff;
                overflow-y: auto;
                transition: min-height .18s ease-in-out, max-height .18s ease-in-out;
            }
            .aar-inbox .aar-reply-input-wrap.is-expanded textarea.form-control {
                min-height: 208px;
                max-height: 360px;
            }
            .aar-inbox .aar-conversation-empty {
                color: #6c757d;
                padding: 24px;
                background: #fff;
                border: 1px dashed #cdd5db;
                border-radius: 6px;
                margin: 20px;
            }
            .aar-inbox textarea.form-control:focus {
                border-color: #25b7a8;
                box-shadow: 0 0 0 1px rgba(37, 183, 168, .18);
            }
            .aar-inbox .btn-primary {
                background: #0b7f72;
                border-color: #0b7f72;
                border-width: 0;
                box-shadow: none;
            }
            .aar-inbox .btn-primary:hover,
            .aar-inbox .btn-primary:focus {
                background: #2d3137;
                border-color: #2d3137;
                box-shadow: none;
            }
            .aar-inbox .aar-reply-compose .aar-send-button {
                flex: 0 0 auto;
                min-width: 108px;
                height: 38px;
                padding: 6px 16px;
                border-radius: 6px;
            }
            @media (max-width: 1199px) {
                .aar-inbox-panel {
                    height: auto;
                    min-height: 0;
                }
                .aar-inbox .aar-thread-list {
                    height: 360px;
                }
                .aar-inbox,
                .aar-inbox .aar-inbox-col-conversation,
                .aar-inbox .aar-conversation-shell {
                    min-height: auto;
                    height: auto;
                }
                .aar-inbox .aar-message-window {
                    min-height: 420px;
                    max-height: none;
                    flex: 0 0 auto;
                }
                .aar-inbox .aar-reply-form {
                    position: static;
                }
                .aar-inbox .aar-return-decision-panel {
                    position: static;
                }
                .aar-inbox .aar-reply-compose {
                    flex-direction: column;
                    align-items: stretch;
                }
                .aar-inbox .aar-quick-reply-menu {
                    width: min(300px, calc(100vw - 90px));
                }
                .aar-inbox .aar-reply-compose .aar-send-button {
                    width: 100%;
                    height: 38px;
                }
                .aar-inbox .aar-claim-topbar,
                .aar-inbox .aar-claim-deadline-head,
                .aar-inbox .aar-conversation-header {
                    flex-direction: column;
                    align-items: stretch;
                }
                .aar-inbox-panel .aar-issues-filters {
                    justify-content: flex-start;
                    flex-wrap: wrap;
                }
                .aar-inbox .aar-claim-badges,
                .aar-inbox .aar-claim-deadline-date {
                    justify-content: flex-start;
                    align-items: flex-start;
                }
                .aar-inbox .aar-thread-deadline-row {
                    flex-direction: column;
                    align-items: flex-start;
                    gap: 4px;
                }
                .aar-inbox .aar-claim-grid {
                    grid-template-columns: 1fr;
                }
                .aar-inbox .aar-return-simple-grid {
                    grid-template-columns: repeat(2, minmax(0, 1fr));
                }
                .aar-inbox .aar-checkout-details {
                    grid-template-columns: 1fr;
                }
            }
            @media (max-width: 767px) {
                .aar-inbox .aar-return-product-row,
                .aar-inbox .aar-return-simple-grid {
                    grid-template-columns: 1fr;
                }
                .aar-inbox .aar-return-product-side,
                .aar-inbox .aar-return-total,
                .aar-inbox .aar-return-decision-total {
                    text-align: left;
                }
                .aar-inbox .aar-return-decision-panel-head {
                    flex-direction: column;
                    align-items: stretch;
                }
                .aar-inbox .aar-return-decision-dropdown {
                    display: flex;
                    width: 100%;
                }
                .aar-inbox .aar-return-decision-dropdown > .btn {
                    width: 100%;
                }
            }
        </style>
        <script>
            (function () {
                var scheduled = false;

                var getViewportHeight = function () {
                    if (window.visualViewport && window.visualViewport.height) {
                        return Math.floor(window.visualViewport.height);
                    }

                    return window.innerHeight;
                };

                var applyInboxHeight = function () {
                    var panel = document.querySelector(".aar-inbox-panel");
                    if (!panel) {
                        return;
                    }

                    if (window.innerWidth <= 1199) {
                        panel.style.removeProperty("--aar-inbox-height");
                        panel.style.removeProperty("--aar-inbox-top-gap");
                        return;
                    }

                    panel.style.removeProperty("--aar-inbox-top-gap");
                    var rect = panel.getBoundingClientRect();
                    var topGap = 10;
                    var coverBottom = 0;
                    var blockers = document.querySelectorAll("#header, .page-head, .bootstrap .page-head, .toolbarBox");
                    blockers.forEach(function (blocker) {
                        if (!blocker || blocker.contains(panel)) {
                            return;
                        }

                        var style = window.getComputedStyle(blocker);
                        if (style.position !== "fixed" && style.position !== "sticky") {
                            return;
                        }

                        var blockerRect = blocker.getBoundingClientRect();
                        if (blockerRect.bottom > 0 && blockerRect.top < rect.top + 8) {
                            coverBottom = Math.max(coverBottom, blockerRect.bottom);
                        }
                    });
                    if (coverBottom > rect.top) {
                        topGap = Math.min(96, Math.ceil(coverBottom - rect.top + 10));
                        panel.style.setProperty("--aar-inbox-top-gap", topGap + "px");
                        rect = panel.getBoundingClientRect();
                    }

                    var bottomGap = 12;
                    var viewportHeight = getViewportHeight();
                    var available = Math.floor(viewportHeight - Math.max(rect.top, 0) - bottomGap);
                    if (available < 320) {
                        available = 320;
                    }

                    panel.style.setProperty("--aar-inbox-height", available + "px");
                };

                var scrollMessagesToBottom = function () {
                    var windows = document.querySelectorAll(".aar-message-window");
                    windows.forEach(function (messageWindow) {
                        messageWindow.scrollTop = messageWindow.scrollHeight;
                    });
                };

                var captureMessageWindowMetrics = function (triggerElement) {
                    var form = triggerElement ? triggerElement.closest(".aar-reply-form") : null;
                    var shell = form ? form.closest(".aar-conversation-shell") : null;
                    var messageWindow = shell ? shell.querySelector(".aar-message-window") : null;
                    if (!messageWindow) {
                        return null;
                    }

                    return {
                        messageWindow: messageWindow,
                        scrollTop: messageWindow.scrollTop,
                        scrollHeight: messageWindow.scrollHeight,
                        clientHeight: messageWindow.clientHeight,
                        isNearBottom: (messageWindow.scrollTop + messageWindow.clientHeight) >= (messageWindow.scrollHeight - 10)
                    };
                };

                var restoreMessageWindowAfterComposerResize = function (snapshot) {
                    if (!snapshot || !snapshot.messageWindow) {
                        return;
                    }

                    window.requestAnimationFrame(function () {
                        var messageWindow = snapshot.messageWindow;
                        if (!messageWindow.isConnected) {
                            return;
                        }

                        if (snapshot.isNearBottom) {
                            messageWindow.scrollTop = messageWindow.scrollHeight;
                            return;
                        }

                        var reducedViewportBy = Math.max(0, snapshot.clientHeight - messageWindow.clientHeight);
                        if (reducedViewportBy > 0) {
                            messageWindow.scrollTop = snapshot.scrollTop + reducedViewportBy;
                        }
                    });
                };

                var scheduleInitialMessageScroll = function () {
                    window.requestAnimationFrame(function () {
                        scrollMessagesToBottom();
                        setTimeout(scrollMessagesToBottom, 50);
                        setTimeout(scrollMessagesToBottom, 250);
                    });
                };

                var loadConversation = function (link, panelSelector, nextPanelSelector) {
                    var panel = link.closest(panelSelector);
                    if (!panel || !window.fetch || !window.DOMParser) {
                        window.location.href = link.href;
                        return;
                    }

                    var target = panel.querySelector(".aar-inbox-col-conversation");
                    if (!target) {
                        window.location.href = link.href;
                        return;
                    }

                    target.classList.add("is-loading");
                    target.innerHTML = '<div class="aar-conversation-loader" role="status" aria-live="polite"><span class="aar-conversation-spinner" aria-hidden="true"></span></div>';

                    fetch(link.href, {
                        credentials: "same-origin",
                        headers: {
                            "X-Requested-With": "XMLHttpRequest"
                        }
                    }).then(function (response) {
                        if (!response.ok) {
                            throw new Error("HTTP " + response.status);
                        }

                        return response.text();
                    }).then(function (html) {
                        var doc = new DOMParser().parseFromString(html, "text/html");
                        var nextTarget = doc.querySelector(nextPanelSelector + " .aar-inbox-col-conversation");
                        if (!nextTarget) {
                            throw new Error("Missing conversation panel");
                        }

                        target.innerHTML = nextTarget.innerHTML;
                        panel.querySelectorAll(".aar-thread-item.active").forEach(function (item) {
                            item.classList.remove("active");
                        });
                        link.classList.add("active");
                        if (window.history && window.history.pushState) {
                            window.history.pushState({}, "", link.href);
                        }
                        rafApply();
                        scheduleInitialMessageScroll();
                    }).catch(function () {
                        window.location.href = link.href;
                    }).finally(function () {
                        target.classList.remove("is-loading");
                    });
                };

                var updateClaimReturnForm = function (form) {
                    if (!form) {
                        return;
                    }

                    var selected = form.querySelector("input[name=claim_return_choice]:checked");
                    var value = selected ? selected.value : "";
                    var submit = form.querySelector(".aar-claim-return-submit");
                    if (submit) {
                        submit.disabled = !value;
                        submit.textContent = value === "SMART" ? "Przejdź do Allegro" : "Wyślij";
                    }

                    form.querySelectorAll("[data-aar-return-fields]").forEach(function (fieldGroup) {
                        var active = fieldGroup.getAttribute("data-aar-return-fields") === value;
                        fieldGroup.style.display = active ? "block" : "none";
                        fieldGroup.querySelectorAll("input,textarea").forEach(function (control) {
                            control.required = active && (
                                (value === "SELLER_LABEL" && control.type === "file")
                                || (value === "CUSTOM" && control.tagName === "TEXTAREA")
                            );
                        });
                    });
                };

                document.addEventListener("submit", function (event) {
                    var form = event.target.closest(".aar-claim-return-method-form");
                    if (!form) {
                        return;
                    }

                    var selected = form.querySelector("input[name=claim_return_choice]:checked");
                    if (!selected || selected.value !== "SMART") {
                        return;
                    }

                    var smartUrl = selected.getAttribute("data-aar-smart-url") || "";
                    if (!smartUrl) {
                        return;
                    }

                    event.preventDefault();
                    var smartWindow = window.open(smartUrl, "_blank");
                    if (smartWindow) {
                        smartWindow.opener = null;
                    }
                });

                document.addEventListener("change", function (event) {
                    var returnChoice = event.target.closest(".aar-claim-return-method-form input[name=claim_return_choice]");
                    if (returnChoice) {
                        updateClaimReturnForm(returnChoice.closest(".aar-claim-return-method-form"));
                        return;
                    }

                    var labelInput = event.target.closest(".aar-claim-return-method-form input[name=claim_return_label]");
                    if (!labelInput) {
                        return;
                    }

                    var labelForm = labelInput.closest(".aar-claim-return-method-form");
                    var fileName = labelForm ? labelForm.querySelector("[data-aar-label-file-name]") : null;
                    if (fileName) {
                        fileName.textContent = labelInput.files && labelInput.files.length
                            ? labelInput.files[0].name
                            : "PDF lub obraz, maksymalnie 2 MB";
                    }
                });

                document.addEventListener("input", function (event) {
                    var textarea = event.target.closest(".aar-claim-return-method-form textarea[maxlength=\"700\"]");
                    if (!textarea) {
                        return;
                    }

                    var returnForm = textarea.closest(".aar-claim-return-method-form");
                    var counter = returnForm ? returnForm.querySelector("[data-aar-count-for=\"" + textarea.id + "\"]") : null;
                    if (counter) {
                        counter.textContent = textarea.value.length;
                    }
                });

                var maybeLoadMoreMessages = function () {
                    var button = document.querySelector(".aar-messages-panel [data-aar-messages-load-more]:not(.is-loading)");
                    if (!button) {
                        return;
                    }
                    var list = button.closest(".aar-thread-list");
                    if (!list) {
                        return;
                    }
                    if (button.getBoundingClientRect().top <= list.getBoundingClientRect().bottom + 80) {
                        button.click();
                    }
                };

                document.addEventListener("scroll", function (event) {
                    if (event.target && event.target.closest && event.target.closest(".aar-messages-panel .aar-thread-list")) {
                        maybeLoadMoreMessages();
                    }
                }, true);
                document.addEventListener("wheel", function (event) {
                    if (event.deltaY > 0 && event.target && event.target.closest && event.target.closest(".aar-messages-panel .aar-thread-list")) {
                        maybeLoadMoreMessages();
                    }
                }, {passive: true, capture: true});
                window.addEventListener("load", function () {
                    var toolbar = document.querySelector(".aar-messages-toolbar[data-aar-message-filter-active=\"1\"]");
                    var column = toolbar ? toolbar.closest(".aar-inbox-col-list") : null;
                    var list = column ? column.querySelector(".aar-thread-list") : null;
                    if (list && list.scrollHeight <= list.clientHeight + 2) {
                        maybeLoadMoreMessages();
                    }
                });
                document.addEventListener("click", function (event) {
                    var attachmentPreviewButton = event.target.closest("[data-aar-issue-attachment-preview]");
                    if (attachmentPreviewButton) {
                        event.preventDefault();
                        var previewUrl = attachmentPreviewButton.getAttribute("data-aar-preview-url") || "";
                        var downloadUrl = attachmentPreviewButton.getAttribute("data-aar-download-url") || previewUrl;
                        var previewName = attachmentPreviewButton.getAttribute("data-aar-preview-name") || "Podgląd załącznika";
                        var previewModal = document.getElementById("aar-issue-attachment-preview-modal");
                        var previewImage = previewModal ? previewModal.querySelector("[data-aar-issue-attachment-preview-image]") : null;
                        var previewDownload = previewModal ? previewModal.querySelector("[data-aar-issue-attachment-download]") : null;
                        if (!previewUrl) {
                            return;
                        }
                        if (!previewModal || !previewImage) {
                            window.open(previewUrl, "_blank", "noopener");
                            return;
                        }
                        previewImage.src = previewUrl;
                        previewImage.alt = previewName;
                        if (previewDownload) {
                            previewDownload.href = downloadUrl;
                        }
                        if (window.jQuery && window.jQuery.fn && window.jQuery.fn.modal) {
                            window.jQuery(previewModal).off("shown.bs.modal.aarIssuePreview hidden.bs.modal.aarIssuePreview");
                            window.jQuery(previewModal).on("shown.bs.modal.aarIssuePreview", function () {
                                document.body.classList.add("aar-issue-preview-open");
                            });
                            window.jQuery(previewModal).on("hidden.bs.modal.aarIssuePreview", function () {
                                document.body.classList.remove("aar-issue-preview-open");
                                previewImage.removeAttribute("src");
                            });
                            window.jQuery(previewModal).modal("show");
                        } else {
                            window.open(previewUrl, "_blank", "noopener");
                        }
                        return;
                    }

                    var messagesLoadMore = event.target.closest("[data-aar-messages-load-more]");
                    if (messagesLoadMore) {
                        event.preventDefault();
                        if (messagesLoadMore.classList.contains("is-loading")) {
                            return;
                        }
                        messagesLoadMore.classList.add("is-loading");
                        messagesLoadMore.textContent = "Wczytywanie...";

                        fetch(messagesLoadMore.href, {
                            credentials: "same-origin",
                            headers: {"X-Requested-With": "XMLHttpRequest"}
                        }).then(function (response) {
                            if (!response.ok) {
                                throw new Error("HTTP " + response.status);
                            }
                            return response.text();
                        }).then(function (html) {
                            var doc = new DOMParser().parseFromString(html, "text/html");
                            var currentList = messagesLoadMore.closest(".aar-thread-list");
                            var nextList = doc.querySelector(".aar-messages-panel .aar-thread-list");
                            if (!currentList || !nextList) {
                                throw new Error("Missing message list");
                            }

                            var knownIds = {};
                            currentList.querySelectorAll(".aar-thread-item[data-aar-thread-id]").forEach(function (item) {
                                knownIds[item.getAttribute("data-aar-thread-id")] = true;
                            });
                            var loadMoreWrap = messagesLoadMore.closest(".aar-load-more-wrap");
                            nextList.querySelectorAll(".aar-thread-item[data-aar-thread-id]").forEach(function (item) {
                                var threadId = item.getAttribute("data-aar-thread-id");
                                if (!knownIds[threadId]) {
                                    currentList.insertBefore(item.cloneNode(true), loadMoreWrap);
                                    knownIds[threadId] = true;
                                }
                            });

                            var nextWrap = nextList.querySelector(".aar-load-more-wrap");
                            if (loadMoreWrap) {
                                if (nextWrap) {
                                    loadMoreWrap.replaceWith(nextWrap.cloneNode(true));
                                } else {
                                    loadMoreWrap.remove();
                                }
                            }
                        }).catch(function () {
                            messagesLoadMore.classList.remove("is-loading");
                            messagesLoadMore.textContent = "Spróbuj ponownie";
                        });
                        return;
                    }

                    var copyReturnJsonButton = event.target.closest("[data-aar-copy-return-json]");
                    if (copyReturnJsonButton) {
                        event.preventDefault();
                        var debugModal = copyReturnJsonButton.closest(".aar-return-debug-modal");
                        var debugJson = debugModal ? debugModal.querySelector(".aar-return-debug-json") : null;
                        var jsonText = debugJson ? debugJson.textContent : "";
                        if (!jsonText) {
                            return;
                        }

                        var markCopied = function () {
                            var originalLabel = copyReturnJsonButton.getAttribute("data-aar-original-label") || copyReturnJsonButton.textContent;
                            copyReturnJsonButton.setAttribute("data-aar-original-label", originalLabel);
                            copyReturnJsonButton.textContent = "Skopiowano";
                            window.setTimeout(function () {
                                copyReturnJsonButton.textContent = originalLabel;
                            }, 1600);
                        };
                        var fallbackCopy = function () {
                            var textarea = document.createElement("textarea");
                            textarea.value = jsonText;
                            textarea.setAttribute("readonly", "readonly");
                            textarea.style.position = "fixed";
                            textarea.style.opacity = "0";
                            document.body.appendChild(textarea);
                            textarea.select();
                            var copied = document.execCommand("copy");
                            document.body.removeChild(textarea);
                            if (copied) {
                                markCopied();
                            }
                        };

                        if (navigator.clipboard && navigator.clipboard.writeText) {
                            navigator.clipboard.writeText(jsonText).then(markCopied).catch(fallbackCopy);
                        } else {
                            fallbackCopy();
                        }
                        return;
                    }

                    var returnAction = event.target.closest("[data-aar-return-action]");
                    if (returnAction) {
                        var decisionPanel = returnAction.closest(".aar-return-decision-panel");
                        var rejectionForm = decisionPanel ? decisionPanel.querySelector(".aar-return-rejection-form") : null;
                        var refundForm = decisionPanel ? decisionPanel.querySelector(".aar-return-refund-form") : null;
                        var dropdown = returnAction.closest(".aar-return-decision-dropdown");
                        var action = String(returnAction.getAttribute("data-aar-return-action"));
                        if (action === "refund" && refundForm) {
                            event.preventDefault();
                            refundForm.classList.remove("is-collapsed");
                            if (rejectionForm) {
                                rejectionForm.classList.add("is-collapsed");
                            }
                            if (dropdown && dropdown.classList) {
                                dropdown.classList.remove("open");
                            }
                            var refundInput = refundForm.querySelector("input[name*=\"[amount]\"]");
                            if (refundInput) {
                                refundInput.focus();
                                refundInput.select();
                            }
                        }
                        if (action === "reject" && rejectionForm) {
                            event.preventDefault();
                            rejectionForm.classList.remove("is-collapsed");
                            if (refundForm) {
                                refundForm.classList.add("is-collapsed");
                            }
                            if (dropdown && dropdown.classList) {
                                dropdown.classList.remove("open");
                            }
                            var textarea = rejectionForm.querySelector("textarea");
                            if (textarea) {
                                textarea.focus();
                            }
                        }
                        return;
                    }

                    var issueLink = event.target.closest(".aar-issues-panel .aar-thread-item");
                    var inboxLink = event.target.closest(".aar-inbox-panel:not(.aar-issues-panel) .aar-thread-item");
                    var link = issueLink || inboxLink;
                    if (!link || event.defaultPrevented || event.button !== 0 || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) {
                        return;
                    }

                    event.preventDefault();
                    if (issueLink) {
                        loadConversation(link, ".aar-issues-panel", ".aar-issues-panel");
                        return;
                    }

                    loadConversation(link, ".aar-inbox-panel", ".aar-inbox-panel:not(.aar-issues-panel)");
                });

                document.addEventListener("click", function (event) {
                    var expandToggle = event.target.closest(".aar-reply-expand-toggle");
                    if (expandToggle) {
                        event.preventDefault();
                        var messageWindowSnapshot = captureMessageWindowMetrics(expandToggle);
                        var inputWrap = expandToggle.closest(".aar-reply-input-wrap");
                        if (!inputWrap) {
                            return;
                        }

                        var isExpanded = inputWrap.classList.toggle("is-expanded");
                        expandToggle.setAttribute("aria-expanded", isExpanded ? "true" : "false");
                        var srOnly = expandToggle.querySelector(".sr-only");
                        if (srOnly) {
                            srOnly.textContent = isExpanded ? "Zmniejsz pole wiadomości" : "Powiększ pole wiadomości";
                        }

                        var textarea = inputWrap.querySelector("textarea[name=\"reply_text\"]");
                        if (textarea) {
                            textarea.focus();
                            if (typeof textarea.setSelectionRange === "function") {
                                var cursor = textarea.value.length;
                                textarea.setSelectionRange(cursor, cursor);
                            }
                        }

                        rafApply();
                        restoreMessageWindowAfterComposerResize(messageWindowSnapshot);
                        return;
                    }

                    var option = event.target.closest(".aar-quick-reply-option");
                    if (!option) {
                        return;
                    }

                    var template = option.getAttribute("data-aar-template") || "";
                    var form = option.closest("form");
                    var textarea = form ? form.querySelector("textarea[name=\"reply_text\"]") : null;
                    if (!textarea || !template) {
                        return;
                    }

                    event.preventDefault();
                    textarea.value = template;
                    textarea.dispatchEvent(new Event("input", { bubbles: true }));
                    textarea.dispatchEvent(new Event("change", { bubbles: true }));
                    textarea.focus();
                });

                var rafApply = function () {
                    if (scheduled) {
                        return;
                    }

                    scheduled = true;
                    window.requestAnimationFrame(function () {
                        scheduled = false;
                        applyInboxHeight();
                    });
                };

                if (document.readyState === "loading") {
                    document.addEventListener("DOMContentLoaded", function () {
                        rafApply();
                        scheduleInitialMessageScroll();
                    });
                } else {
                    rafApply();
                    scheduleInitialMessageScroll();
                }

                window.addEventListener("load", rafApply);
                window.addEventListener("load", scheduleInitialMessageScroll);
                window.addEventListener("resize", rafApply);
                window.addEventListener("orientationchange", rafApply);
                window.addEventListener("scroll", function (event) {
                    var target = event.target;
                    if (target === document || target === document.documentElement || target === document.body) {
                        rafApply();
                    }
                }, true);
                document.addEventListener("transitionend", rafApply, true);

                if (window.visualViewport) {
                    window.visualViewport.addEventListener("resize", rafApply);
                    window.visualViewport.addEventListener("scroll", rafApply);
                }

                if (window.ResizeObserver) {
                    var resizeObserver = new ResizeObserver(rafApply);
                    resizeObserver.observe(document.body);
                }

            })();
        </script>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:2dc98106ecb898abbb85@@{literal}<div class="modal fade" id="{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:671002696b5570be225e@@{literal}<form method="post">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:2e8f4e2bc06595fafeaf@@{literal}<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:b6405ad52d4cac1862cc@@{literal}<h4 class="modal-title">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:8a87b5938cc5c384897f@@{literal}<input type="hidden" name="id_rule" value="{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:ee13baf6efcd6519cfda@@{literal}<div class="form-group"><label>Nazwa</label><input class="form-control" name="rule_name" value="{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:1bcf087da9925e97eac2@@{literal}" required></div>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:8381ccb26b222888d95c@@{literal}<div class="form-group"><label>Priorytet</label><input class="form-control" type="number" name="rule_priority" value="{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:6221ccb7573e123ebd92@@{literal}"></div>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:ab79917613ee3d925491@@{literal}<div class="form-group"><label>Typ dopasowania</label><select class="form-control" name="rule_match_type">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:6b4b24bf479e319e9712@@{literal}</select></div>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:0b3dc52c04c0a15ca5f9@@{literal}<div class="form-group"><label>Słowa kluczowe / wyrażenie</label><textarea class="form-control" name="rule_keywords" rows="3" required>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:42d7d3da4e42fe21355b@@{literal}</textarea></div>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:9c5aaa37bdc6595585e1@@{literal}<div class="form-group"><label>Szablon odpowiedzi</label><textarea class="form-control" name="rule_response_template" rows="6" required>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:21f108d7dd6ca038b9ad@@{literal}<div class="form-group"><label>Przerwa między odpowiedziami (minuty)</label><input class="form-control" type="number" name="rule_cooldown_minutes" value="{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:fda54c452159e0f9e450@@{literal}<div class="checkbox"><label><input type="checkbox" name="rule_only_first_message" value="1"{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:ea46fb1e4833edbd8edf@@{literal}> Tylko dla pierwszej wiadomości klienta w wątku</label></div>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:46c0d3c2ec910b75b3e9@@{literal}<div class="checkbox"><label><input type="checkbox" name="rule_enabled" value="1"{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:927390d4993883a5994b@@{literal}> Reguła włączona</label></div>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:689d88c0bfdf9956c9dc@@{literal}<a class="btn btn-default" href="{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:eb5a630ddd755ffe1bf2@@{literal}">Anuluj</a>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:8db8da5e68a15c37de3c@@{literal}<button type="button" class="btn btn-default" data-dismiss="modal">Anuluj</button>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:67bfccb1f773f993e56d@@{literal}<button class="btn btn-primary" name="{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:d4c5f73bcb268fc52c4e@@{literal}<script>
                (function () {
                    function openAarRuleModal() {
                        if (window.jQuery && jQuery.fn && jQuery.fn.modal) {
                            jQuery("#{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:e97de9e99bdf1a7386e8@@{literal}").modal("show");
                        }
                    }

                    if (document.readyState === "loading") {
                        document.addEventListener("DOMContentLoaded", openAarRuleModal);
                    } else {
                        openAarRuleModal();
                    }
                })();
            </script>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:44c441e2f84e75f1d765@@{literal}<h3><i class="icon-magic" aria-hidden="true"></i> {/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:a6c57bf5252e5005b93d@@{literal}</h3>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:ba1394f60b8c51547069@@{literal}<div style="display:flex;align-items:center;justify-content:flex-end;gap:8px;flex-wrap:wrap;margin-bottom:15px;">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:29b0c2eed10c84dd1175@@{literal}<form method="post" style="margin:0;"><button class="btn btn-default" name="submitAarInstallDefaultRules" type="submit">Importuj reguły startowe</button></form>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:31139f8760584accd4e0@@{literal}<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#aar-rule-modal">Dodaj regułę</button>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:bf5be171731f365f6fc4@@{literal}<div class="table-responsive"><table class="table"><thead><tr><th>ID</th><th>Nazwa</th><th>Typ</th><th>Priorytet</th><th>Aktywna</th><th>Słowa kluczowe</th><th></th></tr></thead><tbody>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:76d306827b3c62681ee4@@{literal}<tr><td colspan="7">Brak reguł.</td></tr>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:9b84c614b473bf1d182e@@{literal}<tr>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:ad76f84d9f135f96caee@@{literal}<td>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:b8073d8a2f01abcc6c6b@@{literal}</td>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:4f4cd8d2530f5cf54586@@{literal}<td><code>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:1607e82b489cb6914b0d@@{literal}</code></td>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:111c4c53971d960da99e@@{literal}<td><a class="btn btn-default" href="{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:293a77fb2552a98b207d@@{literal}">Edytuj</a> <a class="btn btn-default" href="{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:cc4c613d1a8c6bc0e395@@{literal}">Usuń</a></td>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:3ed7440ce0756928276f@@{literal}</tr>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:7fa98554c4a983f787a6@@{literal}</tbody></table></div></div>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:76585433da6e75eff0c6@@{literal}<button type="button" class="aar-reply-expand-toggle" aria-expanded="false">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:8b42a9d0ee2f50e18c32@@{literal}<span class="aar-reply-expand-dots" aria-hidden="true">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:b9cd067dfe98cd6e2a04@@{literal}<span class="aar-reply-expand-dot"></span>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:c61942e24146c734a0d6@@{literal}<span class="sr-only">Powiększ pole wiadomości</span>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:f1e1affdd6308460b7a1@@{literal}<li>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:d08ee50d9521b20a41f5@@{literal}<button type="button" class="aar-quick-reply-option" data-aar-template="{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:16d2938ae98cd040db3a@@{literal}</li>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:7c54a4ae16ad23e5db38@@{literal}<div class="btn-group dropup aar-quick-reply-dropup">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:e4162f84d310dca01f2d@@{literal}<button type="button" class="btn btn-default dropdown-toggle aar-quick-reply-button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:0580e4b96d272a0e4997@@{literal}<span class="aar-quick-reply-icon" aria-hidden="true">&#9776;</span>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:e4b1746383934d54e726@@{literal}<span class="sr-only">Gotowe odpowiedzi</span>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:2215c26d4d994a5b3e79@@{literal}<ul class="dropdown-menu dropdown-menu-right aar-quick-reply-menu">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:c2f1e9cf97e9c304fb17@@{literal}<style>
            .aar-quick-replies-panel {
                overflow: hidden;
            }
            .aar-quick-replies-panel .aar-quick-replies-head {
                display: flex;
                justify-content: flex-end;
                align-items: center;
                gap: 16px;
                margin: 0 0 15px;
            }
            .aar-quick-replies-panel .aar-quick-replies-body {
                padding: 0;
            }
            .aar-quick-replies-panel .aar-quick-replies-hint {
                display: flex;
                align-items: flex-start;
                gap: 10px;
                color: #53636a;
                margin: 0 0 16px;
                padding: 12px 14px;
                border: 1px solid #dce8ed;
                border-radius: 4px;
                background: #f4f9fb;
                line-height: 1.5;
            }
            .aar-quick-replies-panel .aar-quick-replies-hint i {
                margin-top: 2px;
                color: #25b9d7;
                font-size: 16px;
            }
            .aar-quick-replies-panel .aar-variable-list {
                margin-top: 7px;
            }
            .aar-quick-replies-panel .aar-variable-list code {
                display: inline-block;
                margin: 2px 3px 2px 0;
                padding: 2px 6px;
                border: 1px solid #eadde2;
                border-radius: 3px;
                background: #fff;
                color: #c7254e;
                font-size: 12px;
            }
            .aar-quick-replies-panel .aar-quick-replies-table {
                margin: 0;
                border-collapse: separate;
                border-spacing: 0 8px;
            }
            .aar-quick-replies-panel .aar-quick-replies-table thead th {
                padding: 0 12px 4px;
                border: 0;
                color: #6c757d;
                font-size: 12px;
                font-weight: 600;
                letter-spacing: .02em;
                text-transform: uppercase;
            }
            .aar-quick-replies-panel .aar-quick-replies-table td {
                padding: 12px;
                border-top: 1px solid #dbe3e8;
                border-bottom: 1px solid #dbe3e8;
                background: #fff;
                vertical-align: top;
            }
            .aar-quick-replies-panel .aar-quick-replies-table td:first-child {
                border-left: 1px solid #dbe3e8;
                border-radius: 5px 0 0 5px;
                text-align: center;
            }
            .aar-quick-replies-panel .aar-quick-replies-table td:last-child {
                border-right: 1px solid #dbe3e8;
                border-radius: 0 5px 5px 0;
                text-align: right;
            }
            .aar-quick-replies-panel .aar-quick-replies-table .form-control {
                border-color: #bbcdd4;
                box-shadow: none;
            }
            .aar-quick-replies-panel .aar-quick-replies-table .form-control:focus {
                border-color: #25b9d7;
                box-shadow: 0 0 0 2px rgba(37, 185, 215, .12);
            }
            .aar-quick-replies-panel .aar-quick-replies-table textarea {
                min-height: 88px;
                resize: vertical;
            }
            .aar-quick-replies-panel .aar-quick-reply-status {
                display: inline-block;
                min-width: 74px;
                padding: 5px 9px;
                border-radius: 12px;
                color: #fff;
                background: #72c279;
                font-size: 11px;
                font-weight: 700;
                line-height: 1;
                text-align: center;
                text-transform: uppercase;
            }
            .aar-quick-replies-panel .aar-quick-reply-status.is-disabled {
                color: #6c757d;
                background: #e8ecef;
            }
            .aar-quick-replies-panel .aar-quick-reply-name {
                color: #363a41;
                font-weight: 600;
            }
            .aar-quick-replies-panel .aar-quick-reply-preview {
                display: -webkit-box;
                overflow: hidden;
                color: #5d6973;
                line-height: 1.45;
                -webkit-box-orient: vertical;
                -webkit-line-clamp: 3;
            }
            .aar-quick-replies-panel .aar-quick-reply-row-actions {
                white-space: nowrap;
            }
            .aar-quick-replies-panel .aar-quick-reply-row-actions .btn + .btn {
                margin-left: 5px;
            }
            .aar-quick-replies-panel .aar-quick-replies-empty {
                padding: 28px 15px !important;
                color: #7a8288;
                text-align: center !important;
            }
            #aar-quick-reply-modal textarea {
                min-height: 180px;
                resize: vertical;
            }
            .aar-quick-replies-panel .aar-active-toggle {
                display: inline-flex;
                align-items: center;
                justify-content: center;
                width: 34px;
                height: 34px;
                margin: 0;
                border-radius: 4px;
                background: #f1f5f7;
                cursor: pointer;
            }
            .aar-quick-replies-panel .aar-active-toggle input {
                margin: 0;
            }
            .aar-quick-replies-panel .aar-remove-label {
                margin-left: 5px;
            }
            .aar-quick-replies-panel .aar-quick-replies-actions {
                display: flex;
                justify-content: flex-end;
                margin: 10px -20px -20px;
                padding: 13px 20px;
                border-top: 1px solid #dbe3e8;
                background: #f8fafb;
            }
            @media (max-width: 767px) {
                .aar-quick-replies-panel .aar-quick-replies-head .btn {
                    width: 100%;
                }
                .aar-quick-replies-panel .aar-quick-replies-head {
                    display: block;
                }
                .aar-quick-replies-panel .aar-quick-replies-table,
                .aar-quick-replies-panel .aar-quick-replies-table tbody,
                .aar-quick-replies-panel .aar-quick-replies-table tr,
                .aar-quick-replies-panel .aar-quick-replies-table td {
                    display: block;
                    width: 100%;
                }
                .aar-quick-replies-panel .aar-quick-replies-table thead {
                    display: none;
                }
                .aar-quick-replies-panel .aar-quick-replies-table tr {
                    margin-bottom: 14px;
                    padding: 12px;
                    border: 1px solid #dbe3e8;
                    border-radius: 5px;
                }
                .aar-quick-replies-panel .aar-quick-replies-table td,
                .aar-quick-replies-panel .aar-quick-replies-table td:first-child,
                .aar-quick-replies-panel .aar-quick-replies-table td:last-child {
                    padding: 7px 0;
                    border: 0;
                    text-align: left;
                }
                .aar-quick-replies-panel .aar-quick-replies-table td:before {
                    content: attr(data-label);
                    display: block;
                    margin-bottom: 5px;
                    color: #6c757d;
                    font-size: 11px;
                    font-weight: 600;
                    text-transform: uppercase;
                }
                .aar-quick-replies-panel .aar-quick-replies-actions {
                    margin: 10px -20px -20px;
                    padding: 14px 20px;
                }
                .aar-quick-replies-panel .aar-quick-replies-actions .btn {
                    width: 100%;
                }
            }
        </style>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:017cea7b53210d8bae2c@@{literal}<div class="panel aar-quick-replies-panel">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:44c65f359beeee7d578e@@{literal}<h3><i class="icon-comments" aria-hidden="true"></i> Gotowe odpowiedzi</h3>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:f6edc631175c10764f73@@{literal}<div class="aar-quick-replies-head">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:71d8add1192959c3a33a@@{literal}<button type="button" class="btn btn-primary" id="aar-quick-reply-add-row"><i class="icon-plus" aria-hidden="true"></i> Dodaj odpowiedź</button>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:f5f16bcda25efdae86f5@@{literal}<div class="aar-quick-replies-body">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:802fe0f002ac4dcedd2b@@{literal}<div class="aar-quick-replies-hint"><i class="icon-info-circle" aria-hidden="true"></i><div><strong>Szablony do ręcznych odpowiedzi</strong><br>Gotowe treści znajdziesz pod ikoną listy przy polu odpowiedzi. W treści możesz używać zmiennych:<div class="aar-variable-list"><code>{buyer_login}</code> <code>{shop_name}</code> <code>{order_id}</code> <code>{offer_id}</code> <code>{offer_title}</code> <code>{orderdate}</code> <code>{purchase_date}</code> <code>{orderdatetime}</code> <code>{claimdate}</code> <code>{claim_submitted_date}</code> <code>{claim_received_date}</code> <code>{claimdatetime}</code> <code>{claim_product_name}</code> <code>{claim_reason}</code> <code>{claim_reason_description}</code> <code>{claim_amount}</code> <code>{claim_amount_value}</code> <code>{claim_currency}</code> <code>{claim_quantity}</code> <code>{claim_unit_amount}</code></div></div></div>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:7cc0e7a3a1047005ea10@@{literal}<form method="post" id="aar-quick-replies-form">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:a0b55362f957a0f11dec@@{literal}<input type="hidden" name="submitAarSaveQuickReplies" value="1">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:9960784fd6b96a12fbf5@@{literal}<div class="table-responsive">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:3989165b7924bf193ace@@{literal}<table class="table aar-quick-replies-table" id="aar-quick-replies-table">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:ac94edc847a94a14c16a@@{literal}<thead><tr><th style="width:110px;">Status</th><th style="width:260px;">Nazwa</th><th>Treść</th><th style="width:180px;">Akcje</th></tr></thead>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:aee2de443d9bc7cac246@@{literal}<tbody>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:78e007f777cf1a6db39b@@{literal}<tr class="aar-quick-replies-empty-row"><td colspan="4" class="aar-quick-replies-empty">Nie dodano jeszcze żadnych gotowych odpowiedzi.</td></tr>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:f4c47ecec5c57f200471@@{literal}<tr class="aar-quick-reply-row" data-index="{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:e43ac3d1ac277eda6847@@{literal}<td data-label="Status"><input type="hidden" class="aar-row-enabled" name="quick_reply_enabled[{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:e69e6a48897674983cfe@@{literal}"><span class="aar-quick-reply-status{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:c2e851dc0760b9cacd7c@@{literal}</span></td>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:47352a51743068e4d60b@@{literal}<td data-label="Nazwa"><input type="hidden" class="aar-row-name" name="quick_reply_name[{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:581a2c2368248e197ff1@@{literal}"><span class="aar-quick-reply-name">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:98984924dc45c13501ee@@{literal}<td data-label="Treść"><textarea class="aar-row-text" name="quick_reply_text[{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:798de03a0f76fc699674@@{literal}</textarea><div class="aar-quick-reply-preview">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:56ef702a1018b1d2e7be@@{literal}</div></td>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:c475c6a23274a039682d@@{literal}<td data-label="Akcje" class="aar-quick-reply-row-actions"><button type="button" class="btn btn-default aar-quick-reply-edit-row"><i class="icon-pencil" aria-hidden="true"></i> Edytuj</button><button type="button" class="btn btn-default aar-quick-reply-remove-row"><i class="icon-trash" aria-hidden="true"></i> Usuń</button></td>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:57d99a57d8a70c2c050e@@{literal}</tbody></table></div>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:afd7e1217dad248aae7b@@{literal}<div class="modal fade" id="aar-quick-reply-modal" tabindex="-1" role="dialog" aria-hidden="true">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:014784f8bbfbc1976bc9@@{literal}<form id="aar-quick-reply-modal-form">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:5d217cb0fd9f80203fdd@@{literal}<div class="modal-header"><button type="button" class="close" data-dismiss="modal" aria-label="Zamknij"><span aria-hidden="true">&times;</span></button><h4 class="modal-title" id="aar-quick-reply-modal-title">Edytuj gotową odpowiedź</h4></div>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:531b590904d2c360318e@@{literal}<input type="hidden" id="aar-quick-reply-edit-index" value="">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:28a27baca999aec61eba@@{literal}<div class="form-group"><label for="aar-quick-reply-edit-name">Nazwa</label><input type="text" class="form-control" id="aar-quick-reply-edit-name" placeholder="Np. Weryfikacja reklamacji" required></div>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:61caacd9d1bacb031f98@@{literal}<div class="form-group"><label for="aar-quick-reply-edit-text">Treść odpowiedzi</label><textarea class="form-control" id="aar-quick-reply-edit-text" placeholder="Wpisz treść gotowej odpowiedzi..." required></textarea></div>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:10c277da07c22c61c9db@@{literal}<div class="checkbox"><label><input type="checkbox" id="aar-quick-reply-edit-enabled" value="1"> Odpowiedź aktywna</label></div>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:61dd50abe005987782fe@@{literal}<div class="modal-footer"><button type="button" class="btn btn-default" data-dismiss="modal">Anuluj</button><button type="submit" class="btn btn-primary"><i class="icon-save" aria-hidden="true"></i> Zapisz odpowiedź</button></div>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:c6103998e3e77513f208@@{literal}</form></div></div></div>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:ef338972b29d2a560d24@@{literal}<script>
            (function () {
                var quickReplyNextIndex = 0;

                function bootstrapQuickReplyNextIndex() {
                    var table = document.getElementById("aar-quick-replies-table");
                    if (!table) {
                        return;
                    }
                    var rows = table.querySelectorAll(".aar-quick-reply-row[data-index]");
                    var maxIndex = -1;
                    rows.forEach(function (row) {
                        var index = parseInt(row.getAttribute("data-index") || "-1", 10);
                        if (!Number.isNaN(index) && index > maxIndex) {
                            maxIndex = index;
                        }
                    });
                    quickReplyNextIndex = maxIndex + 1;
                }

                function createQuickReplyRow(index, name, replyText, enabled) {
                    var tr = document.createElement("tr");
                    tr.className = "aar-quick-reply-row";
                    tr.setAttribute("data-index", String(index));
                    tr.innerHTML = "<td data-label=\"Status\"><input type=\"hidden\" class=\"aar-row-enabled\" name=\"quick_reply_enabled[" + index + "]\"><span class=\"aar-quick-reply-status\"></span></td>"
                        + "<td data-label=\"Nazwa\"><input type=\"hidden\" class=\"aar-row-name\" name=\"quick_reply_name[" + index + "]\"><span class=\"aar-quick-reply-name\"></span></td>"
                        + "<td data-label=\"Treść\"><textarea class=\"aar-row-text\" name=\"quick_reply_text[" + index + "]\" style=\"display:none;\"></textarea><div class=\"aar-quick-reply-preview\"></div></td>"
                        + "<td data-label=\"Akcje\" class=\"aar-quick-reply-row-actions\"><button type=\"button\" class=\"btn btn-default aar-quick-reply-edit-row\"><i class=\"icon-pencil\" aria-hidden=\"true\"></i> Edytuj</button><button type=\"button\" class=\"btn btn-default aar-quick-reply-remove-row\"><i class=\"icon-trash\" aria-hidden=\"true\"></i> Usuń</button></td>";
                    updateQuickReplyRow(tr, name, replyText, enabled);
                    return tr;
                }

                function updateQuickReplyRow(row, name, replyText, enabled) {
                    row.querySelector(".aar-row-enabled").value = enabled ? "1" : "0";
                    row.querySelector(".aar-row-name").value = name;
                    row.querySelector(".aar-row-text").value = replyText;
                    row.querySelector(".aar-quick-reply-name").textContent = name;
                    row.querySelector(".aar-quick-reply-preview").textContent = replyText;
                    var status = row.querySelector(".aar-quick-reply-status");
                    status.textContent = enabled ? "Aktywna" : "Wyłączona";
                    status.classList.toggle("is-disabled", !enabled);
                }

                function openQuickReplyModal(row) {
                    var isEdit = !!row;
                    document.getElementById("aar-quick-reply-modal-title").textContent = isEdit ? "Edytuj gotową odpowiedź" : "Dodaj gotową odpowiedź";
                    document.getElementById("aar-quick-reply-edit-index").value = isEdit ? row.getAttribute("data-index") : "";
                    document.getElementById("aar-quick-reply-edit-name").value = isEdit ? row.querySelector(".aar-row-name").value : "";
                    document.getElementById("aar-quick-reply-edit-text").value = isEdit ? row.querySelector(".aar-row-text").value : "";
                    document.getElementById("aar-quick-reply-edit-enabled").checked = isEdit ? row.querySelector(".aar-row-enabled").value === "1" : true;
                    if (window.jQuery && jQuery.fn && jQuery.fn.modal) {
                        jQuery("#aar-quick-reply-modal").modal("show");
                    }
                }

                document.addEventListener("click", function (event) {
                    var addButton = event.target.closest("#aar-quick-reply-add-row");
                    if (addButton) {
                        event.preventDefault();
                        openQuickReplyModal(null);
                        return;
                    }

                    var editButton = event.target.closest(".aar-quick-reply-edit-row");
                    if (editButton) {
                        event.preventDefault();
                        openQuickReplyModal(editButton.closest(".aar-quick-reply-row"));
                        return;
                    }

                    var removeButton = event.target.closest(".aar-quick-reply-remove-row");
                    if (!removeButton) {
                        return;
                    }

                    event.preventDefault();
                    var row = removeButton.closest(".aar-quick-reply-row");
                    if (!row) {
                        return;
                    }
                    if (!window.confirm("Usunąć tę gotową odpowiedź?")) {
                        return;
                    }
                    row.remove();
                    document.getElementById("aar-quick-replies-form").submit();
                });

                document.getElementById("aar-quick-reply-modal-form").addEventListener("submit", function (event) {
                    event.preventDefault();
                    var indexField = document.getElementById("aar-quick-reply-edit-index");
                    var index = indexField.value;
                    var name = document.getElementById("aar-quick-reply-edit-name").value.trim();
                    var replyText = document.getElementById("aar-quick-reply-edit-text").value.trim();
                    var enabled = document.getElementById("aar-quick-reply-edit-enabled").checked;
                    var tableBody = document.querySelector("#aar-quick-replies-table tbody");
                    var row = index !== "" ? tableBody.querySelector(".aar-quick-reply-row[data-index=\"" + index + "\"]") : null;
                    if (row) {
                        updateQuickReplyRow(row, name, replyText, enabled);
                    } else {
                        var emptyRow = tableBody.querySelector(".aar-quick-replies-empty-row");
                        if (emptyRow) {
                            emptyRow.remove();
                        }
                        tableBody.appendChild(createQuickReplyRow(quickReplyNextIndex++, name, replyText, enabled));
                    }
                    if (window.jQuery && jQuery.fn && jQuery.fn.modal) {
                        jQuery("#aar-quick-reply-modal").modal("hide");
                    }
                    document.getElementById("aar-quick-replies-form").submit();
                });

                bootstrapQuickReplyNextIndex();
            })();
        </script>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:2822a15eff7a270ac8d8@@{literal}<div class="panel"><h3><i class="icon-list-alt" aria-hidden="true"></i> {/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:274a1de194e1f4b812b2@@{literal}<form method="post" style="margin-bottom:15px;"><button class="btn btn-primary" name="submitAarRunTest" type="submit"><i class="icon-refresh" aria-hidden="true"></i> Uruchom skan ręczny</button></form>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:2fd621d45f4fd29b7930@@{literal}<div class="table-responsive"><table class="table"><thead><tr><th>Data</th><th>Co się stało</th><th>Wątek</th><th>Reguła</th><th>Status</th><th>Szczegóły</th></tr></thead><tbody>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:cec28a180aabb17c6dd6@@{literal}<tr><td colspan="6">Brak logów.</td></tr>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:fba4982c1d900fe7fd96@@{literal}<td><small>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:fe86512d40eb618a8f3c@@{literal}</small></td>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:12ece6d97975ed6ac5f1@@{literal}<style>
            .aar-update-panel {
                padding-bottom: 20px;
            }
            .aar-update-summary {
                display: grid;
                grid-template-columns: repeat(5, minmax(130px, 1fr));
                gap: 12px;
                margin: 0 0 18px;
            }
            .aar-update-summary-item {
                padding: 12px 14px;
                border: 1px solid #d8e2e8;
                border-radius: 6px;
                background: #fbfcfd;
                min-width: 0;
            }
            .aar-update-summary-label {
                display: block;
                margin-bottom: 4px;
                color: #7a8288;
                font-size: 11px;
                font-weight: 700;
                letter-spacing: .04em;
                text-transform: uppercase;
            }
            .aar-update-summary-value {
                display: block;
                color: #2f3b46;
                font-size: 15px;
                font-weight: 700;
                overflow-wrap: anywhere;
            }
            .aar-update-check-row {
                display: flex;
                flex-wrap: wrap;
                align-items: center;
                gap: 10px;
                padding: 14px;
                border: 1px solid #d8e2e8;
                border-radius: 6px;
                background: #f7fafb;
            }
            .aar-update-check-row .form-control {
                width: 170px;
                max-width: 100%;
                margin: 0;
            }
            .aar-update-check-row label {
                margin: 0 4px 0 0;
                color: #5d6973;
                font-weight: 700;
            }
            .aar-update-check-row .btn {
                margin: 0;
            }
            .aar-update-check-row .aar-update-main-button {
                min-width: 210px;
                padding: 8px 16px;
                font-size: 14px;
                font-weight: 700;
                text-align: center;
            }
            .aar-update-message {
                margin: 14px 0 0;
            }
            .aar-update-notes {
                display: flex;
                gap: 12px;
                padding: 14px 16px;
                border: 1px solid #d8e2e8;
                border-left: 4px solid #25b9d7;
                border-radius: 6px;
                background: #ffffff;
                color: #2f3b46;
            }
            .aar-update-notes-icon {
                flex: 0 0 auto;
                width: 28px;
                height: 28px;
                border-radius: 999px;
                display: inline-flex;
                align-items: center;
                justify-content: center;
                color: #ffffff;
                background: #25b9d7;
                font-weight: 700;
            }
            .aar-update-notes-body {
                min-width: 0;
            }
            .aar-update-notes-title {
                margin: 0 0 8px;
                color: #2f3b46;
                font-size: 14px;
                font-weight: 800;
            }
            .aar-update-notes-entry {
                margin: 0 0 10px;
            }
            .aar-update-notes-entry:last-child {
                margin-bottom: 0;
            }
            .aar-update-notes-version {
                margin: 0 0 4px;
                color: #5d6973;
                font-size: 13px;
                font-weight: 800;
            }
            .aar-update-notes-list {
                margin: 0;
                padding-left: 18px;
            }
            .aar-update-notes-list li {
                margin: 3px 0;
            }
            .aar-update-error {
                border-left-color: #d9534f;
            }
            .aar-update-error .aar-update-notes-icon {
                background: #d9534f;
            }
            @media (max-width: 1199px) {
                .aar-update-summary {
                    grid-template-columns: repeat(2, minmax(140px, 1fr));
                }
            }
            @media (max-width: 767px) {
                .aar-update-summary {
                    grid-template-columns: 1fr;
                }
                .aar-update-check-row {
                    align-items: stretch;
                }
                .aar-update-check-row .form-control,
                .aar-update-check-row .btn,
                .aar-update-check-row .aar-update-main-button {
                    width: 100%;
                }
            }
        </style>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:aa51b4fa27a55536fe62@@{literal}<div class="panel aar-update-panel">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:551d3431f59b24aeec54@@{literal}<h3><i class="icon-info-circle" aria-hidden="true"></i> {/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:3ad5ab0917aaae71b6e9@@{literal}<div class="aar-update-summary">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:5f8583fee472b568e990@@{literal}<div class="aar-update-summary-item"><span class="aar-update-summary-label">Wersja</span><span class="aar-update-summary-value">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:ab1654fd5972b015013b@@{literal}<div class="aar-update-summary-item"><span class="aar-update-summary-label">Wydanie</span><span class="aar-update-summary-value">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:3d597c47969a2a1c7ad2@@{literal}<div class="aar-update-summary-item"><span class="aar-update-summary-label">Licencja dla</span><span class="aar-update-summary-value">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:9e69133781202df504cf@@{literal}<div class="aar-update-summary-item"><span class="aar-update-summary-label">Domena</span><span class="aar-update-summary-value">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:a89e7118b5233251f157@@{literal}<div class="aar-update-summary-item"><span class="aar-update-summary-label">Aktualizacje do</span><span class="aar-update-summary-value">{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:5727fb5de50651a8fc98@@{literal}<div class="aar-update-message" id="aarManualUpdateMessage" style="display:none;"></div>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:505b4e7e88bcb20bddee@@{literal}<script>
            (function () {
                var ajaxUrl = {/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:08283f5636090d58604d@@{literal};
                var button = document.getElementById("aarManualUpdateCheck");

                function setManualUpdateButtonState(tone, action, label) {
                    if (!button) {
                        return;
                    }

                    button.classList.remove("btn-primary", "btn-success", "btn-danger", "btn-default");
                    button.classList.add(tone === "danger" ? "btn-danger" : (tone === "success" ? "btn-success" : "btn-primary"));
                    button.setAttribute("data-update-action", action || "check");
                    button.innerHTML = "<i class=\"icon-refresh\"></i> " + label;
                }

	                function escapeHtml(value) {
	                    return String(value || "").replace(/[&<>"']/g, function (character) {
	                        return {
	                            "&": "&amp;",
	                            "<": "&lt;",
                            ">": "&gt;",
                            "\"": "&quot;",
                            "'": "&#039;"
	                        }[character];
	                    });
	                }

	                function repairPolishMojibake(value) {
	                    var text = String(value || "");
	                    var replacements = {
	                        "\u00c4\u2026": "ą", "\u00c4\u0085": "ą",
	                        "\u00c4\u201e": "Ą", "\u00c4\u0084": "Ą",
	                        "\u00c4\u2021": "ć", "\u00c4\u0087": "ć",
	                        "\u00c4\u2020": "Ć", "\u00c4\u0086": "Ć",
	                        "\u00c4\u2122": "ę", "\u00c4\u0099": "ę",
	                        "\u00c4\u02dc": "Ę", "\u00c4\u0098": "Ę",
	                        "\u00c5\u201a": "ł", "\u0139\u201a": "ł", "\u00c5\u0082": "ł",
	                        "\u00c5\u0081": "Ł", "\u0139\u0081": "Ł",
	                        "\u00c5\u201e": "ń", "\u0139\u201e": "ń",
	                        "\u00c5\u0192": "Ń", "\u0139\u0083": "Ń",
	                        "\u00c3\u00b3": "ó", "\u0102\u0142": "ó",
	                        "\u00c3\u201c": "Ó", "\u0102\u201c": "Ó",
	                        "\u00c5\u203a": "ś", "\u0139\u203a": "ś", "\u00c5\u009b": "ś",
	                        "\u00c5\u0160": "Ś", "\u0139\u0160": "Ś",
	                        "\u00c5\u00ba": "ź", "\u0139\u015f": "ź",
	                        "\u00c5\u00b9": "Ź", "\u0139\u0179": "Ź",
	                        "\u00c5\u00bc": "ż", "\u0139\u017a": "ż", "\u0139\u013d": "ż",
	                        "\u00c5\u00bb": "Ż", "\u0139\u00bb": "Ż"
	                    };
	                    Object.keys(replacements).forEach(function (needle) {
	                        text = text.split(needle).join(replacements[needle]);
	                    });
	                    text = text.replace(/([A-Za-ząćęłńóśźżĄĆĘŁŃÓŚŹŻ])Ä(?=[\s\]\)\.,;:!?]|$)/g, "$1ą");
	                    return text;
	                }

                function setUpdateMessage(message, isError) {
                    var messageEl = document.getElementById("aarManualUpdateMessage");
                    if (!messageEl) {
                        return;
                    }

                    messageEl.style.display = message ? "" : "none";
                    messageEl.className = "aar-update-message";
                    if (!message) {
                        messageEl.innerHTML = "";
                        return;
                    }

                    if (isError) {
                        messageEl.innerHTML = "<div class=\"aar-update-notes aar-update-error\"><span class=\"aar-update-notes-icon\">!</span><div class=\"aar-update-notes-body\"><p class=\"aar-update-notes-title\">Nie udało się sprawdzić aktualizacji</p><div>" + escapeHtml(message) + "</div></div></div>";
                        return;
                    }

                    messageEl.innerHTML = message;
                }

                function formatUpdateChangelog(changelog) {
                    var entries = changelog && Array.isArray(changelog.entries) ? changelog.entries : [];
                    if (!entries.length) {
                        return "";
                    }

                    var html = "<div class=\"aar-update-notes\"><span class=\"aar-update-notes-icon\">i</span><div class=\"aar-update-notes-body\"><p class=\"aar-update-notes-title\">Zmiany w aktualizacji</p>";
                    entries.forEach(function (entry) {
	                        var header = "v" + escapeHtml(repairPolishMojibake(entry.version || ""));
	                        if (entry.date) {
	                            header += " - " + escapeHtml(repairPolishMojibake(entry.date));
	                        }
                        html += "<div class=\"aar-update-notes-entry\"><p class=\"aar-update-notes-version\">" + header + "</p>";

                        var items = Array.isArray(entry.items) ? entry.items : [];
                        if (items.length) {
	                            html += "<ul class=\"aar-update-notes-list\">";
	                            items.forEach(function (item) {
	                                if (item) {
	                                    html += "<li>" + escapeHtml(repairPolishMojibake(item)) + "</li>";
	                                }
	                            });
                            html += "</ul>";
                        }
                        html += "</div>";
                    });

                    html += "</div></div>";

                    return html;
                }

                function buildManualUpdateBody(action) {
                    var body = new URLSearchParams();
                    body.append("ajax", "1");
                    body.append("action", action);

                    return body;
                }

                function fetchUpdateAction(action) {
                    return fetch(ajaxUrl, {
                        method: "POST",
                        credentials: "same-origin",
                        headers: {
                            "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
                            "X-Requested-With": "XMLHttpRequest"
                        },
                        body: buildManualUpdateBody(action).toString()
                    }).then(function (response) {
                        return response.text().then(function (text) {
                            var json;
                            try {
                                json = JSON.parse(text);
                            } catch (error) {
                                text = text.replace(/<[^>]*>/g, " ").replace(/\s+/g, " ").trim();
                                throw new Error(text ? text.substring(0, 220) : "Nieprawidłowa odpowiedź serwera.");
                            }

                            if (!response.ok || !json || json.ok === false) {
                                throw new Error((json && (json.error || json.message)) || "Błąd aktualizacji.");
                            }

                            return json;
                        });
                    });
                }

                function checkUpdatesManually() {
                    if (!button) {
                        return;
                    }

                    button.disabled = true;
                    setUpdateMessage("", false);
                    setManualUpdateButtonState("primary", "check", "Sprawdzam...");

                    fetchUpdateAction("CheckForUpdates")
                        .then(function (data) {
                            var status = data && data.ok ? (data.status || {}) : null;

                            if (!status || !status.configured) {
                                setManualUpdateButtonState("primary", "check", "Aktualizacje nieskonfigurowane");
                                return;
                            }

                            if (status.available && !status.updates_allowed) {
                                setManualUpdateButtonState("danger", "check", "Dostęp do aktualizacji wygasł");
                                setUpdateMessage("Okres aktualizacji wygasł" + (status.updates_until ? " " + status.updates_until : "") + ". Odnów dostęp w Prestino.", true);
                                return;
                            }

                            if (status.available && status.version) {
                                var targetLabel = status.version;
                                setManualUpdateButtonState("danger", "install", "Zaktualizuj do " + targetLabel);
                                var updateMessage = formatUpdateChangelog(data.changelog || {});
                                if (!updateMessage && status.notes) {
                                    updateMessage = status.notes;
                                }
                                if (updateMessage) {
                                    setUpdateMessage(updateMessage, false);
                                }
                                return;
                            }

                            setManualUpdateButtonState("success", "check", "Brak aktualizacji");
                        })
                        .catch(function (error) {
                            setManualUpdateButtonState("primary", "check", "Błąd sprawdzania");
                            setUpdateMessage(error.message || "Nie udało się sprawdzić aktualizacji.", true);
                        })
                        .finally(function () {
                            button.disabled = false;
                        });
                }

                function installManualUpdate() {
                    if (!button) {
                        return;
                    }

                    var currentLabel = button.textContent.replace(/\s+/g, " ").trim() || "Zaktualizuj";
                    button.disabled = true;
                    setUpdateMessage("", false);
                    setManualUpdateButtonState("danger", "install", "Instaluję aktualizację...");

                    fetchUpdateAction("InstallUpdate")
                        .then(function (data) {
                            if (!data || !data.ok) {
                                throw new Error("install");
                            }

                            setManualUpdateButtonState("success", "check", data.version ? "Zaktualizowano do " + data.version : "Zaktualizowano");
                        })
                        .catch(function (error) {
                            setManualUpdateButtonState("danger", "install", currentLabel);
                            setUpdateMessage(error.message || "Nie udało się zainstalować aktualizacji.", true);
                        })
                        .finally(function () {
                            button.disabled = false;
                        });
                }

                if (button) {
                    button.addEventListener("click", function () {
                        if ((button.getAttribute("data-update-action") || "check") === "install") {
                            installManualUpdate();
                        } else {
                            checkUpdatesManually();
                        }
                    });

                    window.setTimeout(checkUpdatesManually, 0);
                }
            })();
        </script>{/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:c3d943f98a6a841be2c8@@{literal}<strong>Wiadomość klienta:</strong> {/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:a5f4c958039d71807f86@@{literal}<strong>Automatyczna odpowiedź:</strong> {/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:9b1bf8b9d5d8bd2e7d21@@{literal}<strong>Powód:</strong> {/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:483eae5e891f6eef0185@@{literal}<strong>Błąd:</strong> {/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:dc8f1a44dc80da05540c@@{literal}<strong>Kontekst:</strong> {/literal}@@AAR_FRAGMENT_END@@
@@AAR_FRAGMENT:65aef1adba8672a5fe79@@{literal}<br>{/literal}@@AAR_FRAGMENT_END@@

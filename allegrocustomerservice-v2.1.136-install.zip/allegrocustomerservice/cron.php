<?php
/**
 * Copyright (c) 2026 Prestino. All rights reserved.
 *
 * This file is proprietary software. Copying, modification, distribution,
 * or use outside the terms of a valid Prestino license is prohibited.
 *
 * @author Prestino
 * @copyright 2026 Prestino
 * @license Proprietary
 */

require_once dirname(__DIR__, 2) . '/config/config.inc.php';

if (!defined('_PS_VERSION_')) {
    exit;
}

header('Content-Type: application/json; charset=utf-8');

$finish = static function (array $payload, int $status = 200): void {
    http_response_code($status);
    exit(json_encode($payload));
};

$module = Module::getInstanceByName('allegrocustomerservice');
if (!$module instanceof AllegroCustomerService) {
    $finish(['ok' => false, 'message' => 'Module unavailable'], 503);
}

$token = (string) Tools::getValue('token');
$expected = (string) Configuration::get(AllegroCustomerService::CONFIG_PREFIX . 'CRON_TOKEN');

if ($expected === '' || !hash_equals($expected, $token)) {
    $finish(['ok' => false, 'message' => 'Invalid token'], 403);
}

if (!(bool) Configuration::get(AllegroCustomerService::CONFIG_PREFIX . 'ENABLED')) {
    $finish(['ok' => true, 'message' => 'Module disabled']);
}

try {
    $license = new AllegroCustomerServiceLicense($module->getLocalPath(), $module->getModuleContext(), $module);
    $license->assertValid();

    $tokenManager = new PrestaShop\Module\AllegroCustomerService\Service\TokenManager();
    $apiClient = new PrestaShop\Module\AllegroCustomerService\Service\AllegroApiClient($tokenManager);
    $ruleEngine = new PrestaShop\Module\AllegroCustomerService\Service\RuleEngine();
    $logger = new PrestaShop\Module\AllegroCustomerService\Service\Logger();
    $responder = new PrestaShop\Module\AllegroCustomerService\Service\Responder(
        $apiClient,
        $logger,
        (bool) Configuration::get(AllegroCustomerService::CONFIG_PREFIX . 'TEST_MODE')
    );
    $scanner = new PrestaShop\Module\AllegroCustomerService\Service\MessageScanner(
        $apiClient,
        $ruleEngine,
        $responder,
        $logger
    );
    $summary = $scanner->scan((int) Configuration::get(AllegroCustomerService::CONFIG_PREFIX . 'POLL_LIMIT'));

    $finish(array_merge(['ok' => true], $summary));
} catch (Throwable $e) {
    PrestaShopLogger::addLog('[AAR] Cron error: ' . $e->getMessage(), 3);
    $finish(['ok' => false, 'message' => $e->getMessage()], 500);
}

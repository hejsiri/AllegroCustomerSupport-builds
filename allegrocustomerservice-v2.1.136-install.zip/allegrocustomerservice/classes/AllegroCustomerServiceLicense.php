<?php
/**
 * Copyright (c) 2026 Prestino. All rights reserved.
 *
 * This file is proprietary software. Copying, modification, distribution,
 * or use outside the terms of a valid Prestino license is prohibited.
 *
 * @author Prestino
 * @copyright 2026 Prestino
 * @license Proprietary
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

if (!class_exists('AllegroCustomerServiceLicense', false)) {
    class AllegroCustomerServiceLicense
    {
        private const LICENSE_FILE = 'license.php';
        private const PUBLIC_KEY_FILE = 'keys/license_public.pem';

        private $modulePath;
        private $context;
        private $module;
        private $status;

        public function __construct(string $modulePath, $context, Module $module)
        {
            $this->modulePath = rtrim($modulePath, '/\\') . DIRECTORY_SEPARATOR;
            $this->context = $context;
            $this->module = $module;
        }

        public function getStatus(): array
        {
            if ($this->status !== null) {
                return $this->status;
            }

            $licenseKey = $this->loadLicenseKey();
            if ($licenseKey === null || $licenseKey === '') {
                return $this->status = $this->buildStatus(false, 'missing', 'Moduł wymaga prawidłowej licencji Prestino.');
            }

            $parts = explode('.', $licenseKey, 2);
            if (count($parts) !== 2) {
                return $this->status = $this->buildStatus(false, 'invalid_format', 'Plik licencji jest nieprawidłowy.');
            }

            $payloadEncoded = trim($parts[0]);
            $payloadJson = $this->base64UrlDecode($payloadEncoded);
            $signature = $this->base64UrlDecode(trim($parts[1]));
            $payload = json_decode($payloadJson, true);
            $publicKeyPath = $this->modulePath . self::PUBLIC_KEY_FILE;

            if ($payloadJson === '' || $signature === '' || !is_array($payload)
                || !function_exists('openssl_verify') || !is_readable($publicKeyPath)
                || openssl_verify(
                    $payloadEncoded,
                    $signature,
                    (string) file_get_contents($publicKeyPath),
                    OPENSSL_ALGO_SHA256
                ) !== 1
            ) {
                return $this->status = $this->buildStatus(false, 'signature_invalid', 'Podpis licencji jest nieprawidłowy.');
            }

            if ((string) ($payload['module'] ?? '') !== $this->module->name) {
                return $this->status = $this->buildStatus(false, 'module_mismatch', 'Licencja została wystawiona dla innego modułu.');
            }

            $licensedDomain = $this->normalizeDomain((string) ($payload['domain'] ?? ''));
            $currentDomain = $this->normalizeDomain($this->getCurrentDomain());
            $licensedDomains = isset($payload['domains']) && is_array($payload['domains'])
                ? $payload['domains']
                : [$licensedDomain];
            $domainValid = false;
            foreach ($licensedDomains as $candidate) {
                if ($this->domainMatches(
                    $this->normalizeDomain((string) $candidate),
                    $currentDomain,
                    !empty($payload['allow_subdomains'])
                )) {
                    $domainValid = true;
                    break;
                }
            }
            if (!$domainValid) {
                return $this->status = $this->buildStatus(false, 'domain_mismatch', 'Licencja nie jest ważna dla domeny tego sklepu.');
            }

            $startsAt = (string) ($payload['starts_at'] ?? '');
            if ($startsAt !== '' && !$this->dateHasStarted($startsAt)) {
                return $this->status = $this->buildStatus(false, 'not_started', 'Okres obowiązywania licencji jeszcze się nie rozpoczął.');
            }

            $isLegacy = empty($payload['license_id']) && empty($payload['plan']) && empty($payload['license_type']);
            $plan = (string) ($payload['plan'] ?? $payload['license_type'] ?? ($isLegacy ? 'legacy' : 'perpetual'));
            $expiresAt = (string) ($payload['expires_at'] ?? '');
            if (($plan === 'trial' || $isLegacy) && !$this->dateIsActive($expiresAt)) {
                return $this->status = $this->buildStatus(
                    false,
                    $plan === 'trial' ? 'trial_expired' : 'expired',
                    $plan === 'trial' ? 'Wersja testowa modułu wygasła.' : 'Licencja wygasła.'
                );
            }

            $supportIncluded = array_key_exists('support_included', $payload)
                ? (bool) $payload['support_included']
                : in_array($plan, ['annual', 'perpetual_support'], true);
            $supportUntil = $supportIncluded
                ? (string) ($payload['support_until'] ?? $payload['expires_at'] ?? '')
                : '';
            $updatesUntil = $supportIncluded
                ? (string) ($payload['updates_until'] ?? $supportUntil)
                : '';

            return $this->status = $this->buildStatus(true, 'valid', '', [
                'domain' => $licensedDomain,
                'customer' => (string) ($payload['customer'] ?? ''),
                'license_id' => (string) ($payload['license_id'] ?? ''),
                'plan' => $plan,
                'perpetual' => array_key_exists('perpetual', $payload) ? (bool) $payload['perpetual'] : !in_array($plan, ['trial', 'legacy'], true),
                'expires_at' => $expiresAt,
                'support_included' => $supportIncluded,
                'updates_until' => $updatesUntil,
                'updates_active' => $this->dateIsActive($updatesUntil),
                'support_until' => $supportUntil,
                'support_active' => $this->dateIsActive($supportUntil),
                'legacy' => $isLegacy,
                'payload' => $payload,
            ]);
        }

        public function assertValid(): void
        {
            $status = $this->getStatus();
            if (empty($status['valid'])) {
                throw new PrestaShopException((string) $status['message']);
            }
        }

        public function getLicenseKey(): string
        {
            return (string) ($this->loadLicenseKey() ?? '');
        }

        private function loadLicenseKey(): ?string
        {
            $path = $this->modulePath . self::LICENSE_FILE;
            if (!is_file($path)) {
                return null;
            }

            try {
                $value = require $path;
            } catch (Throwable $e) {
                return '';
            }

            if (is_string($value)) {
                return trim($value);
            }
            if (is_array($value)) {
                foreach (['key', 'license_key'] as $field) {
                    if (isset($value[$field]) && is_string($value[$field])) {
                        return trim($value[$field]);
                    }
                }
            }

            return '';
        }

        private function getCurrentDomain(): string
        {
            if (isset($this->context->shop) && method_exists($this->context->shop, 'getBaseURL')) {
                $host = parse_url((string) $this->context->shop->getBaseURL(true), PHP_URL_HOST);
                if (is_string($host) && $host !== '') {
                    return $host;
                }
            }

            return (string) ($_SERVER['HTTP_HOST'] ?? $_SERVER['SERVER_NAME'] ?? '');
        }

        private function normalizeDomain(string $domain): string
        {
            $domain = trim(strtolower($domain));
            if ($domain === '') {
                return '';
            }
            if (strpos($domain, '://') !== false) {
                $domain = (string) parse_url($domain, PHP_URL_HOST);
            }
            $domain = rtrim((string) preg_replace('~:\\d+$~', '', $domain), '.');

            return strpos($domain, 'www.') === 0 ? substr($domain, 4) : $domain;
        }

        private function domainMatches(string $licensedDomain, string $currentDomain, bool $allowSubdomains): bool
        {
            if ($licensedDomain === '' || $currentDomain === '') {
                return false;
            }
            if ($licensedDomain === $currentDomain) {
                return true;
            }
            if (strpos($licensedDomain, '*.') === 0) {
                $suffix = substr($licensedDomain, 1);

                return substr($currentDomain, -strlen($suffix)) === $suffix;
            }

            return $allowSubdomains
                && substr($currentDomain, -strlen('.' . $licensedDomain)) === '.' . $licensedDomain;
        }

        private function dateHasStarted(string $date): bool
        {
            try {
                $value = new DateTimeImmutable($date . (preg_match('/^\\d{4}-\\d{2}-\\d{2}$/', $date) ? ' 00:00:00' : ''));
            } catch (Throwable $e) {
                return false;
            }

            return $value <= new DateTimeImmutable('now');
        }

        private function dateIsActive(string $date): bool
        {
            if (trim($date) === '') {
                return false;
            }
            try {
                $value = new DateTimeImmutable($date . (preg_match('/^\\d{4}-\\d{2}-\\d{2}$/', $date) ? ' 23:59:59' : ''));
            } catch (Throwable $e) {
                return false;
            }

            return $value >= new DateTimeImmutable('now');
        }

        private function base64UrlDecode(string $value): string
        {
            $value = strtr($value, '-_', '+/');
            $decoded = base64_decode($value . str_repeat('=', (4 - strlen($value) % 4) % 4), true);

            return is_string($decoded) ? $decoded : '';
        }

        private function buildStatus(bool $valid, string $code, string $message, array $details = []): array
        {
            return ['valid' => $valid, 'code' => $code, 'message' => $message, 'details' => $details];
        }
    }
}

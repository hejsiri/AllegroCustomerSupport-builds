<?php
/**
 * Copyright (c) 2026 Prestino. All rights reserved.
 *
 * This file is proprietary software. Copying, modification, distribution,
 * or use outside the terms of a valid Prestino license is prohibited.
 *
 * @author Prestino
 * @copyright 2026 Prestino
 * @license Proprietary
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_0_2_121($module)
{
    // Force regeneration with the improved linked-order thumbnail resolver.
    Configuration::deleteByName('AAR_ISSUE_THUMB_CACHE');

    return true;
}

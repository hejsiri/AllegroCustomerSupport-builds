<?php
/**
 * Copyright (c) 2026 Prestino. All rights reserved.
 *
 * This file is proprietary software. Copying, modification, distribution,
 * or use outside the terms of a valid Prestino license is prohibited.
 *
 * @author Prestino
 * @copyright 2026 Prestino
 * @license Proprietary
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_0_2_120($module)
{
    $modulePath = rtrim(method_exists($module, 'getLocalPath') ? $module->getLocalPath() : dirname(__DIR__), '/');
    $paths = [
        'allegroautoresponder.php',
    ];

    foreach ($paths as $path) {
        $fullPath = $modulePath . '/' . $path;
        if (is_file($fullPath) || is_link($fullPath)) {
            @unlink($fullPath);
        }
    }

    return true;
}

<?php
/**
 * Copyright (c) 2026 Prestino. All rights reserved.
 *
 * This file is proprietary software. Copying, modification, distribution,
 * or use outside the terms of a valid Prestino license is prohibited.
 *
 * @author Prestino
 * @copyright 2026 Prestino
 * @license Proprietary
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_0_1_167($module)
{
    if (class_exists('AllegroCustomerServiceUpdater')) {
        Configuration::updateValue(AllegroCustomerServiceUpdater::CONFIG_UPDATE_CHANNEL, AllegroCustomerServiceUpdater::UPDATE_CHANNEL_PUBLIC);
    }

    return true;
}

<?php
/**
 * Copyright (c) 2026 Prestino. All rights reserved.
 *
 * This file is proprietary software. Copying, modification, distribution,
 * or use outside the terms of a valid Prestino license is prohibited.
 *
 * @author Prestino
 * @copyright 2026 Prestino
 * @license Proprietary
 */

if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_allegro_customer_service_prestino_48($module)
{
    return Db::getInstance()->delete('allegro_ar_account')
        && Configuration::deleteByName('AAR_MENU_UNREAD_BADGE_CACHE')
        && Configuration::deleteByName('AAR_MENU_RETURNS_BADGE_CACHE')
        && Configuration::updateValue('AAR_PRESTINO_BUILD', 48);
}

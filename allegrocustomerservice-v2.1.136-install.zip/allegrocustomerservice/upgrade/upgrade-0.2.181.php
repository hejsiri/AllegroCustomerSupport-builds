<?php
/**
 * Copyright (c) 2026 Prestino. All rights reserved.
 *
 * This file is proprietary software. Copying, modification, distribution,
 * or use outside the terms of a valid Prestino license is prohibited.
 *
 * @author Prestino
 * @copyright 2026 Prestino
 * @license Proprietary
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_0_2_181($module)
{
    $raw = (string) Configuration::get('AAR_QUICK_REPLIES');
    if ($raw === '') {
        return true;
    }

    $rows = json_decode($raw, true);
    if (!is_array($rows)) {
        return true;
    }

    $changed = false;
    foreach ($rows as &$row) {
        if (!is_array($row) || trim((string) ($row['name'] ?? '')) !== 'Odpowiedź na reklamację — odmowa') {
            continue;
        }

        $text = (string) ($row['response_template'] ?? $row['text'] ?? '');
        $updatedText = str_replace(
            'dotyczącą produktu „{claim_product_name}”',
            'dotyczącą produktu {offer_title}',
            $text
        );
        if ($updatedText !== $text) {
            $row['response_template'] = $updatedText;
            unset($row['text']);
            $changed = true;
        }
    }
    unset($row);

    if (!$changed) {
        return true;
    }

    return Configuration::updateValue(
        'AAR_QUICK_REPLIES',
        json_encode($rows, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)
    );
}

<?php
/**
 * Copyright (c) 2026 Prestino. All rights reserved.
 *
 * This file is proprietary software. Copying, modification, distribution,
 * or use outside the terms of a valid Prestino license is prohibited.
 *
 * @author Prestino
 * @copyright 2026 Prestino
 * @license Proprietary
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

if (!class_exists('AllegroCustomerServiceReturnThumbnailModuleFrontController', false)) {
    class AllegroCustomerServiceReturnThumbnailModuleFrontController extends ModuleFrontController
    {
        public $display_header = false;
        public $display_footer = false;

        public function initContent()
        {
            parent::initContent();

            if (!$this->module instanceof AllegroCustomerService) {
                http_response_code(503);
                exit;
            }

            $token = trim((string) Tools::getValue('token'));
            $expected = trim((string) Configuration::get(AllegroCustomerService::CONFIG_PREFIX . 'CRON_TOKEN'));
            if ($expected === '' || !hash_equals($expected, $token)) {
                http_response_code(403);
                exit;
            }

            $returnId = trim((string) Tools::getValue('return_id'));
            if ($returnId === '') {
                http_response_code(400);
                exit;
            }

            try {
                $url = $this->module->resolveCustomerReturnThumbnailById($returnId);
                if ($url === '') {
                    http_response_code(404);
                    exit;
                }

                Tools::redirect($url);
            } catch (Throwable $e) {
                PrestaShopLogger::addLog('[AAR] Return thumbnail lookup failed for ' . $returnId . ': ' . $e->getMessage(), 2);
                http_response_code(404);
                exit;
            }
        }
    }
}

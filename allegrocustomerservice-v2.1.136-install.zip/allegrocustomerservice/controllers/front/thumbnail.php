<?php
/**
 * Copyright (c) 2026 Prestino. All rights reserved.
 *
 * This file is proprietary software. Copying, modification, distribution,
 * or use outside the terms of a valid Prestino license is prohibited.
 *
 * @author Prestino
 * @copyright 2026 Prestino
 * @license Proprietary
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

if (!class_exists('AllegroCustomerServiceThumbnailModuleFrontController', false)) {
    class AllegroCustomerServiceThumbnailModuleFrontController extends ModuleFrontController
    {
        public $display_header = false;
        public $display_footer = false;

        public function initContent()
        {
            parent::initContent();

            $module = $this->module;
            if (!$module instanceof AllegroCustomerService) {
                $this->respondError(503, 'Module unavailable');

                return;
            }

            $token = trim((string) Tools::getValue('token'));
            $expected = trim((string) Configuration::get(AllegroCustomerService::CONFIG_PREFIX . 'CRON_TOKEN'));
            if ($expected === '' || !hash_equals($expected, $token)) {
                $this->respondError(403, 'Invalid token');
            }

            $offerId = trim((string) Tools::getValue('offer_id'));
            $productId = trim((string) Tools::getValue('product_id'));
            $checkoutFormId = trim((string) Tools::getValue('checkout_form_id'));
            $issueId = trim((string) Tools::getValue('issue_id'));
            $mode = trim((string) Tools::getValue('mode'));

            if ($offerId === '' && $productId === '' && $checkoutFormId === '' && $issueId === '') {
                $this->respondError(400, 'Missing identifiers');
            }

            try {
                if ($mode !== 'image' || (int) Tools::getValue('debug') === 1) {
                    header('Content-Type: application/json; charset=utf-8');
                    exit(json_encode(
                        $module->debugIssueThumbnailLookup(
                            $offerId,
                            $productId,
                            $checkoutFormId,
                            $issueId,
                            (int) Tools::getValue('refresh') === 1 || (int) Tools::getValue('nocache') === 1
                        ),
                        JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE
                    ));
                }

                $url = $module->warmIssueThumbnailCache($offerId, $productId, $checkoutFormId, $issueId);

                if ($mode === 'image') {
                    if ($url === '') {
                        http_response_code(404);
                        exit;
                    }

                    Tools::redirect($url);
                }

                header('Content-Type: application/json; charset=utf-8');
                exit(json_encode([
                    'ok' => $url !== '',
                    'url' => $url,
                ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE));
            } catch (Throwable $e) {
                $this->respondError(500, $e->getMessage());
            }
        }

        protected function respondError(int $statusCode, string $message): void
        {
            if (trim((string) Tools::getValue('mode')) === 'image') {
                http_response_code($statusCode);
                exit;
            }

            header('Content-Type: application/json; charset=utf-8');
            http_response_code($statusCode);
            exit(json_encode([
                'ok' => false,
                'message' => $message,
            ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE));
        }
    }
}

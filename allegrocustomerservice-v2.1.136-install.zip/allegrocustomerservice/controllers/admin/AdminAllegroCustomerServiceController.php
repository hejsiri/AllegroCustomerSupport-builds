<?php
/**
 * Copyright (c) 2026 Prestino. All rights reserved.
 *
 * This file is proprietary software. Copying, modification, distribution,
 * or use outside the terms of a valid Prestino license is prohibited.
 *
 * @author Prestino
 * @copyright 2026 Prestino
 * @license Proprietary
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

if (!class_exists('AdminAllegroCustomerServiceController', false)) {
    class AdminAllegroCustomerServiceController extends ModuleAdminController
    {
        public function init()
        {
            parent::init();

            $url = method_exists($this->module, 'getAdminLinkFor')
                ? $this->module->getAdminLinkFor('AdminAllegroCustomerServiceMessages')
                : $this->context->link->getAdminLink('AdminAllegroCustomerServiceMessages');

            Tools::redirectAdmin($url);
        }
    }
}

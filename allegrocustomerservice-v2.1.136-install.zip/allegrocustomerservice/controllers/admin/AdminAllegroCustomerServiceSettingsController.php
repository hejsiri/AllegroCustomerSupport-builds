<?php
/**
 * Copyright (c) 2026 Prestino. All rights reserved.
 *
 * This file is proprietary software. Copying, modification, distribution,
 * or use outside the terms of a valid Prestino license is prohibited.
 *
 * @author Prestino
 * @copyright 2026 Prestino
 * @license Proprietary
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

if (!class_exists('AdminAllegroCustomerServiceSettingsController', false)) {
    class AdminAllegroCustomerServiceSettingsController extends ModuleAdminController
    {
        public function __construct()
        {
            $this->bootstrap = true;
            parent::__construct();
        }

        public function initContent()
        {
            if (!$this->module instanceof AllegroCustomerService) {
                throw new RuntimeException('Allegro Customer Service module is unavailable.');
            }

            parent::initContent();

            $this->content .= $this->module->getContent();
            $this->context->smarty->assign('content', $this->content);
        }
    }
}

<?php
/**
 * Copyright (c) 2026 Prestino. All rights reserved.
 *
 * This file is proprietary software. Copying, modification, distribution,
 * or use outside the terms of a valid Prestino license is prohibited.
 *
 * @author Prestino
 * @copyright 2026 Prestino
 * @license Proprietary
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

return [
    'manifest_url' => '',
    'github_repository' => 'hejsiri/AllegroCustomerSupport-builds',
    'github_branch' => 'main',
    'manifest_path' => 'latest.json',
    'manifest_paths' => [
        'public' => 'latest.json',
        'beta' => 'latest-beta.json',
    ],
];

<link rel="stylesheet" href="{$prestino_license_css_url|escape:'htmlall':'UTF-8'}">
<script>
  window.allegroCustomerServicePrestino = {$prestino_browser_config_json nofilter};
</script>
<script src="{$prestino_license_js_url|escape:'htmlall':'UTF-8'}"></script>

<style>
  .aar-settings-page .btn > i[class^="icon-"],
  .aar-settings-page .btn > i[class*=" icon-"] {
    margin-right: 8px !important;
  }

  .aar-account-summary {
    font-size: 14px;
    line-height: 1.55;
  }

  .aar-account-summary p,
  .aar-account-summary code,
  .aar-account-summary .aar-account-line {
    font-size: 14px;
  }

  .aar-cron-field {
    display: flex;
    align-items: stretch;
    margin: 8px 0 18px;
  }

  .aar-cron-field .form-control[readonly] {
    background: #fff;
    cursor: text;
  }

  .aar-cron-field .form-control {
    flex: 1 1 auto;
    width: 1%;
    height: 42px !important;
    min-height: 42px !important;
    margin: 0 !important;
    padding: 0 16px;
    border-radius: 4px 0 0 4px;
    box-sizing: border-box !important;
  }

  .aar-cron-buttons {
    display: flex;
    flex: 0 0 auto;
    align-items: stretch;
    height: 42px !important;
  }

  .aar-cron-field .aar-cron-buttons .btn {
    display: inline-flex !important;
    align-items: center;
    justify-content: center;
    min-width: 112px;
    height: 42px !important;
    min-height: 42px !important;
    max-height: 42px !important;
    margin: 0 !important;
    padding: 0 18px !important;
    border-radius: 0;
    line-height: 1 !important;
    box-sizing: border-box !important;
  }

  .aar-cron-field .aar-cron-buttons .btn + .btn {
    margin-left: -1px !important;
  }

  .aar-cron-field .aar-cron-buttons .btn:last-child {
    border-radius: 0 4px 4px 0;
  }

  .aar-cron-field .aar-cron-buttons .btn i {
    margin: 0 6px 0 0;
    line-height: 1;
  }

  .aar-cron-field .aar-cron-buttons .aar-cron-copy,
  .aar-cron-field .aar-cron-buttons .aar-cron-copy i,
  .aar-cron-field .aar-cron-buttons .aar-cron-copy span {
    color: #fff !important;
  }

  .aar-cron-field .aar-cron-buttons .aar-cron-copy.is-copied {
    color: #fff !important;
    border-color: #72c279 !important;
    background: #72c279 !important;
  }

  .aar-cron-field .aar-cron-buttons .aar-cron-copy.is-copied:hover,
  .aar-cron-field .aar-cron-buttons .aar-cron-copy.is-copied:focus {
    color: #fff !important;
    border-color: #60b768 !important;
    background: #60b768 !important;
  }
</style>

<div class="aar-settings-page">
<div class="aar-prestino-alerts">
  {$license_status_panel nofilter}
</div>
<div class="panel aar-account-summary">
  <h3>Ustawienia modułu Obsługa Klienta Allegro</h3>
  <label for="aar-cron-url">Adres zadania CRON</label>
  <div class="aar-cron-field">
    <input type="text" class="form-control" id="aar-cron-url" value="{$cron_url|escape:'htmlall':'UTF-8'}" readonly>
    <span class="aar-cron-buttons">
      <button type="button" class="btn btn-primary aar-cron-copy" id="aar-cron-copy" title="Kopiuj adres CRON do schowka">
        <i class="icon-copy" aria-hidden="true"></i> <span class="aar-cron-copy-label">Kopiuj</span>
      </button>
      <a class="btn btn-default" href="{$cron_url|escape:'htmlall':'UTF-8'}" target="_blank" rel="noopener noreferrer" title="Uruchom zadanie CRON w nowej karcie">
        <i class="icon-external-link" aria-hidden="true"></i> Otwórz
      </a>
    </span>
  </div>
  {if $connected_account}
    <p>
      <strong>Połączone konto:</strong>
      {$connected_account.login|escape:'htmlall':'UTF-8'}
      {if $connected_account.allegro_user_id}({$connected_account.allegro_user_id|escape:'htmlall':'UTF-8'}){/if}
      <br>
      <span class="aar-account-line">Token ważny do: {$connected_account.expires_at|escape:'htmlall':'UTF-8'}</span>
    </p>
    <form method="post" style="margin:0 0 12px 0;" onsubmit="return confirm('Rozłączyć konto Allegro w module? Tokeny zostaną usunięte lokalnie.');">
      <button type="submit" name="submitAarDisconnectAccount" class="btn btn-danger">
        Rozłącz konto
      </button>
    </form>
  {else}
    <p><strong>Status:</strong> konto Allegro nie jest jeszcze połączone.</p>
    {if $device_auth_enabled}
      <p>
        <button type="button" class="btn btn-primary" id="aar-device-auth-start">
          Połącz konto Allegro
        </button>
      </p>
    {else}
      <p>Brakuje adresu backendu autoryzacji Allegro. Uzupełnij go w konfiguracji technicznej albo zdefiniuj stałą <code>AAR_ALLEGRO_AUTH_BACKEND_URL</code>.</p>
    {/if}
  {/if}
  <p>Na start zostaw test mode włączony. Najpierw podłącz konto Allegro, dodaj reguły i uruchom skan ręczny.</p>
</div>

<div class="modal fade" id="aar-device-auth-modal" tabindex="-1" role="dialog" aria-hidden="true" data-backdrop="static" data-keyboard="false">
  <div class="modal-dialog" role="document" style="max-width:650px;">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title">Autoryzacja konta Allegro</h4>
      </div>
      <div class="modal-body" style="text-align:center;">
        <div id="aar-device-auth-init">
          <p>Powiąż konto z serwisem Allegro, aby ukończyć proces autoryzacji.</p>
          <a href="#" target="_blank" rel="nofollow noopener" class="btn btn-warning" id="aar-device-auth-link">Powiąż konto Allegro</a>
          <p id="aar-device-auth-code-wrap" style="display:none;margin-top:12px;">Kod autoryzacyjny: <strong id="aar-device-auth-code"></strong></p>
        </div>
        <div id="aar-device-auth-waiting" style="display:none;">
          <p><i class="icon-cog"></i></p>
          <p>Oczekiwanie na potwierdzenie w Allegro...</p>
        </div>
        <div id="aar-device-auth-success" style="display:none;">
          <p style="font-size:28px;color:#60ba68;"><i class="icon-check"></i></p>
          <p><span style="color:#60ba68;">Konto zostało pomyślnie zautoryzowane</span><br><span id="aar-device-auth-account"></span></p>
          <a href="" class="btn btn-success" id="aar-device-auth-finish">Zakończ</a>
        </div>
        <div id="aar-device-auth-error" style="display:none;">
          <p style="font-size:28px;color:#d9534f;"><i class="icon-remove"></i></p>
          <p id="aar-device-auth-error-message" style="color:#d9534f;"></p>
          <button type="button" class="btn btn-default" data-dismiss="modal">Zamknij</button>
        </div>
      </div>
    </div>
  </div>
</div>

<script>
  (function () {
    var ajaxUrl = {$device_auth_url_json nofilter};
    var deviceCode = "";
    var pollTimer = null;
    var pollInterval = 5000;

    function copyCronUrl() {
      var input = document.getElementById("aar-cron-url");
      var button = document.getElementById("aar-cron-copy");
      if (!input || !button) {
        return;
      }

      var markCopied = function () {
        var label = button.querySelector(".aar-cron-copy-label");
        button.classList.add("is-copied");
        if (label) {
          label.textContent = "Skopiowano";
        }
        window.setTimeout(function () {
          button.classList.remove("is-copied");
          if (label) {
            label.textContent = "Kopiuj";
          }
        }, 1800);
      };

      if (navigator.clipboard && window.isSecureContext) {
        navigator.clipboard.writeText(input.value).then(markCopied).catch(function () {
          input.select();
          if (document.execCommand("copy")) {
            markCopied();
          }
        });
        return;
      }

      input.select();
      if (document.execCommand("copy")) {
        markCopied();
      }
    }

    function post(action, data) {
      data = data || {};
      data.ajax = 1;
      data.action = action;

      return fetch(ajaxUrl, {
        method: "POST",
        credentials: "same-origin",
        headers: {
          "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
          "X-Requested-With": "XMLHttpRequest"
        },
        body: new URLSearchParams(data).toString()
      }).then(function (response) {
        return response.text().then(function (text) {
          var json;
          try {
            json = JSON.parse(text);
          } catch (error) {
            text = text.replace(/<[^>]*>/g, " ").replace(/\s+/g, " ").trim();
            throw new Error(text ? "Nieprawidłowa odpowiedź serwera: " + text.substring(0, 220) : "Nieprawidłowa odpowiedź serwera.");
          }

          if (!response.ok && json && json.message) {
            throw new Error(json.message);
          }

          return json;
        });
      });
    }

    function showAuthState(state, message) {
      ["init", "waiting", "success", "error"].forEach(function (name) {
        var element = document.getElementById("aar-device-auth-" + name);
        if (element) {
          element.style.display = name === state ? "" : "none";
        }
      });

      if (state === "error") {
        document.getElementById("aar-device-auth-error-message").textContent = message || "Nie udało się zautoryzować konta Allegro.";
      }
    }

    function pollAuthorization() {
      post("pollDeviceAuthorization", {
        device_code: deviceCode
      }).then(function (json) {
        if (!json.success) {
          throw new Error(json.message || "Błąd autoryzacji.");
        }

        if (!json.authorized) {
          if (json.error === "slow_down") {
            pollInterval += 5000;
            window.clearInterval(pollTimer);
            pollTimer = window.setInterval(pollAuthorization, pollInterval);
          }
          return;
        }

        window.clearInterval(pollTimer);
        pollTimer = null;

        var account = json.account || {};
        var label = account.login ? account.login : account.id || "";
        document.getElementById("aar-device-auth-account").textContent = label ? "Konto: " + label : "";
        showAuthState("success");
      }).catch(function (error) {
        window.clearInterval(pollTimer);
        pollTimer = null;
        showAuthState("error", error.message);
      });
    }

    document.addEventListener("click", function (event) {
      if (event.target && event.target.closest("#aar-cron-copy")) {
        event.preventDefault();
        copyCronUrl();
        return;
      }

      if (event.target && event.target.id === "aar-device-auth-start") {
        event.preventDefault();
        showAuthState("waiting");
        if (window.jQuery && jQuery.fn && jQuery.fn.modal) {
          jQuery("#aar-device-auth-modal").modal("show");
        }

        post("startDeviceAuthorization").then(function (json) {
          if (!json.success) {
            throw new Error(json.message || "Nie udało się rozpocząć autoryzacji.");
          }

          deviceCode = json.deviceCode || "";
          pollInterval = Math.max(3, parseInt(json.interval || 5, 10)) * 1000;
          document.getElementById("aar-device-auth-link").href = json.verificationUriComplete;
          document.getElementById("aar-device-auth-code").textContent = json.userCode || "";
          document.getElementById("aar-device-auth-code-wrap").style.display = json.userCode ? "" : "none";
          showAuthState("init");
        }).catch(function (error) {
          showAuthState("error", error.message);
        });
      }

      if (event.target && event.target.id === "aar-device-auth-link") {
        showAuthState("waiting");
        if (pollTimer) {
          window.clearInterval(pollTimer);
        }
        pollTimer = window.setInterval(pollAuthorization, pollInterval);
      }

      if (event.target && event.target.id === "aar-device-auth-finish") {
        event.preventDefault();
        window.location.reload();
      }
    });
  })();
</script>
{$update_panel nofilter}
{$settings_form nofilter}
{$quick_replies_panel nofilter}
{$rule_form nofilter}
{$rules_table nofilter}
{$logs_table nofilter}
</div>

<?php

if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_allegro_customer_service_prestino_21($module)
{
    return Configuration::updateValue('AAR_PRESTINO_BUILD', 21);
}

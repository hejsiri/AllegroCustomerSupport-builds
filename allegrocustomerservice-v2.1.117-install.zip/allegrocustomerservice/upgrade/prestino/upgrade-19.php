<?php

if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_allegro_customer_service_prestino_19($module)
{
    return Configuration::updateValue('AAR_PRESTINO_BUILD', 19)
        && $module->registerHook('actionAdminControllerSetMedia');
}

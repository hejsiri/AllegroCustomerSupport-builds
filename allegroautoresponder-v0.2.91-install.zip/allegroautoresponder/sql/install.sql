CREATE TABLE IF NOT EXISTS `PREFIX_allegro_ar_account` (
  `id_account` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `allegro_user_id` VARCHAR(64) NOT NULL,
  `login` VARCHAR(128) NOT NULL,
  `access_token` TEXT NULL,
  `refresh_token` TEXT NULL,
  `expires_at` DATETIME NULL,
  `token_type` VARCHAR(32) NULL,
  `scope` TEXT NULL,
  `active` TINYINT(1) NOT NULL DEFAULT 1,
  `date_add` DATETIME NOT NULL,
  `date_upd` DATETIME NOT NULL,
  PRIMARY KEY (`id_account`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `PREFIX_allegro_ar_rule` (
  `id_rule` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(191) NOT NULL,
  `enabled` TINYINT(1) NOT NULL DEFAULT 1,
  `priority` INT NOT NULL DEFAULT 100,
  `match_type` VARCHAR(32) NOT NULL DEFAULT 'contains',
  `keywords` TEXT NOT NULL,
  `response_template` LONGTEXT NOT NULL,
  `only_first_message` TINYINT(1) NOT NULL DEFAULT 1,
  `cooldown_minutes` INT NOT NULL DEFAULT 60,
  `date_add` DATETIME NOT NULL,
  `date_upd` DATETIME NOT NULL,
  PRIMARY KEY (`id_rule`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `PREFIX_allegro_ar_thread` (
  `id_thread` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `allegro_thread_id` VARCHAR(128) NOT NULL,
  `allegro_last_message_id` VARCHAR(128) NULL,
  `last_seen_at` DATETIME NULL,
  `last_auto_reply_at` DATETIME NULL,
  `auto_replied_count` INT NOT NULL DEFAULT 0,
  `status` VARCHAR(32) NOT NULL DEFAULT 'active',
  `date_add` DATETIME NOT NULL,
  `date_upd` DATETIME NOT NULL,
  PRIMARY KEY (`id_thread`),
  UNIQUE KEY `uniq_allegro_thread_id` (`allegro_thread_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `PREFIX_allegro_ar_log` (
  `id_log` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `thread_id` VARCHAR(128) NULL,
  `message_id` VARCHAR(128) NULL,
  `action` VARCHAR(64) NOT NULL,
  `matched_rule` VARCHAR(191) NULL,
  `request_payload` LONGTEXT NULL,
  `response_payload` LONGTEXT NULL,
  `success` TINYINT(1) NOT NULL DEFAULT 0,
  `created_at` DATETIME NOT NULL,
  PRIMARY KEY (`id_log`),
  KEY `idx_created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

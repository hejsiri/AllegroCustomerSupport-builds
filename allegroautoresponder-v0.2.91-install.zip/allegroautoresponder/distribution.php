<?php

return [
    'manifest_url' => '',
    'github_repository' => 'hejsiri/AllegroCustomerSupport-builds',
    'github_branch' => 'main',
    'manifest_path' => 'latest.json',
    'manifest_paths' => [
        'public' => 'latest.json',
        'beta' => 'latest-beta.json',
    ],
];

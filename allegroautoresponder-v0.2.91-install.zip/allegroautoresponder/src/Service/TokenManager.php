<?php
namespace PrestaShop\Module\AllegroAutoresponder\Service;

use Configuration;

class TokenManager
{
    private const DEFAULT_AUTH_BACKEND_URL = 'https://www.smartbest.pl/allegro-auth/';
    private const API_URL = 'https://api.allegro.pl';
    private const ACCEPT = 'application/vnd.allegro.public.v1+json';
    private const CONNECT_TIMEOUT = 10;
    private const REQUEST_TIMEOUT = 20;

    public function getValidAccessToken(): string
    {
        $account = $this->getPrimaryAccount();
        if (!$account) {
            throw new \RuntimeException('No Allegro account connected.');
        }

        if (!empty($account['access_token']) && strtotime((string) $account['expires_at']) > time() + 60) {
            return (string) $account['access_token'];
        }

        if (empty($account['refresh_token'])) {
            throw new \RuntimeException('Refresh token missing.');
        }

        return $this->refreshAccessToken((int) $account['id_account'], (string) $account['refresh_token']);
    }

    public function exchangeAuthorizationCode(string $code): void
    {
        $redirectUri = (string) Configuration::get(\AllegroAutoresponder::CONFIG_PREFIX . 'REDIRECT_URI');
        if ($redirectUri === '') {
            $context = \Context::getContext();
            $redirectUri = $context->link->getModuleLink('allegroautoresponder', 'oauth');
        }

        $response = $this->authBackendRequest('exchange_authorization_code', [
            'code' => $code,
            'redirect_uri' => $redirectUri,
        ]);

        $me = $this->apiRequest('/me', (string) $response['access_token']);
        $this->persistTokenSet($response, null, $me);
    }

    public function refreshAccessToken(int $idAccount, string $refreshToken): string
    {
        $response = $this->authBackendRequest('refresh_token', [
            'refresh_token' => $refreshToken,
        ]);

        $this->persistTokenSet($response, $idAccount, null);

        return (string) $response['access_token'];
    }

    public function startDeviceAuthorization(): array
    {
        $formData = [];
        $scope = $this->getDeviceScope();
        if ($scope !== '') {
            $formData['scope'] = $scope;
        }

        return $this->authBackendRequest('start_device_authorization', $formData);
    }

    public function pollDeviceAuthorization(string $deviceCode): array
    {
        $response = $this->authBackendRequest('poll_device_authorization', [
            'device_code' => $deviceCode,
        ], false);

        $status = (int) ($response['_http_status'] ?? 0);
        unset($response['_http_status']);

        if ($status === 400 && in_array((string) ($response['error'] ?? ''), ['authorization_pending', 'slow_down'], true)) {
            return [
                'authorized' => false,
                'pending' => true,
                'error' => (string) ($response['error'] ?? ''),
            ];
        }

        if ($status === 400 && (string) ($response['error'] ?? '') === 'access_denied') {
            throw new \RuntimeException('Autoryzacja konta Allegro została przerwana lub odrzucona.');
        }

        if ($status === 400 && (string) ($response['error'] ?? '') === 'expired_token') {
            throw new \RuntimeException('Kod autoryzacyjny Allegro wygasł. Rozpocznij autoryzację ponownie.');
        }

        if ($status === 400 && (string) ($response['error_description'] ?? '') === 'Invalid device code') {
            throw new \RuntimeException('Allegro odrzuciło kod urządzenia. Rozpocznij autoryzację ponownie.');
        }

        if ($status >= 400 || empty($response['access_token'])) {
            throw new \RuntimeException('OAuth device error (' . $status . '): ' . json_encode($response));
        }

        $me = $this->apiRequest('/me', (string) $response['access_token']);
        $this->persistTokenSet($response, null, $me);

        return [
            'authorized' => true,
            'account' => [
                'id' => (string) ($me['id'] ?? ''),
                'login' => (string) ($me['login'] ?? ''),
                'baseMarketplace' => (string) ($me['baseMarketplace']['id'] ?? ''),
            ],
        ];
    }

    private function authBackendRequest(string $action, array $formData = [], bool $throwOnError = true): array
    {
        $url = $this->getAuthBackendUrl();
        $formData = array_merge([
            'action' => $action,
            'shop_url' => $this->getShopUrl(),
            'module' => 'allegroautoresponder',
        ], $formData);

        $ch = curl_init((string) $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($formData));

        $headers = [
            'Accept: application/json',
            'Content-Type: application/x-www-form-urlencoded',
            'User-Agent: PrestaShop-AllegroCustomerSupport/0.1',
        ];

        $backendKey = $this->getAuthBackendKey();
        if ($backendKey !== '') {
            $headers[] = 'Authorization: Bearer ' . $backendKey;
        }

        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, self::CONNECT_TIMEOUT);
        curl_setopt($ch, CURLOPT_TIMEOUT, self::REQUEST_TIMEOUT);

        $raw = curl_exec($ch);
        $status = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        if ($raw === false) {
            $error = curl_error($ch);
            curl_close($ch);
            throw new \RuntimeException('Auth backend cURL error: ' . $error);
        }
        curl_close($ch);

        $decoded = json_decode($raw, true);
        if (!is_array($decoded)) {
            throw new \RuntimeException('Auth backend error (' . $status . '): ' . $raw);
        }

        if ($status >= 400 && $throwOnError) {
            throw new \RuntimeException('Auth backend error (' . $status . '): ' . $raw);
        }

        if (!isset($decoded['_http_status'])) {
            $decoded['_http_status'] = $status;
        }

        if ((int) $decoded['_http_status'] >= 400 && $throwOnError) {
            throw new \RuntimeException('Auth backend OAuth error (' . (int) $decoded['_http_status'] . '): ' . json_encode($decoded));
        }

        return $decoded;
    }

    public function hasAuthBackend(): bool
    {
        return $this->getAuthBackendUrl() !== '';
    }

    private function getAuthBackendUrl(): string
    {
        $url = trim((string) Configuration::get(\AllegroAutoresponder::CONFIG_PREFIX . 'AUTH_BACKEND_URL'));
        if ($url === '' && defined('AAR_ALLEGRO_AUTH_BACKEND_URL')) {
            $url = trim((string) constant('AAR_ALLEGRO_AUTH_BACKEND_URL'));
        }
        if ($url === '') {
            $url = self::DEFAULT_AUTH_BACKEND_URL;
        }

        return $url;
    }

    private function getAuthBackendKey(): string
    {
        $key = trim((string) Configuration::get(\AllegroAutoresponder::CONFIG_PREFIX . 'AUTH_BACKEND_KEY'));
        if ($key === '' && defined('AAR_ALLEGRO_AUTH_BACKEND_KEY')) {
            $key = trim((string) constant('AAR_ALLEGRO_AUTH_BACKEND_KEY'));
        }

        return $key;
    }

    private function getShopUrl(): string
    {
        if (class_exists('\\Context')) {
            $context = \Context::getContext();
            if ($context && isset($context->shop) && method_exists($context->shop, 'getBaseURL')) {
                return (string) $context->shop->getBaseURL(true, true);
            }
        }

        return '';
    }

    private function getDeviceScope(): string
    {
        if (defined('AAR_ALLEGRO_OAUTH_SCOPES')) {
            return trim((string) constant('AAR_ALLEGRO_OAUTH_SCOPES'));
        }

        return '';
    }

    private function apiRequest(string $path, string $accessToken): array
    {
        $ch = curl_init(self::API_URL . $path);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Authorization: Bearer ' . $accessToken,
            'Accept: ' . self::ACCEPT,
            'User-Agent: PrestaShop-AllegroCustomerSupport/0.1',
        ]);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, self::CONNECT_TIMEOUT);
        curl_setopt($ch, CURLOPT_TIMEOUT, self::REQUEST_TIMEOUT);

        $raw = curl_exec($ch);
        $status = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        if ($raw === false) {
            $error = curl_error($ch);
            curl_close($ch);
            throw new \RuntimeException('Allegro API cURL error: ' . $error);
        }
        curl_close($ch);

        $decoded = json_decode($raw, true);
        if ($status === 403) {
            throw new \RuntimeException('Allegro API access denied for GET ' . $path . '. Sprawdź uprawnienia aplikacji i ponownie połącz konto Allegro. Response: ' . $raw);
        }

        if ($status >= 400 || !is_array($decoded)) {
            throw new \RuntimeException('Allegro API error (' . $status . '): ' . $raw);
        }

        return $decoded;
    }

    private function persistTokenSet(array $tokenSet, ?int $idAccount, ?array $accountInfo): void
    {
        $data = [
            'access_token' => pSQL((string) ($tokenSet['access_token'] ?? '')),
            'refresh_token' => pSQL((string) ($tokenSet['refresh_token'] ?? '')),
            'expires_at' => date('Y-m-d H:i:s', time() + (int) ($tokenSet['expires_in'] ?? 0)),
            'token_type' => pSQL((string) ($tokenSet['token_type'] ?? 'bearer')),
            'scope' => pSQL((string) ($tokenSet['scope'] ?? ''), true),
            'active' => 1,
            'date_upd' => date('Y-m-d H:i:s'),
        ];

        if ($accountInfo) {
            $data['allegro_user_id'] = pSQL((string) ($accountInfo['id'] ?? ''));
            $data['login'] = pSQL((string) ($accountInfo['login'] ?? ''));
        }

        if ($idAccount) {
            if ($data['refresh_token'] === '') {
                unset($data['refresh_token']);
            }
            \Db::getInstance()->update('allegro_ar_account', $data, 'id_account=' . (int) $idAccount);
            return;
        }

        $existing = $this->getPrimaryAccount();
        if ($existing) {
            \Db::getInstance()->update('allegro_ar_account', $data, 'id_account=' . (int) $existing['id_account']);
        } else {
            $data['allegro_user_id'] = $data['allegro_user_id'] ?? '';
            $data['login'] = $data['login'] ?? '';
            $data['date_add'] = date('Y-m-d H:i:s');
            \Db::getInstance()->insert('allegro_ar_account', $data);
        }
    }

    private function getPrimaryAccount(): ?array
    {
        $row = \Db::getInstance()->getRow('SELECT * FROM `' . _DB_PREFIX_ . 'allegro_ar_account` ORDER BY id_account ASC');
        return is_array($row) ? $row : null;
    }
}

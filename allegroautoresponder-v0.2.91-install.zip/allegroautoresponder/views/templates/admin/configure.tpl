<style>
  .aar-account-summary {
    font-size: 14px;
    line-height: 1.55;
  }

  .aar-account-summary p,
  .aar-account-summary code,
  .aar-account-summary .aar-account-line {
    font-size: 14px;
  }
</style>

<div class="panel aar-account-summary">
  <h3>Ustawienia modułu Obsługa Klienta Allegro</h3>
  <p><strong>Adres CRON:</strong> <code>{$cron_url|escape:'htmlall':'UTF-8'}</code></p>
  {if $connected_account}
    <p>
      <strong>Połączone konto:</strong>
      {$connected_account.login|escape:'htmlall':'UTF-8'}
      {if $connected_account.allegro_user_id}({$connected_account.allegro_user_id|escape:'htmlall':'UTF-8'}){/if}
      <br>
      <span class="aar-account-line">Token ważny do: {$connected_account.expires_at|escape:'htmlall':'UTF-8'}</span>
    </p>
    <form method="post" style="margin:0 0 12px 0;" onsubmit="return confirm('Rozłączyć konto Allegro w module? Tokeny zostaną usunięte lokalnie.');">
      <button type="submit" name="submitAarDisconnectAccount" class="btn btn-danger">
        Rozłącz konto
      </button>
    </form>
  {else}
    <p><strong>Status:</strong> konto Allegro nie jest jeszcze połączone.</p>
    {if $device_auth_enabled}
      <p>
        <button type="button" class="btn btn-primary" id="aar-device-auth-start">
          Połącz konto Allegro
        </button>
      </p>
    {else}
      <p>Brakuje adresu backendu autoryzacji Allegro. Uzupełnij go w konfiguracji technicznej albo zdefiniuj stałą <code>AAR_ALLEGRO_AUTH_BACKEND_URL</code>.</p>
    {/if}
  {/if}
  <p>Na start zostaw test mode włączony. Najpierw podłącz konto Allegro, dodaj reguły i uruchom skan ręczny.</p>
</div>

<div class="modal fade" id="aar-device-auth-modal" tabindex="-1" role="dialog" aria-hidden="true" data-backdrop="static" data-keyboard="false">
  <div class="modal-dialog" role="document" style="max-width:650px;">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title">Autoryzacja konta Allegro</h4>
      </div>
      <div class="modal-body" style="text-align:center;">
        <div id="aar-device-auth-init">
          <p>Powiąż konto z serwisem Allegro, aby ukończyć proces autoryzacji.</p>
          <a href="#" target="_blank" rel="nofollow noopener" class="btn btn-warning" id="aar-device-auth-link">Powiąż konto Allegro</a>
          <p id="aar-device-auth-code-wrap" style="display:none;margin-top:12px;">Kod autoryzacyjny: <strong id="aar-device-auth-code"></strong></p>
        </div>
        <div id="aar-device-auth-waiting" style="display:none;">
          <p><i class="icon-cog"></i></p>
          <p>Oczekiwanie na potwierdzenie w Allegro...</p>
        </div>
        <div id="aar-device-auth-success" style="display:none;">
          <p style="font-size:28px;color:#60ba68;"><i class="icon-check"></i></p>
          <p><span style="color:#60ba68;">Konto zostało pomyślnie zautoryzowane</span><br><span id="aar-device-auth-account"></span></p>
          <a href="" class="btn btn-success" id="aar-device-auth-finish">Zakończ</a>
        </div>
        <div id="aar-device-auth-error" style="display:none;">
          <p style="font-size:28px;color:#d9534f;"><i class="icon-remove"></i></p>
          <p id="aar-device-auth-error-message" style="color:#d9534f;"></p>
          <button type="button" class="btn btn-default" data-dismiss="modal">Zamknij</button>
        </div>
      </div>
    </div>
  </div>
</div>

<script>
  (function () {
    var ajaxUrl = {$device_auth_url_json nofilter};
    var deviceCode = "";
    var pollTimer = null;
    var pollInterval = 5000;

    function post(action, data) {
      data = data || {};
      data.ajax = 1;
      data.action = action;

      return fetch(ajaxUrl, {
        method: "POST",
        credentials: "same-origin",
        headers: {
          "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
          "X-Requested-With": "XMLHttpRequest"
        },
        body: new URLSearchParams(data).toString()
      }).then(function (response) {
        return response.text().then(function (text) {
          var json;
          try {
            json = JSON.parse(text);
          } catch (error) {
            text = text.replace(/<[^>]*>/g, " ").replace(/\s+/g, " ").trim();
            throw new Error(text ? "Nieprawidłowa odpowiedź serwera: " + text.substring(0, 220) : "Nieprawidłowa odpowiedź serwera.");
          }

          if (!response.ok && json && json.message) {
            throw new Error(json.message);
          }

          return json;
        });
      });
    }

    function showAuthState(state, message) {
      ["init", "waiting", "success", "error"].forEach(function (name) {
        var element = document.getElementById("aar-device-auth-" + name);
        if (element) {
          element.style.display = name === state ? "" : "none";
        }
      });

      if (state === "error") {
        document.getElementById("aar-device-auth-error-message").textContent = message || "Nie udało się zautoryzować konta Allegro.";
      }
    }

    function pollAuthorization() {
      post("pollDeviceAuthorization", {
        device_code: deviceCode
      }).then(function (json) {
        if (!json.success) {
          throw new Error(json.message || "Błąd autoryzacji.");
        }

        if (!json.authorized) {
          if (json.error === "slow_down") {
            pollInterval += 5000;
            window.clearInterval(pollTimer);
            pollTimer = window.setInterval(pollAuthorization, pollInterval);
          }
          return;
        }

        window.clearInterval(pollTimer);
        pollTimer = null;

        var account = json.account || {};
        var label = account.login ? account.login : account.id || "";
        document.getElementById("aar-device-auth-account").textContent = label ? "Konto: " + label : "";
        showAuthState("success");
      }).catch(function (error) {
        window.clearInterval(pollTimer);
        pollTimer = null;
        showAuthState("error", error.message);
      });
    }

    document.addEventListener("click", function (event) {
      if (event.target && event.target.id === "aar-device-auth-start") {
        event.preventDefault();
        showAuthState("waiting");
        if (window.jQuery && jQuery.fn && jQuery.fn.modal) {
          jQuery("#aar-device-auth-modal").modal("show");
        }

        post("startDeviceAuthorization").then(function (json) {
          if (!json.success) {
            throw new Error(json.message || "Nie udało się rozpocząć autoryzacji.");
          }

          deviceCode = json.deviceCode || "";
          pollInterval = Math.max(3, parseInt(json.interval || 5, 10)) * 1000;
          document.getElementById("aar-device-auth-link").href = json.verificationUriComplete;
          document.getElementById("aar-device-auth-code").textContent = json.userCode || "";
          document.getElementById("aar-device-auth-code-wrap").style.display = json.userCode ? "" : "none";
          showAuthState("init");
        }).catch(function (error) {
          showAuthState("error", error.message);
        });
      }

      if (event.target && event.target.id === "aar-device-auth-link") {
        showAuthState("waiting");
        if (pollTimer) {
          window.clearInterval(pollTimer);
        }
        pollTimer = window.setInterval(pollAuthorization, pollInterval);
      }

      if (event.target && event.target.id === "aar-device-auth-finish") {
        event.preventDefault();
        window.location.reload();
      }
    });
  })();
</script>
{$update_panel nofilter}
{$settings_form nofilter}
{$rule_form nofilter}
{$rules_table nofilter}
{$logs_table nofilter}

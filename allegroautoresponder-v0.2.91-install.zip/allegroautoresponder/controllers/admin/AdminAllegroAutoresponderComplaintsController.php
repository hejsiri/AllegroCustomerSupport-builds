<?php

class AdminAllegroAutoresponderComplaintsController extends ModuleAdminController
{
    public function __construct()
    {
        $this->bootstrap = true;
        parent::__construct();
    }

    public function initPageHeaderToolbar()
    {
        $params = [
            'aar_refresh' => 1,
            '_refresh' => time(),
        ];

        $issueId = trim((string) Tools::getValue('issue_id'));
        if ($issueId !== '') {
            $params['issue_id'] = $issueId;
        }
        $statusFilter = trim((string) Tools::getValue('status_filter'));
        if ($statusFilter !== '') {
            $params['status_filter'] = $statusFilter;
        }
        $issueKind = trim((string) Tools::getValue('issue_kind'));
        if ($issueKind !== '') {
            $params['issue_kind'] = $issueKind;
        }

        $this->page_header_toolbar_btn['refresh_allegro_complaints'] = [
            'href' => $this->context->link->getAdminLink('AdminAllegroAutoresponderComplaints', true, [], $params),
            'desc' => $this->trans('Odśwież', [], 'Modules.Allegroautoresponder.Admin'),
            'icon' => 'process-icon-refresh',
        ];

        parent::initPageHeaderToolbar();
    }

    public function initContent()
    {
        if (!headers_sent()) {
            header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
            header('Pragma: no-cache');
            header('Expires: 0');
        }

        parent::initContent();

        $this->content .= $this->module->getComplaintsContent();
        $this->context->smarty->assign('content', $this->content);
    }
}

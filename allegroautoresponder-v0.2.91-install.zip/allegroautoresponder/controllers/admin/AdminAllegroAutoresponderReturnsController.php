<?php

class AdminAllegroAutoresponderReturnsController extends ModuleAdminController
{
    public function __construct()
    {
        $this->bootstrap = true;
        parent::__construct();
    }

    public function initPageHeaderToolbar()
    {
        parent::initPageHeaderToolbar();
    }

    public function initContent()
    {
        if (!headers_sent()) {
            header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
            header('Pragma: no-cache');
            header('Expires: 0');
        }

        parent::initContent();

        $this->content .= $this->module->getReturnsContent();
        $this->context->smarty->assign('content', $this->content);
    }
}

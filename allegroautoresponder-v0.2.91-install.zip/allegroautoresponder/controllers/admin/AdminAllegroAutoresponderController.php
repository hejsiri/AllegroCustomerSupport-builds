<?php

class AdminAllegroAutoresponderController extends ModuleAdminController
{
    public function init()
    {
        parent::init();

        Tools::redirectAdmin($this->context->link->getAdminLink('AdminAllegroAutoresponderMessages'));
    }
}

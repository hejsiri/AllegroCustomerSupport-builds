<?php
class AllegroAutoresponderCronModuleFrontController extends ModuleFrontController
{
    public $display_header = false;
    public $display_footer = false;

    public function initContent()
    {
        parent::initContent();

        header('Content-Type: application/json');

        $token = (string) Tools::getValue('token');
        $expected = (string) Configuration::get(AllegroAutoresponder::CONFIG_PREFIX . 'CRON_TOKEN');

        if (!$expected || !hash_equals($expected, $token)) {
            http_response_code(403);
            die(json_encode(['ok' => false, 'message' => 'Invalid token']));
        }

        if (!(bool) Configuration::get(AllegroAutoresponder::CONFIG_PREFIX . 'ENABLED')) {
            die(json_encode(['ok' => true, 'message' => 'Module disabled']));
        }

        try {
            $tokenManager = new \PrestaShop\Module\AllegroAutoresponder\Service\TokenManager();
            $apiClient = new \PrestaShop\Module\AllegroAutoresponder\Service\AllegroApiClient($tokenManager);
            $ruleEngine = new \PrestaShop\Module\AllegroAutoresponder\Service\RuleEngine();
            $logger = new \PrestaShop\Module\AllegroAutoresponder\Service\Logger();
            $responder = new \PrestaShop\Module\AllegroAutoresponder\Service\Responder($apiClient, $logger, (bool) Configuration::get(AllegroAutoresponder::CONFIG_PREFIX . 'TEST_MODE'));
            $scanner = new \PrestaShop\Module\AllegroAutoresponder\Service\MessageScanner($apiClient, $ruleEngine, $responder, $logger);
            $scanner->scan((int) Configuration::get(AllegroAutoresponder::CONFIG_PREFIX . 'POLL_LIMIT'));

            die(json_encode(['ok' => true]));
        } catch (Throwable $e) {
            http_response_code(500);
            PrestaShopLogger::addLog('[AAR] Cron error: ' . $e->getMessage(), 3);
            die(json_encode(['ok' => false, 'message' => $e->getMessage()]));
        }
    }
}

<?php

if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_0_1_121($module)
{
    return $module->registerHook('displayBackOfficeHeader')
        && Configuration::deleteByName('AAR_MENU_UNREAD_BADGE_CACHE');
}

<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_0_1_167($module)
{
    if (class_exists('AllegroAutoresponderUpdater')) {
        Configuration::updateValue(AllegroAutoresponderUpdater::CONFIG_UPDATE_CHANNEL, AllegroAutoresponderUpdater::UPDATE_CHANNEL_PUBLIC);
    }

    return true;
}

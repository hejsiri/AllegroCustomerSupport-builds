<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_0_1_170($module)
{
    return true;
}

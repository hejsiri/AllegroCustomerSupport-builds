<?php

if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_0_1_90($module)
{
    return true;
}

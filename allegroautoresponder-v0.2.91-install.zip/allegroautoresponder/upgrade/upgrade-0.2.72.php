<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_0_2_72($module)
{
    return true;
}

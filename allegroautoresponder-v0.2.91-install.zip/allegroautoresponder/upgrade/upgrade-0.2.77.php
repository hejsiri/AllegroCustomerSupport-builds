<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_0_2_77($module)
{
    return true;
}

<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_0_2_54($module)
{
    return true;
}

<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_0_2_57($module)
{
    return true;
}

<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_0_2_34($module)
{
    return true;
}

<?php

if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_0_1_122($module)
{
    return Configuration::deleteByName('AAR_MENU_UNREAD_BADGE_CACHE');
}

<?php

if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_0_1_6($module)
{
    return $module->installTabs()
        && $module->registerHook('displayAdminOrderSide')
        && $module->registerHook('displayAdminOrderMain');
}

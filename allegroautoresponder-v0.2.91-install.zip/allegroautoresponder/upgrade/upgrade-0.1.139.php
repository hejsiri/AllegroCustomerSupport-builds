<?php

if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_0_1_139($module)
{
    return true;
}

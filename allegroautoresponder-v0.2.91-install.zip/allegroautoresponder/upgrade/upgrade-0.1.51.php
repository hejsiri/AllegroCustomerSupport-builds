<?php

if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_0_1_51($module)
{
    if (!method_exists($module, 'seedDefaultRules')) {
        return true;
    }

    return $module->seedDefaultRules();
}

<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_0_1_193($module)
{
    return true;
}

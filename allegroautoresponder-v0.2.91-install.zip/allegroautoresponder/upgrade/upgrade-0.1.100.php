<?php

if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_0_1_100($module)
{
    return true;
}

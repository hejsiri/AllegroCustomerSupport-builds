<?php

if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_0_1_105($module)
{
    return true;
}

<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_0_1_163($module)
{
    Configuration::updateValue(AllegroAutoresponder::CONFIG_PREFIX . 'AUTH_BACKEND_URL', (string) Configuration::get(AllegroAutoresponder::CONFIG_PREFIX . 'AUTH_BACKEND_URL'));
    Configuration::updateValue(AllegroAutoresponder::CONFIG_PREFIX . 'AUTH_BACKEND_KEY', (string) Configuration::get(AllegroAutoresponder::CONFIG_PREFIX . 'AUTH_BACKEND_KEY'));

    return true;
}

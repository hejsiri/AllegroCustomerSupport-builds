<?php

if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_0_1_125($module)
{
    return true;
}

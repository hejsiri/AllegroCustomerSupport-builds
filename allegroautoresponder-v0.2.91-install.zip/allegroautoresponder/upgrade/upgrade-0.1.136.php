<?php

if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_0_1_136($module)
{
    return true;
}

<?php

if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_0_1_151($module)
{
    return true;
}

<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_0_1_160($module)
{
    return true;
}

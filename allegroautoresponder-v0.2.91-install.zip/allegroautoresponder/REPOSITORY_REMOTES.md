# Repository Remotes

Definicje remote'ów są w:

`config/git-remotes.conf`

Ustawienie remote'ów:

```bash
bash scripts/setup_git_remotes.sh
```

Push źródeł:

```bash
bash scripts/push_git_remote.sh source
```

Repo buildów jest aktualizowane przez:

```bash
bash scripts/release_build.sh
```

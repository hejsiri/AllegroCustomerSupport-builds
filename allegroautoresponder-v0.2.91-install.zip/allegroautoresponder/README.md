# AllegroCustomerSupport for PrestaShop 8.x+

Moduł do obsługi klienta Allegro w PrestaShop: wiadomości, dyskusje, reklamacje, zwroty i automatyczne odpowiedzi.

## Co już jest
- instalacja i deinstalacja modułu
- tabele SQL
- panel konfiguracji w BO
- osobne menu BO `Obsługa Klienta Allegro` z sekcjami: Wiadomości, Dyskusje, Reklamacje, Zwroty towarów i Ustawienia
- mini komunikator Allegro w BO: lista wątków, podgląd rozmowy i ręczne odpowiedzi
- panel `Obsługa Klienta Allegro` w widoku zamówienia PrestaShop
- dodawanie, edycja i usuwanie prostych reguł
- przycisk "Połącz konto Allegro" w trybie Device flow przez backend autoryzacji producenta
- cron endpoint
- polling wiadomości + logi
- test mode
- zapis loginu i ID konta z Allegro po autoryzacji
- rozpoznawanie wiadomości kupującego po `author.isInterlocutor`

## Czego jeszcze brakuje do produkcji
- walidacji na realnym koncie Allegro dla wszystkich wariantów wątku i wiadomości
- paginacji i filtrowania komunikatora
- obsługi załączników w komunikatorze
- whitelist / blacklist fraz
- powiązania z zamówieniami PrestaShop / x13
- paginacji logów
- dodatkowych zabezpieczeń anty-spam

## Instalacja lokalna
1. skopiuj folder `allegroautoresponder` do `modules/`
2. zainstaluj moduł w BO
3. wdroż backend autoryzacji producenta z katalogu `../allegro-auth-backend` albo ustaw stałą `AAR_ALLEGRO_AUTH_BACKEND_URL`
4. w aplikacji Allegro producenta zaznacz uprawnienia używane przez moduł, przede wszystkim wiadomości, zamówienia, dyskusje/reklamacje i odczyt ofert
5. kliknij "Połącz konto Allegro"
6. dodaj reguły
7. ustaw cron na kontroler `cron`

## Zmienne w odpowiedzi
- `{shop_name}`
- `{message}`
- `{buyer_login}`
- `{order_id}`
- `{offer_id}`

## Przykładowa reguła
Keywords:
```
wysyłka
kiedy wyślecie
czas realizacji
```

Response:
```
Dzień dobry,

dziękujemy za wiadomość. Zamówienia wysyłamy możliwie szybko, zwykle w czasie podanym w ofercie.

Pozdrawiamy,
{shop_name}
```

## Uwaga
Moduł jest przygotowany jako sensowny start projektu. Przed wdrożeniem produkcyjnym trzeba potwierdzić finalne struktury request/response na Twoim koncie Allegro i dopracować mapowanie danych.

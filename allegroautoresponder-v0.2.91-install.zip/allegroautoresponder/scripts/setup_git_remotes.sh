#!/usr/bin/env bash

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "${SCRIPT_DIR}/.." && pwd)"
CONFIG_FILE="${PROJECT_ROOT}/config/git-remotes.conf"

if [[ ! -f "${CONFIG_FILE}" ]]; then
  echo "Brak pliku konfiguracyjnego: ${CONFIG_FILE}" >&2
  exit 1
fi

# shellcheck disable=SC1090
source "${CONFIG_FILE}"

upsert_remote() {
  local name="$1"
  local url="$2"

  if git -C "${PROJECT_ROOT}" remote get-url "${name}" >/dev/null 2>&1; then
    git -C "${PROJECT_ROOT}" remote set-url "${name}" "${url}"
  else
    git -C "${PROJECT_ROOT}" remote add "${name}" "${url}"
  fi
}

upsert_remote "${SOURCE_REMOTE_NAME}" "${SOURCE_REMOTE_URL}"
upsert_remote "${BUILDS_REMOTE_NAME}" "${BUILDS_REMOTE_URL}"

echo "Remotes ustawione:"
git -C "${PROJECT_ROOT}" remote -v

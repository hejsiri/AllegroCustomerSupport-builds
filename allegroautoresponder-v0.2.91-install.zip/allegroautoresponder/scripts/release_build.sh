#!/usr/bin/env bash

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "${SCRIPT_DIR}/.." && pwd)"
DEFAULT_CONFIG_FILE="${PROJECT_ROOT}/config/release-build.conf"
EXAMPLE_CONFIG_FILE="${PROJECT_ROOT}/config/release-build.conf.example"
GIT_REMOTES_FILE="${PROJECT_ROOT}/config/git-remotes.conf"

CONFIG_FILE="${RELEASE_BUILD_CONFIG:-$DEFAULT_CONFIG_FILE}"
if [[ ! -f "${CONFIG_FILE}" ]]; then
  echo "Brak ${CONFIG_FILE}. Skopiuj ${EXAMPLE_CONFIG_FILE} do config/release-build.conf i uzupelnij dane." >&2
  exit 1
fi

# shellcheck disable=SC1090
source "${CONFIG_FILE}"

if [[ -f "${GIT_REMOTES_FILE}" ]]; then
  # shellcheck disable=SC1090
  source "${GIT_REMOTES_FILE}"
fi

SOURCE_REPO_PATH="${SOURCE_REPO_PATH:-$PROJECT_ROOT}"
BUILDS_REPO_URL="${BUILDS_REPO_URL:-${BUILDS_REMOTE_URL:-}}"
BUILDS_REPO_BRANCH="${BUILDS_REPO_BRANCH:-${BUILDS_REMOTE_BRANCH:-main}}"
BUILDS_REPO_CLONE_PATH="${BUILDS_REPO_CLONE_PATH:-/tmp/AllegroCustomerSupport-builds}"
LOCAL_RELEASES_PATH="${LOCAL_RELEASES_PATH:-${SOURCE_REPO_PATH}/builds-local}"
UPDATE_SIGNING_PRIVATE_KEY="${UPDATE_SIGNING_PRIVATE_KEY:-}"
RELEASE_KEEP_ZIPS="${RELEASE_KEEP_ZIPS:-10}"
DRY_RUN="${DRY_RUN:-0}"
RELEASE_CHANNEL="${RELEASE_CHANNEL:-public}"

if [[ -z "${BUILDS_REPO_URL}" ]]; then
  echo "Brak BUILDS_REPO_URL w konfiguracji." >&2
  exit 1
fi

if ! [[ "${RELEASE_KEEP_ZIPS}" =~ ^[0-9]+$ ]] || [[ "${RELEASE_KEEP_ZIPS}" -lt 1 ]]; then
  echo "RELEASE_KEEP_ZIPS musi byc liczba calkowita >= 1." >&2
  exit 1
fi

if [[ "${RELEASE_CHANNEL}" != "public" && "${RELEASE_CHANNEL}" != "beta" ]]; then
  echo "RELEASE_CHANNEL musi byc ustawiony na public albo beta." >&2
  exit 1
fi

if [[ ! -d "${SOURCE_REPO_PATH}" ]]; then
  echo "Nie znaleziono SOURCE_REPO_PATH: ${SOURCE_REPO_PATH}" >&2
  exit 1
fi

if ! git -C "${SOURCE_REPO_PATH}" rev-parse --is-inside-work-tree >/dev/null 2>&1; then
  echo "SOURCE_REPO_PATH nie jest repozytorium git: ${SOURCE_REPO_PATH}" >&2
  exit 1
fi

if [[ -z "${UPDATE_SIGNING_PRIVATE_KEY}" || ! -f "${UPDATE_SIGNING_PRIVATE_KEY}" ]]; then
  echo "Brak prywatnego klucza podpisu. Ustaw UPDATE_SIGNING_PRIVATE_KEY w ${CONFIG_FILE}." >&2
  exit 1
fi

if ! openssl pkey -in "${UPDATE_SIGNING_PRIVATE_KEY}" -pubout >/dev/null 2>&1; then
  echo "Nie mozna odczytac prywatnego klucza: ${UPDATE_SIGNING_PRIVATE_KEY}" >&2
  exit 1
fi

CONFIG_XML="${SOURCE_REPO_PATH}/config.xml"
CHANGELOG_MD="${SOURCE_REPO_PATH}/CHANGELOG.md"
PUBLIC_KEY_PATH="${SOURCE_REPO_PATH}/keys/update_public.pem"

if [[ ! -f "${CONFIG_XML}" ]]; then
  echo "Brak ${CONFIG_XML}" >&2
  exit 1
fi

if [[ ! -f "${PUBLIC_KEY_PATH}" ]]; then
  echo "Brak ${PUBLIC_KEY_PATH}" >&2
  exit 1
fi

version="$(perl -0ne 'if (m{<version><!\[CDATA\[(.*?)\]\]></version>}s) { print $1 }' "${CONFIG_XML}")"
if [[ -z "${version}" ]]; then
  echo "Nie udalo sie odczytac wersji z ${CONFIG_XML}" >&2
  exit 1
fi

public_key_fingerprint="$(openssl rsa -pubin -in "${PUBLIC_KEY_PATH}" -outform DER 2>/dev/null | shasum -a 256 | awk '{print $1}')"
private_key_fingerprint="$(openssl pkey -in "${UPDATE_SIGNING_PRIVATE_KEY}" -pubout -outform DER 2>/dev/null | shasum -a 256 | awk '{print $1}')"
if [[ "${public_key_fingerprint}" != "${private_key_fingerprint}" ]]; then
  echo "Prywatny klucz nie pasuje do ${PUBLIC_KEY_PATH}." >&2
  exit 1
fi

published_at="$(date -u +"%Y-%m-%dT%H:%M:%SZ")"
zip_name="allegroautoresponder-v${version}-install.zip"
manifest_file="latest.json"
local_manifest_file="latest.json"
commit_label="Release"
if [[ "${RELEASE_CHANNEL}" == "beta" ]]; then
  manifest_file="latest-beta.json"
  local_manifest_file="latest-beta.json"
  commit_label="Beta release"
fi

rm -rf "${BUILDS_REPO_CLONE_PATH}"
git clone --depth 1 --single-branch --branch "${BUILDS_REPO_BRANCH}" "${BUILDS_REPO_URL}" "${BUILDS_REPO_CLONE_PATH}"
mkdir -p "${LOCAL_RELEASES_PATH}"

zip_path="${BUILDS_REPO_CLONE_PATH}/${zip_name}"
manifest_path="${BUILDS_REPO_CLONE_PATH}/${manifest_file}"
local_zip_path="${LOCAL_RELEASES_PATH}/${zip_name}"
local_manifest_path="${LOCAL_RELEASES_PATH}/${local_manifest_file}"
local_version_manifest_path="${LOCAL_RELEASES_PATH}/${local_manifest_file%.json}-v${version}.json"
local_changelog_path="${LOCAL_RELEASES_PATH}/CHANGELOG.md"

git -C "${SOURCE_REPO_PATH}" archive \
  --format=zip \
  --output="${zip_path}" \
  --prefix=allegroautoresponder/ \
  HEAD

zip -dq "${zip_path}" "allegroautoresponder/config/release-build.conf" || true

sha256="$(shasum -a 256 "${zip_path}" | awk '{print $1}')"
zip_url="https://raw.githubusercontent.com/hejsiri/AllegroCustomerSupport-builds/${BUILDS_REPO_BRANCH}/${zip_name}"

signature_payload="$(mktemp)"
signature_raw="$(mktemp)"
signature_b64="$(mktemp)"

printf '%s\n%s\n%s' "${version}" "${zip_url}" "${sha256}" > "${signature_payload}"
openssl dgst -sha256 -sign "${UPDATE_SIGNING_PRIVATE_KEY}" -out "${signature_raw}" "${signature_payload}"
openssl base64 -A -in "${signature_raw}" -out "${signature_b64}"

cat > "${manifest_path}" <<EOF
{
    "version": "${version}",
    "url": "${zip_url}",
    "sha256": "${sha256}",
    "signature": "$(cat "${signature_b64}")",
    "published_at": "${published_at}"
}
EOF

cp "${zip_path}" "${local_zip_path}"
cp "${manifest_path}" "${local_manifest_path}"
cp "${manifest_path}" "${local_version_manifest_path}"
rm -f "${signature_payload}" "${signature_raw}" "${signature_b64}"

if [[ -f "${CHANGELOG_MD}" ]]; then
  cp "${CHANGELOG_MD}" "${BUILDS_REPO_CLONE_PATH}/CHANGELOG.md"
  cp "${BUILDS_REPO_CLONE_PATH}/CHANGELOG.md" "${local_changelog_path}"
else
  echo "# Changelog" > "${BUILDS_REPO_CLONE_PATH}/CHANGELOG.md"
fi

zip_files=()
while IFS= read -r zip_file; do
  zip_files+=("${zip_file}")
done < <(
  find "${BUILDS_REPO_CLONE_PATH}" -maxdepth 1 -type f -name 'allegroautoresponder-v*-install.zip' -print \
    | sed "s#^${BUILDS_REPO_CLONE_PATH}/##" \
    | sort -V
)
zip_count="${#zip_files[@]}"
if [[ "${zip_count}" -gt "${RELEASE_KEEP_ZIPS}" ]]; then
  prune_count=$((zip_count - RELEASE_KEEP_ZIPS))
  for zip_to_remove in "${zip_files[@]:0:prune_count}"; do
    git -C "${BUILDS_REPO_CLONE_PATH}" rm -f "${zip_to_remove}" >/dev/null
  done
fi

git -C "${BUILDS_REPO_CLONE_PATH}" add "${zip_name}" "${manifest_file}" CHANGELOG.md
if git -C "${BUILDS_REPO_CLONE_PATH}" diff --cached --quiet; then
  echo "Brak zmian do release." >&2
  exit 1
fi

git -C "${BUILDS_REPO_CLONE_PATH}" commit -m "${commit_label} ${version}"

if [[ "${DRY_RUN}" == "1" ]]; then
  echo "DRY_RUN=1, pomijam push."
else
  git -C "${BUILDS_REPO_CLONE_PATH}" push origin "${BUILDS_REPO_BRANCH}"
fi

echo "Release gotowy:"
echo "Channel: ${RELEASE_CHANNEL}"
echo "Version: ${version}"
echo "ZIP: ${zip_path}"
echo "SHA256: ${sha256}"
echo "Manifest: ${manifest_path}"
echo "Local ZIP: ${local_zip_path}"
echo "Local manifest: ${local_manifest_path}"

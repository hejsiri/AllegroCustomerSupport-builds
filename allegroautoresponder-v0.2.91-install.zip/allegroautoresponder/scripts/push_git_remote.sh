#!/usr/bin/env bash

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "${SCRIPT_DIR}/.." && pwd)"
CONFIG_FILE="${PROJECT_ROOT}/config/git-remotes.conf"

if [[ ! -f "${CONFIG_FILE}" ]]; then
  echo "Brak pliku konfiguracyjnego: ${CONFIG_FILE}" >&2
  exit 1
fi

# shellcheck disable=SC1090
source "${CONFIG_FILE}"

TARGET="${1:-}"
if [[ -z "${TARGET}" ]]; then
  echo "Uzycie: bash scripts/push_git_remote.sh <source|builds> [git push args...]" >&2
  exit 1
fi
shift || true

case "${TARGET}" in
  source)
    REMOTE_NAME="${SOURCE_REMOTE_NAME}"
    REMOTE_BRANCH="${SOURCE_REMOTE_BRANCH}"
    ;;
  builds)
    REMOTE_NAME="${BUILDS_REMOTE_NAME}"
    REMOTE_BRANCH="${BUILDS_REMOTE_BRANCH}"
    ;;
  *)
    echo "Nieznany target: ${TARGET}. Uzyj source albo builds." >&2
    exit 1
    ;;
esac

CURRENT_BRANCH="$(git -C "${PROJECT_ROOT}" rev-parse --abbrev-ref HEAD)"
if [[ "${CURRENT_BRANCH}" == "HEAD" ]]; then
  echo "Jestes w detached HEAD. Przelacz sie na branche przed push." >&2
  exit 1
fi

git -C "${PROJECT_ROOT}" push "${REMOTE_NAME}" "${CURRENT_BRANCH}:${REMOTE_BRANCH}" "$@"

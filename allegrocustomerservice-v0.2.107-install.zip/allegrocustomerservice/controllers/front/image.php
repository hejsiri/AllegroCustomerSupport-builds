<?php

use PrestaShop\Module\AllegroCustomerService\Service\TokenManager;

if (!class_exists('PrestaShop\\Module\\AllegroCustomerService\\Service\\TokenManager', false)) {
    require_once dirname(__DIR__, 2) . '/src/Service/TokenManager.php';
}

if (!class_exists('AllegroCustomerServiceImageModuleFrontController', false)) {
class AllegroCustomerServiceImageModuleFrontController extends ModuleFrontController
{
    public $display_header = false;
    public $display_footer = false;

    public function initContent()
    {
        parent::initContent();

        $token = trim((string) Tools::getValue('token'));
        $expected = trim((string) Configuration::get(AllegroCustomerService::CONFIG_PREFIX . 'CRON_TOKEN'));
        if ($expected === '' || !hash_equals($expected, $token)) {
            http_response_code(403);
            exit('Forbidden');
        }

        $encodedUrl = (string) Tools::getValue('url');
        $remoteUrl = base64_decode($encodedUrl, true);
        if (!is_string($remoteUrl) || trim($remoteUrl) === '') {
            http_response_code(400);
            exit('Missing image URL');
        }

        $remoteUrl = trim($remoteUrl);
        $host = (string) parse_url($remoteUrl, PHP_URL_HOST);
        $allowedHosts = [
            'api.allegro.pl',
            'a.allegroimg.com',
            'assets.allegroimg.com',
            'allegro.pl',
            'www.allegro.pl',
        ];

        if ($host === '' || !in_array($host, $allowedHosts, true)) {
            http_response_code(400);
            exit('Unsupported host');
        }

        $headers = [
            'User-Agent: PrestaShop-AllegroCustomerSupport/0.1',
        ];

        if ($host === 'api.allegro.pl') {
            try {
                $tokenManager = new TokenManager();
                $headers[] = 'Authorization: Bearer ' . $tokenManager->getValidAccessToken();
            } catch (Throwable $e) {
                http_response_code(500);
                exit('Authorization error');
            }
        }

        $ch = curl_init($remoteUrl);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 5);
        curl_setopt($ch, CURLOPT_TIMEOUT, 12);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

        $body = curl_exec($ch);
        $contentType = (string) curl_getinfo($ch, CURLINFO_CONTENT_TYPE);
        $status = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        curl_close($ch);

        if (!is_string($body) || $body === '' || $status >= 400) {
            http_response_code($status >= 400 ? $status : 502);
            exit($error !== '' ? $error : 'Image download failed');
        }

        header('Content-Type: ' . ($contentType !== '' ? $contentType : 'image/jpeg'));
        header('Cache-Control: public, max-age=3600');
        echo $body;
        exit;
    }
}
}

if (!class_exists('AllegroAutoresponderImageModuleFrontController', false)) {
    class AllegroAutoresponderImageModuleFrontController extends AllegroCustomerServiceImageModuleFrontController
    {
    }
}

<?php

if (!class_exists('AllegroCustomerServiceDeviceauthModuleFrontController', false)) {
class AllegroCustomerServiceDeviceauthModuleFrontController extends ModuleFrontController
{
    public $display_header = false;
    public $display_footer = false;
    public $ajax = true;

    public function initContent()
    {
        parent::initContent();

        $this->respond($this->handleRequest());
    }

    private function handleRequest(): array
    {
        $token = (string) Tools::getValue('token');
        $expected = (string) Configuration::get(AllegroCustomerService::CONFIG_PREFIX . 'CRON_TOKEN');

        if ($expected === '' || !hash_equals($expected, $token)) {
            http_response_code(403);
            return [
                'success' => false,
                'message' => 'Invalid authorization token.',
            ];
        }

        try {
            $action = (string) Tools::getValue('action');
            $tokenManager = new \PrestaShop\Module\AllegroCustomerService\Service\TokenManager();

            if ($action === 'startDeviceAuthorization') {
                $result = $tokenManager->startDeviceAuthorization();

                return [
                    'success' => true,
                    'verificationUriComplete' => (string) ($result['verification_uri_complete'] ?? ''),
                    'userCode' => (string) ($result['user_code'] ?? ''),
                    'deviceCode' => (string) ($result['device_code'] ?? ''),
                    'interval' => max(3, (int) ($result['interval'] ?? 5)),
                ];
            }

            if ($action === 'pollDeviceAuthorization') {
                $deviceCode = (string) Tools::getValue('device_code');
                if ($deviceCode === '') {
                    throw new RuntimeException('Missing device code.');
                }

                $result = $tokenManager->pollDeviceAuthorization($deviceCode);

                return [
                    'success' => true,
                    'authorized' => (bool) ($result['authorized'] ?? false),
                    'pending' => (bool) ($result['pending'] ?? false),
                    'error' => (string) ($result['error'] ?? ''),
                    'account' => $result['account'] ?? null,
                ];
            }

            http_response_code(400);
            return [
                'success' => false,
                'message' => 'Unknown authorization action.',
            ];
        } catch (Throwable $e) {
            http_response_code(500);
            PrestaShopLogger::addLog('[AAR] Device authorization error: ' . $e->getMessage(), 3);

            return [
                'success' => false,
                'message' => $e->getMessage(),
            ];
        }
    }

    private function respond(array $payload): void
    {
        header('Content-Type: application/json; charset=utf-8');
        die(json_encode($payload));
    }
}
}

if (!class_exists('AllegroAutoresponderDeviceauthModuleFrontController', false)) {
    class AllegroAutoresponderDeviceauthModuleFrontController extends AllegroCustomerServiceDeviceauthModuleFrontController
    {
    }
}

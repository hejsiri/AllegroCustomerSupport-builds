<?php
if (!class_exists('AllegroCustomerServiceOauthModuleFrontController', false)) {
class AllegroCustomerServiceOauthModuleFrontController extends ModuleFrontController
{
    public $display_header = false;
    public $display_footer = false;

    public function initContent()
    {
        parent::initContent();

        $code = (string) Tools::getValue('code');
        $error = (string) Tools::getValue('error');
        $state = (string) Tools::getValue('state');
        $expectedState = (string) Configuration::get(AllegroCustomerService::CONFIG_PREFIX . 'OAUTH_STATE');

        if ($error) {
            die('OAuth error: ' . Tools::safeOutput($error));
        }

        if (!$code) {
            die('Missing authorization code.');
        }

        if ($expectedState !== '' && !hash_equals($expectedState, $state)) {
            PrestaShopLogger::addLog('[AAR] OAuth state mismatch.', 3);
            die('OAuth callback failed: invalid state.');
        }

        try {
            $tokenManager = new \PrestaShop\Module\AllegroCustomerService\Service\TokenManager();
            $tokenManager->exchangeAuthorizationCode($code);
            Configuration::updateValue(AllegroCustomerService::CONFIG_PREFIX . 'OAUTH_STATE', '');
            die('Allegro account connected successfully. You can close this window.');
        } catch (Throwable $e) {
            PrestaShopLogger::addLog('[AAR] OAuth callback error: ' . $e->getMessage(), 3);
            die('OAuth callback failed: ' . Tools::safeOutput($e->getMessage()));
        }
    }
}
}

if (!class_exists('AllegroAutoresponderOauthModuleFrontController', false)) {
    class AllegroAutoresponderOauthModuleFrontController extends AllegroCustomerServiceOauthModuleFrontController
    {
    }
}

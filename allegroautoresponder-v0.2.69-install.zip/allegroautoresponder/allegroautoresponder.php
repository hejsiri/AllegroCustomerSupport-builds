<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

require_once __DIR__ . '/src/Service/AllegroApiClient.php';
require_once __DIR__ . '/src/Service/TokenManager.php';
require_once __DIR__ . '/src/Service/RuleEngine.php';
require_once __DIR__ . '/src/Service/MessageScanner.php';
require_once __DIR__ . '/src/Service/Responder.php';
require_once __DIR__ . '/src/Service/Logger.php';
require_once __DIR__ . '/classes/AllegroAutoresponderUpdater.php';

use PrestaShop\Module\AllegroAutoresponder\Service\AllegroApiClient;
use PrestaShop\Module\AllegroAutoresponder\Service\TokenManager;
use PrestaShop\Module\AllegroAutoresponder\Service\RuleEngine;
use PrestaShop\Module\AllegroAutoresponder\Service\MessageScanner;
use PrestaShop\Module\AllegroAutoresponder\Service\Responder;
use PrestaShop\Module\AllegroAutoresponder\Service\Logger;

class AllegroAutoresponder extends Module
{
    public const CONFIG_PREFIX = 'AAR_';
    private const ISSUE_THUMB_CACHE_CONFIG = 'AAR_ISSUE_THUMB_CACHE';
    private const MENU_UNREAD_BADGE_CACHE_CONFIG = 'AAR_MENU_UNREAD_BADGE_CACHE';
    private const MENU_RETURNS_BADGE_CACHE_CONFIG = 'AAR_MENU_RETURNS_BADGE_CACHE';
    private const MENU_UNREAD_BADGE_CACHE_TTL = 120;
    private const ADMIN_PARENT_CLASS = 'AdminAllegroAutoresponder';
    private const ADMIN_TAB_CLASSES = [
        'AdminAllegroAutoresponder',
        'AdminAllegroAutoresponderMessages',
        'AdminAllegroAutoresponderDisputes',
        'AdminAllegroAutoresponderComplaints',
        'AdminAllegroAutoresponderReturns',
        'AdminAllegroAutoresponderSettings',
    ];

    public function __construct()
    {
        $this->name = 'allegroautoresponder';
        $this->tab = 'administration';
        $this->version = '0.2.69';
        $this->author = 'OpenAI';
        $this->need_instance = 0;
        $this->bootstrap = true;
        $this->ps_versions_compliancy = [
            'min' => '8.0.0',
            'max' => _PS_VERSION_,
        ];

        parent::__construct();

        $this->displayName = $this->trans('Obsługa Klienta Allegro', [], 'Modules.Allegroautoresponder.Admin');
        $this->description = $this->trans('AllegroCustomerSupport dla PrestaShop: wiadomości, dyskusje, reklamacje, zwroty, automatyczne odpowiedzi, CRON i logi.', [], 'Modules.Allegroautoresponder.Admin');
    }

    public function install()
    {
        return parent::install()
            && $this->installDatabase()
            && $this->installTabs()
            && $this->registerHook('actionAdminControllerSetMedia')
            && $this->registerHook('displayBackOfficeHeader')
            && $this->registerHook('displayAdminOrderSide')
            && $this->registerHook('displayAdminOrderMain')
            && Configuration::updateValue(self::CONFIG_PREFIX . 'ENABLED', 0)
            && Configuration::updateValue(self::CONFIG_PREFIX . 'CRON_TOKEN', bin2hex(random_bytes(16)))
            && Configuration::updateValue(self::CONFIG_PREFIX . 'POLL_LIMIT', 20)
            && Configuration::updateValue(self::CONFIG_PREFIX . 'COOLDOWN_MINUTES', 60)
            && Configuration::updateValue(self::CONFIG_PREFIX . 'TEST_MODE', 1)
            && Configuration::updateValue(self::CONFIG_PREFIX . 'CLIENT_ID', '')
            && Configuration::updateValue(self::CONFIG_PREFIX . 'CLIENT_SECRET', '')
            && Configuration::updateValue(self::CONFIG_PREFIX . 'AUTH_BACKEND_URL', '')
            && Configuration::updateValue(self::CONFIG_PREFIX . 'AUTH_BACKEND_KEY', '')
            && Configuration::updateValue(self::CONFIG_PREFIX . 'REDIRECT_URI', '')
            && Configuration::updateValue(self::CONFIG_PREFIX . 'OAUTH_STATE', '')
            && Configuration::updateValue(AllegroAutoresponderUpdater::CONFIG_UPDATE_CHANNEL, AllegroAutoresponderUpdater::UPDATE_CHANNEL_PUBLIC)
            && $this->seedDefaultRules();
    }

    public function uninstall()
    {
        return Configuration::deleteByName(self::CONFIG_PREFIX . 'ENABLED')
            && Configuration::deleteByName(self::CONFIG_PREFIX . 'CRON_TOKEN')
            && Configuration::deleteByName(self::CONFIG_PREFIX . 'POLL_LIMIT')
            && Configuration::deleteByName(self::CONFIG_PREFIX . 'COOLDOWN_MINUTES')
            && Configuration::deleteByName(self::CONFIG_PREFIX . 'TEST_MODE')
            && Configuration::deleteByName(self::CONFIG_PREFIX . 'CLIENT_ID')
            && Configuration::deleteByName(self::CONFIG_PREFIX . 'CLIENT_SECRET')
            && Configuration::deleteByName(self::CONFIG_PREFIX . 'AUTH_BACKEND_URL')
            && Configuration::deleteByName(self::CONFIG_PREFIX . 'AUTH_BACKEND_KEY')
            && Configuration::deleteByName(self::CONFIG_PREFIX . 'REDIRECT_URI')
            && Configuration::deleteByName(self::CONFIG_PREFIX . 'OAUTH_STATE')
            && Configuration::deleteByName(AllegroAutoresponderUpdater::CONFIG_UPDATE_CHANNEL)
            && Configuration::deleteByName('AAR_RUNTIME_VERSION')
            && Configuration::deleteByName(self::MENU_UNREAD_BADGE_CACHE_CONFIG)
            && Configuration::deleteByName(self::MENU_RETURNS_BADGE_CACHE_CONFIG)
            && $this->uninstallTabs()
            && $this->uninstallDatabase()
            && parent::uninstall();
    }

    public function installTabs(): bool
    {
        $sellParentId = (int) Tab::getIdFromClassName('SELL');
        if ($sellParentId <= 0) {
            $sellParentId = 0;
        }
        $parentId = $this->installTab(self::ADMIN_PARENT_CLASS, $sellParentId, [
            'pl' => 'Obsługa Klienta Allegro',
            'en' => 'AllegroCustomerSupport',
        ], 'headset_mic');

        if (!$parentId) {
            return false;
        }

        $tabs = [
            'AdminAllegroAutoresponderMessages' => [
                'pl' => 'Wiadomości',
                'en' => 'Messages',
            ],
            'AdminAllegroAutoresponderDisputes' => [
                'pl' => 'Dyskusje',
                'en' => 'Disputes',
            ],
            'AdminAllegroAutoresponderComplaints' => [
                'pl' => 'Reklamacje',
                'en' => 'Complaints',
            ],
            'AdminAllegroAutoresponderReturns' => [
                'pl' => 'Zwroty towarów',
                'en' => 'Returns',
            ],
            'AdminAllegroAutoresponderSettings' => [
                'pl' => 'Ustawienia',
                'en' => 'Settings',
            ],
        ];

        foreach ($tabs as $className => $names) {
            if (!$this->installTab($className, $parentId, $names, '', true)) {
                return false;
            }
        }

        return $this->reorderAdminChildTabs((int) $parentId);
    }

    public function uninstallTabs(): bool
    {
        foreach (array_reverse(self::ADMIN_TAB_CLASSES) as $className) {
            $idTab = (int) Tab::getIdFromClassName($className);
            if ($idTab <= 0) {
                continue;
            }

            $tab = new Tab($idTab);
            if (!$tab->delete()) {
                return false;
            }
        }

        return true;
    }

    private function installTab(string $className, int $parentId, array $names, string $icon = '', bool $active = true)
    {
        $existingId = (int) Tab::getIdFromClassName($className);
        if ($existingId > 0) {
            $tab = new Tab($existingId);
            $tab->id_parent = $parentId;
            $tab->module = $this->name;
            $tab->active = $active ? 1 : 0;
            $tab->name = $this->buildTabNames($names);
            if (property_exists($tab, 'icon')) {
                $tab->icon = $icon;
            }

            return $tab->update() ? $existingId : false;
        }

        $tab = new Tab();
        $tab->active = $active ? 1 : 0;
        $tab->class_name = $className;
        $tab->id_parent = $parentId;
        $tab->module = $this->name;
        $tab->name = $this->buildTabNames($names);
        if (property_exists($tab, 'icon')) {
            $tab->icon = $icon;
        }

        return $tab->add() ? (int) $tab->id : false;
    }

    private function buildTabNames(array $names): array
    {
        $languages = Language::getLanguages(false);
        $tabNames = [];

        foreach ($languages as $language) {
            $iso = (string) ($language['iso_code'] ?? '');
            $tabNames[(int) $language['id_lang']] = $names[$iso] ?? $names['en'] ?? reset($names);
        }

        return $tabNames;
    }

    private function reorderAdminChildTabs(int $parentId): bool
    {
        if ($parentId <= 0) {
            return false;
        }

        $position = 0;
        foreach (self::ADMIN_TAB_CLASSES as $className) {
            if ($className === self::ADMIN_PARENT_CLASS) {
                continue;
            }

            $tabId = (int) Tab::getIdFromClassName($className);
            if ($tabId <= 0) {
                continue;
            }

            $tab = new Tab($tabId);
            $tab->id_parent = $parentId;
            if (property_exists($tab, 'position')) {
                $tab->position = $position;
            }

            if (!$tab->update()) {
                return false;
            }

            $position++;
        }

        return true;
    }

    protected function installDatabase()
    {
        $sql = file_get_contents(__DIR__ . '/sql/install.sql');
        $sql = str_replace('PREFIX_', _DB_PREFIX_, $sql);
        foreach (array_filter(array_map('trim', explode(';', $sql))) as $query) {
            if (!Db::getInstance()->execute($query)) {
                return false;
            }
        }
        return true;
    }

    protected function uninstallDatabase()
    {
        $tables = [
            _DB_PREFIX_ . 'allegro_ar_account',
            _DB_PREFIX_ . 'allegro_ar_rule',
            _DB_PREFIX_ . 'allegro_ar_thread',
            _DB_PREFIX_ . 'allegro_ar_log',
        ];

        foreach ($tables as $table) {
            Db::getInstance()->execute('DROP TABLE IF EXISTS `' . pSQL($table) . '`');
        }

        return true;
    }

    public function seedDefaultRules(): bool
    {
        $existingNames = Db::getInstance()->executeS('SELECT name FROM `' . _DB_PREFIX_ . 'allegro_ar_rule`');
        $existingMap = [];
        foreach ($existingNames as $row) {
            $name = trim((string) ($row['name'] ?? ''));
            if ($name === '') {
                continue;
            }

            $existingMap[mb_strtolower($name)] = true;
        }

        $now = date('Y-m-d H:i:s');

        foreach ($this->getDefaultRuleSeeds() as $rule) {
            $ruleName = trim((string) ($rule['name'] ?? ''));
            if ($ruleName === '' || isset($existingMap[mb_strtolower($ruleName)])) {
                continue;
            }

            $data = [
                'name' => pSQL($ruleName),
                'enabled' => (int) ($rule['enabled'] ?? 1),
                'priority' => (int) ($rule['priority'] ?? 100),
                'match_type' => pSQL((string) ($rule['match_type'] ?? 'contains')),
                'keywords' => pSQL((string) ($rule['keywords'] ?? ''), true),
                'response_template' => pSQL((string) ($rule['response_template'] ?? ''), true),
                'only_first_message' => (int) ($rule['only_first_message'] ?? 0),
                'cooldown_minutes' => (int) ($rule['cooldown_minutes'] ?? 180),
                'date_add' => $now,
                'date_upd' => $now,
            ];

            if (!Db::getInstance()->insert('allegro_ar_rule', $data)) {
                return false;
            }

            $existingMap[mb_strtolower($ruleName)] = true;
        }

        return true;
    }

    protected function getDefaultRuleSeeds(): array
    {
        return [
            [
                'name' => 'Status przesylki',
                'priority' => 10,
                'match_type' => 'contains',
                'keywords' => "gdzie paczka\nstatus przesylki\ngdzie jest przesylka\ngdzie moje zamowienie\nkiedy paczka dojdzie\nczy przesylka zostala wyslana",
                'response_template' => "Czesc {buyer_login},\n\ndziekujemy za wiadomosc. Sprawdzimy status przesylki i wrocimy do Ciebie z informacja tak szybko, jak to mozliwe.\n\nPozdrawiamy,\n{shop_name}",
                'only_first_message' => 0,
                'cooldown_minutes' => 180,
            ],
            [
                'name' => 'Termin wysylki',
                'priority' => 20,
                'match_type' => 'contains',
                'keywords' => "kiedy wysylka\nkiedy bedzie wyslane\nkiedy wyślecie\nna kiedy wysylka\njaki czas realizacji\nkiedy nadacie",
                'response_template' => "Czesc {buyer_login},\n\ndziekujemy za kontakt. Sprawdzimy termin realizacji i wrocimy do Ciebie z odpowiedzia tak szybko, jak to mozliwe.\n\nPozdrawiamy,\n{shop_name}",
                'only_first_message' => 0,
                'cooldown_minutes' => 180,
            ],
            [
                'name' => 'Faktura lub paragon',
                'priority' => 30,
                'match_type' => 'contains',
                'keywords' => "faktura\nparagon\ndokument zakupu\nrachunek\nfv\nfakture",
                'response_template' => "Czesc {buyer_login},\n\ndziekujemy za wiadomosc. Sprawdzimy temat dokumentu zakupu i wracamy z informacja tak szybko, jak to mozliwe.\n\nPozdrawiamy,\n{shop_name}",
                'only_first_message' => 0,
                'cooldown_minutes' => 240,
            ],
            [
                'name' => 'Zwrot produktu',
                'priority' => 40,
                'match_type' => 'contains',
                'keywords' => "zwrot\nchce zwrocic\nodstapienie od umowy\nodeslac produkt\njak zwrocic",
                'response_template' => "Czesc {buyer_login},\n\ndziekujemy za wiadomosc. Przekazemy Ci instrukcje dotyczace zwrotu i dalszych krokow tak szybko, jak to mozliwe.\n\nPozdrawiamy,\n{shop_name}",
                'only_first_message' => 1,
                'cooldown_minutes' => 720,
            ],
            [
                'name' => 'Reklamacja lub uszkodzenie',
                'priority' => 50,
                'match_type' => 'contains',
                'keywords' => "reklamacja\nuszkodzony produkt\nprodukt uszkodzony\nwada produktu\nnie dziala\nnie działa\nbrakuje elementu",
                'response_template' => "Czesc {buyer_login},\n\ndziekujemy za wiadomosc. Sprawdzimy zgloszenie i wrocimy do Ciebie z informacja o dalszych krokach tak szybko, jak to mozliwe.\n\nPozdrawiamy,\n{shop_name}",
                'only_first_message' => 1,
                'cooldown_minutes' => 720,
            ],
            [
                'name' => 'Zmiana lub anulowanie zamowienia',
                'priority' => 60,
                'match_type' => 'contains',
                'keywords' => "anulowac zamowienie\nanulacja zamowienia\nzmiana adresu\nzmienic adres\nzmiana zamowienia\nchce anulowac",
                'response_template' => "Czesc {buyer_login},\n\ndziekujemy za kontakt. Sprawdzimy, czy zmiana lub anulowanie zamowienia jest jeszcze mozliwe, i wrocimy do Ciebie z informacja tak szybko, jak to mozliwe.\n\nPozdrawiamy,\n{shop_name}",
                'only_first_message' => 1,
                'cooldown_minutes' => 360,
            ],
            [
                'name' => 'Dostepnosc produktu',
                'priority' => 70,
                'match_type' => 'contains',
                'keywords' => "dostepny\nczy dostepne\nstan magazynowy\nkiedy bedzie dostepne\nkiedy bedzie na stanie\nczy macie na stanie",
                'response_template' => "Czesc {buyer_login},\n\ndziekujemy za wiadomosc. Sprawdzimy dostepnosc produktu i wrocimy do Ciebie z odpowiedzia tak szybko, jak to mozliwe.\n\nPozdrawiamy,\n{shop_name}",
                'only_first_message' => 0,
                'cooldown_minutes' => 240,
            ],
            [
                'name' => 'Parametry i zgodnosc produktu',
                'priority' => 80,
                'match_type' => 'contains',
                'keywords' => "czy pasuje\nczy bedzie pasowac\njakie wymiary\njakie parametry\nspecyfikacja\nkompatybilnosc",
                'response_template' => "Czesc {buyer_login},\n\ndziekujemy za pytanie. Sprawdzimy parametry lub zgodnosc produktu i wrocimy do Ciebie z odpowiedzia tak szybko, jak to mozliwe.\n\nPozdrawiamy,\n{shop_name}",
                'only_first_message' => 0,
                'cooldown_minutes' => 240,
            ],
            [
                'name' => 'Platnosc i zaksięgowanie',
                'priority' => 90,
                'match_type' => 'contains',
                'keywords' => "platnosc\npłatność\nczy wplata dotarla\nczy platnosc zostala zaksięgowana\noplacone\nopłacone\nprzelew",
                'response_template' => "Czesc {buyer_login},\n\ndziekujemy za wiadomosc. Sprawdzimy status platnosci i wrocimy do Ciebie z informacja tak szybko, jak to mozliwe.\n\nPozdrawiamy,\n{shop_name}",
                'only_first_message' => 0,
                'cooldown_minutes' => 180,
            ],
            [
                'name' => 'Prosba o kontakt',
                'priority' => 100,
                'match_type' => 'contains',
                'keywords' => "prosze o kontakt\nproszę o kontakt\nczy mozecie odpisac\nczy możecie odpisać\nczekam na odpowiedz\nbrak odpowiedzi",
                'response_template' => "Czesc {buyer_login},\n\ndziekujemy za kontakt. Wrocimy do Ciebie z odpowiedzia tak szybko, jak to mozliwe.\n\nPozdrawiamy,\n{shop_name}",
                'only_first_message' => 0,
                'cooldown_minutes' => 180,
            ],
        ];
    }

    public function getContent()
    {
        if ((int) Tools::getValue('ajax') === 1) {
            $this->handleAjaxRequest();
        }

        $output = '';

        $this->handleSettingsActions($output);

        $deviceAuthUrl = $this->context->link->getModuleLink($this->name, 'deviceauth', [
            'token' => Configuration::get(self::CONFIG_PREFIX . 'CRON_TOKEN'),
        ]);

        $this->context->smarty->assign([
            'settings_form' => $this->renderSettingsForm(),
            'rule_form' => $this->renderRuleForm($this->getEditedRule()),
            'rules_table' => $this->renderRulesTable(),
            'logs_table' => $this->renderLogsTable(),
            'update_panel' => $this->renderUpdatePanel(),
            'cron_url' => $this->context->link->getModuleLink($this->name, 'cron', ['token' => Configuration::get(self::CONFIG_PREFIX . 'CRON_TOKEN')]),
            'oauth_url' => $this->getOauthCallbackUrl(),
            'device_auth_url' => $deviceAuthUrl,
            'device_auth_url_json' => json_encode($deviceAuthUrl),
            'device_auth_enabled' => $this->hasAllegroAuthBackend(),
            'connected_account' => $this->getConnectedAccount(),
        ]);

        return $output . $this->display(__FILE__, 'views/templates/admin/configure.tpl');
    }

    protected function handleAjaxRequest(): void
    {
        $action = (string) Tools::getValue('action');

        try {
            if ($action === 'startDeviceAuthorization') {
                $result = (new TokenManager())->startDeviceAuthorization();

                $this->jsonResponse([
                    'success' => true,
                    'verificationUriComplete' => (string) ($result['verification_uri_complete'] ?? ''),
                    'userCode' => (string) ($result['user_code'] ?? ''),
                    'deviceCode' => (string) ($result['device_code'] ?? ''),
                    'interval' => max(3, (int) ($result['interval'] ?? 5)),
                ]);
            }

            if ($action === 'pollDeviceAuthorization') {
                $deviceCode = (string) Tools::getValue('device_code');
                if ($deviceCode === '') {
                    throw new RuntimeException('Missing device code.');
                }

                $result = (new TokenManager())->pollDeviceAuthorization($deviceCode);
                $this->jsonResponse([
                    'success' => true,
                    'authorized' => (bool) ($result['authorized'] ?? false),
                    'pending' => (bool) ($result['pending'] ?? false),
                    'error' => (string) ($result['error'] ?? ''),
                    'account' => $result['account'] ?? null,
                ]);
            }

            if ($action === 'CheckForUpdates') {
                $channel = trim((string) Tools::getValue('channel', ''));
                $updater = $this->getUpdater();
                $channelOverride = $channel !== '' ? $channel : null;
                $status = $updater->checkForUpdates($channelOverride);
                $changelog = $updater->getChangelogForUpdate($channelOverride);

                $this->jsonResponse([
                    'ok' => true,
                    'status' => $status,
                    'changelog' => $changelog,
                ]);
            }

            if ($action === 'InstallUpdate') {
                $channel = trim((string) Tools::getValue('channel', ''));
                $result = $this->getUpdater()->installAvailableUpdate($channel !== '' ? $channel : null);

                $this->jsonResponse([
                    'ok' => true,
                    'version' => (string) ($result['version'] ?? ''),
                    'message' => 'Moduł został zaktualizowany. Odśwież stronę panelu.',
                ]);
            }

            $this->jsonResponse([
                'success' => false,
                'message' => 'Unknown AJAX action.',
            ], 400);
        } catch (Throwable $e) {
            PrestaShopLogger::addLog('[AAR] AJAX error: ' . $e->getMessage(), 3);
            $this->jsonResponse([
                'ok' => false,
                'success' => false,
                'message' => $e->getMessage(),
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    protected function jsonResponse(array $payload, int $status = 200): void
    {
        if (function_exists('http_response_code')) {
            http_response_code($status);
        }

        header('Content-Type: application/json; charset=utf-8');
        die(json_encode($payload));
    }

    public function getMessagesContent(): string
    {
        $output = '';

        if ((int) Tools::getValue('aar_refresh') === 1) {
            $output .= $this->displayConfirmation($this->trans('Wiadomości zostały odświeżone z Allegro.', [], 'Modules.Allegroautoresponder.Admin'));
        }

        if (Tools::isSubmit('submitAarSendMessage')) {
            $result = $this->sendManualMessage();
            $output .= $result
                ? $this->displayConfirmation($this->trans('Wiadomość została wysłana.', [], 'Modules.Allegroautoresponder.Admin'))
                : $this->displayError($this->trans('Nie udało się wysłać wiadomości. Sprawdź logi i uprawnienia Allegro.', [], 'Modules.Allegroautoresponder.Admin'));
        }

        return $output . $this->renderInboxPanel();
    }

    public function getDisputesContent(): string
    {
        return $this->getIssuesContent('DISPUTE', 'Dyskusje', 'Dyskusje zostały odświeżone z Allegro.');
    }

    public function getComplaintsContent(): string
    {
        return $this->getIssuesContent('CLAIM', 'Reklamacje', 'Reklamacje zostały odświeżone z Allegro.');
    }

    public function getReturnsContent(): string
    {
        $output = '';

        if ((int) Tools::getValue('aar_refresh') === 1) {
            Configuration::deleteByName(self::MENU_RETURNS_BADGE_CACHE_CONFIG);
            $output .= $this->displayConfirmation($this->trans('Zwroty zostały odświeżone z Allegro.', [], 'Modules.Allegroautoresponder.Admin'));
        }

        if (Tools::isSubmit('submitAarRefundReturn')) {
            try {
                $this->refundCustomerReturnFromRequest();
                Configuration::deleteByName(self::MENU_RETURNS_BADGE_CACHE_CONFIG);
                $output .= $this->displayConfirmation($this->trans('Zwrot pieniędzy został zlecony w Allegro.', [], 'Modules.Allegroautoresponder.Admin'));
            } catch (Throwable $e) {
                $output .= $this->displayError($this->trans('Nie udało się zlecić zwrotu pieniędzy.', [], 'Modules.Allegroautoresponder.Admin') . ' ' . Tools::safeOutput($e->getMessage()));
            }
        }

        if (Tools::isSubmit('submitAarRejectReturn')) {
            try {
                $this->rejectCustomerReturnFromRequest();
                Configuration::deleteByName(self::MENU_RETURNS_BADGE_CACHE_CONFIG);
                $output .= $this->displayConfirmation($this->trans('Odmowa zwrotu została wysłana do Allegro.', [], 'Modules.Allegroautoresponder.Admin'));
            } catch (Throwable $e) {
                $output .= $this->displayError($this->trans('Nie udało się odmówić zwrotu.', [], 'Modules.Allegroautoresponder.Admin') . ' ' . Tools::safeOutput($e->getMessage()));
            }
        }

        return $output . $this->renderReturnsToolbar() . $this->renderReturnsPanel();
    }

    protected function getIssuesContent(string $issueType, string $sectionTitle, string $refreshMessage): string
    {
        $output = '';

        if ((int) Tools::getValue('aar_refresh') === 1) {
            $output .= $this->displayConfirmation($this->trans($refreshMessage, [], 'Modules.Allegroautoresponder.Admin'));
        }

        if (Tools::isSubmit('submitAarSendIssueMessage')) {
            $result = $this->sendIssueMessage($issueType);
            $output .= $result
                ? $this->displayConfirmation($this->trans('Wiadomość została wysłana.', [], 'Modules.Allegroautoresponder.Admin'))
                : $this->displayError($this->trans('Nie udało się wysłać wiadomości. Sprawdź logi i uprawnienia Allegro.', [], 'Modules.Allegroautoresponder.Admin'));
        }

        return $output . $this->renderIssuesToolbar($issueType) . $this->renderIssuesPanel($issueType, $sectionTitle);
    }

    protected function handleSettingsActions(string &$output): void
    {
        if (Tools::isSubmit('submitAarSettings')) {
            $this->saveSettings();
            $output .= $this->displayConfirmation($this->trans('Ustawienia zapisane.', [], 'Modules.Allegroautoresponder.Admin'));
        }

        if (Tools::isSubmit('submitAarSaveUpdateSettings')) {
            try {
                $this->getUpdater()->saveConfiguredChannel((string) Tools::getValue('aar_update_channel', AllegroAutoresponderUpdater::UPDATE_CHANNEL_PUBLIC));
                $output .= $this->displayConfirmation($this->trans('Ustawienia aktualizacji zapisane.', [], 'Modules.Allegroautoresponder.Admin'));
            } catch (Throwable $e) {
                $output .= $this->displayError($e->getMessage());
            }
        }

        if (Tools::isSubmit('submitAarCheckUpdate')) {
            try {
                $status = $this->getUpdater()->checkForUpdates();
                if (empty($status['configured'])) {
                    $output .= $this->displayWarning($this->trans('Aktualizacje nie są skonfigurowane.', [], 'Modules.Allegroautoresponder.Admin'));
                } elseif (!empty($status['available'])) {
                    $output .= $this->displayConfirmation($this->trans('Dostępna jest aktualizacja modułu.', [], 'Modules.Allegroautoresponder.Admin') . ' ' . Tools::safeOutput((string) $status['version']));
                } else {
                    $output .= $this->displayConfirmation($this->trans('Masz najnowszą wersję modułu.', [], 'Modules.Allegroautoresponder.Admin'));
                }
            } catch (Throwable $e) {
                $output .= $this->displayError($e->getMessage());
            }
        }

        if (Tools::isSubmit('submitAarInstallUpdate')) {
            try {
                $result = $this->getUpdater()->installAvailableUpdate();
                $output .= $this->displayConfirmation($this->trans('Moduł został zaktualizowany. Odśwież stronę panelu.', [], 'Modules.Allegroautoresponder.Admin') . ' ' . Tools::safeOutput((string) ($result['version'] ?? '')));
            } catch (Throwable $e) {
                $output .= $this->displayError($e->getMessage());
            }
        }

        if (Tools::isSubmit('submitAarDisconnectAccount')) {
            $this->disconnectAllegroAccount();
            $output .= $this->displayConfirmation($this->trans('Konto Allegro zostało rozłączone w module.', [], 'Modules.Allegroautoresponder.Admin'));
        }

        if (Tools::isSubmit('submitAarAddRule')) {
            $this->createRuleFromRequest();
            $output .= $this->displayConfirmation($this->trans('Reguła została dodana.', [], 'Modules.Allegroautoresponder.Admin'));
        }

        if (Tools::isSubmit('submitAarSaveRule')) {
            $this->updateRuleFromRequest((int) Tools::getValue('id_rule'));
            $output .= $this->displayConfirmation($this->trans('Reguła została zapisana.', [], 'Modules.Allegroautoresponder.Admin'));
        }

        if (Tools::isSubmit('submitAarRunTest')) {
            $result = $this->runManualScan();
            $output .= $result
                ? $this->displayConfirmation($this->trans('Skan ręczny zakończony.', [], 'Modules.Allegroautoresponder.Admin'))
                : $this->displayError($this->trans('Skan ręczny nie powiódł się. Sprawdź logi i dane API.', [], 'Modules.Allegroautoresponder.Admin'));
        }

        if (Tools::isSubmit('submitAarInstallDefaultRules')) {
            $result = $this->seedDefaultRules();
            $output .= $result
                ? $this->displayConfirmation($this->trans('Pakiet startowych reguł został zaimportowany. Brakujące reguły zostały dodane bez nadpisywania istniejących.', [], 'Modules.Allegroautoresponder.Admin'))
                : $this->displayError($this->trans('Nie udało się zaimportować reguł startowych.', [], 'Modules.Allegroautoresponder.Admin'));
        }

        if (Tools::getIsset('delete_rule')) {
            $this->deleteRule((int) Tools::getValue('delete_rule'));
            $output .= $this->displayConfirmation($this->trans('Reguła została usunięta.', [], 'Modules.Allegroautoresponder.Admin'));
        }
    }

    public function hookDisplayAdminOrderSide(array $params): string
    {
        return '';
    }

    public function hookDisplayAdminOrderMain(array $params): string
    {
        return '';
    }

    public function hookDisplayBackOfficeHeader(array $params): string
    {
        return $this->renderAllegroMenuStateScript()
            . $this->renderAllegroMenuUnreadBadge()
            . $this->renderAllegroMenuReturnsBadge();
    }

    protected function renderAllegroMenuStateScript(): string
    {
        $controller = (string) Tools::getValue('controller');
        if ($controller === '') {
            $controller = (string) Tools::getValue('_legacy_controller');
        }

        $menuControllers = [
            self::ADMIN_PARENT_CLASS,
            'AdminAllegroAutoresponderMessages',
            'AdminAllegroAutoresponderDisputes',
            'AdminAllegroAutoresponderComplaints',
            'AdminAllegroAutoresponderReturns',
            'AdminAllegroAutoresponderSettings',
        ];

        if (!in_array($controller, $menuControllers, true)) {
            return '';
        }

        try {
            $this->installTabs();
        } catch (Throwable $e) {
            PrestaShopLogger::addLog('[AAR] Menu tabs refresh error: ' . $e->getMessage(), 2);
        }

        $config = [
            'parentController' => self::ADMIN_PARENT_CLASS,
            'currentController' => $controller,
            'parentLabels' => [
                'Wiadomości Allegro',
                'Obsługa Klienta Allegro',
                'Allegro Messages',
                'AllegroCustomerSupport',
            ],
            'labelsByController' => [
                'AdminAllegroAutoresponderMessages' => ['Wiadomości', 'Messages'],
                'AdminAllegroAutoresponderDisputes' => ['Dyskusje', 'Disputes'],
                'AdminAllegroAutoresponderComplaints' => ['Reklamacje', 'Complaints', 'Reklamacje i dyskusje', 'Complaints and disputes'],
                'AdminAllegroAutoresponderReturns' => ['Zwroty towarów', 'Returns', 'Zwroty'],
                'AdminAllegroAutoresponderSettings' => ['Ustawienia', 'Settings'],
            ],
            'renameLabels' => [
                'Reklamacje i dyskusje' => 'Reklamacje',
                'Complaints and disputes' => 'Complaints',
                'Zwroty' => 'Zwroty towarów',
            ],
        ];

        return '<script>
            (function () {
                var config = ' . json_encode($config) . ';

                function textOf(element) {
                    return (element && element.textContent ? element.textContent : "").replace(/\\s+/g, " ").trim();
                }

                function hasController(link, controller) {
                    var href = String(link && link.getAttribute("href") || "");
                    return href.indexOf("controller=" + controller) !== -1
                        || href.indexOf("_legacy_controller=" + controller) !== -1
                        || href.indexOf(controller) !== -1;
                }

                function hasAnyLabel(link, labels) {
                    var label = textOf(link);
                    for (var i = 0; i < labels.length; i++) {
                        if (label.indexOf(labels[i]) !== -1) {
                            return true;
                        }
                    }
                    return false;
                }

                function closestMenuItem(element) {
                    return element && element.closest
                        ? element.closest("li, .link-levelone, .link-leveltwo, .menu-item, .nav-item, [data-submenu]")
                        : null;
                }

                function renameMenuLabel(link) {
                    if (!link) {
                        return;
                    }

                    var oldLabel = textOf(link);
                    if (!config.renameLabels[oldLabel]) {
                        return;
                    }

                    var replacement = config.renameLabels[oldLabel];
                    var walker = document.createTreeWalker(link, NodeFilter.SHOW_TEXT, null);
                    var node;
                    while ((node = walker.nextNode())) {
                        if (node.nodeValue && node.nodeValue.indexOf(oldLabel) !== -1) {
                            node.nodeValue = node.nodeValue.replace(oldLabel, replacement);
                            return;
                        }
                    }
                }

                function findMenuLink(controller, labels) {
                    var tab = document.querySelector("[data-submenu=\'" + controller + "\']");
                    if (tab) {
                        var tabLink = tab.tagName && tab.tagName.toLowerCase() === "a" ? tab : tab.querySelector("a");
                        if (tabLink) {
                            return tabLink;
                        }
                    }

                    var links = Array.prototype.slice.call(document.querySelectorAll(
                        "#nav-sidebar a, #main-div a, .nav-bar a, .sidebar a, nav a, a"
                    ));
                    for (var i = 0; i < links.length; i++) {
                        if (hasController(links[i], controller) || hasAnyLabel(links[i], labels || [])) {
                            return links[i];
                        }
                    }

                    return null;
                }

                function activateMenu() {
                    var parentLink = findMenuLink(config.parentController, config.parentLabels);
                    var currentLabels = config.labelsByController[config.currentController] || [];
                    var currentLink = findMenuLink(config.currentController, currentLabels);
                    var complaintsLink = findMenuLink("AdminAllegroAutoresponderComplaints", config.labelsByController.AdminAllegroAutoresponderComplaints || []);
                    renameMenuLabel(complaintsLink);

                    if (!parentLink && !currentLink) {
                        return false;
                    }

                    var parentItem = closestMenuItem(parentLink) || closestMenuItem(currentLink);
                    var currentItem = closestMenuItem(currentLink);

                    if (parentItem) {
                        parentItem.classList.add("active", "current", "open", "menu-open");
                        parentItem.setAttribute("aria-expanded", "true");
                        Array.prototype.slice.call(parentItem.querySelectorAll("ul, .submenu, .collapse")).forEach(function (submenu) {
                            submenu.classList.add("show", "in");
                            submenu.style.display = "";
                        });
                        Array.prototype.slice.call(parentItem.querySelectorAll("[aria-expanded]")).forEach(function (toggle) {
                            toggle.setAttribute("aria-expanded", "true");
                            toggle.classList.remove("collapsed");
                        });
                    }

                    if (currentItem) {
                        currentItem.classList.add("active", "current");
                    }
                    if (currentLink) {
                        currentLink.classList.add("active", "current");
                    }

                    return true;
                }

                function boot() {
                    if (activateMenu()) {
                        return;
                    }
                    window.setTimeout(activateMenu, 300);
                }

                if (document.readyState === "loading") {
                    document.addEventListener("DOMContentLoaded", boot);
                } else {
                    boot();
                }

                if ("MutationObserver" in window) {
                    var attempts = 0;
                    var observer = new MutationObserver(function () {
                        attempts++;
                        if (activateMenu() || attempts > 20) {
                            observer.disconnect();
                        }
                    });
                    observer.observe(document.documentElement, { childList: true, subtree: true });
                    window.setTimeout(function () { observer.disconnect(); }, 5000);
                }
            })();
        </script>';
    }

    protected function renderAllegroMenuUnreadBadge(): string
    {
        $count = $this->getAllegroUnreadThreadsCount();
        if ($count <= 0) {
            return '<script>
                document.addEventListener("DOMContentLoaded", function () {
                    Array.prototype.slice.call(document.querySelectorAll(".allegroautoresponder-menu-badge-unread")).forEach(function (badge) {
                        if (badge.parentNode) {
                            badge.parentNode.removeChild(badge);
                        }
                    });
                });
            </script>';
        }

        $config = [
            'count' => $count,
            'label' => $this->trans('Nowe wiadomości Allegro', [], 'Modules.Allegroautoresponder.Admin'),
            'controller' => self::ADMIN_PARENT_CLASS,
            'labels' => [
                'Wiadomości Allegro',
                'Obsługa Klienta Allegro',
                'Allegro Messages',
                'AllegroCustomerSupport',
            ],
        ];

        return '<style>
            .allegroautoresponder-menu-badge {
                font-size: 10px;
                color: #fff;
                padding: 0 5px !important;
                margin-left: 2px !important;
                border-radius: 10px;
                background: #f54c3e;
                height: 15px;
                min-width: 5px;
                display: inline-block;
                text-align: center;
                line-height: 14px;
                vertical-align: middle;
                text-indent: 0;
            }
        </style>
        <script>
            (function () {
                var config = ' . json_encode($config) . ';
                var badgeClass = "allegroautoresponder-menu-badge allegroautoresponder-menu-badge-unread";

                function textOf(element) {
                    return (element && element.textContent ? element.textContent : "").replace(/\s+/g, " ").trim();
                }

                function linkMatches(link) {
                    if (!link) {
                        return false;
                    }

                    var href = String(link.getAttribute("href") || "");
                    if (href.indexOf(config.controller) !== -1) {
                        return true;
                    }

                    var label = textOf(link);
                    for (var i = 0; i < config.labels.length; i++) {
                        if (label.indexOf(config.labels[i]) !== -1) {
                            return true;
                        }
                    }

                    return false;
                }

                function getMenuAnchor(container) {
                    if (!container) {
                        return null;
                    }

                    if (container.tagName && container.tagName.toLowerCase() === "a") {
                        return container;
                    }

                    return container.querySelector("a");
                }

                function findMenuLink() {
                    var tab = document.querySelector("[data-submenu=\'" + config.controller + "\']");
                    var tabLink = getMenuAnchor(tab);
                    if (linkMatches(tabLink)) {
                        return tabLink;
                    }

                    var candidates = Array.prototype.slice.call(document.querySelectorAll(
                        "a[href*=\'controller=" + config.controller + "\']," +
                        "a[href*=\'_legacy_controller=" + config.controller + "\']," +
                        "a[href*=\'" + config.controller + "\']," +
                        "#nav-sidebar a,.nav-bar a,.sidebar a,nav a"
                    ));

                    for (var i = 0; i < candidates.length; i++) {
                        if (linkMatches(candidates[i])) {
                            return candidates[i];
                        }
                    }

                    return null;
                }

                function attachBadge() {
                    var link = findMenuLink();
                    if (!link) {
                        return false;
                    }

                    Array.prototype.slice.call(document.querySelectorAll(".allegroautoresponder-menu-badge-unread")).forEach(function (badge) {
                        if (badge.parentNode) {
                            badge.parentNode.removeChild(badge);
                        }
                    });

                    var badge = document.createElement("span");
                    badge.className = badgeClass;
                    badge.textContent = String(config.count);
                    badge.setAttribute("aria-label", config.label + ": " + String(config.count));
                    link.appendChild(badge);

                    return true;
                }

                if (!attachBadge()) {
                    document.addEventListener("DOMContentLoaded", function () {
                        if (attachBadge()) {
                            return;
                        }
                        window.setTimeout(attachBadge, 300);
                    });
                }

                if ("MutationObserver" in window) {
                    var attempts = 0;
                    var observer = new MutationObserver(function () {
                        attempts++;
                        if (attachBadge() || attempts > 20) {
                            observer.disconnect();
                        }
                    });
                    observer.observe(document.documentElement, { childList: true, subtree: true });
                    window.setTimeout(function () { observer.disconnect(); }, 5000);
                }
            })();
        </script>';
    }

    protected function renderAllegroMenuReturnsBadge(): string
    {
        $count = $this->getAllegroOpenReturnsCount();
        if ($count <= 0) {
            return '<script>
                document.addEventListener("DOMContentLoaded", function () {
                    Array.prototype.slice.call(document.querySelectorAll(".allegroautoresponder-menu-badge-returns")).forEach(function (badge) {
                        if (badge.parentNode) {
                            badge.parentNode.removeChild(badge);
                        }
                    });
                });
            </script>';
        }

        $config = [
            'count' => $count,
            'label' => $this->trans('Zwroty do obsłużenia', [], 'Modules.Allegroautoresponder.Admin'),
            'controller' => 'AdminAllegroAutoresponderReturns',
            'labels' => [
                'Zwroty towarów',
                'Returns',
                'Zwroty',
            ],
        ];

        return '<script>
            (function () {
                var config = ' . json_encode($config) . ';
                var badgeClass = "allegroautoresponder-menu-badge allegroautoresponder-menu-badge-returns";

                function textOf(element) {
                    return (element && element.textContent ? element.textContent : "").replace(/\\s+/g, " ").trim();
                }

                function linkMatches(link) {
                    if (!link) {
                        return false;
                    }

                    var href = String(link.getAttribute("href") || "");
                    if (href.indexOf(config.controller) !== -1) {
                        return true;
                    }

                    var label = textOf(link);
                    for (var i = 0; i < config.labels.length; i++) {
                        if (label.indexOf(config.labels[i]) !== -1) {
                            return true;
                        }
                    }

                    return false;
                }

                function getMenuAnchor(container) {
                    if (!container) {
                        return null;
                    }

                    if (container.tagName && container.tagName.toLowerCase() === "a") {
                        return container;
                    }

                    return container.querySelector("a");
                }

                function findMenuLink() {
                    var tab = document.querySelector("[data-submenu=\'" + config.controller + "\']");
                    var tabLink = getMenuAnchor(tab);
                    if (linkMatches(tabLink)) {
                        return tabLink;
                    }

                    var candidates = Array.prototype.slice.call(document.querySelectorAll(
                        "a[href*=\'controller=" + config.controller + "\']," +
                        "a[href*=\'_legacy_controller=" + config.controller + "\']," +
                        "a[href*=\'" + config.controller + "\']," +
                        "#nav-sidebar a,.nav-bar a,.sidebar a,nav a"
                    ));

                    for (var i = 0; i < candidates.length; i++) {
                        if (linkMatches(candidates[i])) {
                            return candidates[i];
                        }
                    }

                    return null;
                }

                function attachBadge() {
                    var link = findMenuLink();
                    if (!link) {
                        return false;
                    }

                    Array.prototype.slice.call(document.querySelectorAll(".allegroautoresponder-menu-badge-returns")).forEach(function (badge) {
                        if (badge.parentNode) {
                            badge.parentNode.removeChild(badge);
                        }
                    });

                    var badge = document.createElement("span");
                    badge.className = badgeClass;
                    badge.textContent = String(config.count);
                    badge.setAttribute("aria-label", config.label + ": " + String(config.count));
                    link.appendChild(badge);

                    return true;
                }

                if (!attachBadge()) {
                    document.addEventListener("DOMContentLoaded", function () {
                        if (attachBadge()) {
                            return;
                        }
                        window.setTimeout(attachBadge, 300);
                    });
                }

                if ("MutationObserver" in window) {
                    var attempts = 0;
                    var observer = new MutationObserver(function () {
                        attempts++;
                        if (attachBadge() || attempts > 20) {
                            observer.disconnect();
                        }
                    });
                    observer.observe(document.documentElement, { childList: true, subtree: true });
                    window.setTimeout(function () { observer.disconnect(); }, 5000);
                }
            })();
        </script>';
    }

    protected function getAllegroUnreadThreadsCount(): int
    {
        $cached = $this->getCachedMenuUnreadBadgeCount();
        if ($cached !== null) {
            return $cached;
        }

        try {
            $apiClient = new AllegroApiClient(new TokenManager());
            $limit = 20;
            $maxPages = 5;
            $count = 0;

            for ($page = 0; $page < $maxPages; $page++) {
                $response = $apiClient->getThreads($limit, $page * $limit);
                $threads = $response['threads'] ?? [];
                if (!is_array($threads) || $threads === []) {
                    break;
                }

                foreach ($threads as $thread) {
                    if (is_array($thread) && isset($thread['read']) && !(bool) $thread['read']) {
                        $count++;
                    }
                }

                if (count($threads) < $limit) {
                    break;
                }
            }

            $this->setCachedMenuUnreadBadgeCount($count);

            return $count;
        } catch (\Throwable $e) {
            return $this->getCachedMenuUnreadBadgeCount(false) ?? 0;
        }
    }

    protected function getAllegroOpenReturnsCount(): int
    {
        $cached = $this->getCachedMenuReturnsBadgeCount();
        if ($cached !== null) {
            return $cached;
        }

        try {
            $apiClient = new AllegroApiClient(new TokenManager());
            $limit = 100;
            $maxPages = 5;
            $count = 0;

            for ($page = 0; $page < $maxPages; $page++) {
                $response = $apiClient->getCustomerReturns($limit, $page * $limit);
                $returns = $response['customerReturns'] ?? [];
                if (!is_array($returns) || $returns === []) {
                    break;
                }

                foreach ($returns as $return) {
                    if ($this->isCustomerReturnPending($return)) {
                        $count++;
                    }
                }

                if (count($returns) < $limit) {
                    break;
                }
            }

            $this->setCachedMenuReturnsBadgeCount($count);

            return $count;
        } catch (Throwable $e) {
            return $this->getCachedMenuReturnsBadgeCount(false) ?? 0;
        }
    }

    protected function getCachedMenuUnreadBadgeCount(bool $onlyFresh = true): ?int
    {
        $stored = (string) Configuration::get(self::MENU_UNREAD_BADGE_CACHE_CONFIG);
        if ($stored === '') {
            return null;
        }

        $decoded = json_decode($stored, true);
        if (!is_array($decoded) || !isset($decoded['count'], $decoded['timestamp'])) {
            return null;
        }

        if ($onlyFresh && time() - (int) $decoded['timestamp'] > self::MENU_UNREAD_BADGE_CACHE_TTL) {
            return null;
        }

        return max(0, (int) $decoded['count']);
    }

    protected function setCachedMenuUnreadBadgeCount(int $count): void
    {
        Configuration::updateValue(self::MENU_UNREAD_BADGE_CACHE_CONFIG, json_encode([
            'count' => max(0, $count),
            'timestamp' => time(),
        ]));
    }

    protected function getCachedMenuReturnsBadgeCount(bool $onlyFresh = true): ?int
    {
        $stored = (string) Configuration::get(self::MENU_RETURNS_BADGE_CACHE_CONFIG);
        if ($stored === '') {
            return null;
        }

        $decoded = json_decode($stored, true);
        if (!is_array($decoded) || !isset($decoded['count'], $decoded['timestamp'])) {
            return null;
        }

        if ($onlyFresh && time() - (int) $decoded['timestamp'] > self::MENU_UNREAD_BADGE_CACHE_TTL) {
            return null;
        }

        return max(0, (int) $decoded['count']);
    }

    protected function setCachedMenuReturnsBadgeCount(int $count): void
    {
        Configuration::updateValue(self::MENU_RETURNS_BADGE_CACHE_CONFIG, json_encode([
            'count' => max(0, $count),
            'timestamp' => time(),
        ]));
    }

    protected function isCustomerReturnPending($return): bool
    {
        if (!is_array($return)) {
            return false;
        }

        $status = mb_strtoupper(trim((string) ($return['status'] ?? '')));

        return !in_array($status, ['FINISHED', 'FINISHED_APT', 'REJECTED', 'COMMISSION_REFUNDED'], true);
    }

    protected function saveSettings()
    {
        Configuration::updateValue(self::CONFIG_PREFIX . 'ENABLED', (int) Tools::getValue(self::CONFIG_PREFIX . 'ENABLED'));
        Configuration::updateValue(self::CONFIG_PREFIX . 'POLL_LIMIT', (int) Tools::getValue(self::CONFIG_PREFIX . 'POLL_LIMIT'));
        Configuration::updateValue(self::CONFIG_PREFIX . 'COOLDOWN_MINUTES', (int) Tools::getValue(self::CONFIG_PREFIX . 'COOLDOWN_MINUTES'));
        Configuration::updateValue(self::CONFIG_PREFIX . 'TEST_MODE', (int) Tools::getValue(self::CONFIG_PREFIX . 'TEST_MODE'));
        Configuration::updateValue(self::CONFIG_PREFIX . 'REDIRECT_URI', trim((string) Tools::getValue(self::CONFIG_PREFIX . 'REDIRECT_URI')));
    }

    protected function disconnectAllegroAccount(): void
    {
        Db::getInstance()->execute('TRUNCATE TABLE `' . _DB_PREFIX_ . 'allegro_ar_account`');
        Configuration::deleteByName(self::MENU_UNREAD_BADGE_CACHE_CONFIG);
        Configuration::deleteByName(self::MENU_RETURNS_BADGE_CACHE_CONFIG);
    }

    protected function createRuleFromRequest(): void
    {
        $data = [
            'name' => pSQL((string) Tools::getValue('rule_name')),
            'enabled' => (int) Tools::getValue('rule_enabled', 0),
            'priority' => (int) Tools::getValue('rule_priority', 100),
            'match_type' => pSQL((string) Tools::getValue('rule_match_type', 'contains')),
            'keywords' => pSQL((string) Tools::getValue('rule_keywords')),
            'response_template' => pSQL((string) Tools::getValue('rule_response_template'), true),
            'only_first_message' => (int) Tools::getValue('rule_only_first_message', 0),
            'cooldown_minutes' => (int) Tools::getValue('rule_cooldown_minutes', 60),
            'date_add' => date('Y-m-d H:i:s'),
            'date_upd' => date('Y-m-d H:i:s'),
        ];

        Db::getInstance()->insert('allegro_ar_rule', $data);
    }

    protected function updateRuleFromRequest(int $idRule): void
    {
        if ($idRule <= 0) {
            return;
        }

        Db::getInstance()->update('allegro_ar_rule', [
            'name' => pSQL((string) Tools::getValue('rule_name')),
            'enabled' => (int) Tools::getValue('rule_enabled', 0),
            'priority' => (int) Tools::getValue('rule_priority', 100),
            'match_type' => pSQL((string) Tools::getValue('rule_match_type', 'contains')),
            'keywords' => pSQL((string) Tools::getValue('rule_keywords')),
            'response_template' => pSQL((string) Tools::getValue('rule_response_template'), true),
            'only_first_message' => (int) Tools::getValue('rule_only_first_message', 0),
            'cooldown_minutes' => (int) Tools::getValue('rule_cooldown_minutes', 60),
            'date_upd' => date('Y-m-d H:i:s'),
        ], 'id_rule=' . (int) $idRule);
    }

    protected function deleteRule(int $idRule)
    {
        return Db::getInstance()->delete('allegro_ar_rule', 'id_rule=' . (int) $idRule);
    }

    protected function runManualScan(): bool
    {
        try {
            $tokenManager = new TokenManager();
            $apiClient = new AllegroApiClient($tokenManager);
            $ruleEngine = new RuleEngine();
            $logger = new Logger();
            $responder = new Responder($apiClient, $logger, (bool) Configuration::get(self::CONFIG_PREFIX . 'TEST_MODE'));
            $scanner = new MessageScanner($apiClient, $ruleEngine, $responder, $logger);

            $scanner->scan((int) Configuration::get(self::CONFIG_PREFIX . 'POLL_LIMIT'));

            return true;
        } catch (Throwable $e) {
            PrestaShopLogger::addLog('[AAR] Manual scan error: ' . $e->getMessage(), 3);
            return false;
        }
    }

    protected function sendManualMessage(): bool
    {
        $threadId = trim((string) Tools::getValue('thread_id'));
        $text = trim((string) Tools::getValue('reply_text'));
        $logger = new Logger();

        if ($threadId === '' || $text === '') {
            $logger->log('manual_reply_failed', $threadId, '', '', ['text' => $text], ['error' => 'Thread ID or reply text is empty'], false);
            return false;
        }

        try {
            $apiClient = new AllegroApiClient(new TokenManager());
            $response = $apiClient->sendMessageToThread($threadId, $text);

            try {
                $apiClient->markThreadRead($threadId);
                Configuration::deleteByName(self::MENU_UNREAD_BADGE_CACHE_CONFIG);
            } catch (Throwable $e) {
                $logger->log('mark_read_failed', $threadId, '', '', [], ['error' => $e->getMessage()], false);
            }

            $logger->log('manual_reply_sent', $threadId, (string) ($response['id'] ?? ''), '', ['text' => $text], $response, true);

            return true;
        } catch (Throwable $e) {
            PrestaShopLogger::addLog('[AAR] Manual reply error: ' . $e->getMessage(), 3);
            $logger->log('manual_reply_failed', $threadId, '', '', ['text' => $text], ['error' => $e->getMessage()], false);

            return false;
        }
    }

    protected function sendIssueMessage(string $issueType): bool
    {
        $issueId = trim((string) Tools::getValue('issue_id'));
        $text = trim((string) Tools::getValue('reply_text'));
        $logger = new Logger();

        if ($issueId === '' || $text === '') {
            $logger->log('issue_reply_failed', $issueId, '', '', ['text' => $text, 'type' => $issueType], ['error' => 'Issue ID or reply text is empty'], false);
            return false;
        }

        try {
            $apiClient = new AllegroApiClient(new TokenManager());
            $response = $apiClient->sendIssueMessage($issueId, $text);
            $logger->log('issue_reply_sent', $issueId, (string) ($response['id'] ?? ''), '', ['text' => $text, 'type' => $issueType], $response, true);

            return true;
        } catch (Throwable $e) {
            PrestaShopLogger::addLog('[AAR] Issue reply error: ' . $e->getMessage(), 3);
            $logger->log('issue_reply_failed', $issueId, '', '', ['text' => $text, 'type' => $issueType], ['error' => $e->getMessage()], false);

            return false;
        }
    }

    protected function rejectCustomerReturnFromRequest(): void
    {
        $returnId = trim((string) Tools::getValue('return_id'));
        $selectedReason = mb_strtoupper(trim((string) Tools::getValue('return_rejection_code')));
        $reason = trim((string) Tools::getValue('return_rejection_reason'));
        $definitions = $this->getCustomerReturnRejectionReasonDefinitions();
        $logger = new Logger();
        $code = '';

        if ($returnId === '') {
            throw new RuntimeException('Brakuje identyfikatora zwrotu.');
        }
        if (!isset($definitions[$selectedReason])) {
            throw new RuntimeException('Nieznany powód odmowy zwrotu.');
        }
        $code = (string) ($definitions[$selectedReason]['api_code'] ?? '');
        if ($code === '') {
            throw new RuntimeException('Brakuje mapowania powodu odmowy zwrotu.');
        }
        if ($code === 'REFUND_REJECTED' && $reason === '') {
            throw new RuntimeException('Dla odmowy zwrotu środków wymagane jest uzasadnienie.');
        }

        try {
            $apiClient = new AllegroApiClient(new TokenManager());
            $response = $apiClient->rejectCustomerReturn($returnId, $code, $reason);
            $logger->log('return_rejection_sent', $returnId, '', $code, [
                'reason' => $reason,
            ], $response, true);
        } catch (Throwable $e) {
            PrestaShopLogger::addLog('[AAR] Customer return rejection error: ' . $e->getMessage(), 3);
            $logger->log('return_rejection_failed', $returnId, '', $code, [
                'reason' => $reason,
            ], ['error' => $e->getMessage()], false);
            throw $e;
        }
    }

    protected function refundCustomerReturnFromRequest(): void
    {
        $returnId = trim((string) Tools::getValue('return_id'));
        $linePayloads = Tools::getValue('return_refund_lines');
        $deliveryAmount = $this->normalizeRefundAmount((string) Tools::getValue('return_refund_delivery_amount'));
        $deliveryCurrency = trim((string) Tools::getValue('return_refund_delivery_currency', 'PLN'));
        $refundReason = mb_strtoupper(trim((string) Tools::getValue('return_refund_reason', 'REFUND')));
        $sellerComment = trim((string) Tools::getValue('return_refund_comment'));
        $logger = new Logger();

        if ($returnId === '') {
            throw new RuntimeException('Brakuje identyfikatora zwrotu.');
        }
        $refundReasonOptions = $this->getCustomerReturnRefundReasonOptions();
        if (!isset($refundReasonOptions[$refundReason])) {
            throw new RuntimeException('Nieprawidłowy powód zwrotu pieniędzy.');
        }
        if (!is_array($linePayloads)) {
            $linePayloads = [];
        }

        $apiClient = new AllegroApiClient(new TokenManager());
        $return = $apiClient->getCustomerReturn($returnId);
        $orderId = trim((string) ($return['orderId'] ?? ''));
        if ($orderId === '') {
            throw new RuntimeException('Brakuje identyfikatora zamówienia Allegro dla zwrotu.');
        }

        $checkoutForm = $apiClient->getCheckoutForm($orderId);
        $paymentId = trim((string) ($checkoutForm['payment']['id'] ?? ''));
        if ($paymentId === '') {
            throw new RuntimeException('Brakuje identyfikatora płatności Allegro dla tego zamówienia.');
        }

        $checkoutLineItems = $this->indexCheckoutLineItemsByOfferId($checkoutForm);
        $refundLineItems = [];
        foreach ($linePayloads as $line) {
            if (!is_array($line)) {
                continue;
            }

            $offerId = trim((string) ($line['offer_id'] ?? ''));
            $amount = $this->normalizeRefundAmount((string) ($line['amount'] ?? ''));
            $currency = trim((string) ($line['currency'] ?? 'PLN'));
            if ($offerId === '' || $amount === '') {
                continue;
            }

            $checkoutLineItem = $checkoutLineItems[$offerId] ?? null;
            if (!is_array($checkoutLineItem) || trim((string) ($checkoutLineItem['id'] ?? '')) === '') {
                throw new RuntimeException('Nie udało się dopasować pozycji zamówienia do oferty ' . $offerId . '.');
            }

            $refundLineItems[] = [
                'id' => (string) $checkoutLineItem['id'],
                'type' => 'AMOUNT',
                'value' => [
                    'amount' => $amount,
                    'currency' => $currency !== '' ? $currency : 'PLN',
                ],
            ];
        }

        $payload = [
            'payment' => [
                'id' => $paymentId,
            ],
            'order' => [
                'id' => $orderId,
            ],
            'commandId' => $this->generateUuidV4(),
            'reason' => $refundReason,
        ];

        if ($refundLineItems) {
            $payload['lineItems'] = $refundLineItems;
        }
        if ($deliveryAmount !== '') {
            $payload['delivery'] = [
                'value' => [
                    'amount' => $deliveryAmount,
                    'currency' => $deliveryCurrency !== '' ? $deliveryCurrency : 'PLN',
                ],
            ];
        }
        if (!$refundLineItems && $deliveryAmount === '') {
            throw new RuntimeException('Podaj kwotę zwrotu dla produktu lub dostawy.');
        }
        if ($sellerComment !== '') {
            $payload['sellerComment'] = mb_substr($sellerComment, 0, 250);
        }

        try {
            $response = $apiClient->createPaymentRefund($payload);
            $logger->log('return_refund_sent', $returnId, (string) ($response['id'] ?? ''), $refundReason, $payload, $response, true);
        } catch (Throwable $e) {
            PrestaShopLogger::addLog('[AAR] Customer return refund error: ' . $e->getMessage(), 3);
            $logger->log('return_refund_failed', $returnId, '', $refundReason, $payload, ['error' => $e->getMessage()], false);
            throw $e;
        }
    }

    protected function renderInboxPanel(): string
    {
        if (!$this->getConnectedAccount()) {
            return '<div class="panel"><h3>Obsługa Klienta Allegro</h3><p>Najpierw połącz konto Allegro, potem w tym miejscu pojawi się lista wątków.</p></div>';
        }

        try {
            $apiClient = new AllegroApiClient(new TokenManager());
            $threadPageCount = $this->getCurrentThreadPageCount();
            $hasMoreThreads = false;
            $threads = [];
            $limit = 20;
            $apiPageCount = $threadPageCount * 5;
            for ($page = 0; $page < $apiPageCount; $page++) {
                $threadsResponse = $apiClient->getThreads($limit, $page * $limit);
                $responseThreads = $threadsResponse['threads'] ?? [];
                if (count($responseThreads) >= $limit && $page === $apiPageCount - 1) {
                    $hasMoreThreads = true;
                }

                foreach ($responseThreads as $thread) {
                    if (is_array($thread)) {
                        $threads[] = $thread;
                    }
                }
            }

            if (!$threads) {
                return '<div class="panel"><h3>Obsługa Klienta Allegro</h3><p>Nie znaleziono wątków na koncie Allegro.</p></div>';
            }

            $selectedThreadId = trim((string) Tools::getValue('thread_id'));
            if ($selectedThreadId === '') {
                $selectedThreadId = (string) ($threads[0]['id'] ?? '');
            }

            $selectedThread = $this->findThreadById($threads, $selectedThreadId);
            if (!$selectedThread && $selectedThreadId !== '') {
                $selectedThread = $apiClient->getThread($selectedThreadId);
            }

            $messages = [];
            if ($selectedThreadId !== '') {
                $messageLimit = 20;
                for ($messagePage = 0; $messagePage < 5; $messagePage++) {
                    $messagesResponse = $apiClient->getThreadMessages($selectedThreadId, $messageLimit, $messagePage * $messageLimit);
                    foreach (($messagesResponse['messages'] ?? []) as $message) {
                        if (is_array($message)) {
                            $messages[] = $message;
                        }
                    }

                    if (count($messagesResponse['messages'] ?? []) < $messageLimit) {
                        break;
                    }
                }
                usort($messages, function (array $a, array $b): int {
                    return strtotime((string) ($a['createdAt'] ?? '')) <=> strtotime((string) ($b['createdAt'] ?? ''));
                });
            }

            return $this->renderInboxHtml($threads, $selectedThreadId, $selectedThread ?: [], $messages, $hasMoreThreads, $threadPageCount);
        } catch (Throwable $e) {
            PrestaShopLogger::addLog('[AAR] Inbox render error: ' . $e->getMessage(), 3);
            return '<div class="panel"><h3>Obsługa Klienta Allegro</h3><div class="alert alert-danger">Nie udało się pobrać wiadomości z Allegro: ' . Tools::safeOutput($e->getMessage()) . '</div></div>';
        }
    }

    protected function renderIssuesPanel(string $issueType, string $sectionTitle): string
    {
        if (!$this->getConnectedAccount()) {
            return '<div class="panel"><h3>' . Tools::safeOutput($sectionTitle) . '</h3><p>Najpierw połącz konto Allegro, potem w tym miejscu pojawi się lista zgłoszeń.</p></div>';
        }

        try {
            $apiClient = new AllegroApiClient(new TokenManager());
            $issueKind = $this->getCurrentIssueKindFilter($issueType);
            $statusFilter = $this->getCurrentIssueStatusFilter();
            $issuePageCount = $this->getCurrentIssuePageCount();
            $hasMoreIssues = false;
            $issues = $this->getFilteredIssuesForKind($apiClient, $issueKind, $statusFilter, $issuePageCount, $hasMoreIssues);
            $effectiveSectionTitle = $this->getIssueSectionTitleForKind($issueKind, $sectionTitle);

            if (!$issues) {
                return '<div class="panel"><h3>' . Tools::safeOutput($effectiveSectionTitle) . '</h3><p>Nie znaleziono zgłoszeń dla wybranego filtra.</p></div>';
            }

            $selectedIssueId = trim((string) Tools::getValue('issue_id'));
            if ($selectedIssueId === '') {
                $selectedIssueId = (string) ($issues[0]['id'] ?? '');
            }

            $selectedIssue = $this->findIssueById($issues, $selectedIssueId);
            if (!$selectedIssue && $issues) {
                $selectedIssueId = (string) ($issues[0]['id'] ?? '');
                $selectedIssue = $this->findIssueById($issues, $selectedIssueId);
            }
            if (!$selectedIssue && $selectedIssueId !== '') {
                $selectedIssue = $apiClient->getIssue($selectedIssueId);
            }

            $messages = [];
            $messagesResponse = [];
            if ($selectedIssueId !== '') {
                $messagesResponse = $apiClient->getIssueChat($selectedIssueId, 100);
                $messages = $messagesResponse['chat'] ?? $messagesResponse['messages'] ?? [];
                usort($messages, function (array $a, array $b): int {
                    return strtotime((string) ($a['createdAt'] ?? '')) <=> strtotime((string) ($b['createdAt'] ?? ''));
                });
            }

            $this->maybeDumpIssueDebugPayload($selectedIssueId, $selectedIssue ?: [], $messagesResponse, $messages, $issues);
            $this->maybeDumpIssueOfferDebugPayload($apiClient, $selectedIssue ?: []);
            $this->maybeDumpIssueCheckoutFormDebugPayload($apiClient, $selectedIssue ?: []);

            return $this->renderIssuesHtml($issues, $selectedIssueId, $selectedIssue ?: [], $messages, $issueKind, $effectiveSectionTitle, $statusFilter, $hasMoreIssues, $issuePageCount);
        } catch (Throwable $e) {
            PrestaShopLogger::addLog('[AAR] Issues render error: ' . $e->getMessage(), 3);
            return '<div class="panel"><h3>' . Tools::safeOutput($sectionTitle) . '</h3><div class="alert alert-danger">Nie udało się pobrać danych z Allegro: ' . Tools::safeOutput($e->getMessage()) . '</div></div>';
        }
    }

    protected function renderReturnsPanel(): string
    {
        if (!$this->getConnectedAccount()) {
            return '<div class="panel"><h3>Zwroty towarów</h3><p>Najpierw połącz konto Allegro, potem w tym miejscu pojawi się lista zwrotów.</p></div>';
        }

        try {
            $apiClient = new AllegroApiClient(new TokenManager());
            $pageCount = $this->getCurrentReturnPageCount();
            $hasMoreReturns = false;
            $returns = $this->getFilteredCustomerReturns($apiClient, $pageCount, $hasMoreReturns);

            if (!$returns) {
                return '<div class="panel"><h3>Zwroty towarów</h3><p>Nie znaleziono zwrotów dla wybranych filtrów.</p></div>';
            }

            $selectedReturnId = trim((string) Tools::getValue('return_id'));
            if ($selectedReturnId === '') {
                $selectedReturnId = (string) ($returns[0]['id'] ?? '');
            }

            $selectedReturn = $this->findCustomerReturnById($returns, $selectedReturnId);
            $selectedReturnListItem = is_array($selectedReturn) ? $selectedReturn : [];
            $selectedReturnRaw = $selectedReturn;
            if (!$selectedReturn && $returns) {
                $selectedReturnId = (string) ($returns[0]['id'] ?? '');
                $selectedReturn = $this->findCustomerReturnById($returns, $selectedReturnId);
                $selectedReturnListItem = is_array($selectedReturn) ? $selectedReturn : [];
                $selectedReturnRaw = $selectedReturn;
            }
            if ($selectedReturnId !== '') {
                try {
                    $details = $apiClient->getCustomerReturn($selectedReturnId);
                    if (is_array($details) && $details) {
                        $selectedReturnRaw = $details;
                        $selectedReturn = $details;
                    }
                } catch (Throwable $e) {
                    PrestaShopLogger::addLog('[AAR] Customer return details fetch failed for ' . $selectedReturnId . ': ' . $e->getMessage(), 2);
                }

                if (is_array($selectedReturn)) {
                    $selectedReturn = $this->enrichCustomerReturnWithTracking($apiClient, $selectedReturn);
                    $selectedReturn = $this->enrichCustomerReturnWithCheckoutForm($apiClient, $selectedReturn);
                    if ($selectedReturnListItem) {
                        $selectedReturn['_list_item'] = $selectedReturnListItem;
                    }
                }
            }

            $this->maybeDumpCustomerReturnDebugPayload($selectedReturnId, $selectedReturn ?: [], $returns, $selectedReturnRaw ?? []);

            return $this->renderReturnsHtml($returns, $selectedReturnId, $selectedReturn ?: [], $hasMoreReturns, $pageCount, $selectedReturnRaw ?? []);
        } catch (Throwable $e) {
            PrestaShopLogger::addLog('[AAR] Returns render error: ' . $e->getMessage(), 3);
            return '<div class="panel"><h3>Zwroty towarów</h3><div class="alert alert-danger">Nie udało się pobrać zwrotów z Allegro: ' . Tools::safeOutput($e->getMessage()) . '</div></div>';
        }
    }

    protected function renderInboxHtml(array $threads, string $selectedThreadId, array $selectedThread, array $messages, bool $hasMoreThreads = false, int $threadPageCount = 1): string
    {
        $html = '<div class="panel aar-inbox-panel">';
        $html .= $this->renderInboxColorStyles();
        $html .= '<div class="row aar-inbox">';
        $html .= '<div class="col-lg-4 aar-inbox-col aar-inbox-col-list">';
        $html .= '<div class="list-group aar-thread-list">';

        foreach ($threads as $thread) {
            $threadId = (string) ($thread['id'] ?? '');
            if ($threadId === '') {
                continue;
            }

            $isSelected = $threadId === $selectedThreadId;
            $login = (string) ($thread['interlocutor']['login'] ?? 'Rozmówca');
            $lastDate = (string) ($thread['lastMessageDateTime'] ?? '');
            $read = (bool) ($thread['read'] ?? true);
            $requiresReply = $this->threadRequiresSellerReply($thread);
            $lastPreview = $this->buildThreadPreview($thread);
            $url = $this->getAdminMessagesUrl(['thread_id' => $threadId]);

            $html .= '<a class="list-group-item aar-thread-item' . ($isSelected ? ' active' : '') . ($requiresReply ? ' aar-thread-unread' : '') . '" href="' . Tools::safeOutput($url) . '">';
            $html .= '<div class="aar-thread-head">';
            $html .= '<strong class="aar-thread-login">' . Tools::safeOutput($login) . '</strong>';
            if (!$read) {
                $html .= '<span class="badge aar-badge">nowa</span>';
            }
            $html .= '<small class="aar-thread-date">' . Tools::safeOutput($this->formatAllegroDate($lastDate)) . '</small>';
            $html .= '</div>';
            if ($lastPreview !== '') {
                $html .= '<div class="aar-thread-preview">' . Tools::safeOutput($lastPreview) . '</div>';
            }
            $html .= '</a>';
        }

        if ($hasMoreThreads) {
            $html .= '<div class="aar-load-more-wrap">';
            $html .= '<a class="btn btn-default aar-load-more" href="' . Tools::safeOutput($this->getAdminMessagesUrl([
                'thread_pages' => $threadPageCount + 1,
            ])) . '">Wczytaj więcej</a>';
            $html .= '</div>';
        }

        $html .= '</div>';
        $html .= '</div>';
        $html .= '<div class="col-lg-8 aar-inbox-col aar-inbox-col-conversation">';

        if ($selectedThreadId === '') {
            $html .= '<div class="aar-conversation-shell">';
            $html .= '<div class="aar-conversation-empty">Wybierz wątek z listy, aby zobaczyć rozmowę.</div>';
            $html .= '</div>';
        } else {
            $html .= '<div class="aar-conversation-shell">';
            $recipientLogin = (string) ($selectedThread['interlocutor']['login'] ?? '');
            $html .= '<div class="aar-conversation-header">';
            $html .= '<div class="aar-conversation-title">';
            $html .= '<h4>Rozmowa z ' . Tools::safeOutput($recipientLogin ?: 'klientem') . '</h4>';
            $html .= '<small>Wątek Allegro</small>';
            $html .= '</div>';
            $html .= '</div>';

            $html .= '<div class="aar-message-window">';
            if (!$messages) {
                $html .= '<div class="aar-conversation-empty">Brak wiadomości w tym wątku.</div>';
            } else {
                foreach ($messages as $message) {
                    $isCustomer = (bool) ($message['author']['isInterlocutor'] ?? false);
                    $author = $isCustomer ? (string) ($message['author']['login'] ?? $recipientLogin ?: 'Klient') : 'Ty';
                    $text = $this->decodeAllegroText((string) ($message['text'] ?? ''));
                    $createdAt = (string) ($message['createdAt'] ?? '');
                    $offerId = (string) ($message['relatesTo']['offer']['id'] ?? '');
                    $orderId = (string) ($message['relatesTo']['order']['id'] ?? '');

                    $html .= '<div class="aar-message-row ' . ($isCustomer ? 'aar-message-left' : 'aar-message-right') . '">';
                    $html .= '<div class="aar-message-bubble ' . ($isCustomer ? 'aar-message-customer' : 'aar-message-shop') . '">';
                    $html .= '<div class="aar-message-head"><strong>' . Tools::safeOutput($author) . '</strong> <small>' . Tools::safeOutput($this->formatAllegroDate($createdAt)) . '</small></div>';
                    $html .= '<div class="aar-message-text">' . Tools::safeOutput($text) . '</div>';
                    if ($orderId !== '' || $offerId !== '') {
                        $html .= '<small class="aar-message-meta">';
                        if ($orderId !== '') {
                            $html .= 'Zamówienie: ' . Tools::safeOutput($orderId) . ' ';
                        }
                        if ($offerId !== '') {
                            $html .= 'Oferta: ' . Tools::safeOutput($offerId);
                        }
                        $html .= '</small>';
                    }
                    $html .= '</div>';
                    $html .= '</div>';
                }
            }
            $html .= '</div>';

            $html .= '<form method="post" class="aar-reply-form">';
            $html .= '<input type="hidden" name="thread_id" value="' . Tools::safeOutput($selectedThreadId) . '">';
            $html .= '<div class="form-group">';
            $html .= '<div class="aar-reply-compose">';
            $html .= '<textarea class="form-control" name="reply_text" rows="2" placeholder="Napisz odpowiedź do klienta..." required></textarea>';
            $html .= $this->renderQuickReplySelect([
                '{buyer_login}' => $recipientLogin,
                '{shop_name}' => (string) Configuration::get('PS_SHOP_NAME'),
                '{order_id}' => (string) ($this->extractOrderId($messages) ?? ''),
                '{offer_id}' => (string) ($this->extractOfferId($messages) ?? ''),
            ]);
            $html .= '<button class="btn btn-primary aar-send-button" name="submitAarSendMessage" type="submit">Wyślij</button>';
            $html .= '</div>';
            $html .= '</div>';
            $html .= '</form>';
            $html .= '</div>';
        }

        $html .= '</div>';
        $html .= '</div>';
        $html .= '</div>';

        return $html;
    }

    protected function renderIssuesHtml(array $issues, string $selectedIssueId, array $selectedIssue, array $messages, string $issueType, string $sectionTitle, string $statusFilter = 'all', bool $hasMoreIssues = false, int $issuePageCount = 1): string
    {
        $html = '<div class="panel aar-inbox-panel aar-issues-panel">';
        $html .= $this->renderInboxColorStyles();
        $html .= '<div class="row aar-inbox">';
        $html .= '<div class="col-lg-4 aar-inbox-col aar-inbox-col-list">';
        $html .= '<div class="list-group aar-thread-list">';

        foreach ($issues as $issue) {
            $issueId = (string) ($issue['id'] ?? '');
            if ($issueId === '') {
                continue;
            }

            $isSelected = $issueId === $selectedIssueId;
            $subject = $this->buildIssueSubject($issue);
            $lastDate = (string) ($issue['lastMessage']['createdAt'] ?? $issue['updatedAt'] ?? $issue['createdAt'] ?? '');
            $requiresReply = $this->issueRequiresSellerReply($issue);
            $preview = $this->buildIssuePreview($issue);
            $status = (string) ($issue['currentState']['status'] ?? $issue['status'] ?? '');
            $statusLabel = $this->formatIssueListStatus($status);
            $statusClass = $this->getIssueStatusClass($status);
            $issueTypeLabel = $this->formatIssueTypeLabel((string) ($issue['type'] ?? ''));
            $issueTypeClass = $this->getIssueTypeBadgeClass((string) ($issue['type'] ?? ''));
            $thumbnailUrl = $this->resolveIssueThumbnailUrl($issue, true);
            $thumbnailImageUrl = $this->getIssueThumbnailImageUrl($issue);
            $url = $this->getIssuesAdminUrl($issueType, ['issue_id' => $issueId]);

            $html .= '<a class="list-group-item aar-thread-item' . ($isSelected ? ' active' : '') . ($requiresReply ? ' aar-thread-unread' : '') . '" href="' . Tools::safeOutput($url) . '">';
            $html .= '<div class="aar-thread-body">';
            $html .= '<div class="aar-thread-thumb">';
            if ($thumbnailUrl !== '') {
                $html .= '<img src="' . Tools::safeOutput($thumbnailUrl) . '" alt="" loading="lazy" ' . $this->getThumbnailImageFallbackAttributes() . '>';
            } elseif ($thumbnailImageUrl !== '') {
                $html .= '<img src="' . Tools::safeOutput($thumbnailImageUrl) . '" alt="" loading="lazy" ' . $this->getThumbnailImageFallbackAttributes() . '>';
            }
            $html .= '<span class="aar-thread-thumb-placeholder"' . (($thumbnailUrl !== '' || $thumbnailImageUrl !== '') ? ' style="display:none;"' : '') . '></span>';
            $html .= '</div>';
            $html .= '<div class="aar-thread-content">';
            $html .= '<div class="aar-thread-head">';
            $html .= '<strong class="aar-thread-login">' . Tools::safeOutput($subject) . '</strong>';
            $html .= '<small class="aar-thread-date">' . Tools::safeOutput($this->formatAllegroDate($lastDate)) . '</small>';
            $html .= '</div>';
            if ($preview !== '') {
                $html .= '<div class="aar-thread-preview">' . Tools::safeOutput($preview) . '</div>';
            }
            if ($issueTypeLabel !== '' || $statusLabel !== '') {
                $html .= '<div class="aar-thread-meta">';
                if ($issueTypeLabel !== '') {
                    $html .= '<span class="badge aar-type-badge ' . Tools::safeOutput($issueTypeClass) . '">' . Tools::safeOutput($issueTypeLabel) . '</span>';
                }
                if ($statusLabel !== '') {
                    $html .= '<span class="badge aar-status-badge aar-status-badge-' . Tools::safeOutput($statusClass) . '">' . Tools::safeOutput($statusLabel) . '</span>';
                }
                $html .= '</div>';
            }
            $html .= $this->renderIssueListDeadline($issue, $statusClass);
            $html .= '</div>';
            $html .= '</div>';
            $html .= '</a>';
        }

        if ($hasMoreIssues) {
            $html .= '<div class="aar-load-more-wrap">';
            $html .= '<a class="btn btn-default aar-load-more" href="' . Tools::safeOutput($this->getIssuesAdminUrl($issueType, [
                'issue_pages' => $issuePageCount + 1,
            ])) . '">Wczytaj więcej</a>';
            $html .= '</div>';
        }

        $html .= '</div>';
        $html .= '</div>';
        $html .= '<div class="col-lg-8 aar-inbox-col aar-inbox-col-conversation">';

        if ($selectedIssueId === '') {
            $html .= '<div class="aar-conversation-shell">';
            $html .= '<div class="aar-conversation-empty">Wybierz zgłoszenie z listy, aby zobaczyć rozmowę.</div>';
            $html .= '</div>';
        } else {
            $html .= '<div class="aar-conversation-shell">';
            $html .= '<div class="aar-conversation-header">';
            $html .= '<div class="aar-conversation-title">';
            $headerTitle = $this->buildIssueHeaderTitle($selectedIssue);
            $headerUrl = mb_strtoupper((string) ($selectedIssue['type'] ?? '')) === 'CLAIM' ? $this->getAllegroIssueUrl($selectedIssue) : '';
            if ($headerUrl !== '') {
                $html .= '<h4><a href="' . Tools::safeOutput($headerUrl) . '" target="_blank" rel="noopener noreferrer">' . Tools::safeOutput($headerTitle) . '</a></h4>';
            } else {
                $html .= '<h4>' . Tools::safeOutput($headerTitle) . '</h4>';
            }
            $html .= '<small>' . Tools::safeOutput($this->buildIssueHeaderSubtitle($selectedIssue, $sectionTitle)) . '</small>';
            $html .= '</div>';
            $html .= $this->renderIssueHeaderBadges($selectedIssue);
            $html .= '</div>';

            $html .= '<div class="aar-message-window">';
            if (mb_strtoupper((string) ($selectedIssue['type'] ?? '')) === 'CLAIM') {
                $html .= $this->renderClaimSummaryPanel($selectedIssue, $messages);
            } else {
                $html .= $this->renderIssueOrderSummaryPanel($selectedIssue, $messages);
            }
            if (!$messages) {
                $html .= '<div class="aar-conversation-empty">Brak wiadomości w tym zgłoszeniu.</div>';
            } else {
                foreach ($messages as $message) {
                    $isCustomer = $this->isIssueCustomerMessage($message);
                    $author = $this->getIssueAuthorLabel($message, $selectedIssue);
                    $text = $this->decodeAllegroText((string) ($message['text'] ?? ''));
                    $createdAt = (string) ($message['createdAt'] ?? '');
                    $messageType = (string) ($message['type'] ?? '');

                    $html .= '<div class="aar-message-row ' . ($isCustomer ? 'aar-message-left' : 'aar-message-right') . '">';
                    $html .= '<div class="aar-message-bubble ' . ($isCustomer ? 'aar-message-customer' : 'aar-message-shop') . '">';
                    $html .= '<div class="aar-message-head"><strong>' . Tools::safeOutput($author) . '</strong> <small>' . Tools::safeOutput($this->formatAllegroDate($createdAt)) . '</small></div>';
                    $html .= '<div class="aar-message-text">' . Tools::safeOutput($text) . '</div>';
                    if ($messageType !== '') {
                        $html .= '<small class="aar-message-meta">Typ: ' . Tools::safeOutput($messageType) . '</small>';
                    }
                    $html .= '</div>';
                    $html .= '</div>';
                }
            }
            $html .= '</div>';

            $html .= '<form method="post" class="aar-reply-form">';
            $html .= '<input type="hidden" name="issue_id" value="' . Tools::safeOutput($selectedIssueId) . '">';
            $html .= '<div class="form-group">';
            $html .= '<div class="aar-reply-compose">';
            $html .= '<textarea class="form-control" name="reply_text" rows="2" placeholder="Napisz odpowiedź..." required></textarea>';
            $html .= $this->renderQuickReplySelect([
                '{buyer_login}' => (string) ($selectedIssue['buyer']['login'] ?? ''),
                '{shop_name}' => (string) Configuration::get('PS_SHOP_NAME'),
                '{order_id}' => (string) ($this->extractOrderId($messages) ?? ''),
                '{offer_id}' => (string) ($this->extractOfferId($messages) ?? ''),
            ]);
            $html .= '<button class="btn btn-primary aar-send-button" name="submitAarSendIssueMessage" type="submit">Wyślij</button>';
            $html .= '</div>';
            $html .= '</div>';
            $html .= '</form>';
            $html .= '</div>';
        }

        $html .= '</div>';
        $html .= '</div>';
        $html .= '</div>';

        return $html;
    }

    protected function renderReturnsHtml(array $returns, string $selectedReturnId, array $selectedReturn, bool $hasMoreReturns = false, int $returnPageCount = 1, array $selectedReturnRaw = []): string
    {
        $html = '<div class="panel aar-inbox-panel aar-issues-panel aar-returns-panel">';
        $html .= $this->renderInboxColorStyles();
        $html .= '<div class="row aar-inbox">';
        $html .= '<div class="col-lg-4 aar-inbox-col aar-inbox-col-list">';
        $html .= '<div class="list-group aar-thread-list">';

        foreach ($returns as $return) {
            if (!is_array($return)) {
                continue;
            }

            $returnId = (string) ($return['id'] ?? '');
            if ($returnId === '') {
                continue;
            }

            $isSelected = $returnId === $selectedReturnId;
            $status = (string) ($return['status'] ?? '');
            $statusClass = $this->getCustomerReturnStatusClass($status);
            $subject = $this->buildCustomerReturnSubject($return);
            $preview = $this->buildCustomerReturnPreview($return);
            $createdAt = (string) ($return['createdAt'] ?? '');
            $thumbnailSource = $isSelected && $selectedReturn ? $selectedReturn : $return;
            $thumbnailUrl = $this->getCustomerReturnThumbnailImageUrl($thumbnailSource);
            $url = $this->getReturnsAdminUrl(['return_id' => $returnId]);

            $html .= '<a class="list-group-item aar-thread-item' . ($isSelected ? ' active' : '') . '" href="' . Tools::safeOutput($url) . '">';
            $html .= '<div class="aar-thread-body">';
            $html .= '<div class="aar-thread-thumb">';
            if ($thumbnailUrl !== '') {
                $html .= '<img src="' . Tools::safeOutput($thumbnailUrl) . '" alt="" loading="lazy" ' . $this->getThumbnailImageFallbackAttributes() . '>';
            }
            $html .= '<span class="aar-thread-thumb-placeholder"' . ($thumbnailUrl !== '' ? ' style="display:none;"' : '') . '></span>';
            $html .= '</div>';
            $html .= '<div class="aar-thread-content">';
            $html .= '<div class="aar-thread-head">';
            $html .= '<strong class="aar-thread-login">' . Tools::safeOutput($subject) . '</strong>';
            $html .= '<small class="aar-thread-date">' . Tools::safeOutput($this->formatAllegroDate($createdAt)) . '</small>';
            $html .= '</div>';
            if ($preview !== '') {
                $html .= '<div class="aar-thread-preview">' . Tools::safeOutput($preview) . '</div>';
            }
            $html .= '<div class="aar-thread-meta">';
            $html .= '<span class="badge aar-type-badge is-neutral">Zwrot</span>';
            $html .= '<span class="badge aar-status-badge aar-status-badge-' . Tools::safeOutput($statusClass) . '">' . Tools::safeOutput($this->formatCustomerReturnStatus($status)) . '</span>';
            $html .= '</div>';
            $html .= '</div>';
            $html .= '</div>';
            $html .= '</a>';
        }

        if ($hasMoreReturns) {
            $html .= '<div class="aar-load-more-wrap">';
            $html .= '<a class="btn btn-default aar-load-more" href="' . Tools::safeOutput($this->getReturnsAdminUrl([
                'return_pages' => $returnPageCount + 1,
            ])) . '">Wczytaj więcej</a>';
            $html .= '</div>';
        }

        $html .= '</div>';
        $html .= '</div>';
        $html .= '<div class="col-lg-8 aar-inbox-col aar-inbox-col-conversation">';

        if ($selectedReturnId === '') {
            $html .= '<div class="aar-conversation-shell">';
            $html .= '<div class="aar-conversation-empty">Wybierz zwrot z listy, aby zobaczyć szczegóły.</div>';
            $html .= '</div>';
        } else {
            $html .= '<div class="aar-conversation-shell">';
            $html .= '<div class="aar-conversation-header">';
            $html .= '<div class="aar-conversation-title">';
            $headerUrl = $this->getAllegroReturnUrl($selectedReturn);
            $headerTitle = $this->buildCustomerReturnHeaderTitle($selectedReturn);
            if ($headerUrl !== '') {
                $html .= '<h4><a href="' . Tools::safeOutput($headerUrl) . '" target="_blank" rel="noopener noreferrer">' . Tools::safeOutput($headerTitle) . '</a></h4>';
            } else {
                $html .= '<h4>' . Tools::safeOutput($headerTitle) . '</h4>';
            }
            $html .= $this->renderCustomerReturnHeaderMeta($selectedReturn);
            $html .= '</div>';
            $html .= $this->renderCustomerReturnHeaderBadges($selectedReturn);
            $html .= '</div>';

            $html .= '<div class="aar-message-window">';
            $html .= $this->renderCustomerReturnSummaryPanel($selectedReturn);
            $html .= '</div>';
            $html .= $this->renderCustomerReturnDecisionPanel($selectedReturnId, $selectedReturn, $this->calculateCustomerReturnTotal($selectedReturn));
            $html .= $this->renderCustomerReturnTrackingModal($selectedReturnId, $selectedReturn);
            $html .= $this->renderCustomerReturnDiagnosticsPanel($selectedReturnId, $selectedReturn, $selectedReturnRaw);
            $html .= '</div>';
        }

        $html .= '</div>';
        $html .= '</div>';
        $html .= '</div>';

        return $html;
    }

    protected function renderIssueListDeadline(array $issue, string $statusClass): string
    {
        if (mb_strtoupper((string) ($issue['type'] ?? '')) !== 'CLAIM') {
            return '';
        }

        $decisionDueDate = (string) ($issue['decisionDueDate'] ?? '');
        $timeMeta = $this->buildClaimTimeMeta($issue);
        if ($decisionDueDate === '' && trim((string) ($timeMeta['subline'] ?? '')) === '') {
            return '';
        }

        $deadlineClass = trim((string) ($timeMeta['status_class'] ?? $statusClass));
        $html = '<div class="aar-thread-deadline ' . Tools::safeOutput($deadlineClass) . '">';
        $html .= '<div class="aar-thread-deadline-row">';
        $html .= '<span class="aar-thread-deadline-label">' . Tools::safeOutput((string) ($timeMeta['headline'] ?? 'Termin reklamacji')) . '</span>';
        if ($decisionDueDate !== '') {
            $html .= '<strong class="aar-thread-deadline-date">' . Tools::safeOutput($this->formatAllegroDate($decisionDueDate)) . '</strong>';
        }
        $html .= '</div>';
        if (trim((string) ($timeMeta['subline'] ?? '')) !== '') {
            $html .= '<div class="aar-thread-deadline-subline">' . Tools::safeOutput((string) $timeMeta['subline']) . '</div>';
        }
        $html .= $this->renderClaimProgressBar('aar-thread-deadline-progress', $timeMeta);
        $html .= '</div>';

        return $html;
    }

    protected function renderClaimSummaryPanel(array $issue, array $messages = []): string
    {
        $status = (string) ($issue['currentState']['status'] ?? '');
        $statusDueDate = (string) ($issue['currentState']['statusDueDate'] ?? '');
        $decisionDueDate = (string) ($issue['decisionDueDate'] ?? '');
        $openedDate = (string) ($issue['openedDate'] ?? '');
        $buyerLogin = (string) ($issue['buyer']['login'] ?? '');
        $buyerId = (string) ($issue['buyer']['id'] ?? '');
        $checkoutFormIds = $this->extractCheckoutFormIdsFromPayload($issue);
        foreach ($messages as $message) {
            if (is_array($message)) {
                $checkoutFormIds = array_merge($checkoutFormIds, $this->extractCheckoutFormIdsFromPayload($message));
            }
        }
        $checkoutFormIds = array_values(array_unique(array_filter(array_map('strval', $checkoutFormIds))));
        $checkoutFormId = $checkoutFormIds[0] ?? '';
        $offerId = (string) ($issue['offer']['id'] ?? '');
        $offerQuantity = (string) ($issue['offer']['quantity'] ?? '');
        $productId = (string) ($issue['product']['id'] ?? '');
        $reasonType = (string) ($issue['reason']['type'] ?? '');
        $reasonDescription = $this->resolveIssueTextValue($issue['reason']['description'] ?? null);
        $expectations = $this->formatIssueExpectations($issue['expectations'] ?? []);
        $timeMeta = $this->buildClaimTimeMeta($issue, $messages);
        $statusClass = $this->getIssueStatusClass($status);
        $linkedOrder = $this->resolvePrestashopOrderLink($issue, $messages);
        $decisionResolvedAt = (string) ($timeMeta['resolved_at'] ?? '');

        $html = '<div class="aar-claim-summary">';
        $html .= '<div class="aar-claim-deadline ' . Tools::safeOutput((string) ($timeMeta['status_class'] ?? $statusClass)) . '">';
        $html .= '<div class="aar-claim-deadline-head">';
        $html .= '<div>';
        $html .= '<strong>' . Tools::safeOutput($timeMeta['headline']) . '</strong>';
        $html .= '<div class="aar-claim-deadline-sub">' . Tools::safeOutput($timeMeta['subline']) . '</div>';
        $html .= '</div>';
        $html .= '<div class="aar-claim-deadline-date">';
        $html .= '<span>Termin decyzji</span>';
        $html .= '<strong>' . Tools::safeOutput($this->formatAllegroDate($decisionDueDate)) . '</strong>';
        $html .= '</div>';
        $html .= '</div>';
        $html .= $this->renderClaimProgressBar('aar-claim-progress', $timeMeta);
        $html .= '</div>';

        $orderProductRows = $this->buildIssueOrderProductRows($checkoutFormId, $offerId, $offerQuantity, $productId, $linkedOrder);

        $html .= '<div class="aar-claim-grid">';
        $html .= $this->renderCheckoutBuyerDeliveryCard($checkoutFormId, $buyerLogin);
        $html .= $this->renderClaimInfoCard('Zamówienie i produkt', $orderProductRows);
        $html .= $this->renderClaimInfoCard('Powód reklamacji', [
            'Typ powodu' => $this->formatIssueReasonType($reasonType),
            'Temat' => $this->buildIssueSubject($issue),
        ], $reasonDescription);
        $timingRows = [
            'Oczekiwane rozwiązanie' => $expectations,
        ];
        $orderDate = $this->resolveOrderDateByCheckoutForm($checkoutFormId);
        $orderDateLabel = $this->formatPrestashopOrderDateWithAge($orderDate);
        if ($orderDateLabel !== '') {
            $timingRows['Data zamówienia'] = $orderDateLabel;
        }
        $timingRows['Otwarcie reklamacji'] = $this->formatIssueOpenDateSinceOrder($openedDate, $orderDate);
        $timingRows['Termin decyzji'] = $this->formatAllegroDate($decisionDueDate);
        if ($decisionResolvedAt !== '') {
            $timingRows['Rozpatrzono'] = $this->formatAllegroDate($decisionResolvedAt);
        }
        $html .= $this->renderClaimInfoCard('Oczekiwania i terminy', $timingRows);
        $html .= '</div>';
        $html .= '</div>';

        return $html;
    }

    protected function renderIssueOrderSummaryPanel(array $issue, array $messages = []): string
    {
        $checkoutFormIds = $this->extractCheckoutFormIdsFromPayload($issue);
        foreach ($messages as $message) {
            if (is_array($message)) {
                $checkoutFormIds = array_merge($checkoutFormIds, $this->extractCheckoutFormIdsFromPayload($message));
            }
        }

        $checkoutFormIds = array_values(array_unique(array_filter(array_map('strval', $checkoutFormIds))));
        $checkoutFormId = $checkoutFormIds[0] ?? '';
        $offerId = (string) ($issue['offer']['id'] ?? '');
        $offerQuantity = (string) ($issue['offer']['quantity'] ?? '');
        $productId = (string) ($issue['product']['id'] ?? '');
        $linkedOrder = $this->resolvePrestashopOrderLink($issue, $messages);
        $rows = $this->buildIssueOrderProductRows($checkoutFormId, $offerId, $offerQuantity, $productId, $linkedOrder);

        if (!$rows) {
            return '';
        }

        $html = '<div class="aar-claim-summary aar-issue-order-summary">';
        $html .= $this->renderClaimInfoCard('Zamówienie i produkt', $rows);
        $html .= '</div>';

        return $html;
    }

    protected function renderCustomerReturnDecisionPanel(string $returnId, array $return, string $total = ''): string
    {
        if ($returnId === '') {
            return '';
        }

        $refundModalId = $this->buildCustomerReturnRefundModalId($returnId);
        $rejectionModalId = $this->buildCustomerReturnRejectionModalId($returnId);
        $html = '<div class="aar-return-decision-panel">';
        $html .= '<div class="aar-return-decision-panel-head">';
        $html .= '<div class="btn-group aar-return-decision-dropdown">';
        $html .= '<button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Decyzja zwrotowa <span class="caret"></span></button>';
        $html .= '<ul class="dropdown-menu aar-return-decision-menu">';
        if ($this->canRefundCustomerReturn($return)) {
            $html .= '<li><a href="#" data-toggle="modal" data-target="#' . Tools::safeOutput($refundModalId) . '">Zwróć wybraną kwotę</a></li>';
        } else {
            $html .= '<li class="disabled"><a href="#" tabindex="-1">Zwróć wybraną kwotę</a></li>';
        }
        if ($this->canRejectCustomerReturn($return)) {
            $html .= '<li><a href="#" data-toggle="modal" data-target="#' . Tools::safeOutput($rejectionModalId) . '">Odmowa zwrotu pieniędzy</a></li>';
        } else {
            $html .= '<li class="disabled"><a href="#" tabindex="-1">Odmowa zwrotu pieniędzy</a></li>';
        }
        $html .= '</ul>';
        $html .= '</div>';
        if ($total !== '') {
            $html .= '<div class="aar-return-decision-total"><span>Razem</span><strong>' . Tools::safeOutput($total) . '</strong></div>';
        }
        $html .= '</div>';
        $html .= '</div>';
        $html .= $this->renderCustomerReturnRefundModal($returnId, $return);
        $html .= $this->renderCustomerReturnRejectionModal($returnId, $return);

        return $html;
    }

    protected function canRefundCustomerReturn(array $return): bool
    {
        if (is_array($return['rejection'] ?? null)) {
            return false;
        }

        $status = mb_strtoupper(trim((string) ($return['status'] ?? '')));
        if (in_array($status, ['FINISHED', 'FINISHED_APT', 'REJECTED', 'COMMISSION_REFUNDED'], true)) {
            return false;
        }

        foreach (($return['items'] ?? []) as $item) {
            if (!is_array($item)) {
                continue;
            }

            if (trim((string) ($item['offerId'] ?? '')) !== '' && $this->calculateCustomerReturnItemAmount($item) > 0) {
                return true;
            }
        }

        return false;
    }

    protected function canRejectCustomerReturn(array $return): bool
    {
        if (is_array($return['rejection'] ?? null)) {
            return false;
        }

        $status = mb_strtoupper(trim((string) ($return['status'] ?? '')));

        return !in_array($status, ['FINISHED', 'FINISHED_APT', 'REJECTED'], true);
    }

    protected function renderCustomerReturnSummaryPanel(array $return): string
    {
        $buyerProfile = $this->getCustomerReturnBuyerProfile($return);
        $buyerName = $buyerProfile['name'];
        $buyerLogin = $buyerProfile['login'];
        $buyerEmail = $buyerProfile['email'];
        $buyerPhone = $buyerProfile['phone'];
        $deliveryMethod = $this->getCustomerReturnDeliveryMethod($return);
        $deliveryWaybill = $this->getCustomerReturnWaybill($return);
        $returnAddress = $this->getCustomerReturnAddressLines($return);
        $refundLines = $this->getCustomerReturnRefundLines($return);
        $itemsBody = $this->renderCustomerReturnItems($return);
        $total = $this->calculateCustomerReturnTotal($return);

        $html = '<div class="aar-claim-summary aar-return-summary">';
        if ($itemsBody !== '') {
            $html .= '<div class="aar-return-products">' . $itemsBody . '</div>';
        }
        $html .= '<div class="aar-return-simple-grid">';
        $html .= '<section class="aar-return-simple-section aar-return-status-section">';
        $html .= '<h5>Status zwrotu towaru</h5>';
        $html .= $this->renderCustomerReturnTimeline($return);
        $html .= '</section>';

        $html .= '<section class="aar-return-simple-section">';
        $html .= '<h5>Dane kupującego</h5>';
        if ($buyerName !== '') {
            $html .= '<div>' . Tools::safeOutput($buyerName) . '</div>';
        }
        if ($buyerLogin !== '') {
            $html .= '<div>login: ' . Tools::safeOutput($buyerLogin) . '</div>';
        }
        if ($buyerEmail !== '') {
            $html .= '<div><a href="mailto:' . Tools::safeOutput($buyerEmail) . '">' . Tools::safeOutput($buyerEmail) . '</a></div>';
        }
        if ($buyerPhone !== '') {
            $html .= '<div>tel. ' . Tools::safeOutput($this->formatPhoneNumber($buyerPhone)) . '</div>';
        }
        $html .= '<div><span class="aar-return-invoice-flag ' . ($this->customerReturnHasInvoice($return) ? 'is-invoice' : 'is-no-invoice') . '">' . ($this->customerReturnHasInvoice($return) ? 'FAKTURA' : 'BEZ FAKTURY') . '</span></div>';
        $html .= '</section>';

        $html .= '<section class="aar-return-simple-section">';
        $html .= '<h5>Metoda dostawy</h5>';
        if ($deliveryMethod !== '') {
            $html .= '<div>' . Tools::safeOutput($deliveryMethod) . '</div>';
        }
        if ($deliveryWaybill !== '') {
            if ($this->shouldUseCustomerReturnTrackingModal($return)) {
                $trackingModalId = $this->buildCustomerReturnTrackingModalId((string) ($return['id'] ?? ''), $deliveryWaybill);
                $html .= '<div><button type="button" class="btn btn-link aar-return-tracking-link" data-toggle="modal" data-target="#' . Tools::safeOutput($trackingModalId) . '">' . Tools::safeOutput($deliveryWaybill) . '</button></div>';
            } else {
                $trackingUrl = $this->getCustomerReturnTrackingUrl($return);
                if ($trackingUrl !== '') {
                    $html .= '<div><a href="' . Tools::safeOutput($trackingUrl) . '" target="_blank" rel="noopener noreferrer">' . Tools::safeOutput($deliveryWaybill) . '</a></div>';
                } else {
                    $html .= '<div>' . Tools::safeOutput($deliveryWaybill) . '</div>';
                }
            }
        }
        if ($returnAddress) {
            $html .= '<h5 class="aar-return-subheading">Adres zwrotu</h5>';
            foreach ($returnAddress as $line) {
                $html .= '<div>' . Tools::safeOutput($line) . '</div>';
            }
        }
        $html .= '</section>';

        $html .= '<section class="aar-return-simple-section aar-return-refund-section">';
        $html .= '<h5>Zwrot środków</h5>';
        if ($refundLines) {
            foreach ($refundLines as $index => $line) {
                $lineClass = $index === 0 ? ' class="aar-return-refund-account"' : '';
                $html .= '<div' . $lineClass . '>' . Tools::safeOutput($line) . '</div>';
            }
        } else {
            $html .= '<div class="text-muted">Brak danych do zwrotu środków w danych Allegro.</div>';
        }
        $html .= '</section>';
        $html .= '</div>';
        $html .= '</div>';

        return $html;
    }

    protected function renderCustomerReturnDiagnosticsPanel(string $returnId, array $selectedReturn, array $selectedReturnRaw = []): string
    {
        if ($returnId === '') {
            return '';
        }

        $debugUrl = $this->getReturnsAdminUrl(['return_id' => $returnId, 'aar_debug_return' => 1]);
        $modalId = $this->buildCustomerReturnDebugModalId($returnId);
        $payload = [
            'selected_return_id' => $returnId,
            'api_response' => $selectedReturnRaw ?: $selectedReturn,
            'enriched_response' => $selectedReturn,
        ];

        $html = '<div class="modal fade aar-return-debug-modal" id="' . Tools::safeOutput($modalId) . '" tabindex="-1" role="dialog" aria-labelledby="' . Tools::safeOutput($modalId . '-title') . '">';
        $html .= '<div class="modal-dialog modal-lg" role="document">';
        $html .= '<div class="modal-content">';
        $html .= '<div class="modal-header">';
        $html .= '<button type="button" class="close" data-dismiss="modal" aria-label="Zamknij"><span aria-hidden="true">&times;</span></button>';
        $html .= '<h4 class="modal-title" id="' . Tools::safeOutput($modalId . '-title') . '">Diagnostyka API zwrotu</h4>';
        $html .= '</div>';
        $html .= '<div class="modal-body">';
        $html .= '<div class="aar-return-debug-head">';
        $html .= '<a class="btn btn-default btn-sm" href="' . Tools::safeOutput($debugUrl) . '">Odśwież debug</a>';
        $html .= '</div>';
        $html .= '<pre class="aar-return-debug-json">' . Tools::safeOutput(json_encode($payload, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)) . '</pre>';
        $html .= '</div>';
        $html .= '<div class="modal-footer">';
        $html .= '<button type="button" class="btn btn-default" data-dismiss="modal">Zamknij</button>';
        $html .= '</div>';
        $html .= '</div>';
        $html .= '</div>';
        $html .= '</div>';

        return $html;
    }

    protected function renderCustomerReturnTrackingModal(string $returnId, array $return): string
    {
        $waybill = $this->getCustomerReturnWaybill($return);
        if ($returnId === '' || $waybill === '' || !$this->shouldUseCustomerReturnTrackingModal($return)) {
            return '';
        }

        $modalId = $this->buildCustomerReturnTrackingModalId($returnId, $waybill);
        $trackingEntry = $this->findCustomerReturnTrackingEntry($return, $waybill);
        $statuses = is_array($trackingEntry['trackingDetails']['statuses'] ?? null) ? $trackingEntry['trackingDetails']['statuses'] : [];
        $externalUrl = $this->getCustomerReturnTrackingUrl($return);

        $html = '<div class="modal fade aar-return-tracking-modal" id="' . Tools::safeOutput($modalId) . '" tabindex="-1" role="dialog" aria-labelledby="' . Tools::safeOutput($modalId . '-title') . '">';
        $html .= '<div class="modal-dialog modal-lg" role="document">';
        $html .= '<div class="modal-content">';
        $carrierName = $this->getCustomerReturnDeliveryMethod($return);
        $html .= '<div class="modal-header aar-return-tracking-header">';
        $html .= '<div class="aar-return-tracking-header-main">';
        $html .= '<h4 class="modal-title" id="' . Tools::safeOutput($modalId . '-title') . '">Tracking przesyłki</h4>';
        $html .= '<div class="aar-return-tracking-header-meta">';
        $html .= '<strong>' . Tools::safeOutput($waybill) . '</strong>';
        if ($carrierName !== '') {
            $html .= '<span>' . Tools::safeOutput($carrierName) . '</span>';
        }
        $html .= '</div>';
        $html .= '</div>';
        $html .= '<button type="button" class="close" data-dismiss="modal" aria-label="Zamknij"><span aria-hidden="true">&times;</span></button>';
        $html .= '</div>';
        $html .= '<div class="modal-body">';

        if ($statuses) {
            $html .= '<div class="aar-return-tracking-timeline" aria-label="Historia trackingu przesyłki">';
            $totalStatuses = count($statuses);
            foreach ($statuses as $index => $status) {
                if (!is_array($status)) {
                    continue;
                }

                $occurredAt = $this->formatAllegroDate((string) ($status['occurredAt'] ?? $status['createdAt'] ?? ''));
                $description = trim((string) ($status['description'] ?? ''));
                $code = trim((string) ($status['code'] ?? ''));
                $translatedDescription = $this->translateCustomerReturnTrackingDescription($code, $description);
                $classes = ['aar-return-tracking-step', 'is-completed'];
                if ($index === $totalStatuses - 1) {
                    $classes[] = 'is-active';
                }
                if ($index < $totalStatuses - 1) {
                    $classes[] = 'has-next-completed';
                }

                $html .= '<div class="' . Tools::safeOutput(implode(' ', $classes)) . '">';
                $html .= '<div class="aar-return-tracking-marker"></div>';
                $html .= '<div class="aar-return-tracking-label">' . Tools::safeOutput($translatedDescription !== '' ? $translatedDescription : $this->formatCustomerReturnTrackingCode($code)) . '</div>';
                if ($occurredAt !== '') {
                    $html .= '<div class="aar-return-tracking-date">' . Tools::safeOutput($occurredAt) . '</div>';
                }
                if ($code !== '' && $translatedDescription !== '' && $translatedDescription !== $code) {
                    $html .= '<div class="aar-return-tracking-code">' . Tools::safeOutput($this->formatCustomerReturnTrackingCode($code)) . '</div>';
                } elseif ($description !== '' && $translatedDescription === '') {
                    $html .= '<div class="aar-return-tracking-code">' . Tools::safeOutput($description) . '</div>';
                }
                $html .= '</div>';
            }
            $html .= '</div>';
        } else {
            $html .= '<div class="alert alert-info">API Allegro nie zwróciło historii statusów dla tej przesyłki.</div>';
        }

        $html .= '</div>';
        $html .= '<div class="modal-footer">';
        if ($externalUrl !== '') {
            $html .= '<a class="btn btn-primary aar-return-tracking-external-button" href="' . Tools::safeOutput($externalUrl) . '" target="_blank" rel="noopener noreferrer">Śledź na stronie przewoźnika</a>';
        }
        $html .= '<button type="button" class="btn btn-default" data-dismiss="modal">Zamknij</button>';
        $html .= '</div>';
        $html .= '</div>';
        $html .= '</div>';
        $html .= '</div>';

        return $html;
    }

    protected function buildCustomerReturnDebugModalId(string $returnId): string
    {
        return 'aar-return-debug-' . preg_replace('/[^a-zA-Z0-9_-]/', '-', $returnId);
    }

    protected function buildCustomerReturnTrackingModalId(string $returnId, string $waybill): string
    {
        return 'aar-return-tracking-' . preg_replace('/[^a-zA-Z0-9_-]/', '-', $returnId . '-' . $waybill);
    }

    protected function renderCustomerReturnTimeline(array $return): string
    {
        $steps = $this->buildCustomerReturnTimelineSteps($return);
        if (!$steps) {
            return '';
        }

        $html = '<div class="aar-return-timeline" aria-label="Status zwrotu towaru">';
        foreach ($steps as $step) {
            $classes = ['aar-return-timeline-step'];
            if (!empty($step['completed'])) {
                $classes[] = 'is-completed';
            }
            if (!empty($step['active'])) {
                $classes[] = 'is-active';
            }
            if (!empty($step['next_completed'])) {
                $classes[] = 'has-next-completed';
            }

            $html .= '<div class="' . Tools::safeOutput(implode(' ', $classes)) . '">';
            $html .= '<div class="aar-return-timeline-marker"></div>';
            $html .= '<div class="aar-return-timeline-label">' . Tools::safeOutput((string) ($step['label'] ?? '')) . '</div>';
            if (trim((string) ($step['date'] ?? '')) !== '') {
                $html .= '<div class="aar-return-timeline-date">' . Tools::safeOutput($this->formatAllegroDate((string) $step['date'])) . '</div>';
            }
            $html .= '</div>';
        }
        $html .= '</div>';
        $returnId = trim((string) ($return['id'] ?? ''));
        if ($returnId !== '') {
            $modalId = $this->buildCustomerReturnDebugModalId($returnId);
            $html .= '<div class="aar-return-debug-link-wrap"><button type="button" class="btn btn-link aar-return-debug-link" data-toggle="modal" data-target="#' . Tools::safeOutput($modalId) . '">Pokaż API</button></div>';
        }

        return $html;
    }

    protected function buildCustomerReturnTimelineSteps(array $return): array
    {
        $status = mb_strtoupper(trim((string) ($return['status'] ?? '')));
        $isOwnShipping = $this->isCustomerReturnOwnShipping($return);
        $statusOrder = [
            'CREATED' => 0,
            'DISPATCHED' => 1,
            'IN_TRANSIT' => 2,
            'DELIVERED' => 3,
            'WAREHOUSE_DELIVERED' => 3,
            'WAREHOUSE_VERIFICATION' => 3,
            'FINISHED' => 4,
            'FINISHED_APT' => 4,
            'COMMISSION_REFUND_CLAIMED' => 4,
            'COMMISSION_REFUNDED' => 5,
        ];
        $activeIndex = $statusOrder[$status] ?? 0;
        $isRejected = $status === 'REJECTED' || is_array($return['rejection'] ?? null);

        $dates = [
            'CREATED' => (string) ($return['createdAt'] ?? ''),
            'DISPATCHED' => $this->findCustomerReturnDate($return, ['DISPATCHED', 'SENT']),
            'IN_TRANSIT' => $this->findCustomerReturnDate($return, ['IN_TRANSIT']),
            'DELIVERED' => $this->findCustomerReturnDate($return, ['DELIVERED', 'WAREHOUSE_DELIVERED', 'WAREHOUSE_VERIFICATION']),
            'FINISHED' => $this->findCustomerReturnDate($return, ['FINISHED', 'FINISHED_APT']),
            'COMMISSION_REFUNDED' => $this->findCustomerReturnDate($return, ['COMMISSION_REFUNDED']),
        ];

        if ($dates['IN_TRANSIT'] === '') {
            $dates['IN_TRANSIT'] = $this->findCustomerReturnTrackingDate($return, ['IN_TRANSIT', 'RELEASED_FOR_DELIVERY', 'AVAILABLE_FOR_PICKUP']);
        }
        if ($dates['DISPATCHED'] === '') {
            $dates['DISPATCHED'] = $this->findCustomerReturnTrackingDispatchDate($return);
        }
        if ($dates['DELIVERED'] === '') {
            $dates['DELIVERED'] = $this->findCustomerReturnTrackingDate($return, ['DELIVERED']);
        }
        if ($dates['DELIVERED'] === '') {
            $dates['DELIVERED'] = $this->findFirstParcelDate($return, ['deliveredAt', 'receivedAt']);
        }
        if ($isRejected && is_array($return['rejection'] ?? null)) {
            $dates['FINISHED'] = (string) ($return['rejection']['createdAt'] ?? $dates['FINISHED']);
        }
        if (
            $dates['FINISHED'] === ''
            && (
                in_array($status, ['FINISHED', 'FINISHED_APT', 'COMMISSION_REFUNDED'], true)
                || is_array($return['refund'] ?? null)
            )
        ) {
            $dates['FINISHED'] = $this->findCustomerReturnDateByPathHints($return, [
                'refund',
                'refunded',
                'payment',
                'moneyback',
                'money_back',
                'finished',
                'finish',
            ], [
                'commission',
                'rebate',
                'tracking',
                'parcel',
                'waybill',
                '_checkout_form',
                'checkout_form',
            ]);
        }
        if (
            $dates['FINISHED'] === ''
            && in_array($status, ['FINISHED', 'FINISHED_APT', 'COMMISSION_REFUNDED'], true)
        ) {
            $dates['FINISHED'] = $this->findCustomerReturnDateFromListItem($return, [
                'FINISHED',
                'FINISHED_APT',
                'COMMISSION_REFUNDED',
            ], [
                'refund',
                'refunded',
                'payment',
                'moneyback',
                'money_back',
                'finished',
                'finish',
                'updated',
                'status',
                'change',
            ], [
                'commission',
                'rebate',
                'tracking',
                'parcel',
                'waybill',
                '_checkout_form',
                'checkout_form',
            ]);
        }
        if ($dates['COMMISSION_REFUNDED'] === '' && $status === 'COMMISSION_REFUNDED') {
            $dates['COMMISSION_REFUNDED'] = $this->findCustomerReturnDateByPathHints($return, [
                'commission',
                'rebate',
                'transactionrebate',
                'transaction_rebate',
                'refundclaim',
                'refund_claim',
                'commissionrefunded',
                'commission_refunded',
            ]);
        }
        if ($dates['COMMISSION_REFUNDED'] === '' && $status === 'COMMISSION_REFUNDED') {
            $dates['COMMISSION_REFUNDED'] = $this->findCustomerReturnDateFromListItem($return, [
                'COMMISSION_REFUNDED',
            ], [
                'commission',
                'rebate',
                'transactionrebate',
                'transaction_rebate',
                'refundclaim',
                'refund_claim',
                'commissionrefunded',
                'commission_refunded',
                'updated',
                'status',
                'change',
            ]);
        }

        if ($isOwnShipping) {
            $definitions = [
                ['status' => 'CREATED', 'label' => 'Zwrot zgłoszony'],
                ['status' => 'FINISHED', 'label' => $isRejected ? 'Zwrot odrzucony' : 'Zwrot wpłaty'],
                ['status' => 'COMMISSION_REFUNDED', 'label' => 'Zwrot prowizji'],
            ];
        } else {
            $definitions = [
                ['status' => 'CREATED', 'label' => 'Zwrot zgłoszony'],
                ['status' => 'DISPATCHED', 'label' => 'Nadany'],
                ['status' => 'IN_TRANSIT', 'label' => 'W drodze'],
                ['status' => 'DELIVERED', 'label' => 'Doręczony'],
                ['status' => 'FINISHED', 'label' => $isRejected ? 'Zwrot odrzucony' : 'Zwrot wpłaty'],
                ['status' => 'COMMISSION_REFUNDED', 'label' => 'Zwrot prowizji'],
            ];
        }

        $steps = [];
        foreach ($definitions as $index => $definition) {
            $stepStatus = (string) $definition['status'];
            $date = trim((string) ($dates[$stepStatus] ?? ''));
            $completed = $date !== '';
            if ($isRejected && $index > 4) {
                $completed = false;
            }
            if ($stepStatus === 'FINISHED' && !in_array($status, ['FINISHED', 'FINISHED_APT', 'COMMISSION_REFUNDED'], true)) {
                $completed = false;
                $date = '';
            }
            $nextDefinition = $definitions[$index + 1] ?? null;
            $nextStatus = is_array($nextDefinition) ? (string) ($nextDefinition['status'] ?? '') : '';
            $nextDate = $nextStatus !== '' ? trim((string) ($dates[$nextStatus] ?? '')) : '';
            $nextCompleted = $nextStatus !== '' && $nextDate !== '';
            $lineCompleted = $completed && $nextCompleted;
            if ($isRejected && $index + 1 > 4) {
                $lineCompleted = false;
            }

            $steps[] = [
                'label' => (string) $definition['label'],
                'date' => $date,
                'completed' => $completed,
                'next_completed' => $lineCompleted,
                'active' => $index === $activeIndex || ($isRejected && $index === 4),
            ];
        }

        return $steps;
    }

    protected function findCustomerReturnDateFromListItem(array $return, array $statuses, array $includeHints = [], array $excludeHints = []): string
    {
        $listItem = is_array($return['_list_item'] ?? null) ? $return['_list_item'] : [];
        if (!$listItem) {
            return '';
        }

        $date = $this->findCustomerReturnDate($listItem, $statuses);
        if ($date !== '') {
            return $date;
        }

        if ($includeHints) {
            $date = $this->findCustomerReturnDateByPathHints($listItem, $includeHints, $excludeHints);
            if ($date !== '') {
                return $date;
            }
        }

        foreach (['statusChangedAt', 'statusUpdatedAt', 'updatedAt'] as $fallbackField) {
            $candidate = trim((string) ($listItem[$fallbackField] ?? ''));
            if ($candidate !== '' && strtotime($candidate) !== false) {
                return $candidate;
            }
        }

        return '';
    }

    protected function isCustomerReturnOwnShipping(array $return): bool
    {
        $hasTracking = !empty($return['_tracking']);
        $hasAnyParcel = false;
        $hasCarrierOrWaybill = false;

        foreach (($return['parcels'] ?? []) as $parcel) {
            if (!is_array($parcel)) {
                continue;
            }

            $hasAnyParcel = true;
            $carrierId = trim((string) $this->firstNonEmptyString([
                $parcel['carrierId'] ?? null,
                $parcel['transportingCarrierId'] ?? null,
                $parcel['truckingCarrierId'] ?? null,
            ]));
            $waybill = trim((string) $this->firstNonEmptyString([
                $parcel['waybill'] ?? null,
                $parcel['transportingWaybill'] ?? null,
                $parcel['truckingWaybill'] ?? null,
            ]));

            if ($carrierId !== '' || $waybill !== '') {
                $hasCarrierOrWaybill = true;
                break;
            }
        }

        return $hasAnyParcel && !$hasCarrierOrWaybill && !$hasTracking;
    }

    protected function enrichCustomerReturnWithTracking(AllegroApiClient $apiClient, array $return): array
    {
        $requests = [];
        foreach (($return['parcels'] ?? []) as $parcel) {
            if (!is_array($parcel)) {
                continue;
            }

            $trackingPairs = [
                [
                    'carrier_id' => trim((string) $this->firstNonEmptyString([
                        $parcel['transportingCarrierId'] ?? null,
                        $parcel['truckingCarrierId'] ?? null,
                    ])),
                    'waybill' => trim((string) $this->firstNonEmptyString([
                        $parcel['transportingWaybill'] ?? null,
                        $parcel['truckingWaybill'] ?? null,
                    ])),
                ],
                [
                    'carrier_id' => trim((string) ($parcel['carrierId'] ?? '')),
                    'waybill' => trim((string) ($parcel['waybill'] ?? '')),
                ],
            ];

            foreach ($trackingPairs as $pair) {
                $carrierId = trim((string) ($pair['carrier_id'] ?? ''));
                $waybill = trim((string) ($pair['waybill'] ?? ''));
                if ($carrierId === '' || $waybill === '') {
                    continue;
                }

                $requests[$carrierId][$waybill] = true;
            }
        }

        if (!$requests) {
            return $return;
        }

        $tracking = [];
        foreach ($requests as $carrierId => $waybillMap) {
            try {
                $response = $apiClient->getCarrierTracking((string) $carrierId, array_keys($waybillMap));
                if ($response) {
                    $tracking[] = $response;
                }
            } catch (Throwable $e) {
                PrestaShopLogger::addLog('[AAR] Customer return tracking fetch failed for carrier ' . $carrierId . ': ' . $e->getMessage(), 2);
            }
        }

        if ($tracking) {
            $return['_tracking'] = $tracking;
        }

        return $return;
    }

    protected function enrichCustomerReturnWithCheckoutForm(AllegroApiClient $apiClient, array $return): array
    {
        $checkoutFormId = trim((string) ($return['orderId'] ?? ''));
        if ($checkoutFormId === '') {
            return $return;
        }

        try {
            $checkoutForm = $apiClient->getCheckoutForm($checkoutFormId);
            if (is_array($checkoutForm) && $checkoutForm) {
                $return['_checkout_form'] = $checkoutForm;

                return $return;
            }
        } catch (Throwable $e) {
            PrestaShopLogger::addLog('[AAR] Customer return checkout form fetch failed for ' . $checkoutFormId . ': ' . $e->getMessage(), 2);
        }

        $storedCheckoutForm = $this->getStoredCheckoutFormContent($checkoutFormId);
        if ($storedCheckoutForm) {
            $return['_checkout_form'] = $storedCheckoutForm;
        }

        return $return;
    }

    protected function getCustomerReturnBuyerProfile(array $return): array
    {
        $checkoutForm = is_array($return['_checkout_form'] ?? null) ? $return['_checkout_form'] : [];
        $buyer = is_array($checkoutForm['buyer'] ?? null) ? $checkoutForm['buyer'] : [];
        $deliveryAddress = is_array($checkoutForm['delivery']['address'] ?? null) ? $checkoutForm['delivery']['address'] : [];
        $invoiceAddress = is_array($checkoutForm['invoice']['address'] ?? null) ? $checkoutForm['invoice']['address'] : [];

        $name = $this->firstNonEmptyString([
            $buyer['name'] ?? null,
            $this->joinNameParts($buyer),
            $buyer['companyName'] ?? null,
            $this->joinNameParts($invoiceAddress),
            $invoiceAddress['name'] ?? null,
            $invoiceAddress['companyName'] ?? null,
            $this->joinNameParts($deliveryAddress),
            $deliveryAddress['name'] ?? null,
            $deliveryAddress['companyName'] ?? null,
            $this->getCustomerReturnBuyerName($return),
        ]);
        $login = $this->firstNonEmptyString([
            $buyer['login'] ?? null,
            $buyer['userName'] ?? null,
            $return['buyer']['login'] ?? null,
        ]);
        $email = $this->firstNonEmptyString([
            $buyer['email'] ?? null,
            $return['buyer']['email'] ?? null,
        ]);
        $phone = $this->firstNonEmptyString([
            $buyer['phoneNumber'] ?? null,
            $buyer['phone'] ?? null,
            $invoiceAddress['phoneNumber'] ?? null,
            $invoiceAddress['phone'] ?? null,
            $deliveryAddress['phoneNumber'] ?? null,
            $deliveryAddress['phone'] ?? null,
            $this->getCustomerReturnBuyerPhone($return),
        ]);

        return [
            'name' => trim((string) $name),
            'login' => trim((string) $login),
            'email' => trim((string) $email),
            'phone' => trim((string) $phone),
        ];
    }

    protected function customerReturnHasInvoice(array $return): bool
    {
        $checkoutForm = is_array($return['_checkout_form'] ?? null) ? $return['_checkout_form'] : [];
        $invoice = is_array($checkoutForm['invoice'] ?? null) ? $checkoutForm['invoice'] : [];
        if (!$invoice) {
            return false;
        }

        if (array_key_exists('required', $invoice)) {
            return (bool) $invoice['required'];
        }

        $invoiceAddress = is_array($invoice['address'] ?? null) ? $invoice['address'] : [];
        $invoiceCompany = is_array($invoice['company'] ?? null) ? $invoice['company'] : [];
        $invoiceFields = [
            $invoice['taxId'] ?? null,
            $invoice['vatNumber'] ?? null,
            $invoice['vatId'] ?? null,
            $invoice['companyName'] ?? null,
            $invoiceAddress['companyName'] ?? null,
            $invoiceAddress['taxId'] ?? null,
            $invoiceAddress['vatNumber'] ?? null,
            $invoiceAddress['vatId'] ?? null,
            $invoiceCompany['name'] ?? null,
            $invoiceCompany['taxId'] ?? null,
            $invoiceCompany['vatNumber'] ?? null,
            $invoiceAddress['street'] ?? null,
            $invoiceAddress['addressLine1'] ?? null,
            $invoiceAddress['city'] ?? null,
            $invoiceAddress['zipCode'] ?? null,
            $invoiceAddress['postCode'] ?? null,
            $this->joinNameParts($invoiceAddress),
        ];

        foreach ($invoiceFields as $field) {
            if (trim((string) $field) !== '') {
                return true;
            }
        }

        return false;
    }

    protected function findCustomerReturnTrackingDate(array $return, array $codes): string
    {
        $codes = array_map('mb_strtoupper', $codes);
        $latestMatch = '';
        foreach (($return['_tracking'] ?? []) as $trackingResponse) {
            if (!is_array($trackingResponse)) {
                continue;
            }

            foreach (($trackingResponse['waybills'] ?? []) as $waybill) {
                if (!is_array($waybill)) {
                    continue;
                }

                $statuses = $waybill['trackingDetails']['statuses'] ?? [];
                if (!is_array($statuses)) {
                    continue;
                }

                foreach ($statuses as $status) {
                    if (!is_array($status)) {
                        continue;
                    }

                    $code = mb_strtoupper(trim((string) ($status['code'] ?? '')));
                    if (!in_array($code, $codes, true)) {
                        continue;
                    }

                    $date = trim((string) ($status['occurredAt'] ?? $status['createdAt'] ?? ''));
                    if ($date === '') {
                        continue;
                    }

                    if ($latestMatch === '' || (strtotime($date) ?: 0) > (strtotime($latestMatch) ?: 0)) {
                        $latestMatch = $date;
                    }
                }
            }
        }

        return $latestMatch;
    }

    protected function findCustomerReturnTrackingDispatchDate(array $return): string
    {
        foreach (($return['_tracking'] ?? []) as $trackingResponse) {
            if (!is_array($trackingResponse)) {
                continue;
            }

            foreach (($trackingResponse['waybills'] ?? []) as $waybill) {
                if (!is_array($waybill)) {
                    continue;
                }

                $statuses = $waybill['trackingDetails']['statuses'] ?? [];
                if (!is_array($statuses)) {
                    continue;
                }

                $seenPending = false;
                foreach ($statuses as $status) {
                    if (!is_array($status)) {
                        continue;
                    }

                    $code = mb_strtoupper(trim((string) ($status['code'] ?? '')));
                    $date = trim((string) ($status['occurredAt'] ?? $status['createdAt'] ?? ''));
                    if ($code === 'PENDING') {
                        $seenPending = true;
                        continue;
                    }

                    if ($code === 'IN_TRANSIT' && $date !== '' && $seenPending) {
                        return $date;
                    }
                }
            }
        }

        return '';
    }

    protected function findCustomerReturnDate(array $return, array $statuses): string
    {
        $statuses = array_map('mb_strtoupper', $statuses);
        $dates = $this->collectCustomerReturnStatusDates($return, $statuses);
        if (!$dates) {
            return '';
        }

        usort($dates, function (string $a, string $b): int {
            return (strtotime($b) ?: 0) <=> (strtotime($a) ?: 0);
        });

        return $dates[0];
    }

    protected function collectCustomerReturnStatusDates($value, array $statuses, string $path = '', int $depth = 0): array
    {
        if ($depth > 10) {
            return [];
        }

        if (!is_array($value)) {
            return [];
        }

        $containerHints = ['timeline', 'history', 'events', 'statushistory', 'statuses', 'statuseslist'];
        $pathLower = mb_strtolower($path);
        $isStatusContainer = $pathLower === '';
        foreach ($containerHints as $hint) {
            if ($hint !== '' && strpos($pathLower, $hint) !== false) {
                $isStatusContainer = true;
                break;
            }
        }

        $statusFields = ['status', 'statusCode', 'code', 'type', 'name', 'label', 'title', 'action', 'state', 'step'];
        $dateFields = ['createdAt', 'date', 'occurredAt', 'updatedAt', 'finishedAt', 'deliveredAt', 'sentAt', 'dispatchedAt'];
        $dates = [];

        if ($isStatusContainer) {
            $currentStatus = '';
            foreach ($statusFields as $field) {
                if (!array_key_exists($field, $value)) {
                    continue;
                }

                $candidate = mb_strtoupper(trim($this->firstNonEmptyString([$value[$field] ?? null])));
                if ($candidate !== '') {
                    $currentStatus = $candidate;
                    break;
                }
            }

            if ($currentStatus !== '' && in_array($currentStatus, $statuses, true)) {
                foreach ($dateFields as $field) {
                    if (!array_key_exists($field, $value)) {
                        continue;
                    }

                    $candidate = trim((string) ($value[$field] ?? ''));
                    if ($candidate !== '' && strtotime($candidate) !== false) {
                        $dates[] = $candidate;
                    }
                }
            }
        }

        foreach ($value as $key => $child) {
            $childPath = $path === '' ? (string) $key : $path . '.' . (string) $key;
            if (is_array($child)) {
                $dates = array_merge($dates, $this->collectCustomerReturnStatusDates($child, $statuses, $childPath, $depth + 1));
            }
        }

        return $dates;
    }

    protected function findCustomerReturnDateByPathHints(array $payload, array $includeHints, array $excludeHints = []): string
    {
        $includeHints = array_map('mb_strtolower', $includeHints);
        $excludeHints = array_map('mb_strtolower', $excludeHints);
        $dates = $this->collectCustomerReturnDatesByPathHints($payload, $includeHints, $excludeHints);
        if (!$dates) {
            return '';
        }

        usort($dates, function (string $a, string $b): int {
            return (strtotime($b) ?: 0) <=> (strtotime($a) ?: 0);
        });

        return $dates[0];
    }

    protected function collectCustomerReturnDatesByPathHints($value, array $includeHints, array $excludeHints, string $path = '', int $depth = 0): array
    {
        if ($depth > 8) {
            return [];
        }

        $pathLower = mb_strtolower($path);
        foreach ($excludeHints as $hint) {
            if ($hint !== '' && strpos($pathLower, $hint) !== false) {
                return [];
            }
        }

        $hasIncludeHint = false;
        foreach ($includeHints as $hint) {
            if ($hint !== '' && strpos($pathLower, $hint) !== false) {
                $hasIncludeHint = true;
                break;
            }
        }

        if (is_scalar($value)) {
            $candidate = trim((string) $value);
            if ($hasIncludeHint && $candidate !== '' && strtotime($candidate) !== false && preg_match('/\\d{4}-\\d{2}-\\d{2}/', $candidate)) {
                return [$candidate];
            }

            return [];
        }

        if (!is_array($value)) {
            return [];
        }

        $dates = [];
        foreach ($value as $key => $child) {
            $childPath = $path === '' ? (string) $key : $path . '.' . (string) $key;
            $childPathLower = mb_strtolower($childPath);
            $looksLikeDateKey = preg_match('/(date|at|time)$/i', (string) $key) === 1;
            $childHasIncludeHint = $hasIncludeHint;
            foreach ($includeHints as $hint) {
                if ($hint !== '' && strpos($childPathLower, $hint) !== false) {
                    $childHasIncludeHint = true;
                    break;
                }
            }

            if ($childHasIncludeHint && $looksLikeDateKey && is_scalar($child)) {
                $candidate = trim((string) $child);
                if ($candidate !== '' && strtotime($candidate) !== false) {
                    $dates[] = $candidate;
                    continue;
                }
            }

            $dates = array_merge($dates, $this->collectCustomerReturnDatesByPathHints($child, $includeHints, $excludeHints, $childPath, $depth + 1));
        }

        return $dates;
    }

    protected function findFirstParcelDate(array $return, array $keys = ['createdAt', 'sentAt', 'dispatchedAt']): string
    {
        $parcels = $return['parcels'] ?? [];
        if (!is_array($parcels)) {
            return '';
        }

        foreach ($parcels as $parcel) {
            if (!is_array($parcel)) {
                continue;
            }

            foreach ($keys as $key) {
                $date = trim((string) ($parcel[$key] ?? ''));
                if ($date !== '') {
                    return $date;
                }
            }
        }

        return '';
    }

    protected function renderCustomerReturnItems(array $return): string
    {
        $items = $return['items'] ?? [];
        if (!is_array($items) || !$items) {
            return '';
        }

        $html = '<div class="aar-return-items-simple">';
        foreach ($items as $item) {
            if (!is_array($item)) {
                continue;
            }

            $name = trim((string) ($item['name'] ?? 'Produkt'));
            $offerId = trim((string) ($item['offerId'] ?? ''));
            $quantity = trim((string) ($item['quantity'] ?? ''));
            $price = $this->formatMoneyValue($item['price'] ?? []);
            $reasonType = $this->formatCustomerReturnReasonType((string) ($item['reason']['type'] ?? ''));
            $comment = $this->resolveCustomerReturnReasonComment($item);
            $url = trim((string) ($item['url'] ?? ''));
            $thumbnailUrl = $this->resolveCustomerReturnItemThumbnailUrl($item, $return);

            if ($thumbnailUrl !== '') {
                $html .= '<div class="aar-return-product-row has-thumb">';
                $html .= '<div class="aar-return-product-thumb"><img src="' . Tools::safeOutput($thumbnailUrl) . '" alt="" loading="lazy"></div>';
            } else {
                $html .= '<div class="aar-return-product-row">';
            }
            $html .= '<div class="aar-return-product-main">';
            if ($url !== '') {
                $html .= '<strong><a href="' . Tools::safeOutput($url) . '" target="_blank" rel="noopener noreferrer">' . Tools::safeOutput($name) . '</a></strong>';
            } else {
                $html .= '<strong>' . Tools::safeOutput($name) . '</strong>';
            }
            if ($offerId !== '') {
                $html .= '<div class="text-muted">' . Tools::safeOutput($offerId) . '</div>';
            }
            $reason = trim($reasonType . ($comment !== '' ? ': ' . $comment : ''));
            if ($reason !== '') {
                $html .= '<div class="aar-return-reason"><span>Powód zwrotu:</span> ' . Tools::safeOutput($reason) . '</div>';
            }
            $html .= '</div>';
            $html .= '<div class="aar-return-product-side">';
            if ($quantity !== '') {
                $html .= '<div>' . Tools::safeOutput($quantity . ' ' . $this->pluralizePolish((int) $quantity, 'sztuka', 'sztuki', 'sztuk')) . '</div>';
            }
            if ($price !== '') {
                $html .= '<strong>' . Tools::safeOutput($price) . '</strong>';
            }
            $html .= '</div>';
            $html .= '</div>';
        }
        $html .= '</div>';

        return $html;
    }

    protected function renderCustomerReturnParcels(array $return): string
    {
        $parcels = $return['parcels'] ?? [];
        if (!is_array($parcels) || !$parcels) {
            return '';
        }

        $html = '<div class="aar-return-parcels">';
        foreach ($parcels as $parcel) {
            if (!is_array($parcel)) {
                continue;
            }

            $waybill = $this->firstNonEmptyString([$parcel['transportingWaybill'] ?? null, $parcel['truckingWaybill'] ?? null, $parcel['waybill'] ?? null]);
            $carrier = $this->firstNonEmptyString([$parcel['transportingCarrierId'] ?? null, $parcel['truckingCarrierId'] ?? null, $parcel['carrierId'] ?? null]);
            $createdAt = $this->formatAllegroDate((string) ($parcel['createdAt'] ?? ''));
            $phone = $this->maskPhone((string) ($parcel['sender']['phoneNumber'] ?? ''));
            $parts = array_filter([
                $waybill !== '' ? 'List: ' . $waybill : '',
                $carrier !== '' ? 'Przewoźnik: ' . $carrier : '',
                $createdAt !== '' ? 'Utworzono: ' . $createdAt : '',
                $phone !== '' ? 'Telefon nadawcy: ' . $phone : '',
            ]);

            if ($parts) {
                $html .= '<div class="aar-claim-link-meta">' . Tools::safeOutput(implode(' • ', $parts)) . '</div>';
            }
        }
        $html .= '</div>';

        return $html;
    }

    protected function getCustomerReturnBuyerName(array $return): string
    {
        $buyer = is_array($return['buyer'] ?? null) ? $return['buyer'] : [];
        $name = $this->firstNonEmptyString([
            $buyer['name'] ?? null,
            $this->joinNameParts($buyer),
            $buyer['companyName'] ?? null,
        ]);

        if ($name !== '') {
            return $name;
        }

        foreach (['deliveryAddress', 'address', 'invoiceAddress'] as $key) {
            $address = is_array($buyer[$key] ?? null) ? $buyer[$key] : [];
            $name = $this->firstNonEmptyString([
                $address['name'] ?? null,
                $address['companyName'] ?? null,
                $this->joinNameParts($address),
            ]);
            if ($name !== '') {
                return $name;
            }
        }

        foreach (($return['parcels'] ?? []) as $parcel) {
            if (!is_array($parcel)) {
                continue;
            }
            $sender = is_array($parcel['sender'] ?? null) ? $parcel['sender'] : [];
            $name = $this->firstNonEmptyString([
                $sender['name'] ?? null,
                $sender['companyName'] ?? null,
                $this->joinNameParts($sender),
            ]);
            if ($name !== '') {
                return $name;
            }
        }

        $name = $this->findCustomerReturnPersonNameRecursively($return);
        if ($name !== '') {
            return $name;
        }

        return '';
    }

    protected function findCustomerReturnPersonNameRecursively(array $payload, int $depth = 0): string
    {
        if ($depth > 6) {
            return '';
        }

        foreach ($payload as $key => $value) {
            $keyLower = mb_strtolower((string) $key);
            if (in_array($keyLower, ['login', 'email', 'mail', 'username', 'userid', 'id'], true)) {
                continue;
            }

            if (is_array($value)) {
                $name = $this->firstNonEmptyString([
                    $value['name'] ?? null,
                    $value['fullName'] ?? null,
                    $value['fullname'] ?? null,
                    $this->joinNameParts($value),
                ]);
                if ($this->looksLikePersonName($name)) {
                    return $name;
                }

                if (preg_match('/(buyer|customer|sender|person|address|contact)/i', (string) $key)) {
                    $name = $this->findCustomerReturnPersonNameRecursively($value, $depth + 1);
                    if ($name !== '') {
                        return $name;
                    }
                }
            }
        }

        return '';
    }

    protected function looksLikePersonName(string $name): bool
    {
        $name = trim($name);
        if ($name === '' || strpos($name, '@') !== false) {
            return false;
        }
        if (preg_match('/^[a-z0-9_.-]+$/i', $name) === 1 && strpos($name, ' ') === false) {
            return false;
        }

        return preg_match('/[\\p{L}]{2,}/u', $name) === 1;
    }

    protected function getCustomerReturnBuyerPhone(array $return): string
    {
        $buyer = is_array($return['buyer'] ?? null) ? $return['buyer'] : [];
        $phone = $this->firstNonEmptyString([
            $buyer['phoneNumber'] ?? null,
            $buyer['phone'] ?? null,
        ]);

        if ($phone !== '') {
            return $phone;
        }

        foreach (($return['parcels'] ?? []) as $parcel) {
            if (!is_array($parcel)) {
                continue;
            }
            $phone = $this->firstNonEmptyString([
                $parcel['sender']['phoneNumber'] ?? null,
                $parcel['sender']['phone'] ?? null,
            ]);
            if ($phone !== '') {
                return $phone;
            }
        }

        return '';
    }

    protected function getCustomerReturnDeliveryMethod(array $return): string
    {
        if ($this->isCustomerReturnOwnShipping($return)) {
            return 'Wysyłka własna';
        }

        $preferredParcel = $this->getPreferredCustomerReturnParcel($return);
        if ($preferredParcel) {
            $method = $this->firstNonEmptyString([
                $preferredParcel['carrierName'] ?? null,
                $preferredParcel['transportingCarrierId'] ?? null,
                $preferredParcel['truckingCarrierId'] ?? null,
                $preferredParcel['carrierId'] ?? null,
            ]);
            if ($method !== '') {
                return $method;
            }
        }

        foreach (($return['parcels'] ?? []) as $parcel) {
            if (!is_array($parcel)) {
                continue;
            }

            $method = $this->firstNonEmptyString([
                $parcel['carrierName'] ?? null,
                $parcel['transportingCarrierId'] ?? null,
                $parcel['truckingCarrierId'] ?? null,
                $parcel['carrierId'] ?? null,
            ]);
            if ($method !== '') {
                return $method;
            }
        }

        return '';
    }

    protected function getCustomerReturnWaybill(array $return): string
    {
        $preferredParcel = $this->getPreferredCustomerReturnParcel($return);
        if ($preferredParcel) {
            $waybill = $this->firstNonEmptyString([
                $preferredParcel['waybill'] ?? null,
                $preferredParcel['transportingWaybill'] ?? null,
                $preferredParcel['truckingWaybill'] ?? null,
            ]);
            if ($waybill !== '') {
                return $waybill;
            }
        }

        foreach (($return['parcels'] ?? []) as $parcel) {
            if (!is_array($parcel)) {
                continue;
            }

            $waybill = $this->firstNonEmptyString([
                $parcel['transportingWaybill'] ?? null,
                $parcel['truckingWaybill'] ?? null,
                $parcel['waybill'] ?? null,
            ]);
            if ($waybill !== '') {
                return $waybill;
            }
        }

        return '';
    }

    protected function getPreferredCustomerReturnParcel(array $return): array
    {
        foreach (($return['parcels'] ?? []) as $parcel) {
            if (!is_array($parcel)) {
                continue;
            }

            $carrierId = mb_strtoupper(trim((string) ($parcel['carrierId'] ?? '')));
            $waybill = trim((string) ($parcel['waybill'] ?? ''));
            if ($this->isCustomerReturnApiTrackingCarrier($carrierId) && $waybill !== '') {
                return $parcel;
            }
        }

        foreach (($return['parcels'] ?? []) as $parcel) {
            if (is_array($parcel)) {
                return $parcel;
            }
        }

        return [];
    }

    protected function getCustomerReturnTrackingUrl(array $return): string
    {
        $carrierId = '';
        $waybill = '';
        $preferredParcel = $this->getPreferredCustomerReturnParcel($return);
        if ($preferredParcel) {
            $preferredCarrierId = mb_strtoupper(trim((string) ($preferredParcel['carrierId'] ?? '')));
            $carrierId = $this->isCustomerReturnApiTrackingCarrier($preferredCarrierId)
                ? trim((string) ($preferredParcel['carrierId'] ?? ''))
                : $this->firstNonEmptyString([
                    $preferredParcel['transportingCarrierId'] ?? null,
                    $preferredParcel['truckingCarrierId'] ?? null,
                    $preferredParcel['carrierId'] ?? null,
                ]);
            $waybill = $this->isCustomerReturnApiTrackingCarrier($preferredCarrierId)
                ? trim((string) ($preferredParcel['waybill'] ?? ''))
                : $this->firstNonEmptyString([
                    $preferredParcel['transportingWaybill'] ?? null,
                    $preferredParcel['truckingWaybill'] ?? null,
                    $preferredParcel['waybill'] ?? null,
                ]);
        }

        if ($waybill === '') {
            return '';
        }

        return $this->buildCarrierTrackingUrl($carrierId, $waybill);
    }

    protected function findCustomerReturnTrackingEntry(array $return, string $waybill): array
    {
        $waybill = trim($waybill);
        if ($waybill === '') {
            return [];
        }

        foreach (($return['_tracking'] ?? []) as $trackingResponse) {
            if (!is_array($trackingResponse)) {
                continue;
            }

            foreach (($trackingResponse['waybills'] ?? []) as $trackingWaybill) {
                if (!is_array($trackingWaybill)) {
                    continue;
                }

                if (trim((string) ($trackingWaybill['waybill'] ?? '')) === $waybill) {
                    return $trackingWaybill;
                }
            }
        }

        return [];
    }

    protected function shouldUseCustomerReturnTrackingModal(array $return): bool
    {
        foreach (($return['parcels'] ?? []) as $parcel) {
            if (!is_array($parcel)) {
                continue;
            }

            $carrierId = mb_strtoupper(trim((string) ($parcel['carrierId'] ?? '')));
            $waybill = trim((string) ($parcel['waybill'] ?? ''));
            if ($this->isCustomerReturnApiTrackingCarrier($carrierId) && $waybill !== '') {
                return true;
            }
        }

        return false;
    }

    protected function isCustomerReturnApiTrackingCarrier(string $carrierId): bool
    {
        $carrierId = mb_strtoupper(trim($carrierId));

        return in_array($carrierId, ['ALLEGRO', 'INPOST'], true);
    }

    protected function translateCustomerReturnTrackingDescription(string $code, string $description): string
    {
        $code = mb_strtoupper(trim($code));
        $description = trim($description);
        $normalized = mb_strtolower(preg_replace('/\s+/', ' ', $description));

        $byDescription = [
            'parcel has been prepared by the sender' => 'Przesyłka została przygotowana przez nadawcę',
            'parcel has been dispatched' => 'Przesyłka została nadana',
            'parcel has been picked up from parcel locker by courier' => 'Przesyłka została odebrana z automatu przez kuriera',
            'courier has transferred the parcel to the warehouse' => 'Kurier przekazał przesyłkę do magazynu',
            'parcel has been picked up by the courier' => 'Przesyłka została odebrana przez kuriera',
            'parcel has been accepted at the branch' => 'Przesyłka została przyjęta w oddziale',
            'parcel has been released for delivery' => 'Przesyłka została wydana do doręczenia',
            'parcel has been delivered' => 'Przesyłka została doręczona',
            'prepared by sender' => 'Przesyłka została przygotowana przez nadawcę',
            'dispatched' => 'Przesyłka została nadana',
            'picked up from sender' => 'Przesyłka została odebrana od nadawcy',
            'accepted at inpost delivery center' => 'Przesyłka została przyjęta w oddziale InPost',
            'in transit' => 'Przesyłka jest w drodze',
            'in delivery' => 'Przesyłka została wydana do doręczenia',
            'delivered' => 'Przesyłka została doręczona',
        ];

        if ($normalized !== '' && isset($byDescription[$normalized])) {
            return $byDescription[$normalized];
        }

        $byCode = [
            'PENDING' => 'Przesyłka została przygotowana',
            'IN_TRANSIT' => 'Przesyłka jest w drodze',
            'RELEASED_FOR_DELIVERY' => 'Przesyłka została wydana do doręczenia',
            'DELIVERED' => 'Przesyłka została doręczona',
            'AVAILABLE_FOR_PICKUP' => 'Przesyłka czeka na odbiór',
            'RETURNED' => 'Przesyłka została zwrócona',
        ];

        if ($code !== '' && isset($byCode[$code])) {
            return $byCode[$code];
        }

        return $description;
    }

    protected function formatCustomerReturnTrackingCode(string $code): string
    {
        $code = mb_strtoupper(trim($code));
        if ($code === '') {
            return '';
        }

        $labels = [
            'PENDING' => 'Oczekuje',
            'IN_TRANSIT' => 'W drodze',
            'RELEASED_FOR_DELIVERY' => 'Wydana do doreczenia',
            'DELIVERED' => 'Doreczona',
            'AVAILABLE_FOR_PICKUP' => 'Gotowa do odbioru',
            'RETURNED' => 'Zwrocona',
        ];

        return $labels[$code] ?? str_replace('_', ' ', $code);
    }

    protected function buildCarrierTrackingUrl(string $carrierId, string $waybill): string
    {
        $carrier = mb_strtolower(trim($carrierId));
        $waybill = trim($waybill);
        if ($waybill === '') {
            return '';
        }

        if (strpos($carrier, 'inpost') !== false) {
            return 'https://inpost.pl/sledzenie-przesylek?number=' . rawurlencode($waybill);
        }
        if (strpos($carrier, 'dpd') !== false) {
            return 'https://tracktrace.dpd.com.pl/findParcel?p1=' . rawurlencode($waybill);
        }
        if (strpos($carrier, 'orlen') !== false || strpos($carrier, 'ruch') !== false) {
            return 'https://www.orlenpaczka.pl/sledz-paczke/' . rawurlencode($waybill);
        }
        if (strpos($carrier, 'dhl') !== false) {
            return 'https://www.dhl.com/pl-pl/home/tracking.html?tracking-id=' . rawurlencode($waybill);
        }
        if ($carrier === 'allegro') {
            return 'https://allegro.pl/kampania/one/kurier/sledzenie-paczki?numer=' . rawurlencode($waybill);
        }
        if (strpos($carrier, 'ups') !== false) {
            return 'https://www.ups.com/track?loc=pl_PL&tracknum=' . rawurlencode($waybill);
        }
        if (strpos($carrier, 'fedex') !== false) {
            return 'https://www.fedex.com/fedextrack/?trknbr=' . rawurlencode($waybill);
        }
        if (strpos($carrier, 'gls') !== false) {
            return 'https://gls-group.com/PL/pl/sledzenie-paczek/?match=' . rawurlencode($waybill);
        }
        if (strpos($carrier, 'poczta') !== false || strpos($carrier, 'polish_post') !== false) {
            return 'https://emonitoring.poczta-polska.pl/?numer=' . rawurlencode($waybill);
        }

        return 'https://salescenter.allegro.com/returns/?' . http_build_query([
            'query' => $waybill,
        ]);
    }

    protected function getCustomerReturnAddressLines(array $return): array
    {
        $address = [];
        foreach ([
            $return['returnAddress'] ?? null,
            $return['address'] ?? null,
            $return['seller']['returnAddress'] ?? null,
        ] as $candidate) {
            if (is_array($candidate) && $candidate) {
                $address = $candidate;
                break;
            }
        }

        if (!$address) {
            return [];
        }

        $name = $this->firstNonEmptyString([
            $address['name'] ?? null,
            $address['companyName'] ?? null,
            $this->joinNameParts($address),
        ]);
        $street = $this->firstNonEmptyString([$address['street'] ?? null, $address['addressLine1'] ?? null]);
        $postalCity = trim($this->firstNonEmptyString([$address['zipCode'] ?? null, $address['postCode'] ?? null]) . ' ' . $this->firstNonEmptyString([$address['city'] ?? null]));
        $country = $this->firstNonEmptyString([$address['countryCode'] ?? null, $address['country'] ?? null]);

        return array_values(array_filter([$name, $street, $postalCity, $country]));
    }

    protected function getCustomerReturnRefundLines(array $return): array
    {
        $bankAccount = $return['refund']['bankAccount'] ?? [];
        if (!is_array($bankAccount) || !$bankAccount) {
            return [];
        }

        $address = is_array($bankAccount['address'] ?? null) ? $bankAccount['address'] : [];
        $lines = [
            trim((string) ($bankAccount['iban'] ?? $bankAccount['accountNumber'] ?? '')),
            trim((string) ($bankAccount['owner'] ?? '')),
            trim((string) ($address['street'] ?? '')),
            trim($this->firstNonEmptyString([$address['postCode'] ?? null, $address['zipCode'] ?? null]) . ' ' . $this->firstNonEmptyString([$address['city'] ?? null])),
        ];

        return array_values(array_filter($lines));
    }

    protected function calculateCustomerReturnTotal(array $return): string
    {
        $total = 0.0;
        $currency = '';
        foreach (($return['items'] ?? []) as $item) {
            if (!is_array($item)) {
                continue;
            }

            $price = is_array($item['price'] ?? null) ? $item['price'] : [];
            $amount = trim((string) ($price['amount'] ?? ''));
            if ($amount === '' || !is_numeric(str_replace(',', '.', $amount))) {
                continue;
            }

            $quantity = max(1, (int) ($item['quantity'] ?? 1));
            $total += (float) str_replace(',', '.', $amount) * $quantity;
            $currency = trim((string) ($price['currency'] ?? $currency));
        }

        if ($total <= 0) {
            return '';
        }

        return number_format($total, 2, ',', ' ') . ($currency !== '' ? ' ' . $currency : '');
    }

    protected function calculateCustomerReturnItemAmount(array $item): float
    {
        $price = is_array($item['price'] ?? null) ? $item['price'] : [];
        $amount = trim((string) ($price['amount'] ?? ''));
        if ($amount === '' || !is_numeric(str_replace(',', '.', $amount))) {
            return 0.0;
        }

        return (float) str_replace(',', '.', $amount) * max(1, (int) ($item['quantity'] ?? 1));
    }

    protected function getCustomerReturnCurrency(array $return): string
    {
        foreach (($return['items'] ?? []) as $item) {
            if (!is_array($item)) {
                continue;
            }

            $currency = trim((string) ($item['price']['currency'] ?? ''));
            if ($currency !== '') {
                return $currency;
            }
        }

        return 'PLN';
    }

    protected function normalizeRefundAmount(string $amount): string
    {
        $amount = trim(str_replace([' ', "\xc2\xa0"], '', $amount));
        if ($amount === '') {
            return '';
        }

        $amount = str_replace(',', '.', $amount);
        if (!is_numeric($amount) || (float) $amount <= 0) {
            throw new RuntimeException('Nieprawidłowa kwota zwrotu: ' . $amount . '.');
        }

        return number_format((float) $amount, 2, '.', '');
    }

    protected function indexCheckoutLineItemsByOfferId(array $checkoutForm): array
    {
        $indexed = [];
        foreach (($checkoutForm['lineItems'] ?? []) as $lineItem) {
            if (!is_array($lineItem)) {
                continue;
            }

            $offerId = trim((string) ($lineItem['offer']['id'] ?? ''));
            if ($offerId !== '' && !isset($indexed[$offerId])) {
                $indexed[$offerId] = $lineItem;
            }
        }

        return $indexed;
    }

    protected function generateUuidV4(): string
    {
        $bytes = random_bytes(16);
        $bytes[6] = chr((ord($bytes[6]) & 0x0f) | 0x40);
        $bytes[8] = chr((ord($bytes[8]) & 0x3f) | 0x80);

        return vsprintf('%s%s-%s-%s-%s-%s%s%s', str_split(bin2hex($bytes), 4));
    }

    protected function getCustomerReturnRefundReasonOptions(): array
    {
        return [
            'REFUND' => 'zwrot produktu',
            'MISSING_ITEM' => 'brak produktu',
            'COMPLAINT' => 'reklamacja',
            'OVERPAYMENT' => 'zwrot nadpłaty',
            'CANCELED_BY_BUYER' => 'anulowanie przez kupującego',
            'UNCLAIMED' => 'nieodebrane zamówienie',
            'LACK_OF_FULL_PAYMENT' => 'brak pełnej kwoty za zamówienie',
        ];
    }

    protected function buildCustomerReturnRefundModalId(string $returnId): string
    {
        return 'aar-return-refund-modal-' . preg_replace('/[^a-zA-Z0-9_-]/', '-', $returnId);
    }

    protected function buildCustomerReturnRejectionModalId(string $returnId): string
    {
        return 'aar-return-rejection-modal-' . preg_replace('/[^a-zA-Z0-9_-]/', '-', $returnId);
    }

    protected function renderCustomerReturnRefundModal(string $returnId, array $return): string
    {
        if ($returnId === '' || !$this->canRefundCustomerReturn($return)) {
            return '';
        }

        $modalId = $this->buildCustomerReturnRefundModalId($returnId);
        $html = '<div class="modal fade aar-return-refund-modal" id="' . Tools::safeOutput($modalId) . '" tabindex="-1" role="dialog" aria-labelledby="' . Tools::safeOutput($modalId . '-title') . '">';
        $html .= '<div class="modal-dialog modal-lg" role="document">';
        $html .= '<div class="modal-content">';
        $html .= '<div class="modal-header">';
        $html .= '<button type="button" class="close" data-dismiss="modal" aria-label="Zamknij"><span aria-hidden="true">&times;</span></button>';
        $html .= '<h4 class="modal-title" id="' . Tools::safeOutput($modalId . '-title') . '">Zwrot pieniędzy</h4>';
        $html .= '</div>';
        $html .= '<div class="modal-body">';
        $html .= $this->renderCustomerReturnRefundForm($returnId, $return, false);
        $html .= '</div>';
        $html .= '</div>';
        $html .= '</div>';
        $html .= '</div>';

        return $html;
    }

    protected function renderCustomerReturnRejectionModal(string $returnId, array $return): string
    {
        if ($returnId === '' || !$this->canRejectCustomerReturn($return)) {
            return '';
        }

        $modalId = $this->buildCustomerReturnRejectionModalId($returnId);
        $html = '<div class="modal fade aar-return-rejection-modal" id="' . Tools::safeOutput($modalId) . '" tabindex="-1" role="dialog" aria-labelledby="' . Tools::safeOutput($modalId . '-title') . '">';
        $html .= '<div class="modal-dialog modal-lg" role="document">';
        $html .= '<div class="modal-content">';
        $html .= '<div class="modal-header">';
        $html .= '<button type="button" class="close" data-dismiss="modal" aria-label="Zamknij"><span aria-hidden="true">&times;</span></button>';
        $html .= '<h4 class="modal-title" id="' . Tools::safeOutput($modalId . '-title') . '">Odmowa zwrotu pieniędzy</h4>';
        $html .= '</div>';
        $html .= '<div class="modal-body">';
        $html .= $this->renderCustomerReturnRejectionForm($returnId, $return, false);
        $html .= '</div>';
        $html .= '</div>';
        $html .= '</div>';
        $html .= '</div>';

        return $html;
    }

    protected function renderCustomerReturnRejectionForm(string $returnId, array $return, bool $collapsed = false): string
    {
        if ($returnId === '' || !$this->canRejectCustomerReturn($return)) {
            return '';
        }

        $definitions = $this->getCustomerReturnRejectionReasonDefinitions();
        $html = '<form method="post" class="aar-reply-form aar-return-rejection-form' . ($collapsed ? ' is-collapsed' : '') . '" onsubmit="return confirm(\'Wysłać odmowę zwrotu do Allegro?\');">';
        $html .= '<input type="hidden" name="return_id" value="' . Tools::safeOutput($returnId) . '">';
        $html .= '<div class="aar-return-rejection-head">';
        $html .= '<h5>Powód odmowy <span class="text-danger">*</span></h5>';
        $html .= '<p>Wybierz powód, który przekażemy kupującemu w decyzji.</p>';
        $html .= '</div>';
        $html .= '<div class="aar-return-rejection-reasons">';
        foreach ($definitions as $code => $definition) {
            $label = (string) ($definition['label'] ?? '');
            $description = (string) ($definition['description'] ?? '');
            $html .= '<label class="aar-return-rejection-option">';
            $html .= '<input type="radio" name="return_rejection_code" value="' . Tools::safeOutput($code) . '"' . ($code === 'OTHER_REASON' ? ' checked' : '') . ' required>';
            $html .= '<span class="aar-return-rejection-option-body">';
            $html .= '<span class="aar-return-rejection-option-label">' . Tools::safeOutput($label) . '</span>';
            if ($description !== '') {
                $html .= '<span class="aar-return-rejection-option-desc">' . Tools::safeOutput($description) . '</span>';
            }
            $html .= '</span>';
            $html .= '</label>';
        }
        $html .= '</div>';
        $html .= '<div class="aar-return-rejection-comment">';
        $html .= '<label for="aar-return-rejection-reason-' . Tools::safeOutput($returnId) . '">Uzasadnienie decyzji</label>';
        $html .= '<textarea id="aar-return-rejection-reason-' . Tools::safeOutput($returnId) . '" class="form-control" name="return_rejection_reason" rows="4" maxlength="250" placeholder="Podaj szczegóły (wymagane dla: Inny powód)"></textarea>';
        $html .= '</div>';
        $html .= '<div class="aar-return-rejection-actions">';
        $html .= '<button class="btn btn-danger aar-send-button" name="submitAarRejectReturn" type="submit">Wyślij decyzję</button>';
        $html .= '</div>';
        $html .= '</form>';

        return $html;
    }

    protected function renderCustomerReturnRefundForm(string $returnId, array $return, bool $collapsed = false): string
    {
        if ($returnId === '' || !$this->canRefundCustomerReturn($return)) {
            return '';
        }

        $items = is_array($return['items'] ?? null) ? $return['items'] : [];
        if (!$items) {
            return '';
        }

        $html = '<form method="post" class="aar-reply-form aar-return-refund-form' . ($collapsed ? ' is-collapsed' : '') . '" onsubmit="return confirm(\'Zlecić zwrot pieniędzy w Allegro?\');">';
        $html .= '<input type="hidden" name="return_id" value="' . Tools::safeOutput($returnId) . '">';
        $html .= '<div class="aar-return-refund-grid">';
        $html .= '<div class="aar-return-refund-reasons-wrap">';
        $html .= '<h5>Powód zwrotu pieniędzy</h5>';
        $html .= '<div class="aar-return-refund-reasons-hint">Wybierz powód zwrotu</div>';
        $html .= '<div class="aar-return-refund-reasons">';
        foreach ($this->getCustomerReturnRefundReasonOptions() as $code => $label) {
            $checked = $code === 'REFUND' ? ' checked' : '';
            $html .= '<label class="aar-return-refund-option">';
            $html .= '<input type="radio" name="return_refund_reason" value="' . Tools::safeOutput($code) . '"' . $checked . ' required>';
            $html .= '<span>' . Tools::safeOutput($label) . '</span>';
            $html .= '</label>';
        }
        $html .= '</div>';
        $html .= '</div>';
        $index = 0;
        foreach ($items as $item) {
            if (!is_array($item)) {
                continue;
            }

            $offerId = trim((string) ($item['offerId'] ?? ''));
            $amount = $this->calculateCustomerReturnItemAmount($item);
            if ($offerId === '' || $amount <= 0) {
                continue;
            }

            $currency = trim((string) ($item['price']['currency'] ?? 'PLN'));
            $name = trim((string) ($item['name'] ?? 'Produkt'));
            $quantity = max(1, (int) ($item['quantity'] ?? 1));
            $html .= '<div class="aar-return-refund-line">';
            $html .= '<input type="hidden" name="return_refund_lines[' . (int) $index . '][offer_id]" value="' . Tools::safeOutput($offerId) . '">';
            $html .= '<input type="hidden" name="return_refund_lines[' . (int) $index . '][currency]" value="' . Tools::safeOutput($currency !== '' ? $currency : 'PLN') . '">';
            $html .= '<label>' . Tools::safeOutput($name) . '<span>' . Tools::safeOutput($quantity . ' ' . $this->pluralizePolish($quantity, 'sztuka', 'sztuki', 'sztuk')) . '</span></label>';
            $html .= '<div class="input-group">';
            $html .= '<input class="form-control" type="text" name="return_refund_lines[' . (int) $index . '][amount]" value="' . Tools::safeOutput(number_format($amount, 2, '.', '')) . '">';
            $html .= '<span class="input-group-addon">' . Tools::safeOutput($currency !== '' ? $currency : 'PLN') . '</span>';
            $html .= '</div>';
            $html .= '</div>';
            $index++;
        }
        $html .= '<div class="aar-return-refund-line aar-return-refund-delivery">';
        $html .= '<input type="hidden" name="return_refund_delivery_currency" value="' . Tools::safeOutput($this->getCustomerReturnCurrency($return)) . '">';
        $html .= '<label>Dostawa<span>opcjonalnie</span></label>';
        $html .= '<div class="input-group">';
        $html .= '<input class="form-control" type="text" name="return_refund_delivery_amount" value="" placeholder="0.00">';
        $html .= '<span class="input-group-addon">' . Tools::safeOutput($this->getCustomerReturnCurrency($return)) . '</span>';
        $html .= '</div>';
        $html .= '</div>';
        $html .= '<textarea class="form-control" name="return_refund_comment" rows="2" maxlength="250" placeholder="Uzasadnienie decyzji (opcjonalnie)"></textarea>';
        $html .= '<button class="btn btn-primary aar-send-button" name="submitAarRefundReturn" type="submit">Zwróć pieniądze</button>';
        $html .= '</div>';
        $html .= '</form>';

        return $index > 0 ? $html : '';
    }

    protected function buildIssueOrderProductRows(string $checkoutFormId, string $offerId, string $offerQuantity, string $productId, ?array $linkedOrder = null): array
    {
        if ((!is_array($linkedOrder) || empty($linkedOrder['url'])) && trim($checkoutFormId) !== '') {
            $linkedOrder = $this->findPrestashopOrderByPrXallegroCheckoutForm($checkoutFormId);
        }

        $rows = [];
        $rows[] = [
            'label' => 'Zamówienie Allegro',
            'value' => $checkoutFormId,
            'url' => $this->getAllegroOrdersUrl($checkoutFormId),
        ];

        if (is_array($linkedOrder) && (int) ($linkedOrder['id_order'] ?? 0) > 0) {
            $rows[] = [
                'label' => 'Zamówienie w sklepie',
                'value' => $this->formatPrestashopOrderReference($linkedOrder),
                'url' => (string) $linkedOrder['url'],
            ];
        } elseif ($checkoutFormId !== '') {
            $rows[] = [
                'label' => 'Zamówienie w sklepie',
                'value' => $this->buildPrestashopOrderLookupMissLabel($checkoutFormId),
            ];
        }

        $rows[] = [
            'label' => 'Oferta',
            'value' => $offerId,
            'url' => $this->getAllegroOfferUrl($offerId),
        ];
        $rows[] = [
            'label' => 'Produkt',
            'value' => $productId,
            'url' => $this->getAllegroProductUrl($productId),
        ];

        return array_values(array_filter($rows, function (array $row): bool {
            return trim((string) ($row['value'] ?? '')) !== '';
        }));
    }

    protected function formatPrestashopOrderReference(array $linkedOrder): string
    {
        $reference = trim((string) ($linkedOrder['reference'] ?? ''));
        if ($reference !== '' && $reference !== '#0') {
            return $reference;
        }

        $idOrder = (int) ($linkedOrder['id_order'] ?? 0);

        return $idOrder > 0 ? '#' . $idOrder : '';
    }

    protected function renderCheckoutBuyerDeliveryCard(string $checkoutFormId, string $buyerLogin = ''): string
    {
        $checkoutForm = $this->getStoredCheckoutFormContent($checkoutFormId);
        $buyerLines = $this->extractCheckoutBuyerLines($checkoutForm, $buyerLogin);
        $deliveryLines = $this->extractCheckoutDeliveryLines($checkoutForm);

        if (!$buyerLines && trim($buyerLogin) !== '') {
            $buyerLines[] = trim($buyerLogin);
        }

        $html = '<div class="aar-claim-card aar-checkout-card">';
        $html .= '<div class="aar-checkout-details">';

        $html .= '<div class="aar-checkout-details-section">';
        $html .= '<h5>Kupujący</h5>';
        foreach ($buyerLines as $line) {
            $html .= '<span>' . Tools::safeOutput($line) . '</span>';
        }
        $html .= '</div>';

        if ($deliveryLines) {
            $html .= '<div class="aar-checkout-details-section">';
            $html .= '<h5>Dane dostawy</h5>';
            foreach ($deliveryLines as $line) {
                $html .= '<span>' . Tools::safeOutput($line) . '</span>';
            }
            $html .= '</div>';
        }

        $html .= '</div>';
        $html .= '</div>';

        return $html;
    }

    protected function getStoredCheckoutFormContent(string $checkoutFormId): array
    {
        $checkoutFormId = trim($checkoutFormId);
        if ($checkoutFormId === '') {
            return [];
        }

        try {
            $raw = (string) Db::getInstance()->getValue('
                SELECT `checkout_form_content`
                FROM `pr_xallegro_order`
                WHERE `checkout_form` LIKE "%' . pSQL($checkoutFormId) . '%"
            ');
        } catch (Throwable $e) {
            PrestaShopLogger::addLog('[AAR] checkout_form_content lookup skipped for ' . $checkoutFormId . ': ' . $e->getMessage(), 2);
            return [];
        }

        return $this->decodeStoredCheckoutFormContent($raw);
    }

    protected function decodeStoredCheckoutFormContent(string $raw): array
    {
        $raw = trim($raw);
        if ($raw === '') {
            return [];
        }

        $decoded = json_decode($raw, true);
        if (is_array($decoded)) {
            return $decoded;
        }

        $decoded = json_decode(html_entity_decode($raw, ENT_QUOTES | ENT_HTML5, 'UTF-8'), true);
        if (is_array($decoded)) {
            return $decoded;
        }

        $decoded = json_decode(stripslashes($raw), true);
        return is_array($decoded) ? $decoded : [];
    }

    protected function extractCheckoutBuyerLines(array $checkoutForm, string $buyerLogin = ''): array
    {
        $buyer = $checkoutForm['buyer'] ?? [];
        $deliveryAddress = $checkoutForm['delivery']['address'] ?? [];
        $invoiceAddress = $checkoutForm['invoice']['address'] ?? [];
        $buyer = is_array($buyer) ? $buyer : [];
        $deliveryAddress = is_array($deliveryAddress) ? $deliveryAddress : [];
        $invoiceAddress = is_array($invoiceAddress) ? $invoiceAddress : [];
        $lines = [];
        $name = $this->firstNonEmptyString([
            $this->joinNameParts($buyer),
            $buyer['name'] ?? null,
            $buyer['companyName'] ?? null,
            $this->joinNameParts($deliveryAddress),
            $this->joinNameParts($invoiceAddress),
        ]);
        $login = $this->firstNonEmptyString([
            $buyerLogin,
            $buyer['login'] ?? null,
            $buyer['userName'] ?? null,
        ]);
        $phone = $this->firstNonEmptyString([
            $buyer['phoneNumber'] ?? null,
            $buyer['phone'] ?? null,
            $deliveryAddress['phoneNumber'] ?? null,
            $deliveryAddress['phone'] ?? null,
            $invoiceAddress['phoneNumber'] ?? null,
        ]);

        foreach ([$name, $login, $phone] as $line) {
            if ($line !== '') {
                $lines[] = $line;
            }
        }

        return array_values(array_unique($lines));
    }

    protected function extractCheckoutDeliveryLines(array $checkoutForm): array
    {
        $address = $checkoutForm['delivery']['address'] ?? [];
        if (!is_array($address) || !$address) {
            $address = $checkoutForm['deliveryAddress'] ?? [];
        }
        if (!is_array($address) || !$address) {
            return [];
        }

        $name = $this->firstNonEmptyString([
            $this->joinNameParts($address),
            $address['name'] ?? null,
            $address['companyName'] ?? null,
        ]);
        $street = $this->firstNonEmptyString([
            $address['street'] ?? null,
            $address['addressLine1'] ?? null,
        ]);
        $postalCity = trim($this->firstNonEmptyString([$address['zipCode'] ?? null, $address['postCode'] ?? null]) . ' ' . $this->firstNonEmptyString([$address['city'] ?? null]));
        $country = $this->firstNonEmptyString([$address['countryCode'] ?? null, $address['country'] ?? null]);
        $phone = $this->firstNonEmptyString([$address['phoneNumber'] ?? null, $address['phone'] ?? null]);
        $lines = [];

        foreach ([$name, $street, $postalCity, $country, $phone] as $line) {
            if ($line !== '') {
                $lines[] = $line;
            }
        }

        return array_values(array_unique($lines));
    }

    protected function joinNameParts(array $payload): string
    {
        return trim($this->firstNonEmptyString([$payload['firstName'] ?? null]) . ' ' . $this->firstNonEmptyString([$payload['lastName'] ?? null]));
    }

    protected function firstNonEmptyString(array $values): string
    {
        foreach ($values as $value) {
            if (!is_scalar($value)) {
                continue;
            }

            $value = trim((string) $value);
            if ($value !== '') {
                return $value;
            }
        }

        return '';
    }

    protected function resolveOrderDateByCheckoutForm(string $checkoutFormId): string
    {
        $checkoutFormId = trim($checkoutFormId);
        if ($checkoutFormId === '') {
            return '';
        }

        $row = [];
        try {
            $row = Db::getInstance()->getRow('
                SELECT *
                FROM `pr_xallegro_order`
                WHERE `checkout_form` LIKE "%' . pSQL($checkoutFormId) . '%"
            ');
        } catch (Throwable $e) {
            PrestaShopLogger::addLog('[AAR] order date lookup skipped for ' . $checkoutFormId . ': ' . $e->getMessage(), 2);
        }

        if (is_array($row)) {
            foreach (['occurred_at', 'occured_at', 'occurrence', 'event_time', 'event_date', 'created_at', 'updated_at', 'date_add', 'date_upd'] as $column) {
                $date = trim((string) ($row[$column] ?? ''));
                if ($date !== '' && strtotime($date) !== false) {
                    return $date;
                }
            }

            $checkoutForm = $this->decodeStoredCheckoutFormContent((string) ($row['checkout_form_content'] ?? ''));
            $date = $this->extractDateFromCheckoutFormPayload($checkoutForm);
            if ($date !== '') {
                return $date;
            }
        }

        $checkoutForm = $this->getStoredCheckoutFormContent($checkoutFormId);

        return $this->extractDateFromCheckoutFormPayload($checkoutForm);
    }

    protected function extractDateFromCheckoutFormPayload(array $payload): string
    {
        $preferredKeys = ['boughtAt', 'purchasedAt', 'createdAt', 'updatedAt', 'checkoutCompletedAt', 'finishedAt'];
        foreach ($preferredKeys as $key) {
            $date = trim((string) ($payload[$key] ?? ''));
            if ($date !== '' && strtotime($date) !== false) {
                return $date;
            }
        }

        foreach ($payload as $key => $value) {
            if (is_array($value)) {
                $date = $this->extractDateFromCheckoutFormPayload($value);
                if ($date !== '') {
                    return $date;
                }
                continue;
            }

            if (!is_scalar($value) || !preg_match('/(?:date|at|time)$/i', (string) $key)) {
                continue;
            }

            $date = trim((string) $value);
            if ($date !== '' && strtotime($date) !== false) {
                return $date;
            }
        }

        return '';
    }

    protected function formatPrestashopOrderDateWithAge(string $date): string
    {
        $formatted = $this->formatAllegroDate($date);
        if ($formatted === '') {
            return '';
        }

        $age = $this->formatDateAge($date);

        return $age !== '' ? $formatted . ' (' . $age . ')' : $formatted;
    }

    protected function formatIssueOpenDateSinceOrder(string $openedDate, string $orderDate): string
    {
        $formatted = $this->formatAllegroDate($openedDate);
        if ($formatted === '') {
            return '';
        }

        $distance = $this->formatDateDistance($orderDate, $openedDate);

        return $distance !== '' ? $formatted . ' (' . $distance . ' od zakupu)' : $formatted;
    }

    protected function formatDateDistance(string $startDate, string $endDate): string
    {
        try {
            $startedAt = new DateTimeImmutable($startDate);
            $endedAt = new DateTimeImmutable($endDate);
        } catch (Exception $exception) {
            return '';
        }

        if ($startedAt > $endedAt) {
            return '';
        }

        $diff = $startedAt->diff($endedAt);
        $parts = [];
        if ((int) $diff->y > 0) {
            $parts[] = $diff->y . ' ' . $this->pluralizePolish((int) $diff->y, 'rok', 'lata', 'lat');
        }
        if ((int) $diff->m > 0) {
            $parts[] = $diff->m . ' ' . $this->pluralizePolish((int) $diff->m, 'miesiąc', 'miesiące', 'miesięcy');
        }
        if ((int) $diff->d > 0 || !$parts) {
            $parts[] = $diff->d . ' ' . $this->pluralizePolish((int) $diff->d, 'dzień', 'dni', 'dni');
        }

        if (count($parts) === 1) {
            return $parts[0];
        }

        $last = array_pop($parts);

        return implode(', ', $parts) . ' i ' . $last;
    }

    protected function formatDateAge(string $date): string
    {
        try {
            $startedAt = new DateTimeImmutable($date);
            $now = new DateTimeImmutable('now');
        } catch (Exception $exception) {
            return '';
        }

        if ($startedAt > $now) {
            return '';
        }

        $days = (int) floor(($now->getTimestamp() - $startedAt->getTimestamp()) / 86400);
        if ($days < 31) {
            return $days . ' ' . $this->pluralizePolish($days, 'dzień', 'dni', 'dni') . ' temu';
        }

        $months = (int) floor($days / 30);
        if ($months < 12) {
            return $months . ' ' . $this->pluralizePolish($months, 'miesiąc', 'miesiące', 'miesięcy') . ' temu';
        }

        $years = (int) $startedAt->diff($now)->y;
        $anniversary = $startedAt->modify('+' . $years . ' years');
        $remainingDays = max(0, (int) $anniversary->diff($now)->days);
        $yearLabel = $years . ' ' . $this->pluralizePolish($years, 'rok', 'lata', 'lat');

        if ($remainingDays > 0) {
            return $yearLabel . ' i ' . $remainingDays . ' ' . $this->pluralizePolish($remainingDays, 'dzień', 'dni', 'dni') . ' temu';
        }

        return $yearLabel . ' temu';
    }

    protected function pluralizePolish(int $count, string $one, string $few, string $many): string
    {
        $mod10 = $count % 10;
        $mod100 = $count % 100;
        if ($count === 1) {
            return $one;
        }
        if ($mod10 >= 2 && $mod10 <= 4 && !($mod100 >= 12 && $mod100 <= 14)) {
            return $few;
        }

        return $many;
    }

    protected function renderClaimInfoCard(string $title, array $rows, string $body = '', bool $bodyIsHtml = false): string
    {
        $html = '<div class="aar-claim-card">';
        $html .= '<h5>' . Tools::safeOutput($title) . '</h5>';
        if ($rows) {
            $html .= '<dl>';
            foreach ($rows as $label => $value) {
                $url = '';
                $extraHtml = '';
                if (is_array($value)) {
                    $label = (string) ($value['label'] ?? $label);
                    $url = trim((string) ($value['url'] ?? ''));
                    $extraHtml = trim((string) ($value['extra_html'] ?? ''));
                    $value = $value['value'] ?? '';
                }

                $value = trim((string) $value);
                if ($value === '') {
                    continue;
                }

                $html .= '<div class="aar-claim-row">';
                $html .= '<dt>' . Tools::safeOutput($label) . '</dt>';
                if ($url !== '') {
                    $html .= '<dd><a href="' . Tools::safeOutput($url) . '" target="_blank" rel="noopener noreferrer">' . Tools::safeOutput($value) . '</a>' . $extraHtml . '</dd>';
                } else {
                    $html .= '<dd>' . Tools::safeOutput($value) . $extraHtml . '</dd>';
                }
                $html .= '</div>';
            }
            $html .= '</dl>';
        }
        if ($body !== '') {
            $html .= '<div class="aar-claim-body">' . ($bodyIsHtml ? $body : nl2br(Tools::safeOutput($body))) . '</div>';
        }
        $html .= '</div>';

        return $html;
    }

    protected function getAllegroOrdersUrl(string $checkoutFormId): string
    {
        $checkoutFormId = trim($checkoutFormId);
        if ($checkoutFormId === '') {
            return '';
        }

        $account = $this->getConnectedAccount();
        $marketplaceLogin = trim((string) ($account['login'] ?? ''));
        $params = [
            'query' => $checkoutFormId,
        ];

        if ($marketplaceLogin !== '') {
            $params['marketplaceLogin'] = $marketplaceLogin;
        }

        return 'https://salescenter.allegro.com/orders/?' . http_build_query($params);
    }

    protected function getAllegroIssueUrl(array $issue): string
    {
        $issueId = trim((string) ($issue['id'] ?? ''));
        if ($issueId !== '') {
            return 'https://salescenter.allegro.com/claims/' . rawurlencode($issueId);
        }

        $referenceNumber = trim((string) ($issue['referenceNumber'] ?? ''));
        if ($referenceNumber === '') {
            return '';
        }

        $account = $this->getConnectedAccount();
        $marketplaceLogin = trim((string) ($account['login'] ?? ''));
        $params = [
            'query' => $referenceNumber,
        ];

        if ($marketplaceLogin !== '') {
            $params['marketplaceLogin'] = $marketplaceLogin;
        }

        return 'https://salescenter.allegro.com/issues/?' . http_build_query($params);
    }

    protected function getAllegroReturnUrl(array $return): string
    {
        $referenceNumber = trim((string) ($return['referenceNumber'] ?? ''));
        if ($referenceNumber !== '') {
            return $this->buildAllegroReturnsSearchUrl($referenceNumber);
        }

        $returnId = trim((string) ($return['id'] ?? ''));
        if ($returnId !== '') {
            return $this->buildAllegroReturnsSearchUrl($returnId);
        }

        return '';
    }

    protected function buildAllegroReturnsSearchUrl(string $search): string
    {
        $search = trim($search);
        if ($search === '') {
            return '';
        }

        $params = [
            'page' => 1,
            'limit' => 25,
            'search' => $search,
        ];

        $dateRange = $this->getCurrentReturnDateRangeFilter();
        if ($dateRange !== 'all') {
            $days = max(1, (int) $dateRange);
            $from = new DateTimeImmutable('now', new DateTimeZone('UTC'));
            $from = $from->modify('-' . $days . ' days')->setTime(0, 0, 0, 0);
            $params['from'] = $from->format('Y-m-d\TH:i:s.000\Z');
        }

        return 'https://salescenter.allegro.com/returns?' . http_build_query($params);
    }

    protected function getAllegroOfferUrl(string $offerId): string
    {
        $offerId = trim($offerId);
        if ($offerId === '') {
            return '';
        }

        return 'https://allegro.pl/oferta/' . rawurlencode($offerId);
    }

    protected function getAllegroProductUrl(string $productId): string
    {
        $productId = trim($productId);
        if ($productId === '') {
            return '';
        }

        return 'https://allegro.pl/produkt/' . rawurlencode($productId);
    }

    protected function extractIssueCheckoutFormId(array $issue): string
    {
        $ids = $this->extractCheckoutFormIdsFromPayload($issue);

        return $ids[0] ?? '';
    }

    protected function extractCheckoutFormIdsFromPayload(array $payload): array
    {
        $directCandidates = [
            $payload['checkoutForm']['id'] ?? null,
            $payload['checkoutFormId'] ?? null,
            $payload['checkout_form_id'] ?? null,
            $payload['order']['id'] ?? null,
            $payload['orderId'] ?? null,
            $payload['order_id'] ?? null,
            $payload['relatesTo']['order']['id'] ?? null,
            $payload['order']['checkoutForm']['id'] ?? null,
            $payload['order']['checkoutFormId'] ?? null,
            $payload['buyer']['order']['id'] ?? null,
            $payload['buyer']['order']['checkoutForm']['id'] ?? null,
            $payload['buyer']['order']['checkoutFormId'] ?? null,
        ];

        $ids = [];
        foreach ($directCandidates as $candidate) {
            if (!is_scalar($candidate)) {
                continue;
            }

            $value = trim((string) $candidate);
            if ($value !== '') {
                $ids[$value] = true;
            }
        }

        foreach ($this->findCheckoutFormIdsRecursively($payload) as $value) {
            $ids[$value] = true;
        }

        return array_keys($ids);
    }

    protected function findCheckoutFormIdRecursively(array $payload): string
    {
        $ids = $this->findCheckoutFormIdsRecursively($payload);

        return $ids[0] ?? '';
    }

    protected function findCheckoutFormIdsRecursively(array $payload): array
    {
        $ids = [];
        foreach ($payload as $key => $value) {
            $normalizedKey = strtolower((string) $key);
            if (in_array($normalizedKey, ['checkoutformid', 'checkout_form_id', 'checkout-form-id', 'orderid', 'order_id'], true)) {
                if (!is_scalar($value)) {
                    continue;
                }

                $candidate = trim((string) $value);
                if ($candidate !== '') {
                    $ids[$candidate] = true;
                }
            }

            if (in_array($normalizedKey, ['checkoutform', 'order'], true) && is_array($value)) {
                if (is_scalar($value['id'] ?? null)) {
                    $candidate = trim((string) ($value['id'] ?? ''));
                    if ($candidate !== '') {
                        $ids[$candidate] = true;
                    }
                }
            }

            if (is_array($value)) {
                foreach ($this->findCheckoutFormIdsRecursively($value) as $candidate) {
                    $ids[$candidate] = true;
                }
            }
        }

        return array_keys($ids);
    }

    protected function renderLinkedOrderBody(?array $linkedOrder): string
    {
        if (!$linkedOrder) {
            return '';
        }

        $html = '<div class="aar-claim-order-link">';
        $html .= '<a class="btn btn-default aar-inline-order-button" href="' . Tools::safeOutput($linkedOrder['url']) . '" target="_blank" rel="noopener noreferrer">Otwórz zamówienie w PrestaShop</a>';
        if (!empty($linkedOrder['source'])) {
            $html .= '<div class="aar-claim-link-meta">Powiązano przez: ' . Tools::safeOutput($linkedOrder['source']) . '</div>';
        }
        $html .= '</div>';

        return $html;
    }

    protected function buildThreadPreview(array $thread): string
    {
        $preview = (string) ($thread['lastMessage']['text'] ?? $thread['snippet'] ?? $thread['subject'] ?? '');
        $preview = $this->decodeAllegroText($preview);
        $preview = preg_replace('/\s+/u', ' ', trim($preview));

        if ($preview === null || $preview === '') {
            return '';
        }

        return mb_strimwidth($preview, 0, 72, '...');
    }

    protected function buildIssuePreview(array $issue): string
    {
        $issueType = mb_strtoupper(trim((string) ($issue['type'] ?? '')));
        if ($issueType === 'CLAIM') {
            $parts = [];
            $buyerLogin = trim((string) ($issue['buyer']['login'] ?? ''));
            $expectations = trim($this->formatIssueExpectations($issue['expectations'] ?? []));
            $referenceNumber = trim((string) ($issue['referenceNumber'] ?? ''));

            if ($buyerLogin !== '') {
                $parts[] = $buyerLogin;
            }
            if ($expectations !== '') {
                $parts[] = $expectations;
            } elseif ($referenceNumber !== '') {
                $parts[] = 'Nr ' . $referenceNumber;
            }

            $preview = implode(' • ', $parts);
            if ($preview !== '') {
                return mb_strimwidth($preview, 0, 72, '...');
            }
        }

        $preview = $this->resolveIssueTextValue($issue['lastMessage']['text'] ?? null);
        if ($preview === '') {
            $preview = $this->formatIssueSubjectText($this->resolveIssueTextValue($issue['subject'] ?? null));
        }
        $preview = $this->decodeAllegroText($preview);
        $preview = preg_replace('/\s+/u', ' ', trim($preview));

        if ($preview === null || $preview === '') {
            return '';
        }

        return mb_strimwidth($preview, 0, 72, '...');
    }

    protected function buildIssueSubject(array $issue): string
    {
        $issueType = mb_strtoupper(trim((string) ($issue['type'] ?? '')));
        if ($issueType === 'CLAIM') {
            $reasonType = trim((string) ($issue['reason']['type'] ?? ''));
            $formattedReason = $this->formatIssueReasonType($reasonType);
            if ($formattedReason !== '') {
                return $formattedReason;
            }
        }

        $orderId = (string) ($issue['order']['id'] ?? $issue['buyer']['order']['id'] ?? '');
        $reason = $this->formatIssueSubjectText($this->resolveIssueTextValue($issue['reason']['name'] ?? null));
        if ($reason === '') {
            $reason = $this->formatIssueSubjectText($this->resolveIssueTextValue($issue['reason'] ?? null));
        }
        if ($reason === '') {
            $reason = $this->formatIssueSubjectText($this->resolveIssueTextValue($issue['subject'] ?? null));
        }
        $buyerLogin = (string) ($issue['buyer']['login'] ?? $issue['participant']['login'] ?? '');

        if ($reason !== '') {
            return $reason;
        }

        if ($orderId !== '') {
            return 'Zamówienie ' . $orderId;
        }

        if ($buyerLogin !== '') {
            return 'Klient: ' . $buyerLogin;
        }

        return 'Zgłoszenie Allegro';
    }

    protected function buildIssueHeaderTitle(array $issue): string
    {
        $issueType = mb_strtoupper(trim((string) ($issue['type'] ?? '')));
        if ($issueType === 'CLAIM') {
            $referenceNumber = trim((string) ($issue['referenceNumber'] ?? ''));
            if ($referenceNumber !== '') {
                return 'Reklamacja ' . $referenceNumber;
            }

            return 'Reklamacja Allegro';
        }

        return $this->buildIssueSubject($issue);
    }

    protected function buildIssueHeaderSubtitle(array $issue, string $sectionTitle): string
    {
        $issueType = mb_strtoupper(trim((string) ($issue['type'] ?? '')));
        if ($issueType === 'CLAIM') {
            $parts = [];
            $reasonType = trim((string) ($issue['reason']['type'] ?? ''));
            $formattedReason = $this->formatIssueReasonType($reasonType);
            $buyerLogin = trim((string) ($issue['buyer']['login'] ?? ''));

            if ($formattedReason !== '') {
                $parts[] = $formattedReason;
            }
            if ($buyerLogin !== '') {
                $parts[] = $buyerLogin;
            }

            if ($parts) {
                return implode(' • ', $parts);
            }
        }

        if ($issueType === 'DISPUTE') {
            $buyerLogin = trim((string) ($issue['buyer']['login'] ?? $issue['participant']['login'] ?? ''));
            if ($buyerLogin !== '') {
                return 'Dyskusja z ' . $buyerLogin;
            }

            return 'Dyskusja Allegro';
        }

        return trim($sectionTitle . ' Allegro');
    }

    protected function resolveIssueThumbnailUrl(array $issue, bool $allowPrestashopFallback = true): string
    {
        $offer = is_array($issue['offer'] ?? null) ? $issue['offer'] : [];
        $thumbnailContext = $this->extractIssueThumbnailContext($issue);
        $offerId = $thumbnailContext['offer_id'];
        $checkoutFormId = $thumbnailContext['checkout_form_id'];
        $issueId = $thumbnailContext['issue_id'];
        $cacheKeys = $this->buildIssueThumbnailCacheKeys($offerId, $checkoutFormId, '', $issueId);
        if ($allowPrestashopFallback) {
            $prestashopOfferThumbnailUrl = $this->findPrestashopProductThumbnailByOfferPayload($offer);
            if ($prestashopOfferThumbnailUrl !== '') {
                $this->storeIssueThumbnailCaches($cacheKeys, $prestashopOfferThumbnailUrl);
                return $prestashopOfferThumbnailUrl;
            }

            $prestashopOrderThumbnailUrl = $this->resolvePrestashopOrderThumbnailUrl($issue);
            if ($prestashopOrderThumbnailUrl !== '') {
                $this->storeIssueThumbnailCaches($cacheKeys, $prestashopOrderThumbnailUrl);
                return $prestashopOrderThumbnailUrl;
            }
        }

        $cachedUrl = $this->getIssueThumbnailFromCaches($cacheKeys);
        if ($cachedUrl !== '') {
            return $cachedUrl;
        }

        return '';
    }

    public function warmIssueThumbnailCache(string $offerId, string $productId = '', string $checkoutFormId = '', string $issueId = ''): string
    {
        $offerId = trim($offerId);
        $productId = trim($productId);
        $checkoutFormId = trim($checkoutFormId);
        $issueId = trim($issueId);

        try {
            $apiClient = new AllegroApiClient(new TokenManager());
            $thumbnailUrl = '';
            $issuePayload = [];
            $messages = [];

            if ($issueId !== '') {
                try {
                    $issuePayload = $apiClient->getIssue($issueId);
                    if (is_array($issuePayload) && $issuePayload) {
                        $thumbnailUrl = $this->resolveIssueThumbnailUrl($issuePayload, true);
                        $resolvedContext = $this->extractIssueThumbnailContext($issuePayload);
                        if ($offerId === '') {
                            $offerId = $resolvedContext['offer_id'];
                        }
                        if ($productId === '') {
                            $productId = $resolvedContext['product_id'];
                        }
                        if ($checkoutFormId === '') {
                            $checkoutFormId = $resolvedContext['checkout_form_id'];
                        }
                    }
                } catch (Throwable $e) {
                    $thumbnailUrl = '';
                }

                try {
                    $messagesResponse = $apiClient->getIssueChat($issueId, 100);
                    $messages = $messagesResponse['chat'] ?? $messagesResponse['messages'] ?? [];
                    if (is_array($messages)) {
                        if ($checkoutFormId === '') {
                            foreach ($messages as $message) {
                                if (!is_array($message)) {
                                    continue;
                                }

                                $messageCheckoutFormIds = $this->extractCheckoutFormIdsFromPayload($message);
                                if ($messageCheckoutFormIds) {
                                    $checkoutFormId = (string) $messageCheckoutFormIds[0];
                                    break;
                                }
                            }
                        }

                        if ($offerId === '') {
                            $messageOfferId = $this->extractOfferId($messages);
                            if ($messageOfferId !== null) {
                                $offerId = $messageOfferId;
                            }
                        }
                    }
                } catch (Throwable $e) {
                    // Chat context is optional for thumbnails.
                }
            }

            if ($thumbnailUrl === '' && is_array($issuePayload) && $issuePayload && is_array($messages)) {
                $thumbnailUrl = $this->resolvePrestashopOrderThumbnailUrl($issuePayload, $messages);
            }

            $cacheKeys = $this->buildIssueThumbnailCacheKeys($offerId, $checkoutFormId, '', $issueId);
            $cachedUrl = $this->getIssueThumbnailFromCaches($cacheKeys);
            if ($thumbnailUrl === '' && $cachedUrl !== '') {
                return $cachedUrl;
            }

            if ($thumbnailUrl === '' && $checkoutFormId !== '') {
                try {
                    $checkoutFormPayload = $apiClient->getCheckoutForm($checkoutFormId);
                    $thumbnailUrl = $this->findPrestashopProductThumbnailByCheckoutForm($checkoutFormPayload);
                    if ($thumbnailUrl === '') {
                        $resolvedOfferId = $this->extractFirstOfferIdFromCheckoutForm($checkoutFormPayload);
                        if ($resolvedOfferId !== '') {
                            $offerId = $resolvedOfferId;
                        }
                    }
                } catch (Throwable $e) {
                    $thumbnailUrl = '';
                }
            }

            if ($thumbnailUrl === '' && $offerId !== '') {
                try {
                    $offerPayload = $apiClient->getProductOffer($offerId);
                    $thumbnailUrl = $this->findPrestashopProductThumbnailByOfferPayload($offerPayload);
                } catch (Throwable $e) {
                    $thumbnailUrl = '';
                }
            }

            if ($thumbnailUrl === '' && $offerId !== '') {
                try {
                    $offerPayload = $apiClient->getOffer($offerId);
                    $thumbnailUrl = $this->findPrestashopProductThumbnailByOfferPayload($offerPayload);
                } catch (Throwable $e) {
                    $thumbnailUrl = '';
                }
            }

            if ($thumbnailUrl === '' && $productId !== '') {
                $productCacheKeys = $this->buildIssueThumbnailCacheKeys('', '', $productId, '');
                $cachedProductUrl = $this->getIssueThumbnailFromCaches($productCacheKeys);
                if ($cachedProductUrl !== '') {
                    return $cachedProductUrl;
                }

                try {
                    $productPayload = $apiClient->getProduct($productId);
                    $thumbnailUrl = $this->findPrestashopProductThumbnailByOfferPayload($productPayload);
                } catch (Throwable $e) {
                    $thumbnailUrl = '';
                }
            }

            if ($thumbnailUrl !== '') {
                $storeProductKey = $offerId === '' && $checkoutFormId === '' && $issueId === '' ? $productId : '';
                $this->storeIssueThumbnailCaches($this->buildIssueThumbnailCacheKeys($offerId, $checkoutFormId, $storeProductKey, $issueId), $thumbnailUrl);
            }

            return $thumbnailUrl;
        } catch (Throwable $e) {
            PrestaShopLogger::addLog('[AAR] Lazy thumbnail lookup failed for offer ' . $offerId . ' / product ' . $productId . ' / checkoutForm ' . $checkoutFormId . ' / issue ' . $issueId . ': ' . $e->getMessage(), 2);
        }

        return '';
    }

    protected function buildIssueThumbnailCacheKeys(string $offerId = '', string $checkoutFormId = '', string $productId = '', string $issueId = ''): array
    {
        $issueId = trim($issueId);
        if ($issueId !== '') {
            $keys = ['issue-ps-v1:' . $issueId => true];

            $offerId = trim($offerId);
            if ($offerId !== '') {
                $keys['offer-ps-v1:' . $offerId] = true;
            }

            $checkoutFormId = trim($checkoutFormId);
            if ($checkoutFormId !== '') {
                $keys['checkout-ps-v1:' . $checkoutFormId] = true;
            }

            return array_keys($keys);
        }

        $keys = [];
        $primaryKey = $this->buildIssueThumbnailCacheKey($offerId, $checkoutFormId, $productId);
        if ($primaryKey !== '') {
            $keys[$primaryKey] = true;
        }

        $offerId = trim($offerId);
        if ($offerId !== '') {
            $keys['offer-ps-v1:' . $offerId] = true;
        }

        $checkoutFormId = trim($checkoutFormId);
        if ($checkoutFormId !== '') {
            $keys['checkout-ps-v1:' . $checkoutFormId] = true;
        }

        $productId = trim($productId);
        if ($productId !== '') {
            $keys['product-ps-v1:' . $productId] = true;
        }

        return array_keys($keys);
    }

    protected function buildIssueThumbnailCacheKey(string $offerId = '', string $checkoutFormId = '', string $productId = ''): string
    {
        $offerId = trim($offerId);
        if ($offerId !== '') {
            return 'offer-ps-v1:' . $offerId;
        }

        $checkoutFormId = trim($checkoutFormId);
        if ($checkoutFormId !== '') {
            return 'checkout-ps-v1:' . $checkoutFormId;
        }

        $productId = trim($productId);
        if ($productId !== '') {
            return 'product-ps-v1:' . $productId;
        }

        return '';
    }

    protected function normalizeIssueImageUrl($value): string
    {
        if (is_string($value)) {
            $value = trim($value);
            if ($value !== '' && strpos($value, '//') === 0) {
                $value = 'https:' . $value;
            }
            if ($value !== '' && preg_match('~^https?://~i', $value) && $this->isAllowedIssueImageUrl($value)) {
                return $value;
            }
        }

        if (is_array($value) && !empty($value['url']) && is_string($value['url'])) {
            $url = trim($value['url']);
            if ($url !== '' && preg_match('~^https?://~i', $url) && $this->isAllowedIssueImageUrl($url)) {
                return $url;
            }
        }

        return '';
    }

    protected function isAllowedIssueImageUrl(string $url): bool
    {
        $host = strtolower((string) parse_url($url, PHP_URL_HOST));
        if ($host === '') {
            return false;
        }

        if ($host === 'api.allegro.pl' || substr($host, -15) === '.api.allegro.pl') {
            return false;
        }

        return true;
    }

    protected function extractIssueThumbnailContext(array $issue): array
    {
        $offerIds = $this->extractIssueOfferIdsFromPayload($issue);
        $productIds = $this->extractIssueProductIdsFromPayload($issue);
        $checkoutFormIds = $this->extractCheckoutFormIdsFromPayload($issue);

        return [
            'issue_id' => trim((string) ($issue['id'] ?? '')),
            'offer_id' => $offerIds[0] ?? '',
            'product_id' => $productIds[0] ?? '',
            'checkout_form_id' => $checkoutFormIds[0] ?? '',
        ];
    }

    protected function extractIssueOfferIdsFromPayload(array $payload, array $path = [], int $depth = 0): array
    {
        if ($depth > 8) {
            return [];
        }

        $ids = [];
        foreach ($payload as $key => $value) {
            $keyString = (string) $key;
            $normalizedKey = strtolower(preg_replace('/[^a-z0-9]/i', '', $keyString));
            $currentPath = array_merge($path, [$normalizedKey]);

            if (is_scalar($value)) {
                $candidate = $this->normalizeOptionalId($value);
                if ($candidate !== '' && $this->isIssueOfferIdPath($currentPath)) {
                    $ids[$candidate] = true;
                }

                continue;
            }

            if (is_array($value)) {
                if ($normalizedKey === 'offer' && is_scalar($value['id'] ?? null)) {
                    $candidate = $this->normalizeOptionalId($value['id']);
                    if ($candidate !== '') {
                        $ids[$candidate] = true;
                    }
                }

                foreach ($this->extractIssueOfferIdsFromPayload($value, $currentPath, $depth + 1) as $candidate) {
                    $ids[$candidate] = true;
                }
            }
        }

        return array_keys($ids);
    }

    protected function isIssueOfferIdPath(array $path): bool
    {
        $last = end($path);
        if (in_array($last, ['offerid', 'idoferta', 'idoferty'], true)) {
            return true;
        }

        if ($last !== 'id') {
            return false;
        }

        $previous = count($path) > 1 ? $path[count($path) - 2] : '';

        return $previous === 'offer' || $previous === 'offers';
    }

    protected function extractIssueProductIdsFromPayload(array $payload, array $path = [], int $depth = 0): array
    {
        if ($depth > 8) {
            return [];
        }

        $ids = [];
        foreach ($payload as $key => $value) {
            $keyString = (string) $key;
            $normalizedKey = strtolower(preg_replace('/[^a-z0-9]/i', '', $keyString));
            $currentPath = array_merge($path, [$normalizedKey]);

            if (is_scalar($value)) {
                $candidate = $this->normalizeOptionalId($value);
                if ($candidate !== '' && $this->isIssueProductIdPath($currentPath)) {
                    $ids[$candidate] = true;
                }

                continue;
            }

            if (is_array($value)) {
                if ($normalizedKey === 'product' && is_scalar($value['id'] ?? null)) {
                    $candidate = $this->normalizeOptionalId($value['id']);
                    if ($candidate !== '') {
                        $ids[$candidate] = true;
                    }
                }

                foreach ($this->extractIssueProductIdsFromPayload($value, $currentPath, $depth + 1) as $candidate) {
                    $ids[$candidate] = true;
                }
            }
        }

        return array_keys($ids);
    }

    protected function isIssueProductIdPath(array $path): bool
    {
        $last = end($path);
        if (in_array($last, ['productid', 'idproduct'], true)) {
            return true;
        }

        if ($last !== 'id') {
            return false;
        }

        $previous = count($path) > 1 ? $path[count($path) - 2] : '';

        return $previous === 'product' || $previous === 'products';
    }

    protected function maybeDumpIssueDebugPayload(string $selectedIssueId, array $selectedIssue, array $messagesResponse, array $messages, array $issues): void
    {
        if ((int) Tools::getValue('aar_debug_issue') !== 1 || $selectedIssueId === '') {
            return;
        }

        $debugDir = __DIR__ . '/var/debug';
        if (!is_dir($debugDir)) {
            @mkdir($debugDir, 0775, true);
        }

        if (!is_dir($debugDir) || !is_writable($debugDir)) {
            PrestaShopLogger::addLog('[AAR] Issue debug dump skipped. Directory is not writable: ' . $debugDir, 2);
            return;
        }

        $payload = [
            'generated_at' => date('c'),
            'selected_issue_id' => $selectedIssueId,
            'selected_issue' => $selectedIssue,
            'messages_response' => $messagesResponse,
            'messages_sorted' => $messages,
            'issues_list_item' => $this->findIssueById($issues, $selectedIssueId) ?: [],
        ];

        $filePath = $debugDir . '/issue-' . preg_replace('/[^a-zA-Z0-9_-]/', '-', $selectedIssueId) . '.json';
        $written = @file_put_contents($filePath, json_encode($payload, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));

        if ($written === false) {
            PrestaShopLogger::addLog('[AAR] Issue debug dump write failed for ' . $selectedIssueId, 2);
            return;
        }

        PrestaShopLogger::addLog('[AAR] Issue debug dump saved: ' . $filePath, 1);
    }

    protected function maybeDumpCustomerReturnDebugPayload(string $selectedReturnId, array $selectedReturn, array $returns, array $selectedReturnRaw = []): void
    {
        if ((int) Tools::getValue('aar_debug_return') !== 1 || $selectedReturnId === '') {
            return;
        }

        $debugDir = __DIR__ . '/var/debug';
        if (!is_dir($debugDir)) {
            @mkdir($debugDir, 0775, true);
        }

        if (!is_dir($debugDir) || !is_writable($debugDir)) {
            PrestaShopLogger::addLog('[AAR] Customer return debug dump skipped. Directory is not writable: ' . $debugDir, 2);
            return;
        }

        $payload = [
            'generated_at' => date('c'),
            'selected_return_id' => $selectedReturnId,
            'selected_return' => $selectedReturn,
            'selected_return_raw' => $selectedReturnRaw,
            'returns_list_item' => $this->findCustomerReturnById($returns, $selectedReturnId) ?: [],
        ];

        $filePath = $debugDir . '/customer-return-' . preg_replace('/[^a-zA-Z0-9_-]/', '-', $selectedReturnId) . '.json';
        $written = @file_put_contents($filePath, json_encode($payload, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));

        if ($written === false) {
            PrestaShopLogger::addLog('[AAR] Customer return debug dump write failed for ' . $selectedReturnId, 2);
            return;
        }

        PrestaShopLogger::addLog('[AAR] Customer return debug dump saved: ' . $filePath, 1);
    }

    protected function maybeDumpIssueOfferDebugPayload(AllegroApiClient $apiClient, array $selectedIssue): void
    {
        if ((int) Tools::getValue('aar_debug_issue') !== 1) {
            return;
        }

        $offerId = trim((string) (($selectedIssue['offer']['id'] ?? '')));
        if ($offerId === '') {
            return;
        }

        $debugDir = __DIR__ . '/var/debug';
        if (!is_dir($debugDir)) {
            @mkdir($debugDir, 0775, true);
        }

        if (!is_dir($debugDir) || !is_writable($debugDir)) {
            PrestaShopLogger::addLog('[AAR] Offer debug dump skipped. Directory is not writable: ' . $debugDir, 2);
            return;
        }

        $payload = [
            'generated_at' => date('c'),
            'offer_id' => $offerId,
            'product_offer' => null,
            'product_offer_error' => null,
            'offer' => null,
            'offer_error' => null,
        ];

        try {
            $payload['product_offer'] = $apiClient->getProductOffer($offerId);
        } catch (Throwable $e) {
            $payload['product_offer_error'] = $e->getMessage();
        }

        try {
            $payload['offer'] = $apiClient->getOffer($offerId);
        } catch (Throwable $e) {
            $payload['offer_error'] = $e->getMessage();
        }

        $filePath = $debugDir . '/offer-' . preg_replace('/[^a-zA-Z0-9_-]/', '-', $offerId) . '.json';
        $written = @file_put_contents($filePath, json_encode($payload, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));

        if ($written === false) {
            PrestaShopLogger::addLog('[AAR] Offer debug dump write failed for ' . $offerId, 2);
            return;
        }

        PrestaShopLogger::addLog('[AAR] Offer debug dump saved: ' . $filePath, 1);
    }

    protected function maybeDumpIssueCheckoutFormDebugPayload(AllegroApiClient $apiClient, array $selectedIssue): void
    {
        if ((int) Tools::getValue('aar_debug_issue') !== 1) {
            return;
        }

        $checkoutFormId = $this->extractIssueCheckoutFormId($selectedIssue);
        if ($checkoutFormId === '') {
            return;
        }

        $debugDir = __DIR__ . '/var/debug';
        if (!is_dir($debugDir)) {
            @mkdir($debugDir, 0775, true);
        }

        if (!is_dir($debugDir) || !is_writable($debugDir)) {
            PrestaShopLogger::addLog('[AAR] Checkout form debug dump skipped. Directory is not writable: ' . $debugDir, 2);
            return;
        }

        $payload = [
            'generated_at' => date('c'),
            'checkout_form_id' => $checkoutFormId,
            'checkout_form' => null,
            'checkout_form_error' => null,
            'first_offer_id' => null,
            'product_offer' => null,
            'product_offer_error' => null,
            'offer' => null,
            'offer_error' => null,
        ];

        try {
            $payload['checkout_form'] = $apiClient->getCheckoutForm($checkoutFormId);
        } catch (Throwable $e) {
            $payload['checkout_form_error'] = $e->getMessage();
        }

        $firstOfferId = '';
        if (is_array($payload['checkout_form'])) {
            $firstOfferId = $this->extractFirstOfferIdFromCheckoutForm($payload['checkout_form']);
        }

        if ($firstOfferId !== '') {
            $payload['first_offer_id'] = $firstOfferId;

            try {
                $payload['product_offer'] = $apiClient->getProductOffer($firstOfferId);
            } catch (Throwable $e) {
                $payload['product_offer_error'] = $e->getMessage();
            }

            try {
                $payload['offer'] = $apiClient->getOffer($firstOfferId);
            } catch (Throwable $e) {
                $payload['offer_error'] = $e->getMessage();
            }
        }

        $filePath = $debugDir . '/checkout-form-' . preg_replace('/[^a-zA-Z0-9_-]/', '-', $checkoutFormId) . '.json';
        $written = @file_put_contents($filePath, json_encode($payload, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));

        if ($written === false) {
            PrestaShopLogger::addLog('[AAR] Checkout form debug dump write failed for ' . $checkoutFormId, 2);
            return;
        }

        PrestaShopLogger::addLog('[AAR] Checkout form debug dump saved: ' . $filePath, 1);
    }

    protected function findImageUrlRecursively(array $payload, int $depth = 0): string
    {
        if ($depth > 6) {
            return '';
        }

        foreach ($payload as $key => $value) {
            if (is_string($value)) {
                $url = trim($value);
                if (
                    $url !== ''
                    && preg_match('~^https?://~i', $url)
                    && $this->isAllowedIssueImageUrl($url)
                    && (
                        stripos($url, 'allegroimg.com') !== false
                        || preg_match('~(^|_)(img|image|thumbnail)(_|$)~i', (string) $key)
                    )
                ) {
                    return $url;
                }

                continue;
            }

            if (is_array($value)) {
                $directUrl = $this->normalizeIssueImageUrl($value);
                if ($directUrl !== '') {
                    return $directUrl;
                }

                $nestedUrl = $this->findImageUrlRecursively($value, $depth + 1);
                if ($nestedUrl !== '') {
                    return $nestedUrl;
                }
            }
        }

        return '';
    }

    protected function getIssueThumbnailCache(): array
    {
        $raw = Configuration::get(self::ISSUE_THUMB_CACHE_CONFIG);
        $cache = json_decode((string) $raw, true);

        return is_array($cache) ? $cache : [];
    }

    protected function getIssueThumbnailFromCache(string $offerId): string
    {
        if ($offerId === '') {
            return '';
        }

        $cache = $this->getIssueThumbnailCache();
        $url = $cache[$offerId] ?? '';

        return is_string($url) ? $this->normalizeIssueImageUrl($url) : '';
    }

    protected function getIssueThumbnailFromCaches(array $cacheKeys): string
    {
        foreach ($cacheKeys as $cacheKey) {
            $cachedUrl = $this->getIssueThumbnailFromCache((string) $cacheKey);
            if ($cachedUrl !== '') {
                return $cachedUrl;
            }
        }

        return '';
    }

    protected function storeIssueThumbnailCache(string $offerId, string $imageUrl): void
    {
        $offerId = trim($offerId);
        $imageUrl = trim($imageUrl);
        if ($offerId === '' || $imageUrl === '') {
            return;
        }

        $cache = $this->getIssueThumbnailCache();
        $cache[$offerId] = $imageUrl;

        if (count($cache) > 500) {
            $cache = array_slice($cache, -500, null, true);
        }

        Configuration::updateValue(self::ISSUE_THUMB_CACHE_CONFIG, json_encode($cache, JSON_UNESCAPED_SLASHES));
    }

    protected function storeIssueThumbnailCaches(array $cacheKeys, string $imageUrl): void
    {
        foreach ($cacheKeys as $cacheKey) {
            $this->storeIssueThumbnailCache((string) $cacheKey, $imageUrl);
        }
    }

    protected function fetchIssueThumbnailFromPublicOfferPage(string $offerId): string
    {
        $offerId = trim($offerId);
        if ($offerId === '') {
            return '';
        }

        $url = 'https://allegro.pl/oferta/' . rawurlencode($offerId);
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 5);
        curl_setopt($ch, CURLOPT_TIMEOUT, 8);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'User-Agent: PrestaShop-AllegroCustomerSupport/0.1',
            'Accept-Language: pl-PL,pl;q=0.9,en;q=0.8',
        ]);

        $html = curl_exec($ch);
        $httpCode = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $curlError = curl_error($ch);
        curl_close($ch);

        if (!is_string($html) || $html === '' || $httpCode >= 400) {
            if ($curlError !== '' || $httpCode >= 400) {
                PrestaShopLogger::addLog('[AAR] Public offer thumbnail lookup failed for offer ' . $offerId . ': HTTP ' . $httpCode . ' ' . $curlError, 2);
            }

            return '';
        }

        $patterns = [
            '/<meta[^>]+property=["\']og:image["\'][^>]+content=["\']([^"\']+)["\']/i',
            '/<meta[^>]+content=["\']([^"\']+)["\'][^>]+property=["\']og:image["\']/i',
            '/https?:\/\/[^"\']*allegroimg\.com\/[^"\']+/i',
        ];

        foreach ($patterns as $pattern) {
            if (!preg_match($pattern, $html, $matches)) {
                continue;
            }

            $candidate = trim((string) ($matches[1] ?? $matches[0] ?? ''));
            $imageUrl = $this->normalizeIssueImageUrl($candidate);
            if ($imageUrl !== '') {
                return $imageUrl;
            }
        }

        return '';
    }

    protected function getIssueThumbnailImageUrl(array $issue): string
    {
        $thumbnailContext = $this->extractIssueThumbnailContext($issue);
        $offerId = $thumbnailContext['offer_id'];
        $productId = $thumbnailContext['product_id'];
        $checkoutFormId = $thumbnailContext['checkout_form_id'];
        $issueId = $thumbnailContext['issue_id'];

        if ($offerId === '' && $productId === '' && $checkoutFormId === '' && $issueId === '') {
            return '';
        }

        return $this->context->link->getModuleLink($this->name, 'thumbnail', [
            'token' => (string) Configuration::get(self::CONFIG_PREFIX . 'CRON_TOKEN'),
            'offer_id' => $offerId,
            'product_id' => $issueId === '' ? $productId : '',
            'checkout_form_id' => $checkoutFormId,
            'issue_id' => $issueId,
            'mode' => 'image',
        ]);
    }

    protected function getThumbnailImageFallbackAttributes(): string
    {
        return 'onload="if(this.nextElementSibling){ this.nextElementSibling.style.display=\'none\'; }" onerror="this.style.display=\'none\'; if(this.nextElementSibling){ this.nextElementSibling.style.display=\'block\'; }"';
    }

    protected function getCustomerReturnThumbnailImageUrl(array $return): string
    {
        $checkoutForm = is_array($return['_checkout_form'] ?? null) ? $return['_checkout_form'] : [];
        if ($checkoutForm) {
            $prestashopThumbnailUrl = $this->findPrestashopProductThumbnailByCheckoutForm($checkoutForm);
            if ($prestashopThumbnailUrl !== '') {
                return $prestashopThumbnailUrl;
            }
        }

        foreach (($return['items'] ?? []) as $item) {
            if (!is_array($item)) {
                continue;
            }

            $prestashopThumbnailUrl = $this->findPrestashopProductThumbnailByReturnItem($item);
            if ($prestashopThumbnailUrl !== '') {
                return $prestashopThumbnailUrl;
            }
        }

        $offerId = '';
        foreach (($return['items'] ?? []) as $item) {
            if (!is_array($item)) {
                continue;
            }

            $offerId = trim((string) ($item['offerId'] ?? ''));
            if ($offerId !== '') {
                break;
            }
        }

        $checkoutFormId = trim((string) ($return['orderId'] ?? ''));
        if ($offerId === '' && $checkoutFormId === '') {
            foreach (($return['items'] ?? []) as $item) {
                if (!is_array($item)) {
                    continue;
                }

                $directUrl = $this->resolveCustomerReturnItemThumbnailUrl($item, $return);
                if ($directUrl !== '') {
                    return $directUrl;
                }
            }

            return '';
        }

        return $this->context->link->getModuleLink($this->name, 'thumbnail', [
            'token' => (string) Configuration::get(self::CONFIG_PREFIX . 'CRON_TOKEN'),
            'offer_id' => $offerId,
            'checkout_form_id' => $checkoutFormId,
            'mode' => 'image',
        ]);
    }

    protected function resolveCustomerReturnItemThumbnailUrl(array $item, array $return = []): string
    {
        $prestashopThumbnailUrl = $this->findPrestashopProductThumbnailByReturnItem($item);
        if ($prestashopThumbnailUrl !== '') {
            return $prestashopThumbnailUrl;
        }

        foreach ([
            $item['imageUrl'] ?? null,
            $item['thumbnailUrl'] ?? null,
            $item['image'] ?? null,
            $item['thumbnail'] ?? null,
            $item['offer']['imageUrl'] ?? null,
            $item['offer']['image'] ?? null,
            $item['offer']['thumbnail'] ?? null,
        ] as $candidate) {
            $imageUrl = $this->normalizeIssueImageUrl($candidate);
            if ($imageUrl !== '') {
                return $imageUrl;
            }
        }

        foreach (['images', 'thumbnails'] as $key) {
            foreach (($item[$key] ?? []) as $image) {
                $imageUrl = $this->normalizeIssueImageUrl($image);
                if ($imageUrl !== '') {
                    return $imageUrl;
                }
            }
        }

        $recursiveUrl = $this->findImageUrlRecursively($item);
        if ($recursiveUrl !== '') {
            return $recursiveUrl;
        }

        $offerId = trim((string) ($item['offerId'] ?? ''));
        $checkoutFormId = trim((string) ($return['orderId'] ?? ''));
        if ($offerId === '' && $checkoutFormId === '') {
            return '';
        }

        return $this->context->link->getModuleLink($this->name, 'thumbnail', [
            'token' => (string) Configuration::get(self::CONFIG_PREFIX . 'CRON_TOKEN'),
            'offer_id' => $offerId,
            'checkout_form_id' => $checkoutFormId,
            'mode' => 'image',
        ]);
    }


    protected function extractFirstImageUrlFromOffer(array $offer, bool $allowCatalogProductImages = true): string
    {
        $prestashopThumbnailUrl = $this->findPrestashopProductThumbnailByOfferPayload($offer);
        if ($prestashopThumbnailUrl !== '') {
            return $prestashopThumbnailUrl;
        }

        $directCandidates = [
            $offer['imageUrl'] ?? null,
            $offer['image']['url'] ?? null,
            $offer['image'] ?? null,
            $offer['thumbnailUrl'] ?? null,
            $offer['thumbnail']['url'] ?? null,
            $offer['thumbnail'] ?? null,
            $offer['primaryImage']['url'] ?? null,
            $offer['primaryImage'] ?? null,
            $offer['representativeImage']['url'] ?? null,
            $offer['representativeImage'] ?? null,
            $offer['coverImage']['url'] ?? null,
            $offer['coverImage'] ?? null,
            $offer['imageUrlTemplate'] ?? null,
        ];

        foreach ($directCandidates as $candidate) {
            $imageUrl = $this->normalizeIssueImageUrl($candidate);
            if ($imageUrl !== '') {
                return $imageUrl;
            }
        }

        foreach (($offer['images'] ?? []) as $image) {
            $imageUrl = $this->normalizeIssueImageUrl($image);
            if ($imageUrl !== '') {
                return $imageUrl;
            }
        }

        if ($allowCatalogProductImages) {
            foreach (($offer['productSet'] ?? []) as $productSet) {
                if (!is_array($productSet)) {
                    continue;
                }

                foreach (($productSet['product']['images'] ?? []) as $image) {
                    $imageUrl = $this->normalizeIssueImageUrl($image);
                    if ($imageUrl !== '') {
                        return $imageUrl;
                    }
                }
            }
        }

        $recursiveUrl = $this->findImageUrlRecursively($allowCatalogProductImages ? $offer : $this->removeCatalogProductImageSources($offer));
        if ($recursiveUrl !== '') {
            return $recursiveUrl;
        }

        return '';
    }

    protected function extractFirstImageUrlFromCheckoutForm(array $checkoutForm, bool $allowCatalogProductImages = true): string
    {
        foreach (($checkoutForm['lineItems'] ?? []) as $lineItem) {
            if (!is_array($lineItem)) {
                continue;
            }

            $offerPayload = is_array($lineItem['offer'] ?? null) ? $lineItem['offer'] : [];
            if ($offerPayload) {
                $imageUrl = $this->extractFirstImageUrlFromOffer($offerPayload, $allowCatalogProductImages);
                if ($imageUrl !== '') {
                    return $imageUrl;
                }
            }

            if ($allowCatalogProductImages) {
                foreach (($lineItem['offer']['productSet'] ?? []) as $productSet) {
                    if (!is_array($productSet)) {
                        continue;
                    }

                    $imageUrl = $this->extractFirstImageUrlFromOffer($productSet);
                    if ($imageUrl !== '') {
                        return $imageUrl;
                    }
                }
            }
        }

        return $allowCatalogProductImages ? $this->findImageUrlRecursively($checkoutForm) : '';
    }

    protected function removeCatalogProductImageSources(array $payload): array
    {
        unset($payload['productSet'], $payload['product'], $payload['products']);

        return $payload;
    }

    protected function issueAllowsCatalogProductThumbnails(array $issue): bool
    {
        $issueType = mb_strtoupper(trim((string) ($issue['type'] ?? '')));

        return $issueType !== 'CLAIM';
    }

    protected function extractFirstOfferIdFromCheckoutForm(array $checkoutForm): string
    {
        foreach (($checkoutForm['lineItems'] ?? []) as $lineItem) {
            if (!is_array($lineItem)) {
                continue;
            }

            $offerId = trim((string) (($lineItem['offer']['id'] ?? '')));
            if ($offerId !== '') {
                return $offerId;
            }
        }

        return '';
    }

    protected function findPrestashopProductThumbnailByCheckoutForm(array $checkoutForm): string
    {
        foreach (($checkoutForm['lineItems'] ?? []) as $lineItem) {
            if (!is_array($lineItem)) {
                continue;
            }

            $externalId = trim((string) (($lineItem['offer']['external']['id'] ?? '')));
            if ($externalId !== '') {
                $thumbnailUrl = $this->findPrestashopProductThumbnailByIdentifier($externalId);
                if ($thumbnailUrl !== '') {
                    return $thumbnailUrl;
                }
            }

            $offerId = trim((string) (($lineItem['offer']['id'] ?? '')));
            if ($offerId !== '') {
                $thumbnailUrl = $this->findPrestashopProductThumbnailByIdentifier($offerId);
                if ($thumbnailUrl !== '') {
                    return $thumbnailUrl;
                }
            }

            $offerName = trim((string) (($lineItem['offer']['name'] ?? '')));
            if ($offerName !== '') {
                $thumbnailUrl = $this->findPrestashopProductThumbnailByName($offerName);
                if ($thumbnailUrl !== '') {
                    return $thumbnailUrl;
                }
            }
        }

        return '';
    }

    protected function findPrestashopProductThumbnailByOfferPayload(array $offer): string
    {
        $offerId = trim((string) ($offer['id'] ?? $offer['offer']['id'] ?? ''));
        if ($offerId !== '') {
            $thumbnailUrl = $this->findPrestashopProductThumbnailByIdentifier($offerId);
            if ($thumbnailUrl !== '') {
                return $thumbnailUrl;
            }
        }

        foreach ($this->extractPrestashopProductIdentifiersFromPayload($offer) as $identifier) {
            $thumbnailUrl = $this->findPrestashopProductThumbnailByIdentifier($identifier);
            if ($thumbnailUrl !== '') {
                return $thumbnailUrl;
            }
        }

        foreach ($this->extractPrestashopProductNamesFromPayload($offer) as $name) {
            $thumbnailUrl = $this->findPrestashopProductThumbnailByName($name);
            if ($thumbnailUrl !== '') {
                return $thumbnailUrl;
            }
        }

        return '';
    }

    protected function findPrestashopProductThumbnailByReturnItem(array $item): string
    {
        foreach ($this->extractPrestashopProductIdentifiersFromPayload($item) as $identifier) {
            $thumbnailUrl = $this->findPrestashopProductThumbnailByIdentifier($identifier);
            if ($thumbnailUrl !== '') {
                return $thumbnailUrl;
            }
        }

        $offerId = trim((string) ($item['offerId'] ?? $item['offer']['id'] ?? ''));
        if ($offerId !== '') {
            $thumbnailUrl = $this->findPrestashopProductThumbnailByIdentifier($offerId);
            if ($thumbnailUrl !== '') {
                return $thumbnailUrl;
            }
        }

        foreach ($this->extractPrestashopProductNamesFromPayload($item) as $name) {
            $thumbnailUrl = $this->findPrestashopProductThumbnailByName($name);
            if ($thumbnailUrl !== '') {
                return $thumbnailUrl;
            }
        }

        return '';
    }

    protected function extractPrestashopProductIdentifiersFromPayload(array $payload): array
    {
        $candidates = [
            $payload['external']['id'] ?? null,
            $payload['externalId'] ?? null,
            $payload['external_id'] ?? null,
            $payload['reference'] ?? null,
            $payload['sku'] ?? null,
            $payload['ean'] ?? null,
            $payload['ean13'] ?? null,
            $payload['gtin'] ?? null,
            $payload['barcode'] ?? null,
            $payload['producerCode'] ?? null,
            $payload['product']['external']['id'] ?? null,
            $payload['product']['reference'] ?? null,
            $payload['product']['sku'] ?? null,
            $payload['product']['ean'] ?? null,
            $payload['product']['ean13'] ?? null,
            $payload['offer']['external']['id'] ?? null,
            $payload['offer']['externalId'] ?? null,
            $payload['offer']['reference'] ?? null,
            $payload['offer']['sku'] ?? null,
            $payload['offer']['ean'] ?? null,
            $payload['offer']['ean13'] ?? null,
        ];
        $identifiers = [];

        foreach ($candidates as $candidate) {
            if (!is_scalar($candidate)) {
                continue;
            }

            $identifier = trim((string) $candidate);
            if ($identifier !== '') {
                $identifiers[$identifier] = true;
            }
        }

        return array_keys($identifiers);
    }

    protected function extractPrestashopProductNamesFromPayload(array $payload): array
    {
        $candidates = [
            $payload['name'] ?? null,
            $payload['title'] ?? null,
            $payload['product']['name'] ?? null,
            $payload['product']['title'] ?? null,
            $payload['offer']['name'] ?? null,
            $payload['offer']['title'] ?? null,
        ];
        $names = [];

        foreach ($candidates as $candidate) {
            if (!is_scalar($candidate)) {
                continue;
            }

            $name = trim((string) $candidate);
            if ($name !== '') {
                $names[$name] = true;
            }
        }

        return array_keys($names);
    }

    protected function findPrestashopProductThumbnailByIdentifier(string $identifier): string
    {
        $identifier = trim($identifier);
        if ($identifier === '') {
            return '';
        }

        $sql = 'SELECT p.`id_product`
            FROM `' . _DB_PREFIX_ . 'product` p
            WHERE p.`ean13` = "' . pSQL($identifier) . '"
                OR p.`reference` = "' . pSQL($identifier) . '"
                OR p.`supplier_reference` = "' . pSQL($identifier) . '"
                OR p.`upc` = "' . pSQL($identifier) . '"
            ORDER BY p.`id_product` ASC
            LIMIT 1';

        try {
            $row = Db::getInstance()->getRow($sql);
        } catch (Throwable $e) {
            PrestaShopLogger::addLog('[AAR] PrestaShop product thumbnail lookup by identifier skipped: ' . $e->getMessage(), 2);
            return '';
        }
        $idProduct = (int) ($row['id_product'] ?? 0);

        return $this->getPrestashopProductThumbnailUrl($idProduct);
    }

    protected function findPrestashopProductThumbnailByName(string $name): string
    {
        $name = trim($name);
        if ($name === '') {
            return '';
        }

        $idLang = (int) ($this->context->language->id ?? Configuration::get('PS_LANG_DEFAULT'));
        $idShop = (int) ($this->context->shop->id ?? Context::getContext()->shop->id ?? 1);

        $sql = 'SELECT pl.`id_product`
            FROM `' . _DB_PREFIX_ . 'product_lang` pl
            WHERE pl.`id_lang` = ' . (int) $idLang . '
                AND pl.`id_shop` = ' . (int) $idShop . '
                AND (
                    pl.`name` = "' . pSQL($name) . '"
                    OR pl.`name` LIKE "%' . pSQL($name) . '%"
                    OR "' . pSQL($name) . '" LIKE CONCAT("%", pl.`name`, "%")
                )
            ORDER BY
                CASE WHEN pl.`name` = "' . pSQL($name) . '" THEN 0 ELSE 1 END,
                CHAR_LENGTH(pl.`name`) ASC,
                pl.`id_product` ASC
            LIMIT 1';

        try {
            $row = Db::getInstance()->getRow($sql);
        } catch (Throwable $e) {
            PrestaShopLogger::addLog('[AAR] PrestaShop product thumbnail lookup by name skipped: ' . $e->getMessage(), 2);
            return '';
        }
        $idProduct = (int) ($row['id_product'] ?? 0);

        return $this->getPrestashopProductThumbnailUrl($idProduct);
    }

    protected function getPrestashopProductThumbnailUrl(int $idProduct): string
    {
        if ($idProduct <= 0) {
            return '';
        }

        $idLang = (int) ($this->context->language->id ?? Configuration::get('PS_LANG_DEFAULT'));
        $idShop = (int) ($this->context->shop->id ?? Context::getContext()->shop->id ?? 1);

        $sql = 'SELECT pl.`link_rewrite`, i.`id_image`
            FROM `' . _DB_PREFIX_ . 'product_lang` pl
            INNER JOIN `' . _DB_PREFIX_ . 'image` i
                ON (i.`id_product` = pl.`id_product`)
            WHERE pl.`id_product` = ' . (int) $idProduct . '
                AND pl.`id_lang` = ' . (int) $idLang . '
                AND pl.`id_shop` = ' . (int) $idShop . '
            ORDER BY i.`cover` DESC, i.`position` ASC, i.`id_image` ASC
            LIMIT 1';

        try {
            $row = Db::getInstance()->getRow($sql);
        } catch (Throwable $e) {
            PrestaShopLogger::addLog('[AAR] PrestaShop product image lookup skipped for product #' . (int) $idProduct . ': ' . $e->getMessage(), 2);
            return '';
        }
        if (!is_array($row) || (int) ($row['id_image'] ?? 0) <= 0) {
            return '';
        }

        $linkRewrite = trim((string) ($row['link_rewrite'] ?? ''));
        if ($linkRewrite === '') {
            return '';
        }

        return (string) $this->context->link->getImageLink($linkRewrite, (string) $row['id_image'], 'small_default');
    }

    protected function renderIssuesFilters(string $issueKind, string $statusFilter, bool $showIssueKindFilter = true): string
    {
        $html = '<form method="get" action="' . Tools::safeOutput($this->getCurrentIssuesFilterActionUrl()) . '" class="aar-issues-filters">';
        $currentController = trim((string) Tools::getValue('controller'));
        $currentToken = trim((string) Tools::getAdminTokenLite($currentController !== '' ? $currentController : 'AdminAllegroAutoresponderComplaints'));
        if ($currentController !== '') {
            $html .= '<input type="hidden" name="controller" value="' . Tools::safeOutput($currentController) . '">';
        }
        if ($currentToken !== '') {
            $html .= '<input type="hidden" name="token" value="' . Tools::safeOutput($currentToken) . '">';
        }
        if ($showIssueKindFilter) {
            $html .= '<div class="aar-filter-group">';
            $html .= '<label for="aar-issue-kind-filter">Typ zgłoszenia</label>';
            $html .= '<select id="aar-issue-kind-filter" name="issue_kind" class="form-control" onchange="this.form.submit()">';
            foreach ($this->getIssueKindFilterOptions() as $value => $label) {
                $html .= '<option value="' . Tools::safeOutput($value) . '"' . ($issueKind === $value ? ' selected' : '') . '>' . Tools::safeOutput($label) . '</option>';
            }
            $html .= '</select>';
            $html .= '</div>';
        } else {
            $html .= '<input type="hidden" name="issue_kind" value="' . Tools::safeOutput($issueKind) . '">';
        }
        $html .= '<div class="aar-filter-group">';
        $html .= '<label for="aar-status-filter">Status</label>';
        $html .= '<select id="aar-status-filter" name="status_filter" class="form-control" onchange="this.form.submit()">';
        foreach ($this->getIssueStatusFilterOptions() as $value => $label) {
            $html .= '<option value="' . Tools::safeOutput($value) . '"' . ($statusFilter === $value ? ' selected' : '') . '>' . Tools::safeOutput($label) . '</option>';
        }
        $html .= '</select>';
        $html .= '</div>';
        $html .= '</form>';

        return $html;
    }

    protected function renderIssuesToolbar(string $issueType): string
    {
        $issueKind = $this->getCurrentIssueKindFilter($issueType);
        $statusFilter = $this->getCurrentIssueStatusFilter();
        $showIssueKindFilter = mb_strtoupper($issueType) === 'ALL';

        $html = '<style>
            .aar-issues-toolbar {
                display: flex;
                justify-content: flex-end;
                align-items: center;
                gap: 12px;
                margin: 0 0 12px;
            }
            .aar-issues-toolbar-mounted {
                display: inline-flex;
                margin: 0;
                width: auto;
                flex: 0 0 auto;
            }
            .aar-issues-toolbar-item {
                display: inline-flex !important;
                align-items: center !important;
                margin: 0 !important;
                padding: 0 !important;
                list-style: none !important;
                float: none !important;
                flex: 0 0 auto !important;
            }
            .aar-issues-toolbar-mounted-fallback {
                display: flex;
                justify-content: flex-end;
            }
            .aar-issues-toolbar-host {
                display: flex !important;
                align-items: center !important;
                gap: 12px !important;
                margin: 0 !important;
                float: none !important;
                width: auto !important;
                flex-wrap: nowrap !important;
            }
            .btn-toolbar.aar-issues-toolbar-host,
            .toolbarBox .btn-toolbar.aar-issues-toolbar-host,
            .toolbarBox .btn-toolbar .nav.aar-issues-toolbar-host {
                display: inline-flex !important;
                align-items: center !important;
                justify-content: flex-end !important;
                gap: 12px !important;
                flex-wrap: nowrap !important;
                width: auto !important;
            }
            .aar-issues-toolbar-host > *,
            .aar-issues-toolbar-host > li,
            .aar-issues-toolbar-host > a {
                flex: 0 0 auto;
            }
            .aar-issues-toolbar .aar-issues-filters {
                display: flex;
                align-items: center;
                gap: 12px;
                margin: 0;
            }
            .aar-issues-toolbar .aar-filter-group {
                display: flex;
                align-items: center;
                gap: 8px;
            }
            .aar-issues-toolbar .aar-filter-group label {
                margin: 0;
                font-size: 12px;
                font-weight: 700;
                color: #7a8288;
                text-transform: uppercase;
                letter-spacing: .04em;
                white-space: nowrap;
            }
            .aar-issues-toolbar .aar-filter-group .form-control {
                width: 170px;
                height: 36px;
                min-height: 0;
                border-radius: 6px;
                box-shadow: none;
            }
            @media (max-width: 991px) {
                .aar-issues-toolbar,
                .aar-issues-toolbar .aar-issues-filters {
                    flex-wrap: wrap;
                    justify-content: flex-start;
                }
            }
        </style>';
        $html .= '<div class="aar-issues-toolbar">';
        $html .= $this->renderIssuesFilters($issueKind, $statusFilter, $showIssueKindFilter);
        $html .= '</div>';
        $html .= '<script>
            document.addEventListener("DOMContentLoaded", function () {
                var filters = document.querySelector(".aar-issues-toolbar");
                if (!filters) {
                    return;
                }

                var refreshButton = document.querySelector("a[href*=\'aar_refresh\']");
                if (!refreshButton) {
                    refreshButton = document.querySelector(".process-icon-refresh");
                    refreshButton = refreshButton ? refreshButton.closest("a, button") : null;
                }

                if (refreshButton) {
                    var refreshItem = refreshButton;
                    while (refreshItem && refreshItem.parentNode && refreshItem.parentNode !== document.body) {
                        var tag = refreshItem.tagName ? refreshItem.tagName.toLowerCase() : "";
                        if (tag === "li") {
                            break;
                        }
                        if (refreshItem.parentNode && refreshItem.parentNode.classList && refreshItem.parentNode.classList.contains("btn-toolbar")) {
                            break;
                        }
                        refreshItem = refreshItem.parentNode;
                    }

                    var host = refreshItem && refreshItem.parentNode ? refreshItem.parentNode : refreshButton.parentNode;
                    var insertionPoint = refreshItem || refreshButton;
                    if (host && host.tagName && host.tagName.toLowerCase() === "a") {
                        insertionPoint = host;
                        host = host.parentNode;
                    }

                    if (host) {
                        if (host.tagName && ["ul", "ol"].indexOf(host.tagName.toLowerCase()) !== -1) {
                            var item = document.createElement("li");
                            item.className = "aar-issues-toolbar-item";
                            item.appendChild(filters);
                            host.insertBefore(item, insertionPoint);
                        } else {
                            host.insertBefore(filters, insertionPoint);
                        }
                        host.classList.add("aar-issues-toolbar-host");
                    } else {
                        filters.classList.add("aar-issues-toolbar-mounted-fallback");
                        return;
                    }
                    filters.classList.add("aar-issues-toolbar-mounted");
                    return;
                }

                filters.classList.add("aar-issues-toolbar-mounted-fallback");
            });
        </script>';

        return $html;
    }

    protected function renderReturnsToolbar(): string
    {
        $statusFilter = $this->getCurrentReturnStatusFilter();
        $dateRange = $this->getCurrentReturnDateRangeFilter();
        $query = trim((string) Tools::getValue('return_query'));
        $refreshUrl = $this->getReturnsAdminUrl([
            'aar_refresh' => 1,
            '_refresh' => time(),
        ]);
        $clearUrl = $this->context->link->getAdminLink('AdminAllegroAutoresponderReturns', true);

        $html = '<style>
            .aar-returns-toolbar {
                width: 100%;
                display: flex;
                justify-content: space-between;
                align-items: center;
                gap: 14px;
                margin: 0 0 14px;
                padding: 12px 14px;
                background: #ffffff;
                border: 1px solid #d8dde0;
                border-radius: 6px;
                box-shadow: 0 1px 2px rgba(16, 24, 40, .04);
            }
            .aar-returns-filters {
                display: grid;
                grid-template-columns: minmax(130px, 160px) minmax(130px, 160px) minmax(260px, 1fr) auto auto;
                align-items: stretch;
                gap: 10px;
                margin: 0;
                flex: 1 1 auto;
                min-width: 0;
            }
            .aar-returns-filters .form-control {
                height: 36px;
                min-height: 0;
                border-radius: 6px;
                box-shadow: none;
            }
            .aar-returns-filters select {
                width: 100%;
            }
            .aar-returns-filters input[type=text] {
                width: 100%;
            }
            .aar-returns-toolbar .btn {
                height: 36px;
                display: inline-flex;
                align-items: center;
                justify-content: center;
                border-radius: 6px;
                font-weight: 700;
                white-space: nowrap;
                padding-left: 14px;
                padding-right: 14px;
            }
            .aar-returns-toolbar-actions {
                display: flex;
                align-items: center;
                gap: 10px;
                flex: 0 0 auto;
            }
            .aar-returns-toolbar .aar-refresh-button {
                background: #25b9d7;
                border-color: #25b9d7;
                color: #ffffff;
                min-width: 118px;
            }
            .aar-returns-toolbar .aar-refresh-button:hover,
            .aar-returns-toolbar .aar-refresh-button:focus {
                background: #178ca6;
                border-color: #178ca6;
                color: #ffffff;
            }
            .aar-returns-toolbar .aar-clear-button {
                color: #6b7280;
            }
            @media (max-width: 1199px) {
                .aar-returns-toolbar {
                    align-items: stretch;
                    flex-direction: column;
                }
                .aar-returns-filters {
                    grid-template-columns: minmax(140px, 1fr) minmax(140px, 1fr) minmax(220px, 2fr) auto auto;
                    width: 100%;
                }
                .aar-returns-toolbar-actions {
                    justify-content: flex-end;
                }
            }
            @media (max-width: 767px) {
                .aar-returns-filters {
                    grid-template-columns: 1fr;
                }
                .aar-returns-toolbar-actions {
                    flex-direction: column;
                }
                .aar-returns-toolbar .btn,
                .aar-returns-toolbar-actions,
                .aar-returns-toolbar-actions .btn {
                    width: 100%;
                }
            }
        </style>';
        $html .= '<div class="aar-returns-toolbar">';
        $html .= '<form method="get" action="' . Tools::safeOutput($this->getCurrentReturnsFilterActionUrl()) . '" class="aar-returns-filters">';
        $currentController = trim((string) Tools::getValue('controller'));
        $currentToken = trim((string) Tools::getAdminTokenLite($currentController !== '' ? $currentController : 'AdminAllegroAutoresponderReturns'));
        if ($currentController !== '') {
            $html .= '<input type="hidden" name="controller" value="' . Tools::safeOutput($currentController) . '">';
        }
        if ($currentToken !== '') {
            $html .= '<input type="hidden" name="token" value="' . Tools::safeOutput($currentToken) . '">';
        }
        $html .= '<input type="hidden" name="return_pages" value="1">';
        $html .= '<select name="return_status" class="form-control" onchange="this.form.submit()" aria-label="Status zwrotu">';
        foreach ($this->getCustomerReturnStatusFilterOptions() as $value => $label) {
            $html .= '<option value="' . Tools::safeOutput($value) . '"' . ($statusFilter === $value ? ' selected' : '') . '>' . Tools::safeOutput($label) . '</option>';
        }
        $html .= '</select>';
        $html .= '<select name="return_date_range" class="form-control" onchange="this.form.submit()" aria-label="Zakres dat">';
        foreach ($this->getCustomerReturnDateRangeOptions() as $value => $label) {
            $html .= '<option value="' . Tools::safeOutput($value) . '"' . ($dateRange === $value ? ' selected' : '') . '>' . Tools::safeOutput($label) . '</option>';
        }
        $html .= '</select>';
        $html .= '<input type="text" name="return_query" class="form-control" value="' . Tools::safeOutput($query) . '" placeholder="nr zwrotu, przesyłki, telefon kupującego...">';
        $html .= '<button class="btn btn-default" type="submit">Filtruj</button>';
        if ($query !== '' || $statusFilter !== 'all' || $dateRange !== '90') {
            $html .= '<a class="btn btn-default aar-clear-button" href="' . Tools::safeOutput($clearUrl) . '">Wyczyść</a>';
        }
        $html .= '</form>';
        $html .= '<div class="aar-returns-toolbar-actions">';
        $html .= '<a class="btn aar-refresh-button" href="' . Tools::safeOutput($refreshUrl) . '"><i class="icon-refresh"></i> Odśwież</a>';
        $html .= '</div>';
        $html .= '</div>';

        return $html;
    }

    protected function getCurrentReturnsFilterActionUrl(): string
    {
        $requestUri = isset($_SERVER['REQUEST_URI']) ? trim((string) $_SERVER['REQUEST_URI']) : '';
        if ($requestUri !== '') {
            $cleanUri = preg_replace('/([&?])return_id=[^&]*/', '$1', $requestUri);
            $cleanUri = preg_replace('/([&?])return_pages=[^&]*/', '$1', (string) $cleanUri);
            $cleanUri = preg_replace('/&&+/', '&', (string) $cleanUri);
            $cleanUri = str_replace('?&', '?', (string) $cleanUri);
            $cleanUri = preg_replace('/[?&]+$/', '', (string) $cleanUri);

            return $cleanUri;
        }

        return $this->context->link->getAdminLink('AdminAllegroAutoresponderReturns', true);
    }

    protected function getCurrentIssuesFilterActionUrl(): string
    {
        $requestUri = isset($_SERVER['REQUEST_URI']) ? trim((string) $_SERVER['REQUEST_URI']) : '';
        if ($requestUri !== '') {
            $cleanUri = preg_replace('/([&?])issue_id=[^&]*/', '$1', $requestUri);
            $cleanUri = preg_replace('/([&?])issue_pages=[^&]*/', '$1', (string) $cleanUri);
            $cleanUri = preg_replace('/&&+/', '&', (string) $cleanUri);
            $cleanUri = str_replace('?&', '?', (string) $cleanUri);
            $cleanUri = preg_replace('/[?&]+$/', '', (string) $cleanUri);

            return $cleanUri;
        }

        $currentController = trim((string) Tools::getValue('controller'));
        if ($currentController === '') {
            $currentController = 'AdminAllegroAutoresponderComplaints';
        }

        return $this->context->link->getAdminLink($currentController, true);
    }

    protected function getIssueKindFilterOptions(): array
    {
        return [
            'ALL' => 'wszystkie',
            'DISPUTE' => 'Dyskusje',
            'CLAIM' => 'Reklamacje',
        ];
    }

    protected function getCurrentIssueKindFilter(string $defaultIssueType): string
    {
        $defaultIssueType = mb_strtoupper(trim($defaultIssueType));
        if (in_array($defaultIssueType, ['DISPUTE', 'CLAIM'], true)) {
            return $defaultIssueType;
        }

        $kind = mb_strtoupper(trim((string) Tools::getValue('issue_kind', $defaultIssueType)));
        $options = $this->getIssueKindFilterOptions();

        return isset($options[$kind]) ? $kind : mb_strtoupper($defaultIssueType);
    }

    protected function getCurrentIssuePageCount(): int
    {
        return max(1, min(20, (int) Tools::getValue('issue_pages', 1)));
    }

    protected function getCurrentThreadPageCount(): int
    {
        return max(1, min(20, (int) Tools::getValue('thread_pages', 1)));
    }

    protected function getCurrentReturnPageCount(): int
    {
        return max(1, min(20, (int) Tools::getValue('return_pages', 1)));
    }

    protected function getFilteredCustomerReturns(AllegroApiClient $apiClient, int $pageCount = 1, &$hasMoreReturns = false): array
    {
        $returns = [];
        $seenReturnIds = [];
        $hasMoreReturns = false;
        $limit = 100;
        $pageCount = max(1, $pageCount);
        $filters = $this->getCurrentReturnApiFilters();

        for ($page = 0; $page < $pageCount; $page++) {
            $response = $apiClient->getCustomerReturns($limit, $page * $limit, $filters);
            $responseReturns = $response['customerReturns'] ?? [];
            if (!is_array($responseReturns)) {
                $responseReturns = [];
            }
            if (count($responseReturns) >= $limit && $page === $pageCount - 1) {
                $hasMoreReturns = true;
            }

            foreach ($responseReturns as $return) {
                if (!is_array($return)) {
                    continue;
                }

                $returnId = trim((string) ($return['id'] ?? ''));
                if ($returnId !== '') {
                    if (isset($seenReturnIds[$returnId])) {
                        continue;
                    }

                    $seenReturnIds[$returnId] = true;
                }

                $returns[] = $return;
            }
        }

        usort($returns, function (array $a, array $b): int {
            return (strtotime((string) ($b['createdAt'] ?? '')) ?: 0) <=> (strtotime((string) ($a['createdAt'] ?? '')) ?: 0);
        });

        $query = trim((string) Tools::getValue('return_query'));
        if ($query !== '') {
            $returns = $this->filterCustomerReturnsBySearch($apiClient, $returns, $query);
        }

        return $returns;
    }

    protected function getCurrentReturnApiFilters(): array
    {
        $filters = [];
        $status = $this->getCurrentReturnStatusFilter();
        if ($status !== 'all') {
            $filters['status'] = $status;
        }

        $dateRange = $this->getCurrentReturnDateRangeFilter();
        if ($dateRange !== 'all') {
            $days = max(1, (int) $dateRange);
            $from = new DateTimeImmutable('now', new DateTimeZone('UTC'));
            $from = $from->modify('-' . $days . ' days')->setTime(0, 0, 0, 0);
            $filters['createdAt.gte'] = $from->format('Y-m-d\TH:i:s.000\Z');
        }

        return $filters;
    }

    protected function filterCustomerReturnsBySearch(AllegroApiClient $apiClient, array $returns, string $query): array
    {
        $filtered = [];

        foreach ($returns as $return) {
            if (!is_array($return)) {
                continue;
            }

            if ($this->customerReturnMatchesSearch($return, $query)) {
                $filtered[] = $return;
                continue;
            }

            $returnId = trim((string) ($return['id'] ?? ''));
            if ($returnId === '') {
                continue;
            }

            try {
                $details = $apiClient->getCustomerReturn($returnId);
                if (is_array($details) && $details && $this->customerReturnMatchesSearch($details, $query)) {
                    $filtered[] = $details;
                }
            } catch (Throwable $e) {
                PrestaShopLogger::addLog('[AAR] Customer return search details fetch failed for ' . $returnId . ': ' . $e->getMessage(), 2);
            }
        }

        return $filtered;
    }

    protected function customerReturnMatchesSearch(array $return, string $query): bool
    {
        $query = trim($query);
        if ($query === '') {
            return true;
        }

        $parts = [];
        $parts[] = (string) ($return['id'] ?? '');
        $parts[] = (string) ($return['referenceNumber'] ?? '');
        $parts[] = (string) ($return['orderId'] ?? '');
        $parts[] = (string) ($return['buyer']['login'] ?? '');
        $parts[] = (string) ($return['buyer']['email'] ?? '');
        $parts[] = (string) ($return['buyer']['firstName'] ?? '');
        $parts[] = (string) ($return['buyer']['lastName'] ?? '');
        $parts[] = (string) ($return['buyer']['phoneNumber'] ?? '');
        $parts[] = (string) ($return['delivery']['phoneNumber'] ?? '');
        $parts[] = (string) ($return['sender']['phoneNumber'] ?? '');

        foreach (($return['items'] ?? []) as $item) {
            if (!is_array($item)) {
                continue;
            }
            $parts[] = (string) ($item['name'] ?? '');
            $parts[] = (string) ($item['offerId'] ?? '');
            $parts[] = (string) ($item['reason']['type'] ?? '');
            $parts[] = (string) ($item['reason']['userComment'] ?? '');
        }

        foreach (($return['parcels'] ?? []) as $parcel) {
            if (!is_array($parcel)) {
                continue;
            }
            $parts[] = (string) ($parcel['waybill'] ?? '');
            $parts[] = (string) ($parcel['transportingWaybill'] ?? '');
            $parts[] = (string) ($parcel['sender']['phoneNumber'] ?? '');
        }

        $parts[] = $this->getCustomerReturnBuyerName($return);

        $haystack = $this->normalizeSearchText(implode(' ', array_filter($parts, 'strlen')));
        $needle = $this->normalizeSearchText($query);
        if ($needle !== '' && strpos($haystack, $needle) !== false) {
            return true;
        }

        $haystackCompact = $this->normalizeSearchTextCompact(implode('', array_filter($parts, 'strlen')));
        $needleCompact = $this->normalizeSearchTextCompact($query);

        return $needleCompact !== '' && strpos($haystackCompact, $needleCompact) !== false;
    }

    protected function normalizeSearchText(string $value): string
    {
        $value = Tools::replaceAccentedChars($value);
        $value = mb_strtolower($value);
        $value = preg_replace('/\s+/u', ' ', $value);

        return trim((string) $value);
    }

    protected function normalizeSearchTextCompact(string $value): string
    {
        $value = $this->normalizeSearchText($value);

        return (string) preg_replace('/[^a-z0-9]+/u', '', $value);
    }

    protected function getCurrentReturnStatusFilter(): string
    {
        $status = mb_strtoupper(trim((string) Tools::getValue('return_status', 'all')));
        $options = $this->getCustomerReturnStatusFilterOptions();

        return isset($options[$status]) ? $status : 'all';
    }

    protected function getCurrentReturnDateRangeFilter(): string
    {
        $range = trim((string) Tools::getValue('return_date_range', '90'));
        $options = $this->getCustomerReturnDateRangeOptions();

        return isset($options[$range]) ? $range : '90';
    }

    protected function getCurrentReturnQueryType(): string
    {
        $type = trim((string) Tools::getValue('return_query_type', 'referenceNumber'));
        $options = $this->getCustomerReturnQueryTypeOptions();

        return isset($options[$type]) ? $type : 'referenceNumber';
    }

    protected function getCustomerReturnStatusFilterOptions(): array
    {
        return [
            'all' => 'wszystkie',
            'CREATED' => 'utworzone',
            'DISPATCHED' => 'nadane',
            'IN_TRANSIT' => 'w transporcie',
            'DELIVERED' => 'dostarczone',
            'WAREHOUSE_DELIVERED' => 'w magazynie',
            'WAREHOUSE_VERIFICATION' => 'w weryfikacji',
            'FINISHED' => 'zakończone',
            'FINISHED_APT' => 'zakończone APT',
            'REJECTED' => 'odrzucone',
            'COMMISSION_REFUND_CLAIMED' => 'wniosek o prowizję',
            'COMMISSION_REFUNDED' => 'prowizja zwrócona',
        ];
    }

    protected function getCustomerReturnDateRangeOptions(): array
    {
        return [
            '30' => 'ostatnie 30 dni',
            '90' => 'ostatnie 90 dni',
            '180' => 'ostatnie 180 dni',
            '365' => 'ostatni rok',
            'all' => 'całe archiwum',
        ];
    }

    protected function getCustomerReturnQueryTypeOptions(): array
    {
        return [
            'referenceNumber' => 'nr zwrotu',
            'customerReturnId' => 'id zwrotu',
            'orderId' => 'id zamówienia',
            'buyer.login' => 'login kupującego',
            'buyer.email' => 'e-mail kupującego',
            'items.offerId' => 'id oferty',
            'items.name' => 'nazwa produktu',
            'parcels.waybill' => 'nr przesyłki',
            'parcels.transportingWaybill' => 'nr przesyłki przewoźnika',
        ];
    }

    protected function getFilteredIssuesForKind(AllegroApiClient $apiClient, string $issueKind, string $statusFilter, int $pageCount = 1, &$hasMoreIssues = false): array
    {
        $issueKinds = $issueKind === 'ALL' ? ['DISPUTE', 'CLAIM'] : [$issueKind];
        $issues = [];
        $seenIssueIds = [];
        $hasMoreIssues = false;
        $limit = 100;
        $pageCount = max(1, $pageCount);

        foreach ($issueKinds as $singleIssueType) {
            for ($page = 0; $page < $pageCount; $page++) {
                $response = $apiClient->getIssues($limit, $page * $limit, ['type' => $singleIssueType]);
                $responseIssues = $response['issues'] ?? [];
                if (count($responseIssues) >= $limit && $page === $pageCount - 1) {
                    $hasMoreIssues = true;
                }

                foreach ($responseIssues as $issue) {
                    if (is_array($issue)) {
                        $returnedIssueType = mb_strtoupper(trim((string) ($issue['type'] ?? '')));
                        if ($returnedIssueType !== '' && $returnedIssueType !== $singleIssueType) {
                            continue;
                        }

                        $issueId = trim((string) ($issue['id'] ?? ''));
                        if ($issueId !== '') {
                            if (isset($seenIssueIds[$issueId])) {
                                continue;
                            }

                            $seenIssueIds[$issueId] = true;
                        }

                        $issue['type'] = $issue['type'] ?? $singleIssueType;
                        $issues[] = $issue;
                    }
                }
            }
        }

        $issues = $this->filterIssuesByStatus($issues, $statusFilter);

        usort($issues, function (array $a, array $b): int {
            return $this->getIssueSortTimestamp($b) <=> $this->getIssueSortTimestamp($a);
        });

        return $issues;
    }

    protected function getIssueSortTimestamp(array $issue): int
    {
        $date = (string) (
            $issue['lastMessage']['createdAt']
            ?? $issue['updatedAt']
            ?? $issue['createdAt']
            ?? $issue['openedDate']
            ?? ''
        );

        return strtotime($date) ?: 0;
    }

    protected function getIssueSectionTitleForKind(string $issueKind, string $defaultSectionTitle): string
    {
        if ($issueKind === 'ALL') {
            return 'Reklamacje i dyskusje';
        }

        if ($issueKind === 'DISPUTE') {
            return 'Dyskusje';
        }

        if ($issueKind === 'CLAIM') {
            return 'Reklamacje';
        }

        return $defaultSectionTitle;
    }

    protected function formatIssueSubjectText(string $subject): string
    {
        $normalized = mb_strtolower(trim($subject));
        if ($normalized === '') {
            return '';
        }

        $map = [
            'no refund after returning the product' => 'Brak zwrotu środków po odesłaniu produktu',
            'missing product element' => 'Brak elementu produktu',
            'defects emerged during use' => 'Wada ujawniona podczas użytkowania',
            'defect found during use' => 'Wada ujawniona podczas użytkowania',
            'product and parcel damaged in transit' => 'Produkt i przesyłka uszkodzone w transporcie',
            'product and parcel damaged (in transit)' => 'Produkt i przesyłka uszkodzone w transporcie',
            'i have not received the product' => 'Nie otrzymałem produktu',
            'no product in the parcel' => 'Brak produktu w przesyłce',
            'product not as described' => 'Produkt niezgodny z opisem',
            'damaged product' => 'Uszkodzony produkt',
            'the seller does not want to accept the return' => 'Sprzedający nie chce przyjąć zwrotu',
            'seller does not want to accept the return' => 'Sprzedający nie chce przyjąć zwrotu',
            'the seller doesn\'t want to accept the return' => 'Sprzedający nie chce przyjąć zwrotu',
            'seller doesn\'t want to accept the return' => 'Sprzedający nie chce przyjąć zwrotu',
            'the seller refuses to accept the return' => 'Sprzedający odmawia przyjęcia zwrotu',
            'seller refuses to accept the return' => 'Sprzedający odmawia przyjęcia zwrotu',
            'the seller refused to accept the return' => 'Sprzedający odmówił przyjęcia zwrotu',
            'seller refused to accept the return' => 'Sprzedający odmówił przyjęcia zwrotu',
            'the seller rejected the return' => 'Sprzedający odrzucił zwrot',
            'seller rejected the return' => 'Sprzedający odrzucił zwrot',
        ];

        return $map[$normalized] ?? $subject;
    }

    protected function resolveIssueTextValue($value): string
    {
        if (is_string($value)) {
            return trim($value);
        }

        if (is_numeric($value)) {
            return trim((string) $value);
        }

        if (!is_array($value)) {
            return '';
        }

        foreach (['pl', 'pl-PL', 'en', 'en-US', 'name', 'label', 'value', 'message', 'text'] as $key) {
            if (array_key_exists($key, $value)) {
                $resolved = $this->resolveIssueTextValue($value[$key]);
                if ($resolved !== '') {
                    return $resolved;
                }
            }
        }

        foreach ($value as $item) {
            $resolved = $this->resolveIssueTextValue($item);
            if ($resolved !== '') {
                return $resolved;
            }
        }

        return '';
    }

    protected function threadRequiresSellerReply(array $thread): bool
    {
        $read = (bool) ($thread['read'] ?? true);
        if ($read) {
            return false;
        }

        if (isset($thread['lastMessage']['author']['isInterlocutor'])) {
            return (bool) $thread['lastMessage']['author']['isInterlocutor'];
        }

        if (isset($thread['lastMessage']['author']['login'], $thread['interlocutor']['login'])) {
            return (string) $thread['lastMessage']['author']['login'] === (string) $thread['interlocutor']['login'];
        }

        return $read === false;
    }

    protected function issueRequiresSellerReply(array $issue): bool
    {
        $status = mb_strtoupper(trim((string) ($issue['status'] ?? '')));
        if ($status === 'CLOSED' || $status === 'RESOLVED') {
            return false;
        }

        if (isset($issue['lastMessage']['author']['role'])) {
            return mb_strtoupper((string) $issue['lastMessage']['author']['role']) !== 'SELLER';
        }

        return true;
    }

    protected function isIssueCustomerMessage(array $message): bool
    {
        if (isset($message['author']['role'])) {
            return mb_strtoupper((string) $message['author']['role']) !== 'SELLER';
        }

        return true;
    }

    protected function getIssueAuthorLabel(array $message, array $issue): string
    {
        $role = mb_strtoupper((string) ($message['author']['role'] ?? ''));
        if ($role === 'SELLER') {
            return 'Ty';
        }

        $login = (string) ($message['author']['login'] ?? $issue['buyer']['login'] ?? '');
        if ($login !== '') {
            return $login;
        }

        if ($role === 'ALLEGRO') {
            return 'Allegro';
        }

        return 'Klient';
    }

    protected function formatIssueStatus(string $status): string
    {
        $map = [
            'NEW' => 'Nowa',
            'OPEN' => 'Otwarta',
            'IN_PROGRESS' => 'W trakcie',
            'DISPUTE_ONGOING' => 'Dyskusja w toku',
            'DISPUTE_UNRESOLVED' => 'Dyskusja nierozwiązana',
            'DISPUTE_RESOLVED' => 'Dyskusja rozwiązana',
            'DISPUTE_CLOSED' => 'Dyskusja zamknięta',
            'CLAIM_SUBMITTED' => 'Reklamacja zgłoszona',
            'CLAIM_REJECTED' => 'Reklamacja odrzucona',
            'CLAIM_ACCEPTED' => 'Reklamacja uznana',
            'RESOLVED' => 'Rozwiązana',
            'CLOSED' => 'Zamknięta',
        ];

        $status = mb_strtoupper(trim($status));

        return $map[$status] ?? ($status !== '' ? str_replace('_', ' ', $status) : 'Nieznany status');
    }

    protected function formatIssueListStatus(string $status): string
    {
        $status = mb_strtoupper(trim($status));

        $map = [
            'DISPUTE_ONGOING' => 'W toku',
            'DISPUTE_UNRESOLVED' => 'Nierozwiązana',
            'DISPUTE_RESOLVED' => 'Rozwiązana',
            'DISPUTE_CLOSED' => 'Zamknięta',
            'CLAIM_SUBMITTED' => 'Zgłoszona',
            'CLAIM_REJECTED' => 'Odrzucona',
            'CLAIM_ACCEPTED' => 'Uznana',
        ];

        return $map[$status] ?? $this->formatIssueStatus($status);
    }

    protected function getIssueStatusFilterOptions(): array
    {
        return [
            'all' => 'wszystkie',
            'in_progress' => 'w toku',
            'unresolved' => 'nierozwiązane',
            'resolved' => 'rozwiązane',
            'overdue' => 'przedawnione',
        ];
    }

    protected function getCurrentIssueStatusFilter(): string
    {
        $filter = trim((string) Tools::getValue('status_filter', 'all'));
        $options = $this->getIssueStatusFilterOptions();

        return isset($options[$filter]) ? $filter : 'all';
    }

    protected function filterIssuesByStatus(array $issues, string $statusFilter): array
    {
        if ($statusFilter === 'all') {
            return $issues;
        }

        return array_values(array_filter($issues, function (array $issue) use ($statusFilter): bool {
            $resolved = $this->isIssueResolved($issue);
            $overdue = $this->isIssueOverdue($issue);

            switch ($statusFilter) {
                case 'in_progress':
                    return !$resolved && !$overdue;
                case 'unresolved':
                    return !$resolved;
                case 'resolved':
                    return $resolved;
                case 'overdue':
                    return $overdue;
                default:
                    return true;
            }
        }));
    }

    protected function isIssueResolved(array $issue): bool
    {
        $status = mb_strtoupper(trim((string) ($issue['currentState']['status'] ?? $issue['status'] ?? '')));

        return in_array($status, ['CLAIM_ACCEPTED', 'CLAIM_REJECTED', 'RESOLVED', 'CLOSED'], true);
    }

    protected function isIssueOverdue(array $issue): bool
    {
        if ($this->isIssueResolved($issue)) {
            return false;
        }

        $dueDate = (string) ($issue['decisionDueDate'] ?? $issue['currentState']['statusDueDate'] ?? '');
        $dueTimestamp = strtotime($dueDate);

        return $dueTimestamp !== false && $dueTimestamp < time();
    }

    protected function getIssueStatusClass(string $status): string
    {
        $status = mb_strtoupper(trim($status));

        if (in_array($status, ['CLAIM_ACCEPTED', 'RESOLVED', 'CLOSED', 'DISPUTE_CLOSED'], true)) {
            return 'is-ok';
        }

        if (in_array($status, ['CLAIM_REJECTED'], true)) {
            return 'is-overdue';
        }

        if (in_array($status, ['NEW', 'OPEN', 'IN_PROGRESS', 'DISPUTE_ONGOING'], true)) {
            return 'is-warning';
        }

        if ($status === 'DISPUTE_RESOLVED') {
            return 'is-ok';
        }

        return 'is-neutral';
    }

    protected function formatIssueTypeLabel(string $issueType): string
    {
        $issueType = mb_strtoupper(trim($issueType));

        if ($issueType === 'DISPUTE') {
            return 'Dyskusja';
        }

        if ($issueType === 'CLAIM') {
            return 'Reklamacja';
        }

        return '';
    }

    protected function getIssueTypeBadgeClass(string $issueType): string
    {
        $issueType = mb_strtoupper(trim($issueType));

        if ($issueType === 'DISPUTE') {
            return 'is-dispute';
        }

        if ($issueType === 'CLAIM') {
            return 'is-claim';
        }

        return 'is-neutral';
    }

    protected function formatIssueReasonType(string $reasonType): string
    {
        $map = [
            'MISSING_PRODUCT_ELEMENT' => 'Brak elementu produktu',
            'DEFECTS_EMERGED_DURING_USE' => 'Wada ujawniona podczas użytkowania',
            'DEFECT_FOUND_DURING_USE' => 'Wada ujawniona podczas użytkowania',
            'PRODUCT_NOT_AS_DESCRIBED' => 'Produkt niezgodny z opisem',
            'DAMAGED_PRODUCT' => 'Uszkodzony produkt',
            'PRODUCT_DOES_NOT_WORK' => 'Produkt nie działa',
            'WRONG_PRODUCT' => 'Błędny produkt',
            'INCOMPLETE_PRODUCT' => 'Niekompletny produkt',
            'MISSING_ACCESSORY' => 'Brak akcesorium',
            'BROKEN_PRODUCT' => 'Uszkodzony produkt',
            'PRODUCT_AND_PARCEL_DAMAGED_IN_TRANSIT' => 'Produkt i przesyłka uszkodzone w transporcie',
            'QUALITY_ISSUE' => 'Problem z jakością produktu',
            'OTHER' => 'Inny powód',
        ];

        $reasonType = mb_strtoupper(trim($reasonType));

        if ($reasonType === '') {
            return '';
        }

        if (isset($map[$reasonType])) {
            return $map[$reasonType];
        }

        $pretty = mb_strtolower(str_replace('_', ' ', $reasonType));

        return mb_strtoupper(mb_substr($pretty, 0, 1)) . mb_substr($pretty, 1);
    }

    protected function formatIssueRight(string $right): string
    {
        $map = [
            'COMPLAINT' => 'Reklamacja ustawowa',
            'WARRANTY' => 'Gwarancja',
        ];

        $right = mb_strtoupper(trim($right));

        return $map[$right] ?? ($right !== '' ? str_replace('_', ' ', $right) : '');
    }

    protected function formatIssueExpectations(array $expectations): string
    {
        if (!$expectations) {
            return '';
        }

        $map = [
            'EXCHANGE' => 'Wymiana',
            'REPAIR' => 'Naprawa',
            'REFUND' => 'Zwrot środków',
            'PRICE_REDUCTION' => 'Obniżenie ceny',
        ];

        $labels = [];
        foreach ($expectations as $expectation) {
            if (!is_array($expectation)) {
                continue;
            }

            $name = mb_strtoupper(trim((string) ($expectation['name'] ?? '')));
            if ($name === '') {
                continue;
            }

            $labels[] = $map[$name] ?? str_replace('_', ' ', $name);
        }

        return implode(', ', array_unique($labels));
    }

    protected function findCustomerReturnById(array $returns, string $returnId): ?array
    {
        foreach ($returns as $return) {
            if (is_array($return) && (string) ($return['id'] ?? '') === $returnId) {
                return $return;
            }
        }

        return null;
    }

    protected function buildCustomerReturnSubject(array $return): string
    {
        $items = $return['items'] ?? [];
        if (is_array($items) && isset($items[0]) && is_array($items[0])) {
            $name = trim((string) ($items[0]['name'] ?? ''));
            if ($name !== '') {
                return $name;
            }
        }

        $referenceNumber = trim((string) ($return['referenceNumber'] ?? ''));
        if ($referenceNumber !== '') {
            return 'Zwrot ' . $referenceNumber;
        }

        $buyerLogin = trim((string) ($return['buyer']['login'] ?? ''));
        if ($buyerLogin !== '') {
            return 'Zwrot od ' . $buyerLogin;
        }

        return 'Zwrot Allegro';
    }

    protected function buildCustomerReturnPreview(array $return): string
    {
        return '';
    }

    protected function buildCustomerReturnHeaderTitle(array $return): string
    {
        $referenceNumber = trim((string) ($return['referenceNumber'] ?? ''));
        if ($referenceNumber !== '') {
            return 'Zwrot ' . $referenceNumber;
        }

        return 'Zwrot Allegro';
    }

    protected function buildCustomerReturnHeaderSubtitle(array $return): string
    {
        $parts = [];
        $buyerLogin = trim((string) ($return['buyer']['login'] ?? ''));
        $createdAt = $this->formatAllegroDate((string) ($return['createdAt'] ?? ''));

        if ($buyerLogin !== '') {
            $parts[] = $buyerLogin;
        }
        if ($createdAt !== '') {
            $parts[] = $createdAt;
        }

        return $parts ? implode(' • ', $parts) : 'Zwrot kliencki Allegro';
    }

    protected function renderCustomerReturnHeaderMeta(array $return): string
    {
        $parts = [];
        $orderId = trim((string) ($return['orderId'] ?? ''));

        if ($orderId !== '') {
            $orderUrl = $this->getAllegroOrdersUrl($orderId);
            if ($orderUrl !== '') {
                $parts[] = '<span>Zamówienie Allegro: <a href="' . Tools::safeOutput($orderUrl) . '" target="_blank" rel="noopener noreferrer">' . Tools::safeOutput($orderId) . '</a></span>';
            } else {
                $parts[] = '<span>Zamówienie Allegro: ' . Tools::safeOutput($orderId) . '</span>';
            }
        }

        $prestashopOrder = $this->resolvePrestashopOrderLinkForReturn($return);
        if ($prestashopOrder !== null) {
            $prestashopOrderLabel = Tools::safeOutput($this->formatPrestashopOrderReference($prestashopOrder));
            $prestashopOrderUrl = trim((string) ($prestashopOrder['url'] ?? ''));
            if ($prestashopOrderUrl !== '') {
                $parts[] = '<span>Zamówienie w sklepie: <a href="' . Tools::safeOutput($prestashopOrderUrl) . '" target="_blank" rel="noopener noreferrer">' . $prestashopOrderLabel . '</a></span>';
            } else {
                $parts[] = '<span>Zamówienie w sklepie: ' . $prestashopOrderLabel . '</span>';
            }
        }

        if (!$parts) {
            return '<small>Zwrot kliencki Allegro</small>';
        }

        return '<small class="aar-return-header-meta">' . implode(' <span class="aar-return-header-separator">•</span> ', $parts) . '</small>';
    }

    protected function resolvePrestashopOrderLinkForReturn(array $return): ?array
    {
        $checkoutFormId = trim((string) ($return['orderId'] ?? ''));
        if ($checkoutFormId === '') {
            return null;
        }

        $resolved = $this->findPrestashopOrderByX13CheckoutForm($checkoutFormId);
        if ($resolved !== null) {
            return $resolved;
        }

        return $this->findPrestashopOrderByExternalIdentifier($checkoutFormId);
    }

    protected function renderCustomerReturnHeaderBadges(array $return): string
    {
        $status = (string) ($return['status'] ?? '');
        $statusClass = $this->getCustomerReturnStatusClass($status);
        $isFulfillment = isset($return['isFulfillment']) ? (bool) $return['isFulfillment'] : false;
        $html = '<div class="aar-claim-badges aar-header-claim-badges">';
        $html .= '<span class="aar-claim-badge aar-claim-status aar-status-badge aar-status-badge-' . Tools::safeOutput($statusClass) . ' ' . Tools::safeOutput($statusClass) . '">' . Tools::safeOutput($this->formatCustomerReturnStatus($status)) . '</span>';
        if ($isFulfillment) {
            $html .= '<span class="aar-claim-badge">One Fulfillment</span>';
        }
        $html .= '</div>';

        return $html;
    }

    protected function formatCustomerReturnStatus(string $status): string
    {
        $status = mb_strtoupper(trim($status));
        $map = [
            'CREATED' => 'Utworzony',
            'DISPATCHED' => 'Nadany',
            'IN_TRANSIT' => 'W transporcie',
            'DELIVERED' => 'Dostarczony',
            'FINISHED' => 'Zakończony',
            'FINISHED_APT' => 'Zakończony APT',
            'REJECTED' => 'Odrzucony',
            'COMMISSION_REFUND_CLAIMED' => 'Wniosek o prowizję',
            'COMMISSION_REFUNDED' => 'Prowizja zwrócona',
            'WAREHOUSE_DELIVERED' => 'W magazynie',
            'WAREHOUSE_VERIFICATION' => 'W weryfikacji',
        ];

        return $map[$status] ?? ($status !== '' ? str_replace('_', ' ', $status) : 'Nieznany status');
    }

    protected function getCustomerReturnStatusClass(string $status): string
    {
        $status = mb_strtoupper(trim($status));
        if (in_array($status, ['FINISHED', 'FINISHED_APT', 'COMMISSION_REFUNDED'], true)) {
            return 'is-ok';
        }
        if (in_array($status, ['REJECTED'], true)) {
            return 'is-overdue';
        }
        if (in_array($status, ['CREATED', 'DISPATCHED', 'IN_TRANSIT', 'DELIVERED', 'WAREHOUSE_DELIVERED', 'WAREHOUSE_VERIFICATION', 'COMMISSION_REFUND_CLAIMED'], true)) {
            return 'is-warning';
        }

        return 'is-neutral';
    }

    protected function formatCustomerReturnReasonType(string $reasonType): string
    {
        $reasonType = mb_strtoupper(trim($reasonType));
        $map = [
            'NONE' => 'Odstąpienie bez podania przyczyny',
            'NO_REASON' => 'Odstąpienie bez podania przyczyny',
            'WITHOUT_REASON' => 'Odstąpienie bez podania przyczyny',
            'NO_REASON_GIVEN' => 'Odstąpienie bez podania przyczyny',
            'NOT_SPECIFIED' => 'Odstąpienie bez podania przyczyny',
            'NOT_AS_DESCRIBED' => 'Niezgodny z opisem',
            'DAMAGED' => 'Uszkodzony',
            'WRONG_PRODUCT' => 'Błędny produkt',
            'INCOMPLETE' => 'Niekompletny',
            'DOES_NOT_FIT' => 'Nie pasuje',
            'DONT_LIKE_IT' => 'Nie pasuje mi',
            'WITHDRAWAL' => 'Odstąpienie bez podania przyczyny',
            'OTHER_FLAW' => 'Inna wada',
            'DIFFERENT' => 'Towar inny niż zamówiony',
            'OTHER' => 'Inny powód',
        ];

        if ($reasonType === '') {
            return '';
        }

        return $map[$reasonType] ?? str_replace('_', ' ', $reasonType);
    }

    protected function resolveCustomerReturnReasonComment(array $item): string
    {
        $reason = is_array($item['reason'] ?? null) ? $item['reason'] : [];
        foreach ([
            $reason['userComment'] ?? null,
            $reason['comment'] ?? null,
            $reason['description'] ?? null,
            $reason['note'] ?? null,
            $reason['name'] ?? null,
            $item['reasonComment'] ?? null,
            $item['returnReason'] ?? null,
        ] as $candidate) {
            $value = $this->resolveIssueTextValue($candidate);
            if ($value !== '') {
                return $value;
            }
        }

        return '';
    }

    protected function buildCustomerReturnRefundRows(array $return): array
    {
        $bankAccount = $return['refund']['bankAccount'] ?? [];
        if (!is_array($bankAccount) || !$bankAccount) {
            return [];
        }

        $address = is_array($bankAccount['address'] ?? null) ? $bankAccount['address'] : [];
        $addressLine = trim(implode(', ', array_filter([
            trim((string) ($address['street'] ?? '')),
            trim((string) ($address['postCode'] ?? '')),
            trim((string) ($address['city'] ?? '')),
            trim((string) ($address['countryCode'] ?? '')),
        ])));

        return [
            'Właściciel' => trim((string) ($bankAccount['owner'] ?? '')),
            'IBAN' => $this->maskBankAccount((string) ($bankAccount['iban'] ?? $bankAccount['accountNumber'] ?? '')),
            'SWIFT' => trim((string) ($bankAccount['swift'] ?? '')),
            'Adres' => $addressLine,
        ];
    }

    protected function buildCustomerReturnRejectionRows(array $return): array
    {
        $rejection = $return['rejection'] ?? [];
        if (!is_array($rejection) || !$rejection) {
            return [];
        }

        return [
            'Powód' => $this->formatCustomerReturnRejectionCode((string) ($rejection['code'] ?? '')),
            'Uzasadnienie' => trim((string) ($rejection['reason'] ?? '')),
            'Data' => $this->formatAllegroDate((string) ($rejection['createdAt'] ?? '')),
        ];
    }

    protected function getCustomerReturnRejectionOptions(): array
    {
        return [
            'REFUND_REJECTED' => 'Inny powód',
            'NEW_ITEM_SENT' => 'Wysłano nowy towar',
            'ITEM_FIXED' => 'Naprawa towaru',
            'MISSING_PART_SENT' => 'Dosłanie brakujących elementów',
            'ITEM_MISMATCH' => 'Zwrot niewłaściwego towaru',
            'BUSINESS_PURCHASE' => 'Zakup na firmę',
            'NO_RETURN_RIGHT' => 'Towar nie podlega zwrotowi',
        ];
    }

    protected function getCustomerReturnRejectionReasonDefinitions(): array
    {
        return [
            'NO_RETURN_RIGHT' => [
                'api_code' => 'NO_RETURN_RIGHT',
                'label' => 'Towar nie podlega zwrotowi',
                'description' => 'Np. rozpieczętowane produkty higieniczne, treści cyfrowe, albo produkty wykonane na indywidualne zamówienie kupującego.',
            ],
            'BUSINESS_PURCHASE' => [
                'api_code' => 'BUSINESS_PURCHASE',
                'label' => 'Zakup na firmę',
                'description' => 'Zakup na spółkę, a w przypadku jednoosobowej działalności - zakup o charakterze zawodowym.',
            ],
            'ITEM_MISMATCH' => [
                'api_code' => 'ITEM_MISMATCH',
                'label' => 'Zwrot niewłaściwego towaru',
                'description' => '',
            ],
            'NEW_ITEM_SENT' => [
                'api_code' => 'NEW_ITEM_SENT',
                'label' => 'Wymiana towaru',
                'description' => '',
            ],
            'ITEM_FIXED' => [
                'api_code' => 'ITEM_FIXED',
                'label' => 'Naprawa towaru',
                'description' => '',
            ],
            'MISSING_PART_SENT' => [
                'api_code' => 'MISSING_PART_SENT',
                'label' => 'Dosłanie brakujących elementów',
                'description' => '',
            ],
            'OTHER_REASON' => [
                'api_code' => 'REFUND_REJECTED',
                'label' => 'Inny powód',
                'description' => 'Podaj szczegóły w uzasadnieniu',
            ],
        ];
    }

    protected function formatCustomerReturnRejectionCode(string $code): string
    {
        $code = mb_strtoupper(trim($code));
        $options = $this->getCustomerReturnRejectionOptions();

        return $options[$code] ?? ($code !== '' ? str_replace('_', ' ', $code) : '');
    }

    protected function formatMoneyValue($value): string
    {
        if (!is_array($value)) {
            return '';
        }

        $amount = trim((string) ($value['amount'] ?? ''));
        $currency = trim((string) ($value['currency'] ?? ''));
        if ($amount === '') {
            return '';
        }

        return trim($amount . ' ' . $currency);
    }

    protected function maskEmail(string $email): string
    {
        $email = trim($email);
        if ($email === '' || strpos($email, '@') === false) {
            return $email;
        }

        [$local, $domain] = explode('@', $email, 2);
        $visible = mb_substr($local, 0, 2);

        return $visible . str_repeat('*', max(3, mb_strlen($local) - 2)) . '@' . $domain;
    }

    protected function maskPhone(string $phone): string
    {
        $phone = trim($phone);
        if ($phone === '') {
            return '';
        }

        return preg_replace('/\d(?=\d{3})/', '*', $phone) ?: $phone;
    }

    protected function formatPhoneNumber(string $phone): string
    {
        $phone = trim($phone);
        if ($phone === '') {
            return '';
        }

        $digits = preg_replace('/\D+/', '', $phone);
        if ($digits === null || $digits === '') {
            return $phone;
        }

        if (strlen($digits) === 11 && strpos($digits, '48') === 0) {
            return '+48 ' . substr($digits, 2, 3) . ' ' . substr($digits, 5, 3) . ' ' . substr($digits, 8, 3);
        }

        if (strlen($digits) === 9) {
            return substr($digits, 0, 3) . ' ' . substr($digits, 3, 3) . ' ' . substr($digits, 6, 3);
        }

        if (strpos($phone, '+') === 0 && strlen($digits) > 9) {
            return '+' . substr($digits, 0, max(1, strlen($digits) - 9)) . ' ' . substr($digits, -9, 3) . ' ' . substr($digits, -6, 3) . ' ' . substr($digits, -3);
        }

        return $phone;
    }

    protected function maskBankAccount(string $account): string
    {
        $account = preg_replace('/\s+/', '', trim($account));
        if ($account === null || $account === '') {
            return '';
        }

        if (mb_strlen($account) <= 8) {
            return str_repeat('*', mb_strlen($account));
        }

        return mb_substr($account, 0, 4) . str_repeat('*', max(8, mb_strlen($account) - 8)) . mb_substr($account, -4);
    }

    protected function buildClaimTimeMeta(array $issue, array $messages = []): array
    {
        $openedDate = (string) ($issue['openedDate'] ?? '');
        $decisionDueDate = (string) ($issue['decisionDueDate'] ?? '');
        $status = mb_strtoupper(trim((string) ($issue['currentState']['status'] ?? $issue['status'] ?? '')));
        $openedTs = strtotime($openedDate);
        $dueTs = strtotime($decisionDueDate);
        $now = time();

        if (!$dueTs) {
            return [
                'headline' => 'Brak terminu decyzji',
                'subline' => '',
                'progress_percent' => 0,
                'marker_percent' => 0,
                'show_marker' => false,
                'status_class' => 'is-neutral',
                'resolved_at' => '',
            ];
        }

        $total = max(1, $dueTs - ($openedTs ?: $now));
        $decisionMeta = $this->resolveClaimDecisionMeta($issue, $messages);

        if (in_array($status, ['CLAIM_ACCEPTED', 'CLAIM_REJECTED'], true)) {
            $resolvedAt = $decisionMeta['created_at'] ?? '';
            $decisionTs = strtotime((string) $resolvedAt);
            if ($decisionTs !== false && $decisionTs > 0) {
                $elapsedAtDecision = max(0, min($total, $decisionTs - ($openedTs ?: $decisionTs)));
                $progressPercent = (int) max(4, min(100, round(($elapsedAtDecision / $total) * 100)));
                $delta = $decisionTs - $dueTs;

                if ($delta > 0) {
                    return [
                        'headline' => 'Reklamacja rozpatrzona po terminie',
                        'subline' => 'Rozpatrzono po ' . $this->formatDuration($delta),
                        'progress_percent' => 100,
                        'marker_percent' => 100,
                        'show_marker' => true,
                        'marker_label' => $this->getClaimDecisionMarkerLabel($status),
                        'status_class' => 'is-overdue',
                        'resolved_at' => (string) $resolvedAt,
                    ];
                }

                $beforeDeadline = abs($delta);
                return [
                    'headline' => 'Reklamacja rozpatrzona w terminie',
                    'subline' => $beforeDeadline > 0
                        ? 'Rozpatrzono przed terminem o ' . $this->formatDuration($beforeDeadline)
                        : 'Rozpatrzono dokładnie w terminie',
                    'progress_percent' => $progressPercent,
                    'marker_percent' => $progressPercent,
                    'show_marker' => true,
                    'marker_label' => $this->getClaimDecisionMarkerLabel($status),
                    'status_class' => 'is-ok',
                    'resolved_at' => (string) $resolvedAt,
                ];
            }

            return [
                'headline' => 'Reklamacja rozpatrzona',
                'subline' => 'Brak dokładnej daty rozpatrzenia w danych Allegro',
                'progress_percent' => 100,
                'marker_percent' => 100,
                'show_marker' => false,
                'marker_label' => '',
                'status_class' => 'is-neutral',
                'resolved_at' => '',
            ];
        }

        $elapsed = max(0, min($total, $now - ($openedTs ?: $now)));
        $remaining = $dueTs - $now;
        $progressPercent = (int) max(4, min(100, round(($elapsed / $total) * 100)));

        if ($remaining < 0) {
            return [
                'headline' => 'Termin decyzji minął',
                'subline' => 'Po terminie o ' . $this->formatDuration(abs($remaining)),
                'progress_percent' => 100,
                'marker_percent' => 100,
                'show_marker' => false,
                'status_class' => 'is-overdue',
                'resolved_at' => '',
            ];
        }

        if ($remaining <= 2 * 24 * 3600) {
            return [
                'headline' => 'Mało czasu na decyzję',
                'subline' => 'Pozostało ' . $this->formatDuration($remaining),
                'progress_percent' => $progressPercent,
                'marker_percent' => $progressPercent,
                'show_marker' => false,
                'status_class' => 'is-warning',
                'resolved_at' => '',
            ];
        }

        return [
            'headline' => 'Czas na rozpatrzenie reklamacji',
            'subline' => 'Pozostało ' . $this->formatDuration($remaining),
            'progress_percent' => $progressPercent,
            'marker_percent' => $progressPercent,
            'show_marker' => false,
            'status_class' => 'is-ok',
            'resolved_at' => '',
        ];
    }

    protected function resolveClaimDecisionMeta(array $issue, array $messages = []): array
    {
        $candidates = [
            ['value' => $issue['resolution']['createdAt'] ?? null, 'source' => 'resolution.createdAt'],
            ['value' => $issue['resolution']['resolvedAt'] ?? null, 'source' => 'resolution.resolvedAt'],
            ['value' => $issue['currentState']['changedAt'] ?? null, 'source' => 'currentState.changedAt'],
            ['value' => $issue['currentState']['statusChangedAt'] ?? null, 'source' => 'currentState.statusChangedAt'],
            ['value' => $issue['currentState']['updatedAt'] ?? null, 'source' => 'currentState.updatedAt'],
            ['value' => $issue['resolvedAt'] ?? null, 'source' => 'resolvedAt'],
            ['value' => $issue['updatedAt'] ?? null, 'source' => 'updatedAt'],
        ];

        foreach ($candidates as $candidate) {
            $createdAt = trim((string) ($candidate['value'] ?? ''));
            if ($createdAt === '' || strtotime($createdAt) === false) {
                continue;
            }

            return [
                'created_at' => $createdAt,
                'source' => (string) $candidate['source'],
            ];
        }

        $latestDecisionMessage = null;
        foreach ($messages as $message) {
            if (!is_array($message)) {
                continue;
            }

            $createdAt = trim((string) ($message['createdAt'] ?? ''));
            if ($createdAt === '' || strtotime($createdAt) === false) {
                continue;
            }

            $role = mb_strtoupper(trim((string) ($message['author']['role'] ?? '')));
            if (!in_array($role, ['SELLER', 'ALLEGRO'], true)) {
                continue;
            }

            $messageType = mb_strtoupper(trim((string) ($message['type'] ?? '')));
            $messageText = mb_strtolower($this->resolveIssueTextValue($message['text'] ?? ''));
            $looksLikeDecision = in_array($messageType, ['CLAIM_ACCEPTED', 'CLAIM_REJECTED', 'ACCEPTED', 'REJECTED'], true)
                || preg_match('/(uznan|odrzucon|rozpatrzon|accepted|rejected)/u', $messageText) === 1;

            if (!$looksLikeDecision) {
                continue;
            }

            $latestDecisionMessage = $createdAt;
        }

        if ($latestDecisionMessage !== null) {
            return [
                'created_at' => $latestDecisionMessage,
                'source' => 'chat.decision_message',
            ];
        }

        return [];
    }

    protected function renderClaimProgressBar(string $className, array $timeMeta): string
    {
        $progressPercent = (float) ($timeMeta['progress_percent'] ?? 0);
        $markerPercent = (float) ($timeMeta['marker_percent'] ?? $progressPercent);
        $showMarker = !empty($timeMeta['show_marker']);
        $markerLabel = trim((string) ($timeMeta['marker_label'] ?? ''));
        $flagClass = $markerPercent >= 88 ? ' aar-claim-progress-flag-right' : '';

        $html = '<div class="' . Tools::safeOutput($className) . '">';
        $html .= '<span style="width:' . Tools::safeOutput((string) $progressPercent) . '%"></span>';
        if ($showMarker) {
            $html .= '<i class="aar-claim-progress-marker" style="left:' . Tools::safeOutput((string) $markerPercent) . '%"></i>';
            if ($markerLabel !== '') {
                $html .= '<b class="aar-claim-progress-flag' . Tools::safeOutput($flagClass) . '" style="left:' . Tools::safeOutput((string) $markerPercent) . '%">' . Tools::safeOutput($markerLabel) . '</b>';
            }
        }
        $html .= '</div>';

        return $html;
    }

    protected function getClaimDecisionMarkerLabel(string $status): string
    {
        $status = mb_strtoupper(trim($status));

        if ($status === 'CLAIM_ACCEPTED') {
            return 'Uznana';
        }

        if ($status === 'CLAIM_REJECTED') {
            return 'Odrzucona';
        }

        return 'Rozpatrzona';
    }

    protected function formatDuration(int $seconds): string
    {
        $days = (int) floor($seconds / 86400);
        $hours = (int) floor(($seconds % 86400) / 3600);

        if ($days > 0) {
            return $days . ' d ' . $hours . ' h';
        }

        $minutes = (int) floor(($seconds % 3600) / 60);
        if ($hours > 0) {
            return $hours . ' h ' . $minutes . ' min';
        }

        return max(0, $minutes) . ' min';
    }

    protected function renderIssueHeaderBadges(array $issue): string
    {
        if (mb_strtoupper((string) ($issue['type'] ?? '')) !== 'CLAIM') {
            return '';
        }

        $status = (string) ($issue['currentState']['status'] ?? '');
        $statusClass = $this->getIssueStatusClass($status);
        $chatActive = !empty($issue['currentState']['chatActive']);
        $right = $this->formatIssueRight((string) ($issue['right'] ?? ''));

        $html = '<div class="aar-claim-badges aar-header-claim-badges">';
        $html .= '<span class="aar-claim-badge aar-claim-status aar-status-badge aar-status-badge-' . Tools::safeOutput($statusClass) . ' ' . Tools::safeOutput($statusClass) . '">' . Tools::safeOutput($this->formatIssueStatus($status)) . '</span>';
        $html .= '<span class="aar-claim-badge">' . Tools::safeOutput($chatActive ? 'Czat aktywny' : 'Czat zamknięty') . '</span>';
        if ($right !== '') {
            $html .= '<span class="aar-claim-badge">' . Tools::safeOutput($right) . '</span>';
        }
        $html .= '</div>';

        return $html;
    }

    protected function resolvePrestashopOrderLink(array $issue, array $messages = []): ?array
    {
        $checkoutFormIds = $this->extractCheckoutFormIdsFromPayload($issue);
        foreach ($messages as $message) {
            if (is_array($message)) {
                $checkoutFormIds = array_merge($checkoutFormIds, $this->extractCheckoutFormIdsFromPayload($message));
            }
        }
        $checkoutFormIds = array_values(array_unique(array_filter(array_map('strval', $checkoutFormIds))));

        foreach ($checkoutFormIds as $checkoutFormId) {
            $resolved = $this->findPrestashopOrderByX13CheckoutForm($checkoutFormId);
            if ($resolved !== null) {
                return $resolved;
            }
        }

        $identifiers = array_filter(array_unique(array_merge($checkoutFormIds, array_map('strval', [
            (string) ($issue['order']['id'] ?? ''),
            (string) ($issue['buyer']['order']['id'] ?? ''),
        ]))));

        foreach ($identifiers as $identifier) {
            $resolved = $this->findPrestashopOrderByExternalIdentifier($identifier);
            if ($resolved !== null) {
                return $resolved;
            }
        }

        $resolved = $this->findPrestashopOrderByX13IssueHints($issue);
        if ($resolved !== null) {
            return $resolved;
        }

        return null;
    }

    protected function findPrestashopOrderByX13CheckoutForm(string $checkoutFormId): ?array
    {
        $checkoutFormId = trim($checkoutFormId);
        if ($checkoutFormId === '') {
            return null;
        }

        $directOrder = $this->findPrestashopOrderByPrXallegroCheckoutForm($checkoutFormId);
        if ($directOrder !== null) {
            return $directOrder;
        }

        foreach ($this->getX13OrderTableNames() as $tableName) {
            try {
                $row = Db::getInstance()->getRow('
                    SELECT xo.`id_order`
                    FROM `' . bqSQL($tableName) . '` xo
                    WHERE (
                        TRIM(xo.`checkout_form`) = "' . pSQL($checkoutFormId) . '"
                        OR xo.`checkout_form` LIKE "%' . pSQL($checkoutFormId) . '%"
                    )
                        AND xo.`id_order` IS NOT NULL
                        AND xo.`id_order` > 0
                    ORDER BY xo.`id_xallegro_order` DESC
                ');
            } catch (Throwable $e) {
                PrestaShopLogger::addLog('[AAR] x13 order link lookup skipped for ' . $tableName . '.checkout_form ' . $checkoutFormId . ': ' . $e->getMessage(), 2);
                continue;
            }

            if (is_array($row) && (int) ($row['id_order'] ?? 0) > 0) {
                return $this->buildPrestashopOrderLinkFromRow($row, $tableName . '.checkout_form');
            }

            try {
                $row = Db::getInstance()->getRow('
                    SELECT xo.`id_order`
                    FROM `' . bqSQL($tableName) . '` xo
                    WHERE xo.`checkout_form_content` LIKE "%' . pSQL($checkoutFormId) . '%"
                        AND xo.`id_order` IS NOT NULL
                        AND xo.`id_order` > 0
                    ORDER BY xo.`id_xallegro_order` DESC
                ');
            } catch (Throwable $e) {
                PrestaShopLogger::addLog('[AAR] x13 order content lookup skipped for ' . $tableName . '.checkout_form_content ' . $checkoutFormId . ': ' . $e->getMessage(), 2);
                continue;
            }

            if (is_array($row) && (int) ($row['id_order'] ?? 0) > 0) {
                return $this->buildPrestashopOrderLinkFromRow($row, $tableName . '.checkout_form_content');
            }
        }

        return null;
    }

    protected function findPrestashopOrderByPrXallegroCheckoutForm(string $checkoutFormId): ?array
    {
        $checkoutFormId = trim($checkoutFormId);
        if ($checkoutFormId === '') {
            return null;
        }

        $conditions = [
            '`checkout_form` = "' . pSQL($checkoutFormId) . '"',
            'TRIM(`checkout_form`) = "' . pSQL($checkoutFormId) . '"',
            '`checkout_form` LIKE "' . pSQL($checkoutFormId) . '"',
            '`checkout_form` LIKE "%' . pSQL($checkoutFormId) . '%"',
            '`checkout_form_content` LIKE "%' . pSQL($checkoutFormId) . '%"',
        ];

        foreach ($conditions as $condition) {
            $row = $this->findPrestashopOrderRowInPrXallegroOrderByCondition($condition, $checkoutFormId);
            if ($row !== null) {
                return $this->buildPrestashopOrderLinkFromRow($row, 'pr_xallegro_order.checkout_form');
            }
        }

        return null;
    }

    protected function findPrestashopOrderRowInPrXallegroOrderByCondition(string $condition, string $checkoutFormId): ?array
    {
        try {
            $idOrder = (int) Db::getInstance()->getValue('
                SELECT `id_order`
                FROM `pr_xallegro_order`
                WHERE ' . $condition . '
                    AND `id_order` > 0
            ');
        } catch (Throwable $e) {
            PrestaShopLogger::addLog('[AAR] direct pr_xallegro_order checkout_form lookup skipped for ' . $checkoutFormId . ': ' . $e->getMessage(), 2);
            return null;
        }

        if ($idOrder <= 0) {
            return null;
        }

        return ['id_order' => $idOrder];
    }

    protected function buildPrestashopOrderLookupMissLabel(string $checkoutFormId): string
    {
        $dbName = '';
        $tableStatus = 'brak danych';

        try {
            $dbName = (string) Db::getInstance()->getValue('SELECT DATABASE()');
        } catch (Throwable $e) {
            $dbName = 'blad DB';
        }

        try {
            $count = (int) Db::getInstance()->getValue('
                SELECT COUNT(*)
                FROM `pr_xallegro_order`
                WHERE `checkout_form` LIKE "%' . pSQL($checkoutFormId) . '%"
            ');
            $tableStatus = 'pasujace rekordy: ' . $count;
        } catch (Throwable $e) {
            $tableStatus = 'blad COUNT: ' . $e->getMessage();
        }

        try {
            $idOrder = (int) Db::getInstance()->getValue('
                SELECT `id_order`
                FROM `pr_xallegro_order`
                WHERE `checkout_form` LIKE "%' . pSQL($checkoutFormId) . '%"
            ');
            $tableStatus .= ', id_order: ' . $idOrder;
        } catch (Throwable $e) {
            $tableStatus .= ', blad ID: ' . $e->getMessage();
        }

        $parts = ['Nie znaleziono w PrestaShop'];
        if ($dbName !== '') {
            $parts[] = 'DB: ' . $dbName;
        }
        $parts[] = $tableStatus;

        return implode(' | ', $parts);
    }

    protected function getX13OrderTableNames(): array
    {
        $prefix = (string) _DB_PREFIX_;
        $prefixWithoutTrailingUnderscore = rtrim($prefix, '_');
        $tables = [
            $prefix . 'xallegro_order',
            $prefixWithoutTrailingUnderscore . '_xallegro_order',
            'pr_xallegro_order',
        ];

        try {
            $rows = Db::getInstance()->executeS('SHOW TABLES LIKE "%xallegro\\_order"');
            if (is_array($rows)) {
                foreach ($rows as $row) {
                    $tableName = (string) reset($row);
                    if ($tableName !== '') {
                        $tables[] = $tableName;
                    }
                }
            }
        } catch (Throwable $e) {
            PrestaShopLogger::addLog('[AAR] x13 order table discovery skipped: ' . $e->getMessage(), 2);
        }

        return array_values(array_unique(array_filter($tables, function (string $tableName): bool {
            return $this->isSafeSqlIdentifier($tableName);
        })));
    }

    protected function buildPrestashopOrderLinkFromRow(array $row, string $source): ?array
    {
        $idOrder = (int) ($row['id_order'] ?? 0);
        if ($idOrder <= 0) {
            return null;
        }

        $reference = trim((string) ($row['reference'] ?? ''));
        if ($reference === '') {
            $orderRow = $this->findPrestashopOrderRowById($idOrder);
            $reference = trim((string) ($orderRow['reference'] ?? ''));
        }

        return [
            'id_order' => $idOrder,
            'reference' => $reference !== '' ? $reference : ('#' . $idOrder),
            'url' => $this->getPrestashopOrderViewUrl($idOrder),
            'source' => $source,
        ];
    }

    protected function findPrestashopOrderRowById(int $idOrder): array
    {
        if ($idOrder <= 0) {
            return [];
        }

        foreach ($this->getPrestashopCoreTableNames('orders') as $tableName) {
            try {
                $row = Db::getInstance()->getRow('
                    SELECT `id_order`, `reference`
                    FROM `' . bqSQL($tableName) . '`
                    WHERE `id_order` = ' . (int) $idOrder . '
                ');
            } catch (Throwable $e) {
                PrestaShopLogger::addLog('[AAR] order reference lookup skipped for ' . $tableName . ' #' . (int) $idOrder . ': ' . $e->getMessage(), 2);
                continue;
            }

            if (is_array($row) && (int) ($row['id_order'] ?? 0) > 0) {
                return $row;
            }
        }

        return [];
    }

    protected function getPrestashopCoreTableNames(string $baseName): array
    {
        $prefix = (string) _DB_PREFIX_;
        $prefixWithoutTrailingUnderscore = rtrim($prefix, '_');

        return array_values(array_unique(array_filter([
            $prefix . $baseName,
            $prefixWithoutTrailingUnderscore . '_' . $baseName,
            'pr_' . $baseName,
        ], function (string $tableName): bool {
            return $this->isSafeSqlIdentifier($tableName);
        })));
    }

    protected function getPrestashopOrderViewUrl(int $idOrder): string
    {
        if ($idOrder <= 0) {
            return '';
        }

        $adminBase = $this->getCurrentAdminIndexUrl();
        if ($adminBase === '') {
            $adminBase = $this->context->link->getAdminBaseLink();
            $adminBase = preg_replace('#/index\.php(?:/.*)?$#', '/index.php', (string) $adminBase);
            $adminBase = rtrim((string) $adminBase, '/');
        }

        return $adminBase . '/sell/orders/' . (int) $idOrder . '/view';
    }

    protected function getCurrentAdminIndexUrl(): string
    {
        $isHttps = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
            || (string) ($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https';
        $scheme = $isHttps ? 'https' : 'http';
        $host = trim((string) ($_SERVER['HTTP_HOST'] ?? ''));
        $scriptName = trim((string) ($_SERVER['SCRIPT_NAME'] ?? ''));

        if ($host === '' || $scriptName === '') {
            return '';
        }

        $adminDir = rtrim(str_replace('\\', '/', dirname($scriptName)), '/');

        return $scheme . '://' . $host . $adminDir . '/index.php';
    }

    protected function findPrestashopOrderByX13IssueHints(array $issue): ?array
    {
        $offerId = trim((string) ($issue['offer']['id'] ?? ''));
        $buyerLogin = trim((string) ($issue['buyer']['login'] ?? ''));
        $buyerId = trim((string) ($issue['buyer']['id'] ?? ''));
        if ($offerId === '' || ($buyerLogin === '' && $buyerId === '')) {
            return null;
        }

        $tableName = _DB_PREFIX_ . 'xallegro_order';
        $buyerCondition = [];
        if ($buyerLogin !== '') {
            $buyerCondition[] = 'xo.`checkout_form_content` LIKE "%' . pSQL($buyerLogin) . '%"';
        }
        if ($buyerId !== '') {
            $buyerCondition[] = 'xo.`checkout_form_content` LIKE "%' . pSQL($buyerId) . '%"';
        }

        try {
            $row = Db::getInstance()->getRow('
                SELECT xo.`id_order`, o.`reference`
                FROM `' . bqSQL($tableName) . '` xo
                INNER JOIN `' . _DB_PREFIX_ . 'orders` o ON (o.`id_order` = xo.`id_order`)
                WHERE xo.`checkout_form_content` LIKE "%' . pSQL($offerId) . '%"
                    AND (' . implode(' OR ', $buyerCondition) . ')
                    AND xo.`id_order` IS NOT NULL
                ORDER BY xo.`id_xallegro_order` DESC
            ');
        } catch (Throwable $e) {
            PrestaShopLogger::addLog('[AAR] x13 order content lookup skipped for offer ' . $offerId . ': ' . $e->getMessage(), 2);
            return null;
        }

        if (!is_array($row) || (int) ($row['id_order'] ?? 0) <= 0) {
            return null;
        }

        return $this->buildPrestashopOrderLinkFromRow($row, $tableName . '.checkout_form_content');
    }

    protected function findPrestashopOrderByExternalIdentifier(string $identifier): ?array
    {
        static $candidates = null;

        $identifier = trim($identifier);
        if ($identifier === '') {
            return null;
        }

        if ($candidates === null) {
            $candidates = $this->discoverPrestashopOrderLinkCandidates();
        }

        foreach ($candidates as $candidate) {
            $tableName = trim((string) ($candidate['table'] ?? ''));
            $matchColumn = trim((string) ($candidate['match_column'] ?? ''));
            if (!$this->isSafeSqlIdentifier($tableName) || !$this->isSafeSqlIdentifier($matchColumn)) {
                continue;
            }

            $sql = 'SELECT * FROM `' . bqSQL($tableName) . '` WHERE `' . bqSQL($matchColumn) . '` = "' . pSQL($identifier) . '" LIMIT 1';

            try {
                $row = Db::getInstance()->getRow($sql);
            } catch (Throwable $e) {
                PrestaShopLogger::addLog('[AAR] Order link lookup skipped for ' . $tableName . '.' . $matchColumn . ': ' . $e->getMessage(), 2);
                continue;
            }

            if (!is_array($row)) {
                continue;
            }

            $idOrder = $this->extractPrestashopOrderIdFromRow($row);
            if ($idOrder <= 0) {
                continue;
            }

            $orderRow = Db::getInstance()->getRow('SELECT id_order, reference FROM `' . _DB_PREFIX_ . 'orders` WHERE id_order=' . (int) $idOrder);
            if (!is_array($orderRow)) {
                continue;
            }

            return $this->buildPrestashopOrderLinkFromRow($orderRow, $tableName . '.' . $matchColumn);
        }

        return null;
    }

    protected function resolvePrestashopOrderThumbnailUrl(array $issue, array $messages = []): string
    {
        $linkedOrder = $this->resolvePrestashopOrderLink($issue, $messages);
        if (!is_array($linkedOrder) || (int) ($linkedOrder['id_order'] ?? 0) <= 0) {
            return '';
        }

        return $this->getPrestashopOrderThumbnailUrl((int) $linkedOrder['id_order']);
    }

    protected function getPrestashopOrderThumbnailUrl(int $idOrder): string
    {
        if ($idOrder <= 0) {
            return '';
        }

        $idLang = (int) ($this->context->language->id ?? Configuration::get('PS_LANG_DEFAULT'));
        $idShop = (int) ($this->context->shop->id ?? Context::getContext()->shop->id ?? 1);

        $sql = 'SELECT od.`product_id`, pl.`link_rewrite`, i.`id_image`
            FROM `' . _DB_PREFIX_ . 'order_detail` od
            INNER JOIN `' . _DB_PREFIX_ . 'product_lang` pl
                ON (pl.`id_product` = od.`product_id` AND pl.`id_lang` = ' . (int) $idLang . ' AND pl.`id_shop` = ' . (int) $idShop . ')
            LEFT JOIN `' . _DB_PREFIX_ . 'image` i
                ON (i.`id_product` = od.`product_id`)
            WHERE od.`id_order` = ' . (int) $idOrder . '
            ORDER BY i.`cover` DESC, i.`position` ASC, od.`id_order_detail` ASC
            LIMIT 1';

        try {
            $row = Db::getInstance()->getRow($sql);
        } catch (Throwable $e) {
            PrestaShopLogger::addLog('[AAR] PrestaShop order thumbnail lookup skipped for order #' . (int) $idOrder . ': ' . $e->getMessage(), 2);
            return '';
        }
        if (!is_array($row) || (int) ($row['product_id'] ?? 0) <= 0 || (int) ($row['id_image'] ?? 0) <= 0) {
            return '';
        }

        $linkRewrite = trim((string) ($row['link_rewrite'] ?? ''));
        if ($linkRewrite === '') {
            return '';
        }

        return (string) $this->context->link->getImageLink($linkRewrite, (string) $row['id_image'], 'small_default');
    }

    protected function discoverPrestashopOrderLinkCandidates(): array
    {
        $tables = Db::getInstance()->executeS('SHOW TABLES');
        if (!is_array($tables)) {
            return [];
        }

        $matchNeedles = ['checkout', 'allegro', 'external', 'marketplace', 'order_uuid', 'orderuid', 'buyform'];
        $idOrderColumns = ['id_order', 'order_id', 'id_orders', 'id_ps_order'];
        $candidates = [];

        foreach ($tables as $tableRow) {
            $tableName = (string) reset($tableRow);
            if ($tableName === '' || strpos($tableName, _DB_PREFIX_) !== 0) {
                continue;
            }

            if (!preg_match('/(allegro|x13|marketplace|order)/i', $tableName)) {
                continue;
            }

            $columnsRows = Db::getInstance()->executeS('SHOW COLUMNS FROM `' . bqSQL($tableName) . '`');
            if (!is_array($columnsRows)) {
                continue;
            }

            $columns = array_map(function (array $column): string {
                return (string) ($column['Field'] ?? '');
            }, $columnsRows);

            $hasIdOrder = (bool) array_intersect($idOrderColumns, $columns);
            if (!$hasIdOrder) {
                continue;
            }

            foreach ($columns as $column) {
                if (!$this->isSafeSqlIdentifier($column) || in_array($column, $idOrderColumns, true)) {
                    continue;
                }

                foreach ($matchNeedles as $needle) {
                    if (stripos($column, $needle) !== false) {
                        $candidates[] = [
                            'table' => $tableName,
                            'match_column' => $column,
                        ];
                        break;
                    }
                }
            }
        }

        return $candidates;
    }

    protected function isSafeSqlIdentifier(string $identifier): bool
    {
        return $identifier !== '' && preg_match('/^[A-Za-z0-9_]+$/', $identifier) === 1;
    }

    protected function extractPrestashopOrderIdFromRow(array $row): int
    {
        foreach (['id_order', 'order_id', 'id_orders', 'id_ps_order'] as $key) {
            if (isset($row[$key]) && (int) $row[$key] > 0) {
                return (int) $row[$key];
            }
        }

        return 0;
    }

    protected function renderInboxColorStyles(): string
    {
        return '<style>
            .aar-inbox-panel {
                padding: 0 !important;
                margin: var(--aar-inbox-top-gap, 10px) 0 0 !important;
                overflow: hidden;
                height: var(--aar-inbox-height, auto);
                max-height: var(--aar-inbox-height, none);
                min-height: 320px;
                display: flex;
                flex-direction: column;
            }
            .aar-inbox-panel.panel {
                padding: 0 !important;
            }
            .aar-inbox {
                display: flex;
                flex-wrap: nowrap;
                background: #eef2f4;
                min-height: 0;
                flex: 1 1 auto;
                margin: 0 !important;
            }
            .aar-inbox .aar-inbox-col {
                padding-left: 0;
                padding-right: 0;
                min-height: 0;
            }
            .aar-inbox .aar-inbox-col-list {
                border-right: 1px solid #d8dde0;
                background: #f7f8f9;
            }
            .aar-inbox-panel .aar-issues-filters {
                display: flex;
                justify-content: flex-end;
                align-items: center;
                gap: 12px;
                margin: 0;
                flex: 0 0 auto;
            }
            .aar-inbox-panel .aar-filter-group {
                display: flex;
                align-items: center;
                gap: 10px;
            }
            .aar-inbox-panel .aar-filter-group label {
                margin: 0;
                font-size: 12px;
                font-weight: 700;
                color: #7a8288;
                text-transform: uppercase;
                letter-spacing: .04em;
            }
            .aar-inbox-panel .aar-filter-group .form-control {
                width: 190px;
                height: 36px;
                border-radius: 6px;
                box-shadow: none;
            }
            .aar-inbox .aar-thread-list {
                height: 100%;
                overflow: auto;
                overscroll-behavior: contain;
                border: 0;
                background: #f7f8f9;
                margin-bottom: 0;
            }
            .aar-inbox .aar-load-more-wrap {
                padding: 12px 16px 16px;
                background: #f7f8f9;
                text-align: center;
            }
            .aar-inbox .aar-load-more {
                width: 100%;
                border-radius: 6px;
                font-weight: 700;
            }
            .aar-inbox .aar-thread-item {
                border: 0;
                border-bottom: 1px solid #e1e6ea;
                color: #3a3f44;
                background: #f7f8f9;
                margin: 0;
                position: relative;
                padding: 12px 16px 10px;
            }
            .aar-inbox .aar-thread-body {
                display: flex;
                align-items: flex-start;
                gap: 12px;
                min-width: 0;
            }
            .aar-inbox .aar-thread-thumb {
                width: 56px;
                min-width: 56px;
                height: 56px;
                border-radius: 6px;
                overflow: hidden;
                background: #e7edf1;
                border: 1px solid #d8dde0;
                display: flex;
                align-items: center;
                justify-content: center;
            }
            .aar-inbox .aar-thread-thumb img {
                width: 100%;
                height: 100%;
                object-fit: cover;
                display: block;
            }
            .aar-inbox .aar-thread-thumb-placeholder {
                width: 22px;
                height: 22px;
                border-radius: 5px;
                background: #c7d2da;
                display: block;
            }
            .aar-inbox .aar-thread-content {
                min-width: 0;
                flex: 1 1 auto;
            }
            .aar-inbox .aar-thread-head {
                display: flex;
                align-items: baseline;
                justify-content: space-between;
                gap: 10px;
            }
            .aar-inbox .aar-thread-login {
                display: block;
                min-width: 0;
                font-size: 15px;
                line-height: 1.3;
                font-weight: 400;
            }
            .aar-inbox .aar-thread-date {
                color: #7a8288;
                white-space: nowrap;
                flex-shrink: 0;
                font-size: 12px;
            }
            .aar-inbox .aar-thread-preview {
                margin-top: 4px;
                color: #7a8288;
                font-size: 12px;
                line-height: 1.35;
                padding-right: 54px;
            }
            .aar-inbox .aar-thread-meta {
                margin-top: 6px;
                display: flex;
                flex-wrap: wrap;
                gap: 6px;
                align-items: center;
            }
            .aar-inbox .aar-thread-deadline {
                margin-top: 10px;
                padding: 0;
                border-radius: 0;
                background: transparent;
                border: 0;
            }
            .aar-inbox .aar-thread-deadline.is-warning {
                background: transparent;
                border-color: transparent;
            }
            .aar-inbox .aar-thread-deadline.is-overdue {
                background: transparent;
                border-color: transparent;
            }
            .aar-inbox .aar-thread-deadline-row {
                display: flex;
                align-items: baseline;
                justify-content: space-between;
                gap: 10px;
            }
            .aar-inbox .aar-thread-deadline-label {
                color: #2d3033;
                font-size: 11px;
                font-weight: 700;
                line-height: 1.3;
            }
            .aar-inbox .aar-thread-deadline-date {
                color: #4f5a64;
                font-size: 11px;
                font-weight: 700;
                white-space: nowrap;
            }
            .aar-inbox .aar-thread-deadline-subline {
                margin-top: 3px;
                color: #7a8288;
                font-size: 11px;
                line-height: 1.35;
            }
            .aar-inbox .aar-thread-deadline-progress {
                position: relative;
                margin-top: 7px;
                height: 6px;
                background: #e7edf1;
                border-radius: 999px;
                overflow: visible;
            }
            .aar-inbox .aar-thread-deadline-progress span {
                display: block;
                height: 100%;
                background: linear-gradient(90deg, #25b7a8 0%, #0b7f72 100%);
                border-radius: 999px;
            }
            .aar-inbox .aar-claim-progress-marker {
                position: absolute;
                top: 50%;
                width: 22px;
                height: 22px;
                margin-left: -11px;
                transform: translateY(-50%);
                border-radius: 999px;
                background: #ffffff;
                border: 6px solid #0b7f72;
                box-shadow: none;
                z-index: 3;
            }
            .aar-inbox .aar-claim-progress-flag {
                position: absolute;
                top: -42px;
                transform: translateX(-50%);
                display: inline-flex;
                align-items: center;
                justify-content: center;
                min-height: 28px;
                padding: 5px 10px;
                border-radius: 6px;
                background: #0b7f72;
                color: #fff;
                font-size: 12px;
                font-weight: 700;
                line-height: 1;
                white-space: nowrap;
                box-shadow: 0 2px 6px rgba(16, 24, 40, .18);
                z-index: 4;
            }
            .aar-inbox .aar-claim-progress-flag:after {
                content: "";
                position: absolute;
                left: 50%;
                bottom: -5px;
                width: 10px;
                height: 10px;
                background: inherit;
                transform: translateX(-50%) rotate(45deg);
                border-radius: 2px;
            }
            .aar-inbox .aar-claim-progress-flag-right {
                transform: translateX(calc(-100% + 11px));
            }
            .aar-inbox .aar-claim-progress-flag-right:after {
                left: auto;
                right: 6px;
                transform: rotate(45deg);
            }
            .aar-inbox .aar-thread-deadline-progress .aar-claim-progress-flag {
                display: none;
            }
            .aar-inbox .aar-thread-deadline-progress .aar-claim-progress-marker {
                width: 14px;
                height: 14px;
                margin-left: -7px;
                background: #0b7f72;
                border: 0;
                box-shadow: none;
            }
            .aar-inbox .aar-thread-deadline.is-warning .aar-thread-deadline-progress span {
                background: linear-gradient(90deg, #f5b942 0%, #d68b00 100%);
            }
            .aar-inbox .aar-thread-deadline.is-overdue .aar-thread-deadline-progress span {
                background: linear-gradient(90deg, #f97066 0%, #d92d20 100%);
            }
            .aar-inbox .aar-thread-deadline.is-warning .aar-claim-progress-marker {
                border-color: #d68b00;
                background: #d68b00;
            }
            .aar-inbox .aar-thread-deadline.is-overdue .aar-claim-progress-marker {
                border-color: #d92d20;
                background: #d92d20;
            }
            .aar-inbox .aar-type-badge {
                display: inline-flex;
                align-items: center;
                min-height: 22px;
                padding: 2px 8px;
                border-radius: 6px;
                font-size: 11px;
                font-weight: 700;
                line-height: 1;
                border: 0;
                box-shadow: none;
            }
            .aar-inbox .aar-type-badge.is-dispute {
                background: #f4a261;
                color: #fff;
            }
            .aar-inbox .aar-type-badge.is-claim {
                background: #4a4a4a;
                color: #fff;
            }
            .aar-inbox .aar-type-badge.is-neutral {
                background: #eef2f4;
                color: #4f5a64;
            }
            .aar-inbox .aar-status-badge {
                display: inline-flex;
                align-items: center;
                min-height: 22px;
                padding: 2px 8px;
                border-radius: 6px;
                font-size: 11px;
                font-weight: 700;
                line-height: 1;
                border: 0;
                box-shadow: none;
            }
            .aar-inbox .aar-status-badge.aar-status-badge-is-warning {
                background: #f4a261;
                color: #fff;
            }
            .aar-inbox .aar-status-badge.aar-status-badge-is-ok {
                background: #1f9d68;
                color: #fff;
            }
            .aar-inbox .aar-status-badge.aar-status-badge-is-overdue {
                background: #d64545;
                color: #fff;
            }
            .aar-inbox .aar-status-badge.aar-status-badge-is-neutral {
                background: #6b7280;
                color: #fff;
            }
            .aar-inbox .aar-thread-unread .aar-thread-login,
            .aar-inbox .aar-thread-unread .aar-thread-date,
            .aar-inbox .aar-thread-unread .aar-thread-preview {
                font-weight: 700;
            }
            .aar-inbox .aar-thread-unread .aar-thread-date {
                color: #3a3f44;
            }
            .aar-inbox .aar-thread-item:hover,
            .aar-inbox .aar-thread-item:focus {
                color: #0b7f72;
                background: #edf4f3;
            }
            .aar-inbox .aar-thread-item.active,
            .aar-inbox .aar-thread-item.active:hover,
            .aar-inbox .aar-thread-item.active:focus {
                color: #f5f8fa;
                background: #555b63;
                border-bottom-color: #555b63;
            }
            .aar-inbox .aar-thread-item.active .aar-thread-date,
            .aar-inbox .aar-thread-item.active .aar-thread-preview {
                color: #d3dde4;
            }
            .aar-inbox .aar-thread-item.active .aar-thread-deadline {
                background: transparent;
                border-color: transparent;
            }
            .aar-inbox .aar-thread-item.active .aar-thread-deadline.is-warning {
                background: transparent;
                border-color: transparent;
            }
            .aar-inbox .aar-thread-item.active .aar-thread-deadline.is-overdue {
                background: transparent;
                border-color: transparent;
            }
            .aar-inbox .aar-thread-item.active .aar-thread-deadline-label,
            .aar-inbox .aar-thread-item.active .aar-thread-deadline-date {
                color: #f5f8fa;
            }
            .aar-inbox .aar-thread-item.active .aar-thread-deadline-subline {
                color: #d3dde4;
            }
            .aar-inbox .aar-inbox-col-conversation {
                background: #ffffff;
                display: flex;
                min-height: 0;
                position: relative;
            }
            .aar-inbox .aar-inbox-col-conversation.is-loading {
                pointer-events: none;
            }
            .aar-inbox .aar-conversation-loader {
                display: flex;
                flex: 1 1 auto;
                min-height: 360px;
                align-items: center;
                justify-content: center;
                background: #ffffff;
            }
            .aar-inbox .aar-conversation-spinner {
                width: 38px;
                height: 38px;
                border: 4px solid #d9e2e8;
                border-top-color: #25b7a8;
                border-radius: 999px;
                animation: aar-spin .75s linear infinite;
            }
            @keyframes aar-spin {
                to {
                    transform: rotate(360deg);
                }
            }
            .aar-inbox .aar-conversation-shell {
                display: flex;
                flex-direction: column;
                width: 100%;
                height: 100%;
                min-height: 0;
            }
            .aar-inbox .aar-conversation-header {
                display: flex;
                align-items: center;
                justify-content: space-between;
                gap: 18px;
                padding: 14px 20px 10px;
                border-bottom: 1px solid #d8dde0;
                background: #fbfcfc;
                flex: 0 0 auto;
            }
            .aar-inbox .aar-conversation-title {
                min-width: 0;
            }
            .aar-inbox .aar-conversation-title h4 {
                margin: 0;
                font-size: 18px;
                font-weight: 700;
                line-height: 1.25;
            }
            .aar-inbox .aar-conversation-title h4 a,
            .aar-inbox .aar-conversation-title h4 a:visited {
                color: #25b9d7;
                text-decoration: none;
            }
            .aar-inbox .aar-conversation-title h4 a:hover,
            .aar-inbox .aar-conversation-title h4 a:focus {
                color: #178ca6;
                text-decoration: none;
            }
            .aar-inbox .aar-conversation-title small {
                color: #7a8288;
                display: block;
                margin-top: 4px;
                font-size: 14px;
            }
            .aar-inbox .aar-return-header-meta a,
            .aar-inbox .aar-return-header-meta a:visited {
                color: #25b9d7;
                text-decoration: none;
            }
            .aar-inbox .aar-return-header-meta a:hover,
            .aar-inbox .aar-return-header-meta a:focus {
                color: #178ca6;
                text-decoration: none;
            }
            .aar-inbox .aar-return-header-separator {
                color: #a0a7ad;
                margin: 0 4px;
            }
            .aar-inbox .aar-message-window {
                border: 0;
                padding: 22px 20px;
                min-height: 0;
                flex: 1 1 auto;
                overflow: auto;
                overscroll-behavior: contain;
                background: #ffffff;
                margin: 0;
            }
            .aar-inbox .aar-message-row {
                margin-bottom: 18px;
            }
            .aar-inbox .aar-message-left {
                text-align: left;
            }
            .aar-inbox .aar-message-right {
                text-align: right;
            }
            .aar-inbox .aar-message-bubble {
                display: inline-block;
                max-width: 76%;
                text-align: left;
                padding: 14px 16px;
                border: 1px solid #c9d0d4;
                border-radius: 6px;
                line-height: 1.45;
                box-shadow: 0 1px 2px rgba(16, 24, 40, .04);
            }
            .aar-inbox .aar-message-customer {
                color: #2d3033;
                background: #f4f6f8;
                border-color: #bcc4ca;
            }
            .aar-inbox .aar-message-shop {
                color: #f5f8fa;
                background: #363a41;
                border-color: #363a41;
            }
            .aar-inbox .aar-message-head {
                display: flex;
                gap: 10px;
                align-items: baseline;
                justify-content: space-between;
            }
            .aar-inbox .aar-message-head small {
                white-space: nowrap;
                opacity: .9;
            }
            .aar-inbox .aar-message-shop a,
            .aar-inbox .aar-message-shop .aar-message-meta {
                color: #2cc4b3;
            }
            .aar-inbox .aar-message-text {
                white-space: pre-wrap;
                margin-top: 8px;
            }
            .aar-inbox .aar-message-meta {
                display: block;
                margin-top: 10px;
                color: #0b7f72;
            }
            .aar-inbox .aar-claim-summary {
                margin-bottom: 18px;
            }
            .aar-inbox .aar-claim-topbar {
                display: flex;
                align-items: flex-start;
                justify-content: space-between;
                gap: 14px;
                margin-bottom: 14px;
            }
            .aar-inbox .aar-claim-topbar-badges {
                justify-content: flex-end;
            }
            .aar-inbox .aar-claim-label {
                font-size: 12px;
                color: #7a8288;
                text-transform: uppercase;
                letter-spacing: .04em;
            }
            .aar-inbox .aar-claim-badges {
                display: flex;
                flex-wrap: wrap;
                justify-content: flex-end;
                gap: 8px;
            }
            .aar-inbox .aar-header-claim-badges {
                flex: 0 0 auto;
                align-self: center;
            }
            .aar-inbox .aar-claim-badge {
                display: inline-flex;
                align-items: center;
                min-height: 28px;
                padding: 4px 10px;
                background: #fff;
                border: 1px solid #d8dde0;
                border-radius: 6px;
                color: #4f5a64;
                font-size: 12px;
                font-weight: 700;
            }
            .aar-inbox .aar-claim-status.is-ok {
                background: #1f9d68;
                border-color: #1f9d68;
                color: #fff;
            }
            .aar-inbox .aar-claim-status.is-warning {
                background: #d89a28;
                border-color: #d89a28;
                color: #fff;
            }
            .aar-inbox .aar-claim-status.is-overdue {
                background: #d64545;
                border-color: #d64545;
                color: #fff;
            }
            .aar-inbox .aar-claim-status.is-neutral {
                background: #6b7280;
                border-color: #6b7280;
                color: #fff;
            }
            .aar-inbox .aar-claim-deadline {
                padding: 16px 18px;
                background: #fff;
                border: 1px solid #d8dde0;
                border-radius: 6px;
                margin-bottom: 16px;
            }
            .aar-inbox .aar-claim-deadline.is-warning {
                border-color: #ffd597;
                background: #fffaf1;
            }
            .aar-inbox .aar-claim-deadline.is-overdue {
                border-color: #f2b8b8;
                background: #fff4f4;
            }
            .aar-inbox .aar-claim-deadline-head {
                display: flex;
                align-items: flex-start;
                justify-content: space-between;
                gap: 16px;
                margin-bottom: 12px;
            }
            .aar-inbox .aar-claim-deadline-head strong {
                display: block;
                color: #2d3033;
                font-size: 18px;
                margin-bottom: 4px;
            }
            .aar-inbox .aar-claim-deadline-sub,
            .aar-inbox .aar-claim-deadline-date span {
                color: #7a8288;
                font-size: 12px;
            }
            .aar-inbox .aar-claim-deadline-date {
                display: flex;
                flex-direction: column;
                align-items: flex-end;
                gap: 4px;
            }
            .aar-inbox .aar-claim-deadline-date strong {
                font-size: 16px;
                margin: 0;
            }
            .aar-inbox .aar-claim-progress {
                position: relative;
                height: 10px;
                background: #e7edf1;
                border-radius: 999px;
                overflow: visible;
            }
            .aar-inbox .aar-claim-progress span {
                display: block;
                height: 100%;
                background: linear-gradient(90deg, #25b7a8 0%, #0b7f72 100%);
                border-radius: 999px;
            }
            .aar-inbox .aar-claim-deadline.is-warning .aar-claim-progress span {
                background: linear-gradient(90deg, #f5b942 0%, #d68b00 100%);
            }
            .aar-inbox .aar-claim-deadline.is-overdue .aar-claim-progress span {
                background: linear-gradient(90deg, #f97066 0%, #d92d20 100%);
            }
            .aar-inbox .aar-claim-deadline.is-warning .aar-claim-progress-marker {
                border-color: #d68b00;
            }
            .aar-inbox .aar-claim-deadline.is-overdue .aar-claim-progress-marker {
                border-color: #d92d20;
            }
            .aar-inbox .aar-claim-deadline.is-warning .aar-claim-progress-flag {
                background: #d68b00;
            }
            .aar-inbox .aar-claim-deadline.is-overdue .aar-claim-progress-flag {
                background: #d92d20;
            }
            .aar-inbox .aar-claim-grid {
                display: grid;
                grid-template-columns: repeat(2, minmax(0, 1fr));
                gap: 14px;
                margin-bottom: 18px;
            }
            .aar-inbox .aar-claim-card {
                padding: 16px 18px;
                background: #fff;
                border: 1px solid #d8dde0;
                border-radius: 6px;
            }
            .aar-inbox .aar-claim-card h5 {
                margin: 0 0 12px;
                font-size: 15px;
                font-weight: 700;
                color: #2d3033;
            }
            .aar-inbox .aar-claim-card dl {
                margin: 0;
            }
            .aar-inbox .aar-claim-row + .aar-claim-row {
                margin-top: 8px;
                padding-top: 8px;
                border-top: 1px solid #eef2f4;
            }
            .aar-inbox .aar-claim-row {
                display: grid;
                grid-template-columns: max-content minmax(0, 1fr);
                column-gap: 6px;
                align-items: baseline;
            }
            .aar-inbox .aar-claim-row dt {
                margin: 0;
                font-size: 13px;
                color: #7a8288;
                font-weight: 700;
                white-space: nowrap;
            }
            .aar-inbox .aar-claim-row dt::after {
                content: ":";
            }
            .aar-inbox .aar-claim-row dd {
                margin: 0;
                font-size: 14px;
                color: #2d3033;
                font-weight: 600;
                min-width: 0;
                overflow-wrap: anywhere;
            }
            .aar-inbox .aar-claim-body {
                margin-top: 12px;
                padding-top: 12px;
                border-top: 1px solid #eef2f4;
                color: #2d3033;
                line-height: 1.55;
            }
            .aar-inbox .aar-claim-card dl + .aar-claim-body {
                margin-top: 12px;
                padding-top: 12px;
            }
            .aar-inbox .aar-claim-card > h5 + .aar-claim-body {
                margin-top: 0;
                padding-top: 0;
                border-top: 0;
            }
            .aar-inbox .aar-checkout-details {
                display: grid;
                grid-template-columns: repeat(2, minmax(0, 1fr));
                gap: 28px;
                align-items: start;
            }
            .aar-inbox .aar-checkout-details-section {
                min-width: 0;
            }
            .aar-inbox .aar-checkout-details-section:first-child {
                padding-top: 0;
            }
            .aar-inbox .aar-checkout-details-section span {
                display: block;
                color: #2d3033;
                font-size: 14px;
                font-weight: 600;
                overflow-wrap: anywhere;
            }
            .aar-inbox .aar-checkout-details-section span + span {
                margin-top: 4px;
            }
            .aar-inbox .aar-claim-order-link {
                margin-top: 14px;
                padding-top: 14px;
                border-top: 1px solid #eef2f4;
                display: flex;
                flex-direction: column;
                gap: 8px;
                color: #2d3033;
            }
            .aar-inbox .aar-inline-order-button {
                align-self: flex-start;
                border-radius: 6px;
            }
            .aar-inbox .aar-claim-link-meta {
                font-size: 12px;
                color: #7a8288;
            }
            .aar-inbox .aar-return-products {
                padding: 0 0 18px;
                margin: 0 0 18px;
                border-bottom: 1px solid #e1e6ea;
            }
            .aar-inbox .aar-return-product-row {
                display: grid;
                grid-template-columns: minmax(0, 1fr) minmax(120px, auto);
                gap: 18px;
                padding: 14px 0;
                border-bottom: 1px solid #eef2f4;
            }
            .aar-inbox .aar-return-product-row.has-thumb {
                grid-template-columns: 76px minmax(0, 1fr) minmax(120px, auto);
            }
            .aar-inbox .aar-return-product-thumb {
                width: 76px;
                height: 76px;
                border: 1px solid #d8dde0;
                border-radius: 6px;
                background: #f4f6f8;
                overflow: hidden;
            }
            .aar-inbox .aar-return-product-thumb img {
                width: 100%;
                height: 100%;
                object-fit: cover;
                display: block;
            }
            .aar-inbox .aar-return-product-row:last-child {
                border-bottom: 0;
                padding-bottom: 0;
            }
            .aar-inbox .aar-return-product-main {
                min-width: 0;
            }
            .aar-inbox .aar-return-product-main strong {
                display: block;
                color: #2d3033;
                font-size: 15px;
                line-height: 1.35;
            }
            .aar-inbox .aar-return-product-main a {
                color: #2d3033;
                text-decoration: none;
            }
            .aar-inbox .aar-return-product-main a:hover {
                color: #25b9d7;
            }
            .aar-inbox .aar-return-reason {
                margin-top: 10px;
                color: #2d3033;
                font-size: 14px;
            }
            .aar-inbox .aar-return-reason span {
                color: #7a8288;
            }
            .aar-inbox .aar-return-product-side {
                text-align: right;
                color: #2d3033;
                white-space: nowrap;
            }
            .aar-inbox .aar-return-product-side strong {
                display: block;
                margin-top: 8px;
                color: #4f5a64;
                font-size: 15px;
            }
            .aar-inbox .aar-return-simple-grid {
                display: grid;
                grid-template-columns: 1.2fr 1fr 1fr 1.15fr;
                gap: 26px;
                align-items: start;
            }
            .aar-inbox .aar-return-simple-section {
                min-width: 0;
            }
            .aar-inbox .aar-return-simple-section h5 {
                margin: 0 0 14px;
                color: #2d3033;
                font-size: 16px;
                font-weight: 700;
            }
            .aar-inbox .aar-return-debug-link-wrap {
                margin: 14px 0 0 36px;
            }
            .aar-inbox .aar-return-debug-link {
                color: #25b9d7;
                font-size: 12px;
                font-weight: 700;
                text-transform: uppercase;
                letter-spacing: 0;
                padding: 0;
                border: 0;
                background: transparent;
            }
            .aar-inbox .aar-return-debug-link:hover,
            .aar-inbox .aar-return-debug-link:focus {
                color: #1b90a8;
                text-decoration: none;
            }
            .aar-inbox .aar-return-tracking-link {
                padding: 0;
                border: 0;
                background: transparent;
                color: #25b9d7;
                font-size: 14px;
                line-height: 1.45;
            }
            .aar-inbox .aar-return-tracking-link:hover,
            .aar-inbox .aar-return-tracking-link:focus {
                color: #1b90a8;
                text-decoration: none;
            }
            .aar-inbox .aar-return-tracking-modal .modal-dialog,
            .aar-inbox .aar-return-refund-modal .modal-dialog,
            .aar-inbox .aar-return-rejection-modal .modal-dialog,
            .aar-inbox .aar-return-debug-modal .modal-dialog {
                width: min(1100px, calc(100vw - 40px));
            }
            .aar-inbox .aar-return-tracking-modal .modal-dialog {
                width: min(720px, calc(100vw - 40px));
            }
            .aar-inbox .aar-return-refund-modal .modal-dialog {
                width: min(900px, calc(100vw - 40px));
            }
            .aar-inbox .aar-return-rejection-modal .modal-dialog {
                width: min(760px, calc(100vw - 40px));
            }
            .aar-inbox .aar-return-tracking-modal .modal-content,
            .aar-inbox .aar-return-refund-modal .modal-content,
            .aar-inbox .aar-return-rejection-modal .modal-content,
            .aar-inbox .aar-return-debug-modal .modal-content {
                border-radius: 6px;
            }
            .aar-inbox .aar-return-tracking-header {
                display: flex;
                align-items: center;
                justify-content: space-between;
                gap: 16px;
            }
            .aar-inbox .aar-return-tracking-header > .close {
                margin: 0 0 0 auto;
                float: none;
                flex: 0 0 auto;
                align-self: flex-start;
            }
            .aar-inbox .aar-return-tracking-header-main {
                display: flex;
                align-items: baseline;
                flex-wrap: wrap;
                gap: 12px;
                min-width: 0;
            }
            .aar-inbox .aar-return-tracking-header-main .modal-title {
                margin: 0;
                flex: 0 0 auto;
            }
            .aar-inbox .aar-return-tracking-header-meta {
                display: inline-flex;
                align-items: baseline;
                flex-wrap: wrap;
                gap: 12px;
                min-width: 0;
                color: #4f5a64;
            }
            .aar-inbox .aar-return-tracking-header-meta strong {
                color: #2d3033;
                font-size: 16px;
                line-height: 1.3;
            }
            .aar-inbox .aar-return-tracking-modal .modal-body,
            .aar-inbox .aar-return-refund-modal .modal-body,
            .aar-inbox .aar-return-rejection-modal .modal-body,
            .aar-inbox .aar-return-debug-modal .modal-body {
                padding: 16px 18px 18px;
            }
            .aar-inbox .aar-return-tracking-timeline {
                display: block;
                margin: 0;
                padding: 0;
            }
            .aar-inbox .aar-return-tracking-step {
                position: relative;
                min-width: 0;
                min-height: 56px;
                padding: 0 0 18px 34px;
                color: #7a8288;
            }
            .aar-inbox .aar-return-tracking-step:last-child {
                min-height: 0;
                padding-bottom: 0;
            }
            .aar-inbox .aar-return-tracking-step:before,
            .aar-inbox .aar-return-tracking-step:after {
                content: "";
                position: absolute;
                left: 6px;
                width: 6px;
                background: #e3e7ea;
                z-index: 1;
            }
            .aar-inbox .aar-return-tracking-step:before {
                top: 0;
                height: 8px;
            }
            .aar-inbox .aar-return-tracking-step:after {
                top: 16px;
                bottom: 0;
            }
            .aar-inbox .aar-return-tracking-step:first-child:before,
            .aar-inbox .aar-return-tracking-step:last-child:after {
                display: none;
            }
            .aar-inbox .aar-return-tracking-step.is-completed:before,
            .aar-inbox .aar-return-tracking-step.has-next-completed:after,
            .aar-inbox .aar-return-tracking-step.is-active:before {
                background: #25b9d7;
            }
            .aar-inbox .aar-return-tracking-step.is-active:after {
                background: #e3e7ea;
            }
            .aar-inbox .aar-return-tracking-marker {
                position: absolute;
                top: 1px;
                left: 8px;
                width: 16px;
                height: 16px;
                margin-left: -8px;
                border-radius: 999px;
                background: #d9dde1;
                box-shadow: 0 0 0 4px #fff;
                z-index: 2;
            }
            .aar-inbox .aar-return-tracking-step.is-completed .aar-return-tracking-marker {
                background: #25b9d7;
            }
            .aar-inbox .aar-return-tracking-step.is-active .aar-return-tracking-marker {
                width: 18px;
                height: 18px;
                top: 0;
                margin-left: -9px;
                background: #25b9d7;
            }
            .aar-inbox .aar-return-tracking-label {
                color: #2d3033;
                font-size: 15px;
                font-weight: 600;
                line-height: 1.35;
            }
            .aar-inbox .aar-return-tracking-step.is-active .aar-return-tracking-label {
                font-weight: 800;
                color: #25b9d7;
            }
            .aar-inbox .aar-return-tracking-date {
                margin-top: 4px;
                color: #2d3033;
                font-size: 14px;
                font-weight: 600;
            }
            .aar-inbox .aar-return-tracking-code {
                margin-top: 4px;
                color: #7a8288;
                font-size: 12px;
                line-height: 1.35;
            }
            .aar-inbox .aar-return-debug-head {
                display: flex;
                align-items: center;
                justify-content: flex-end;
                gap: 12px;
                margin-bottom: 10px;
            }
            .aar-inbox .aar-return-debug-json {
                margin: 0;
                max-height: min(70vh, 760px);
                overflow: auto;
                padding: 12px;
                background: #f7f9fa;
                border: 1px solid #e3e7ea;
                border-radius: 4px;
                color: #2d3033;
                font-size: 12px;
                line-height: 1.45;
                white-space: pre-wrap;
                word-break: break-word;
            }
            .aar-inbox .aar-return-simple-section div {
                color: #2d3033;
                font-size: 14px;
                line-height: 1.45;
                overflow-wrap: anywhere;
            }
            .aar-inbox .aar-return-simple-section .text-muted {
                color: #7a8288;
            }
            .aar-inbox .aar-return-refund-section {
                min-width: 260px;
            }
            .aar-inbox .aar-return-refund-account {
                white-space: nowrap;
                overflow-wrap: normal !important;
                word-break: keep-all;
            }
            .aar-inbox .aar-return-invoice-flag {
                display: inline-flex;
                align-items: center;
                min-height: 22px;
                margin-top: 8px;
                padding: 2px 8px;
                border-radius: 6px;
                font-size: 12px;
                font-weight: 700;
                line-height: 1.2;
            }
            .aar-inbox .aar-return-invoice-flag.is-invoice {
                background: #2d3033;
                color: #fff;
            }
            .aar-inbox .aar-return-invoice-flag.is-no-invoice {
                background: #eef2f4;
                color: #4f5a64;
            }
            .aar-inbox .aar-return-subheading {
                margin-top: 22px !important;
            }
            .aar-inbox .aar-return-total {
                margin-top: 28px;
                text-align: right;
            }
            .aar-inbox .aar-return-total span {
                display: block;
                color: #2d3033;
                font-size: 13px;
                text-transform: uppercase;
            }
            .aar-inbox .aar-return-total strong {
                display: block;
                color: #4f5a64;
                font-size: 16px;
            }
            .aar-inbox .aar-return-decision-panel {
                padding: 14px 20px 18px;
                background: #fbfcfc;
                border-top: 1px solid #d8dde0;
                flex: 0 0 auto;
            }
            .aar-inbox .aar-return-decision-panel-head {
                display: flex;
                align-items: center;
                justify-content: space-between;
                gap: 18px;
            }
            .aar-inbox .aar-return-decision-dropdown {
                position: relative;
            }
            .aar-inbox .aar-return-decision-total {
                margin-left: auto;
                text-align: right;
                flex: 0 0 auto;
            }
            .aar-inbox .aar-return-decision-total span {
                display: block;
                color: #2d3033;
                font-size: 13px;
                text-transform: uppercase;
            }
            .aar-inbox .aar-return-decision-total strong {
                display: block;
                color: #4f5a64;
                font-size: 16px;
            }
            .aar-inbox .aar-return-decision-menu {
                top: auto;
                bottom: calc(100% + 4px);
                min-width: 230px;
            }
            .aar-inbox .aar-return-timeline {
                display: block;
                margin: 0;
                padding: 0;
                background: transparent;
                border: 0;
                border-radius: 0;
            }
            .aar-inbox .aar-return-timeline-step {
                position: relative;
                min-width: 0;
                min-height: 52px;
                padding: 0 0 16px 34px;
                color: #7a8288;
            }
            .aar-inbox .aar-return-timeline-step:last-child {
                min-height: 0;
                padding-bottom: 0;
            }
            .aar-inbox .aar-return-timeline-step:before,
            .aar-inbox .aar-return-timeline-step:after {
                content: "";
                position: absolute;
                left: 6px;
                width: 6px;
                background: #e3e7ea;
                z-index: 1;
            }
            .aar-inbox .aar-return-timeline-step:before {
                top: 0;
                height: 8px;
            }
            .aar-inbox .aar-return-timeline-step:after {
                top: 16px;
                bottom: 0;
            }
            .aar-inbox .aar-return-timeline-step:first-child:before,
            .aar-inbox .aar-return-timeline-step:last-child:after {
                display: none;
            }
            .aar-inbox .aar-return-timeline-step.is-completed:before,
            .aar-inbox .aar-return-timeline-step.has-next-completed:after,
            .aar-inbox .aar-return-timeline-step.is-active:before {
                background: #25b9d7;
            }
            .aar-inbox .aar-return-timeline-step.is-active:after {
                background: #e3e7ea;
            }
            .aar-inbox .aar-return-timeline-marker {
                position: absolute;
                top: 1px;
                left: 8px;
                width: 16px;
                height: 16px;
                margin-left: -8px;
                border-radius: 999px;
                background: #d9dde1;
                border: 0;
                box-shadow: 0 0 0 4px #fff;
                z-index: 2;
            }
            .aar-inbox .aar-return-timeline-step.is-completed .aar-return-timeline-marker {
                background: #25b9d7;
                box-shadow: 0 0 0 4px #fff;
            }
            .aar-inbox .aar-return-timeline-step.is-active .aar-return-timeline-marker {
                width: 18px;
                height: 18px;
                top: 0;
                margin-left: -9px;
                background: #25b9d7;
                box-shadow: 0 0 0 4px #fff;
            }
            .aar-inbox .aar-return-timeline-label {
                padding: 0;
                text-align: left;
                color: #2d3033;
                font-size: 14px;
                font-weight: 600;
                line-height: 1.25;
                overflow-wrap: anywhere;
            }
            .aar-inbox .aar-return-timeline-step.is-completed .aar-return-timeline-label {
                color: #25b9d7;
            }
            .aar-inbox .aar-return-timeline-step.is-active .aar-return-timeline-label {
                font-weight: 800;
                color: #25b9d7;
            }
            .aar-inbox .aar-return-timeline-date {
                margin-top: 4px;
                padding: 0;
                text-align: left;
                color: #7a8288;
                font-size: 12px;
                line-height: 1.3;
            }
            .aar-inbox .aar-reply-form {
                margin-top: 0;
                padding: 14px 20px 18px;
                background: #fbfcfc;
                border-top: 1px solid #d8dde0;
                flex: 0 0 auto;
            }
            .aar-inbox .aar-return-decision-panel .aar-reply-form {
                margin-top: 14px;
                padding: 0;
                background: transparent;
                border-top: 0;
                position: static;
            }
            .aar-inbox .aar-return-decision-panel .aar-return-rejection-form.is-collapsed,
            .aar-inbox .aar-return-decision-panel .aar-return-refund-form.is-collapsed {
                display: none;
            }
            .aar-inbox .aar-return-refund-grid {
                display: grid;
                grid-template-columns: minmax(0, 1fr) auto;
                gap: 12px;
                align-items: end;
                padding: 14px 20px 18px;
                background: #fbfcfc;
                border-top: 1px solid #d8dde0;
            }
            .aar-inbox .aar-return-refund-line {
                display: grid;
                grid-template-columns: minmax(180px, 1fr) minmax(150px, 220px);
                gap: 10px;
                align-items: end;
                grid-column: 1 / -1;
            }
            .aar-inbox .aar-return-refund-reasons-wrap {
                grid-column: 1 / -1;
                margin-bottom: 4px;
            }
            .aar-inbox .aar-return-refund-reasons-wrap h5 {
                margin: 0;
                color: #2d3033;
                font-size: 28px;
                font-weight: 700;
            }
            .aar-inbox .aar-return-refund-reasons-hint {
                margin: 8px 0 12px;
                color: #6f757a;
                font-size: 15px;
            }
            .aar-inbox .aar-return-refund-reasons {
                display: block;
            }
            .aar-inbox .aar-return-refund-option {
                display: flex;
                align-items: center;
                gap: 10px;
                margin: 0 0 10px;
                cursor: pointer;
                color: #2d3033;
                font-size: 15px;
                font-weight: 500;
            }
            .aar-inbox .aar-return-refund-option input[type=radio] {
                margin: 0;
                flex: 0 0 auto;
            }
            .aar-inbox .aar-return-refund-reason {
                grid-template-columns: minmax(180px, 1fr) minmax(220px, 360px);
            }
            .aar-inbox .aar-return-refund-line label {
                margin: 0;
                color: #363a41;
                font-weight: 600;
                line-height: 1.25;
            }
            .aar-inbox .aar-return-refund-line label span {
                display: block;
                margin-top: 3px;
                color: #7a8288;
                font-size: 12px;
                font-weight: 400;
            }
            .aar-inbox .aar-return-refund-grid textarea {
                grid-column: 1 / 2;
            }
            .aar-inbox .aar-return-refund-grid textarea,
            .aar-inbox .aar-return-refund-grid select {
                min-height: 40px;
            }
            .aar-inbox .aar-return-refund-grid .aar-send-button {
                grid-column: 2 / 3;
                min-height: 56px;
            }
            .aar-inbox .aar-return-rejection-head h5 {
                margin: 0 0 6px;
                font-size: 18px;
                font-weight: 700;
                color: #2d3033;
                line-height: 1.25;
            }
            .aar-inbox .aar-return-rejection-head p {
                margin: 0 0 14px;
                color: #5d6973;
                font-size: 13px;
                line-height: 1.35;
            }
            .aar-inbox .aar-return-rejection-reasons {
                display: block;
                margin: 0;
            }
            .aar-inbox .aar-return-rejection-option {
                display: flex;
                align-items: flex-start;
                gap: 10px;
                margin: 0 0 10px;
                cursor: pointer;
            }
            .aar-inbox .aar-return-rejection-option input[type=radio] {
                margin-top: 2px;
                flex: 0 0 auto;
            }
            .aar-inbox .aar-return-rejection-option-body {
                display: block;
                min-width: 0;
            }
            .aar-inbox .aar-return-rejection-option-label {
                display: block;
                color: #2d3033;
                font-size: 15px;
                font-weight: 600;
                line-height: 1.3;
            }
            .aar-inbox .aar-return-rejection-option-desc {
                display: block;
                margin-top: 2px;
                color: #6f757a;
                font-size: 12px;
                line-height: 1.35;
            }
            .aar-inbox .aar-return-rejection-comment {
                margin-top: 12px;
            }
            .aar-inbox .aar-return-rejection-comment label {
                display: block;
                margin: 0 0 6px;
                color: #2d3033;
                font-weight: 600;
                font-size: 13px;
            }
            .aar-inbox .aar-return-rejection-comment textarea {
                min-height: 94px;
                font-size: 13px;
                line-height: 1.45;
            }
            .aar-inbox .aar-return-rejection-actions {
                display: flex;
                justify-content: flex-end;
                margin-top: 14px;
            }
            .aar-inbox .aar-return-rejection-actions .aar-send-button {
                min-width: 150px;
                min-height: 42px;
            }
            .aar-inbox .aar-reply-form .form-group {
                margin-bottom: 0;
            }
            .aar-inbox .aar-reply-compose {
                display: flex;
                align-items: flex-end;
                gap: 12px;
            }
            .aar-inbox .aar-reply-compose .form-control {
                flex: 1 1 auto;
            }
            .aar-inbox .aar-reply-compose .aar-quick-reply-dropup {
                flex: 0 0 190px;
            }
            .aar-inbox .aar-reply-compose .aar-quick-reply-button {
                width: 100%;
                height: 56px;
                min-width: 160px;
                padding: 0 14px;
                border-radius: 6px;
                text-align: left;
                color: #363a41;
                background: #fff;
                border-color: #bbcdd8;
            }
            .aar-inbox .aar-reply-compose .aar-quick-reply-button .caret {
                float: right;
                margin-top: 8px;
            }
            .aar-inbox .aar-quick-reply-menu {
                width: 260px;
                max-height: 320px;
                overflow-y: auto;
                padding: 6px 0;
            }
            .aar-inbox .aar-quick-reply-option {
                display: block;
                width: 100%;
                padding: 8px 14px;
                border: 0;
                color: #363a41;
                text-align: left;
                background: transparent;
                white-space: normal;
            }
            .aar-inbox .aar-quick-reply-option:hover,
            .aar-inbox .aar-quick-reply-option:focus {
                color: #fff;
                background: #25b7a8;
            }
            .aar-inbox .aar-reply-form textarea.form-control {
                resize: none;
                min-height: 56px;
                padding: 12px 14px;
                border-radius: 6px;
                background: #fff;
            }
            .aar-inbox .aar-conversation-empty {
                color: #6c757d;
                padding: 24px;
                background: #fff;
                border: 1px dashed #cdd5db;
                border-radius: 6px;
                margin: 20px;
            }
            .aar-inbox textarea.form-control:focus {
                border-color: #25b7a8;
                box-shadow: 0 0 0 1px rgba(37, 183, 168, .18);
            }
            .aar-inbox .btn-primary {
                background: #0b7f72;
                border-color: #0b7f72;
                border-width: 0;
                box-shadow: none;
            }
            .aar-inbox .btn-primary:hover,
            .aar-inbox .btn-primary:focus {
                background: #2d3137;
                border-color: #2d3137;
                box-shadow: none;
            }
            .aar-inbox .aar-send-button {
                flex: 0 0 auto;
                min-width: 108px;
                height: 56px;
                padding: 0 18px;
                border-radius: 6px;
            }
            @media (max-width: 1199px) {
                .aar-inbox-panel {
                    height: auto;
                    min-height: 0;
                }
                .aar-inbox .aar-thread-list {
                    height: 360px;
                }
                .aar-inbox,
                .aar-inbox .aar-inbox-col-conversation,
                .aar-inbox .aar-conversation-shell {
                    min-height: auto;
                    height: auto;
                }
                .aar-inbox .aar-message-window {
                    min-height: 420px;
                    max-height: none;
                    flex: 0 0 auto;
                }
                .aar-inbox .aar-reply-form {
                    position: static;
                }
                .aar-inbox .aar-return-decision-panel {
                    position: static;
                }
                .aar-inbox .aar-reply-compose {
                    flex-direction: column;
                    align-items: stretch;
                }
                .aar-inbox .aar-reply-compose .aar-quick-reply-dropup {
                    width: 100%;
                    flex-basis: auto;
                }
                .aar-inbox .aar-reply-compose .aar-quick-reply-button {
                    height: 44px;
                }
                .aar-inbox .aar-quick-reply-menu {
                    width: 100%;
                }
                .aar-inbox .aar-send-button {
                    width: 100%;
                    height: 44px;
                }
                .aar-inbox .aar-claim-topbar,
                .aar-inbox .aar-claim-deadline-head,
                .aar-inbox .aar-conversation-header {
                    flex-direction: column;
                    align-items: stretch;
                }
                .aar-inbox-panel .aar-issues-filters {
                    justify-content: flex-start;
                    flex-wrap: wrap;
                }
                .aar-inbox .aar-claim-badges,
                .aar-inbox .aar-claim-deadline-date {
                    justify-content: flex-start;
                    align-items: flex-start;
                }
                .aar-inbox .aar-thread-deadline-row {
                    flex-direction: column;
                    align-items: flex-start;
                    gap: 4px;
                }
                .aar-inbox .aar-claim-grid {
                    grid-template-columns: 1fr;
                }
                .aar-inbox .aar-return-simple-grid {
                    grid-template-columns: repeat(2, minmax(0, 1fr));
                }
                .aar-inbox .aar-checkout-details {
                    grid-template-columns: 1fr;
                }
            }
            @media (max-width: 767px) {
                .aar-inbox .aar-return-product-row,
                .aar-inbox .aar-return-simple-grid {
                    grid-template-columns: 1fr;
                }
                .aar-inbox .aar-return-product-side,
                .aar-inbox .aar-return-total,
                .aar-inbox .aar-return-decision-total {
                    text-align: left;
                }
                .aar-inbox .aar-return-decision-panel-head {
                    flex-direction: column;
                    align-items: stretch;
                }
                .aar-inbox .aar-return-decision-dropdown {
                    display: flex;
                    width: 100%;
                }
                .aar-inbox .aar-return-decision-dropdown > .btn {
                    width: 100%;
                }
            }
        </style>
        <script>
            (function () {
                var scheduled = false;

                var getViewportHeight = function () {
                    if (window.visualViewport && window.visualViewport.height) {
                        return Math.floor(window.visualViewport.height);
                    }

                    return window.innerHeight;
                };

                var applyInboxHeight = function () {
                    var panel = document.querySelector(".aar-inbox-panel");
                    if (!panel) {
                        return;
                    }

                    if (window.innerWidth <= 1199) {
                        panel.style.removeProperty("--aar-inbox-height");
                        panel.style.removeProperty("--aar-inbox-top-gap");
                        return;
                    }

                    panel.style.removeProperty("--aar-inbox-top-gap");
                    var rect = panel.getBoundingClientRect();
                    var topGap = 10;
                    var coverBottom = 0;
                    var blockers = document.querySelectorAll("#header, .page-head, .bootstrap .page-head, .toolbarBox");
                    blockers.forEach(function (blocker) {
                        if (!blocker || blocker.contains(panel)) {
                            return;
                        }

                        var style = window.getComputedStyle(blocker);
                        if (style.position !== "fixed" && style.position !== "sticky") {
                            return;
                        }

                        var blockerRect = blocker.getBoundingClientRect();
                        if (blockerRect.bottom > 0 && blockerRect.top < rect.top + 8) {
                            coverBottom = Math.max(coverBottom, blockerRect.bottom);
                        }
                    });
                    if (coverBottom > rect.top) {
                        topGap = Math.min(96, Math.ceil(coverBottom - rect.top + 10));
                        panel.style.setProperty("--aar-inbox-top-gap", topGap + "px");
                        rect = panel.getBoundingClientRect();
                    }

                    var bottomGap = 12;
                    var viewportHeight = getViewportHeight();
                    var available = Math.floor(viewportHeight - Math.max(rect.top, 0) - bottomGap);
                    if (available < 320) {
                        available = 320;
                    }

                    panel.style.setProperty("--aar-inbox-height", available + "px");
                };

                var scrollMessagesToBottom = function () {
                    var windows = document.querySelectorAll(".aar-message-window");
                    windows.forEach(function (messageWindow) {
                        messageWindow.scrollTop = messageWindow.scrollHeight;
                    });
                };

                var scheduleInitialMessageScroll = function () {
                    window.requestAnimationFrame(function () {
                        scrollMessagesToBottom();
                        setTimeout(scrollMessagesToBottom, 50);
                        setTimeout(scrollMessagesToBottom, 250);
                    });
                };

                var loadConversation = function (link, panelSelector, nextPanelSelector) {
                    var panel = link.closest(panelSelector);
                    if (!panel || !window.fetch || !window.DOMParser) {
                        window.location.href = link.href;
                        return;
                    }

                    var target = panel.querySelector(".aar-inbox-col-conversation");
                    if (!target) {
                        window.location.href = link.href;
                        return;
                    }

                    target.classList.add("is-loading");
                    target.innerHTML = \'<div class="aar-conversation-loader" role="status" aria-live="polite"><span class="aar-conversation-spinner" aria-hidden="true"></span></div>\';

                    fetch(link.href, {
                        credentials: "same-origin",
                        headers: {
                            "X-Requested-With": "XMLHttpRequest"
                        }
                    }).then(function (response) {
                        if (!response.ok) {
                            throw new Error("HTTP " + response.status);
                        }

                        return response.text();
                    }).then(function (html) {
                        var doc = new DOMParser().parseFromString(html, "text/html");
                        var nextTarget = doc.querySelector(nextPanelSelector + " .aar-inbox-col-conversation");
                        if (!nextTarget) {
                            throw new Error("Missing conversation panel");
                        }

                        target.innerHTML = nextTarget.innerHTML;
                        panel.querySelectorAll(".aar-thread-item.active").forEach(function (item) {
                            item.classList.remove("active");
                        });
                        link.classList.add("active");
                        if (window.history && window.history.pushState) {
                            window.history.pushState({}, "", link.href);
                        }
                        rafApply();
                        scheduleInitialMessageScroll();
                    }).catch(function () {
                        window.location.href = link.href;
                    }).finally(function () {
                        target.classList.remove("is-loading");
                    });
                };

                document.addEventListener("click", function (event) {
                    var returnAction = event.target.closest("[data-aar-return-action]");
                    if (returnAction) {
                        var decisionPanel = returnAction.closest(".aar-return-decision-panel");
                        var rejectionForm = decisionPanel ? decisionPanel.querySelector(".aar-return-rejection-form") : null;
                        var refundForm = decisionPanel ? decisionPanel.querySelector(".aar-return-refund-form") : null;
                        var dropdown = returnAction.closest(".aar-return-decision-dropdown");
                        var action = String(returnAction.getAttribute("data-aar-return-action"));
                        if (action === "refund" && refundForm) {
                            event.preventDefault();
                            refundForm.classList.remove("is-collapsed");
                            if (rejectionForm) {
                                rejectionForm.classList.add("is-collapsed");
                            }
                            if (dropdown && dropdown.classList) {
                                dropdown.classList.remove("open");
                            }
                            var refundInput = refundForm.querySelector("input[name*=\"[amount]\"]");
                            if (refundInput) {
                                refundInput.focus();
                                refundInput.select();
                            }
                        }
                        if (action === "reject" && rejectionForm) {
                            event.preventDefault();
                            rejectionForm.classList.remove("is-collapsed");
                            if (refundForm) {
                                refundForm.classList.add("is-collapsed");
                            }
                            if (dropdown && dropdown.classList) {
                                dropdown.classList.remove("open");
                            }
                            var textarea = rejectionForm.querySelector("textarea");
                            if (textarea) {
                                textarea.focus();
                            }
                        }
                        return;
                    }

                    var issueLink = event.target.closest(".aar-issues-panel .aar-thread-item");
                    var inboxLink = event.target.closest(".aar-inbox-panel:not(.aar-issues-panel) .aar-thread-item");
                    var link = issueLink || inboxLink;
                    if (!link || event.defaultPrevented || event.button !== 0 || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) {
                        return;
                    }

                    event.preventDefault();
                    if (issueLink) {
                        loadConversation(link, ".aar-issues-panel", ".aar-issues-panel");
                        return;
                    }

                    loadConversation(link, ".aar-inbox-panel", ".aar-inbox-panel:not(.aar-issues-panel)");
                });

                document.addEventListener("click", function (event) {
                    var option = event.target.closest(".aar-quick-reply-option");
                    if (!option) {
                        return;
                    }

                    var template = option.getAttribute("data-aar-template") || "";
                    var form = option.closest("form");
                    var textarea = form ? form.querySelector("textarea[name=\"reply_text\"]") : null;
                    if (!textarea || !template) {
                        return;
                    }

                    event.preventDefault();
                    textarea.value = template;
                    textarea.dispatchEvent(new Event("input", { bubbles: true }));
                    textarea.dispatchEvent(new Event("change", { bubbles: true }));
                    textarea.focus();
                });

                var rafApply = function () {
                    if (scheduled) {
                        return;
                    }

                    scheduled = true;
                    window.requestAnimationFrame(function () {
                        scheduled = false;
                        applyInboxHeight();
                    });
                };

                if (document.readyState === "loading") {
                    document.addEventListener("DOMContentLoaded", function () {
                        rafApply();
                        scheduleInitialMessageScroll();
                    });
                } else {
                    rafApply();
                    scheduleInitialMessageScroll();
                }

                window.addEventListener("load", rafApply);
                window.addEventListener("load", scheduleInitialMessageScroll);
                window.addEventListener("resize", rafApply);
                window.addEventListener("orientationchange", rafApply);
                window.addEventListener("scroll", function (event) {
                    var target = event.target;
                    if (target === document || target === document.documentElement || target === document.body) {
                        rafApply();
                    }
                }, true);
                document.addEventListener("transitionend", rafApply, true);

                if (window.visualViewport) {
                    window.visualViewport.addEventListener("resize", rafApply);
                    window.visualViewport.addEventListener("scroll", rafApply);
                }

                if (window.ResizeObserver) {
                    var resizeObserver = new ResizeObserver(rafApply);
                    resizeObserver.observe(document.body);
                }

            })();
        </script>';
    }

    protected function renderSettingsForm(): string
    {
        $fieldsForm = [
            'form' => [
                'legend' => [
                    'title' => $this->trans('Ustawienia ogólne', [], 'Modules.Allegroautoresponder.Admin'),
                    'icon' => 'icon-cogs',
                ],
                'input' => [
                    [
                        'type' => 'switch',
                        'label' => $this->trans('Włącz moduł', [], 'Modules.Allegroautoresponder.Admin'),
                        'name' => self::CONFIG_PREFIX . 'ENABLED',
                        'is_bool' => true,
                        'values' => [
                            ['id' => 'aar_enabled_on', 'value' => 1, 'label' => $this->trans('Yes', [], 'Admin.Global')],
                            ['id' => 'aar_enabled_off', 'value' => 0, 'label' => $this->trans('No', [], 'Admin.Global')],
                        ],
                    ],
                    [
                        'type' => 'switch',
                        'label' => $this->trans('Tryb testowy automatycznych odpowiedzi', [], 'Modules.Allegroautoresponder.Admin'),
                        'desc' => $this->trans('Gdy jest włączony, automatyczne odpowiedzi są analizowane i logowane, ale nie są wysyłane.', [], 'Modules.Allegroautoresponder.Admin'),
                        'name' => self::CONFIG_PREFIX . 'TEST_MODE',
                        'is_bool' => true,
                        'values' => [
                            ['id' => 'aar_test_on', 'value' => 1, 'label' => $this->trans('Yes', [], 'Admin.Global')],
                            ['id' => 'aar_test_off', 'value' => 0, 'label' => $this->trans('No', [], 'Admin.Global')],
                        ],
                    ],
                    [
                        'type' => 'text',
                        'label' => $this->trans('Limit pobieranych wątków', [], 'Modules.Allegroautoresponder.Admin'),
                        'name' => self::CONFIG_PREFIX . 'POLL_LIMIT',
                    ],
                    [
                        'type' => 'text',
                        'label' => $this->trans('Przerwa między automatycznymi odpowiedziami (minuty)', [], 'Modules.Allegroautoresponder.Admin'),
                        'name' => self::CONFIG_PREFIX . 'COOLDOWN_MINUTES',
                    ],
                ],
                'submit' => [
                    'name' => 'submitAarSettings',
                    'title' => $this->trans('Zapisz', [], 'Modules.Allegroautoresponder.Admin'),
                ],
            ],
        ];

        $helper = new HelperForm();
        $helper->module = $this;
        $helper->name_controller = $this->name;
        $helper->identifier = $this->identifier;
        $helper->token = Tools::getAdminTokenLite('AdminModules');
        $helper->currentIndex = AdminController::$currentIndex . '&configure=' . $this->name;
        $helper->submit_action = 'submitAarSettings';
        $helper->default_form_language = (int) $this->context->language->id;
        $helper->allow_employee_form_lang = (int) $this->context->language->id;
        $helper->fields_value = [
            self::CONFIG_PREFIX . 'ENABLED' => (int) Configuration::get(self::CONFIG_PREFIX . 'ENABLED'),
            self::CONFIG_PREFIX . 'TEST_MODE' => (int) Configuration::get(self::CONFIG_PREFIX . 'TEST_MODE'),
            self::CONFIG_PREFIX . 'REDIRECT_URI' => (string) Configuration::get(self::CONFIG_PREFIX . 'REDIRECT_URI'),
            self::CONFIG_PREFIX . 'POLL_LIMIT' => (int) Configuration::get(self::CONFIG_PREFIX . 'POLL_LIMIT'),
            self::CONFIG_PREFIX . 'COOLDOWN_MINUTES' => (int) Configuration::get(self::CONFIG_PREFIX . 'COOLDOWN_MINUTES'),
        ];

        return $helper->generateForm([$fieldsForm]);
    }

    protected function renderRuleForm(?array $rule = null): string
    {
        $isEdit = is_array($rule);
        $actionLabel = $isEdit ? 'Zapisz regułę' : 'Dodaj regułę';
        $submitName = $isEdit ? 'submitAarSaveRule' : 'submitAarAddRule';
        $matchTypeOptions = $this->getRuleMatchTypeOptions();

        $values = [
            'id_rule' => (int) ($rule['id_rule'] ?? 0),
            'name' => (string) ($rule['name'] ?? ''),
            'enabled' => (int) ($rule['enabled'] ?? 1),
            'priority' => (int) ($rule['priority'] ?? 100),
            'match_type' => (string) ($rule['match_type'] ?? 'contains'),
            'keywords' => (string) ($rule['keywords'] ?? ''),
            'response_template' => (string) ($rule['response_template'] ?? ''),
            'only_first_message' => (int) ($rule['only_first_message'] ?? 1),
            'cooldown_minutes' => (int) ($rule['cooldown_minutes'] ?? 60),
        ];

        $modalId = 'aar-rule-modal';
        $modalTitle = $isEdit
            ? $this->trans('Edycja reguły automatycznej odpowiedzi', [], 'Modules.Allegroautoresponder.Admin')
            : $this->trans('Dodaj regułę automatycznej odpowiedzi', [], 'Modules.Allegroautoresponder.Admin');

        $html = '<div class="modal fade" id="' . $modalId . '" tabindex="-1" role="dialog" aria-hidden="true">';
        $html .= '<div class="modal-dialog modal-lg" role="document">';
        $html .= '<div class="modal-content">';
        $html .= '<form method="post">';
        $html .= '<div class="modal-header">';
        $html .= '<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>';
        $html .= '<h4 class="modal-title">' . $modalTitle . '</h4>';
        $html .= '</div>';
        $html .= '<div class="modal-body">';
        if ($isEdit) {
            $html .= '<input type="hidden" name="id_rule" value="' . (int) $values['id_rule'] . '">';
        }
        $html .= '<div class="form-group"><label>Nazwa</label><input class="form-control" name="rule_name" value="' . Tools::safeOutput($values['name']) . '" required></div>';
        $html .= '<div class="form-group"><label>Priorytet</label><input class="form-control" type="number" name="rule_priority" value="' . (int) $values['priority'] . '"></div>';
        $html .= '<div class="form-group"><label>Typ dopasowania</label><select class="form-control" name="rule_match_type">';
        foreach ($matchTypeOptions as $matchType => $label) {
            $html .= '<option value="' . Tools::safeOutput($matchType) . '"' . ($values['match_type'] === $matchType ? ' selected' : '') . '>' . Tools::safeOutput($label) . '</option>';
        }
        $html .= '</select></div>';
        $html .= '<div class="form-group"><label>Słowa kluczowe / wyrażenie</label><textarea class="form-control" name="rule_keywords" rows="3" required>' . Tools::safeOutput($values['keywords']) . '</textarea></div>';
        $html .= '<div class="form-group"><label>Szablon odpowiedzi</label><textarea class="form-control" name="rule_response_template" rows="6" required>' . Tools::safeOutput($values['response_template']) . '</textarea></div>';
        $html .= '<div class="form-group"><label>Przerwa między odpowiedziami (minuty)</label><input class="form-control" type="number" name="rule_cooldown_minutes" value="' . (int) $values['cooldown_minutes'] . '"></div>';
        $html .= '<div class="checkbox"><label><input type="checkbox" name="rule_only_first_message" value="1"' . ($values['only_first_message'] ? ' checked' : '') . '> Tylko dla pierwszej wiadomości klienta w wątku</label></div>';
        $html .= '<div class="checkbox"><label><input type="checkbox" name="rule_enabled" value="1"' . ($values['enabled'] ? ' checked' : '') . '> Reguła włączona</label></div>';
        $html .= '</div>';
        $html .= '<div class="modal-footer">';
        if ($isEdit) {
            $cancelUrl = AdminController::$currentIndex . '&configure=' . $this->name . '&token=' . Tools::getAdminTokenLite('AdminModules');
            $html .= '<a class="btn btn-default" href="' . Tools::safeOutput($cancelUrl) . '">Anuluj</a>';
        } else {
            $html .= '<button type="button" class="btn btn-default" data-dismiss="modal">Anuluj</button>';
        }
        $html .= '<button class="btn btn-primary" name="' . $submitName . '" type="submit">' . $actionLabel . '</button>';
        $html .= '</div>';
        $html .= '</form>';
        $html .= '</div></div></div>';

        if ($isEdit) {
            $html .= '<script>
                (function () {
                    function openAarRuleModal() {
                        if (window.jQuery && jQuery.fn && jQuery.fn.modal) {
                            jQuery("#' . $modalId . '").modal("show");
                        }
                    }

                    if (document.readyState === "loading") {
                        document.addEventListener("DOMContentLoaded", openAarRuleModal);
                    } else {
                        openAarRuleModal();
                    }
                })();
            </script>';
        }

        return $html;
    }

    protected function renderRulesTable(): string
    {
        $rules = Db::getInstance()->executeS('SELECT * FROM `' . _DB_PREFIX_ . 'allegro_ar_rule` ORDER BY priority ASC, id_rule DESC');
        $html = '<div class="panel">';
        $html .= '<h3>' . $this->trans('Reguły automatycznych odpowiedzi', [], 'Modules.Allegroautoresponder.Admin') . '</h3>';
        $html .= '<div style="display:flex;align-items:center;justify-content:flex-end;gap:8px;flex-wrap:wrap;margin-bottom:15px;">';
        $html .= '<form method="post" style="margin:0;"><button class="btn btn-default" name="submitAarInstallDefaultRules" type="submit">Importuj reguły startowe</button></form>';
        $html .= '<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#aar-rule-modal">Dodaj regułę</button>';
        $html .= '</div>';
        $html .= '<div class="table-responsive"><table class="table"><thead><tr><th>ID</th><th>Nazwa</th><th>Typ</th><th>Priorytet</th><th>Aktywna</th><th>Słowa kluczowe</th><th></th></tr></thead><tbody>';
        if (!$rules) {
            $html .= '<tr><td colspan="7">Brak reguł.</td></tr>';
        } else {
            foreach ($rules as $rule) {
                $editUrl = AdminController::$currentIndex . '&configure=' . $this->name . '&token=' . Tools::getAdminTokenLite('AdminModules') . '&edit_rule=' . (int) $rule['id_rule'];
                $deleteUrl = AdminController::$currentIndex . '&configure=' . $this->name . '&token=' . Tools::getAdminTokenLite('AdminModules') . '&delete_rule=' . (int) $rule['id_rule'];
                $matchTypeOptions = $this->getRuleMatchTypeOptions();
                $html .= '<tr>';
                $html .= '<td>' . (int) $rule['id_rule'] . '</td>';
                $html .= '<td>' . Tools::safeOutput($rule['name']) . '</td>';
                $html .= '<td>' . Tools::safeOutput($matchTypeOptions[(string) $rule['match_type']] ?? (string) $rule['match_type']) . '</td>';
                $html .= '<td>' . (int) $rule['priority'] . '</td>';
                $html .= '<td>' . ((int) $rule['enabled'] ? 'Tak' : 'Nie') . '</td>';
                $html .= '<td><code>' . nl2br(Tools::safeOutput($rule['keywords'])) . '</code></td>';
                $html .= '<td><a class="btn btn-default" href="' . Tools::safeOutput($editUrl) . '">Edytuj</a> <a class="btn btn-default" href="' . Tools::safeOutput($deleteUrl) . '">Usuń</a></td>';
                $html .= '</tr>';
            }
        }
        $html .= '</tbody></table></div></div>';

        return $html;
    }

    protected function renderQuickReplySelect(array $replacements = []): string
    {
        $templates = $this->getQuickReplyTemplates();

        if (!$templates) {
            return '';
        }

        $items = '';

        foreach ($templates as $template) {
            $text = strtr((string) ($template['response_template'] ?? ''), $replacements);
            if (trim($text) === '') {
                continue;
            }

            $items .= '<li>';
            $items .= '<button type="button" class="aar-quick-reply-option" data-aar-template="' . Tools::safeOutput($text) . '">';
            $items .= Tools::safeOutput((string) ($template['name'] ?? 'Gotowa wiadomość'));
            $items .= '</button>';
            $items .= '</li>';
        }

        if ($items === '') {
            return '';
        }

        $html = '<div class="btn-group dropup aar-quick-reply-dropup">';
        $html .= '<button type="button" class="btn btn-default dropdown-toggle aar-quick-reply-button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">';
        $html .= 'Gotowiec <span class="caret"></span>';
        $html .= '</button>';
        $html .= '<ul class="dropdown-menu aar-quick-reply-menu">';
        $html .= $items;
        $html .= '</ul>';
        $html .= '</div>';

        return $html;
    }

    protected function getQuickReplyTemplates(): array
    {
        $templates = Db::getInstance()->executeS(
            'SELECT id_rule, name, response_template FROM `' . _DB_PREFIX_ . 'allegro_ar_rule` WHERE enabled = 1 ORDER BY priority ASC, id_rule DESC'
        );

        return is_array($templates) ? $templates : [];
    }

    protected function renderLogsTable(): string
    {
        $logs = Db::getInstance()->executeS('SELECT * FROM `' . _DB_PREFIX_ . 'allegro_ar_log` ORDER BY id_log DESC LIMIT 50');
        $html = '<div class="panel"><h3>' . $this->trans('Ostatnie logi', [], 'Modules.Allegroautoresponder.Admin') . '</h3>';
        $html .= '<form method="post" style="margin-bottom:15px;"><button class="btn btn-default" name="submitAarRunTest" type="submit">Uruchom skan ręczny</button></form>';
        $html .= '<div class="table-responsive"><table class="table"><thead><tr><th>Data</th><th>Co się stało</th><th>Wątek</th><th>Reguła</th><th>Status</th><th>Szczegóły</th></tr></thead><tbody>';
        if (!$logs) {
            $html .= '<tr><td colspan="6">Brak logów.</td></tr>';
        } else {
            foreach ($logs as $log) {
                $html .= '<tr>';
                $html .= '<td>' . Tools::safeOutput($log['created_at']) . '</td>';
                $html .= '<td>' . Tools::safeOutput($this->formatLogAction((string) $log['action'])) . '</td>';
                $html .= '<td>' . Tools::safeOutput($log['thread_id']) . '</td>';
                $html .= '<td>' . Tools::safeOutput($log['matched_rule']) . '</td>';
                $html .= '<td>' . ((int) $log['success'] ? 'OK' : 'FAIL') . '</td>';
                $html .= '<td><small>' . $this->renderLogDetails($log) . '</small></td>';
                $html .= '</tr>';
            }
        }
        $html .= '</tbody></table></div></div>';

        return $html;
    }

    protected function renderUpdatePanel(): string
    {
        $updater = $this->getUpdater();
        $currentVersion = (string) $this->version;
        $channel = $updater->getConfiguredChannel();
        $domain = method_exists('Tools', 'getShopDomainSsl')
            ? (string) Tools::getShopDomainSsl(false)
            : (string) Tools::getShopDomain(false);
        $ajaxUrl = str_replace('&amp;', '&', $this->context->link->getAdminLink('AdminModules', true, [], [
            'configure' => $this->name,
            'ajax' => 1,
        ]));

        $html = '<style>
            .aar-update-panel {
                padding-bottom: 20px;
            }
            .aar-update-summary {
                display: grid;
                grid-template-columns: repeat(4, minmax(140px, 1fr));
                gap: 12px;
                margin: 0 0 18px;
            }
            .aar-update-summary-item {
                padding: 12px 14px;
                border: 1px solid #d8e2e8;
                border-radius: 6px;
                background: #fbfcfd;
                min-width: 0;
            }
            .aar-update-summary-label {
                display: block;
                margin-bottom: 4px;
                color: #7a8288;
                font-size: 11px;
                font-weight: 700;
                letter-spacing: .04em;
                text-transform: uppercase;
            }
            .aar-update-summary-value {
                display: block;
                color: #2f3b46;
                font-size: 15px;
                font-weight: 700;
                overflow-wrap: anywhere;
            }
            .aar-update-check-row {
                display: flex;
                flex-wrap: wrap;
                align-items: center;
                gap: 10px;
                padding: 14px;
                border: 1px solid #d8e2e8;
                border-radius: 6px;
                background: #f7fafb;
            }
            .aar-update-check-row .form-control {
                width: 170px;
                max-width: 100%;
                margin: 0;
            }
            .aar-update-check-row label {
                margin: 0 4px 0 0;
                color: #5d6973;
                font-weight: 700;
            }
            .aar-update-check-row .btn {
                margin: 0;
            }
            .aar-update-check-row .aar-update-main-button {
                min-width: 210px;
                padding: 8px 16px;
                font-size: 14px;
                font-weight: 700;
                text-align: center;
            }
            .aar-update-message {
                margin: 14px 0 0;
            }
            .aar-update-notes {
                display: flex;
                gap: 12px;
                padding: 14px 16px;
                border: 1px solid #d8e2e8;
                border-left: 4px solid #25b9d7;
                border-radius: 6px;
                background: #ffffff;
                color: #2f3b46;
            }
            .aar-update-notes-icon {
                flex: 0 0 auto;
                width: 28px;
                height: 28px;
                border-radius: 999px;
                display: inline-flex;
                align-items: center;
                justify-content: center;
                color: #ffffff;
                background: #25b9d7;
                font-weight: 700;
            }
            .aar-update-notes-body {
                min-width: 0;
            }
            .aar-update-notes-title {
                margin: 0 0 8px;
                color: #2f3b46;
                font-size: 14px;
                font-weight: 800;
            }
            .aar-update-notes-entry {
                margin: 0 0 10px;
            }
            .aar-update-notes-entry:last-child {
                margin-bottom: 0;
            }
            .aar-update-notes-version {
                margin: 0 0 4px;
                color: #5d6973;
                font-size: 13px;
                font-weight: 800;
            }
            .aar-update-notes-list {
                margin: 0;
                padding-left: 18px;
            }
            .aar-update-notes-list li {
                margin: 3px 0;
            }
            .aar-update-error {
                border-left-color: #d9534f;
            }
            .aar-update-error .aar-update-notes-icon {
                background: #d9534f;
            }
            @media (max-width: 1199px) {
                .aar-update-summary {
                    grid-template-columns: repeat(2, minmax(140px, 1fr));
                }
            }
            @media (max-width: 767px) {
                .aar-update-summary {
                    grid-template-columns: 1fr;
                }
                .aar-update-check-row {
                    align-items: stretch;
                }
                .aar-update-check-row .form-control,
                .aar-update-check-row .btn,
                .aar-update-check-row .aar-update-main-button {
                    width: 100%;
                }
            }
        </style>';

        $html .= '<div class="panel aar-update-panel">';
        $html .= '<h3>' . $this->trans('Informacje o module', [], 'Modules.Allegroautoresponder.Admin') . '</h3>';
        $html .= '<div class="aar-update-summary">';
        $html .= '<div class="aar-update-summary-item"><span class="aar-update-summary-label">Wersja</span><span class="aar-update-summary-value">' . Tools::safeOutput($currentVersion) . '</span></div>';
        $html .= '<div class="aar-update-summary-item"><span class="aar-update-summary-label">Licencja dla</span><span class="aar-update-summary-value">—</span></div>';
        $html .= '<div class="aar-update-summary-item"><span class="aar-update-summary-label">Domena</span><span class="aar-update-summary-value">' . Tools::safeOutput($domain !== '' ? $domain : '—') . '</span></div>';
        $html .= '<div class="aar-update-summary-item"><span class="aar-update-summary-label">Wygasa</span><span class="aar-update-summary-value">—</span></div>';
        $html .= '</div>';

        $html .= '<form method="post" class="aar-update-check-row">';
        $html .= '<label for="aarUpdateChannel">Kanał</label>';
        $html .= '<select id="aarUpdateChannel" name="aar_update_channel" class="form-control" aria-label="Kanał aktualizacji">';
        foreach (AllegroAutoresponderUpdater::getAvailableChannels() as $option) {
            $html .= '<option value="' . Tools::safeOutput($option) . '"' . ($channel === $option ? ' selected' : '') . '>' . Tools::safeOutput(ucfirst($option)) . '</option>';
        }
        $html .= '</select>';
        $html .= '<button type="submit" class="btn btn-default" name="submitAarSaveUpdateSettings">Zapisz</button>';
        $html .= '<button type="button" class="btn btn-primary aar-update-main-button" id="aarManualUpdateCheck" data-update-action="check"><i class="icon-refresh"></i> Sprawdź aktualizacje</button>';
        $html .= '</form>';
        $html .= '<div class="aar-update-message" id="aarManualUpdateMessage" style="display:none;"></div>';
        $html .= '<script>
            (function () {
                var ajaxUrl = ' . json_encode($ajaxUrl) . ';
                var button = document.getElementById("aarManualUpdateCheck");

                function setManualUpdateButtonState(tone, action, label) {
                    if (!button) {
                        return;
                    }

                    button.classList.remove("btn-primary", "btn-success", "btn-danger", "btn-default");
                    button.classList.add(tone === "danger" ? "btn-danger" : (tone === "success" ? "btn-success" : "btn-primary"));
                    button.setAttribute("data-update-action", action || "check");
                    button.innerHTML = "<i class=\"icon-refresh\"></i> " + label;
                }

                function escapeHtml(value) {
                    return String(value || "").replace(/[&<>"\']/g, function (character) {
                        return {
                            "&": "&amp;",
                            "<": "&lt;",
                            ">": "&gt;",
                            "\"": "&quot;",
                            "\'": "&#039;"
                        }[character];
                    });
                }

                function setUpdateMessage(message, isError) {
                    var messageEl = document.getElementById("aarManualUpdateMessage");
                    if (!messageEl) {
                        return;
                    }

                    messageEl.style.display = message ? "" : "none";
                    messageEl.className = "aar-update-message";
                    if (!message) {
                        messageEl.innerHTML = "";
                        return;
                    }

                    if (isError) {
                        messageEl.innerHTML = "<div class=\"aar-update-notes aar-update-error\"><span class=\"aar-update-notes-icon\">!</span><div class=\"aar-update-notes-body\"><p class=\"aar-update-notes-title\">Nie udało się sprawdzić aktualizacji</p><div>" + escapeHtml(message) + "</div></div></div>";
                        return;
                    }

                    messageEl.innerHTML = message;
                }

                function formatUpdateChangelog(changelog) {
                    var entries = changelog && Array.isArray(changelog.entries) ? changelog.entries : [];
                    if (!entries.length) {
                        return "";
                    }

                    var html = "<div class=\"aar-update-notes\"><span class=\"aar-update-notes-icon\">i</span><div class=\"aar-update-notes-body\"><p class=\"aar-update-notes-title\">Zmiany w aktualizacji</p>";
                    entries.forEach(function (entry) {
                        var header = "v" + escapeHtml(entry.version || "");
                        if (entry.date) {
                            header += " - " + escapeHtml(entry.date);
                        }
                        html += "<div class=\"aar-update-notes-entry\"><p class=\"aar-update-notes-version\">" + header + "</p>";

                        var items = Array.isArray(entry.items) ? entry.items : [];
                        if (items.length) {
                            html += "<ul class=\"aar-update-notes-list\">";
                            items.forEach(function (item) {
                                if (item) {
                                    html += "<li>" + escapeHtml(item) + "</li>";
                                }
                            });
                            html += "</ul>";
                        }
                        html += "</div>";
                    });

                    html += "</div></div>";

                    return html;
                }

                function buildManualUpdateBody(action) {
                    var channelSelect = document.querySelector("select[name=\"aar_update_channel\"]");
                    var body = new URLSearchParams();
                    body.append("ajax", "1");
                    body.append("action", action);
                    if (channelSelect && channelSelect.value) {
                        body.append("channel", channelSelect.value);
                    }

                    return body;
                }

                function fetchUpdateAction(action) {
                    return fetch(ajaxUrl, {
                        method: "POST",
                        credentials: "same-origin",
                        headers: {
                            "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
                            "X-Requested-With": "XMLHttpRequest"
                        },
                        body: buildManualUpdateBody(action).toString()
                    }).then(function (response) {
                        return response.text().then(function (text) {
                            var json;
                            try {
                                json = JSON.parse(text);
                            } catch (error) {
                                text = text.replace(/<[^>]*>/g, " ").replace(/\\s+/g, " ").trim();
                                throw new Error(text ? text.substring(0, 220) : "Nieprawidłowa odpowiedź serwera.");
                            }

                            if (!response.ok || !json || json.ok === false) {
                                throw new Error((json && (json.error || json.message)) || "Błąd aktualizacji.");
                            }

                            return json;
                        });
                    });
                }

                function checkUpdatesManually() {
                    if (!button) {
                        return;
                    }

                    button.disabled = true;
                    setUpdateMessage("", false);
                    setManualUpdateButtonState("primary", "check", "Sprawdzam...");

                    fetchUpdateAction("CheckForUpdates")
                        .then(function (data) {
                            var status = data && data.ok ? (data.status || {}) : null;

                            if (!status || !status.configured) {
                                setManualUpdateButtonState("primary", "check", "Aktualizacje nieskonfigurowane");
                                return;
                            }

                            if (status.available && status.version) {
                                setManualUpdateButtonState("danger", "install", "Zaktualizuj do " + status.version);
                                var updateMessage = formatUpdateChangelog(data.changelog || {});
                                if (!updateMessage && status.notes) {
                                    updateMessage = status.notes;
                                }
                                if (updateMessage) {
                                    setUpdateMessage(updateMessage, false);
                                }
                                return;
                            }

                            setManualUpdateButtonState("success", "check", "Brak aktualizacji");
                        })
                        .catch(function (error) {
                            setManualUpdateButtonState("primary", "check", "Błąd sprawdzania");
                            setUpdateMessage(error.message || "Nie udało się sprawdzić aktualizacji.", true);
                        })
                        .finally(function () {
                            button.disabled = false;
                        });
                }

                function installManualUpdate() {
                    if (!button) {
                        return;
                    }

                    var currentLabel = button.textContent.replace(/\\s+/g, " ").trim() || "Zaktualizuj";
                    button.disabled = true;
                    setUpdateMessage("", false);
                    setManualUpdateButtonState("danger", "install", "Instaluję aktualizację...");

                    fetchUpdateAction("InstallUpdate")
                        .then(function (data) {
                            if (!data || !data.ok) {
                                throw new Error("install");
                            }

                            setManualUpdateButtonState("success", "check", data.version ? "Zaktualizowano do " + data.version : "Zaktualizowano");
                        })
                        .catch(function (error) {
                            setManualUpdateButtonState("danger", "install", currentLabel);
                            setUpdateMessage(error.message || "Nie udało się zainstalować aktualizacji.", true);
                        })
                        .finally(function () {
                            button.disabled = false;
                        });
                }

                if (button) {
                    button.addEventListener("click", function () {
                        if ((button.getAttribute("data-update-action") || "check") === "install") {
                            installManualUpdate();
                        } else {
                            checkUpdatesManually();
                        }
                    });
                }
            })();
        </script>';
        $html .= '</div>';

        return $html;
    }

    protected function getUpdater(): AllegroAutoresponderUpdater
    {
        return new AllegroAutoresponderUpdater($this->getLocalPath(), $this);
    }

    protected function formatLogAction(string $action): string
    {
        $labels = [
            'test_reply' => 'TEST: wysłałby odpowiedź',
            'reply_sent' => 'Wysłano automatyczną odpowiedź',
            'reply_failed' => 'Błąd automatycznej odpowiedzi',
            'no_match' => 'Brak pasującej reguły',
            'first_message_skip' => 'Pominięto: to nie pierwsza wiadomość',
            'cooldown_skip' => 'Pominięto: aktywna przerwa',
            'manual_reply_sent' => 'Wysłano ręczną odpowiedź',
            'manual_reply_failed' => 'Błąd ręcznej odpowiedzi',
            'issue_reply_sent' => 'Wysłano odpowiedź w zgłoszeniu',
            'issue_reply_failed' => 'Błąd odpowiedzi w zgłoszeniu',
            'mark_read_failed' => 'Nie udało się oznaczyć jako przeczytane',
        ];

        return $labels[$action] ?? $action;
    }

    protected function renderLogDetails(array $log): string
    {
        $request = $this->decodeLogPayload((string) ($log['request_payload'] ?? ''));
        $response = $this->decodeLogPayload((string) ($log['response_payload'] ?? ''));
        $parts = [];

        $incoming = (string) ($request['incoming'] ?? $request['text'] ?? '');
        if ($incoming !== '') {
            $parts[] = '<strong>Wiadomość klienta:</strong> ' . nl2br(Tools::safeOutput($this->shortenLogText($incoming, 260)));
        }

        $outgoing = (string) ($response['outgoing'] ?? '');
        if ($outgoing !== '') {
            $parts[] = '<strong>Automatyczna odpowiedź:</strong> ' . nl2br(Tools::safeOutput($this->shortenLogText($outgoing, 360)));
        }

        $reason = (string) ($response['reason'] ?? '');
        if ($reason !== '') {
            $parts[] = '<strong>Powód:</strong> ' . Tools::safeOutput($reason);
        }

        $error = (string) ($request['error'] ?? $response['error'] ?? '');
        if ($error !== '') {
            $parts[] = '<strong>Błąd:</strong> ' . Tools::safeOutput($this->shortenLogText($error, 260));
        }

        $context = $request['context'] ?? [];
        if (is_array($context)) {
            $contextParts = [];
            if (!empty($context['recipient_login'])) {
                $contextParts[] = 'kupujący: ' . (string) $context['recipient_login'];
            }
            if (!empty($context['order_id'])) {
                $contextParts[] = 'zamówienie: ' . (string) $context['order_id'];
            }
            if (!empty($context['offer_id'])) {
                $contextParts[] = 'oferta: ' . (string) $context['offer_id'];
            }
            if ($contextParts) {
                $parts[] = '<strong>Kontekst:</strong> ' . Tools::safeOutput(implode(', ', $contextParts));
            }
        }

        if (!$parts) {
            $raw = (string) ($log['response_payload'] ?? $log['request_payload'] ?? '');
            $parts[] = Tools::safeOutput($this->shortenLogText($raw, 260));
        }

        return implode('<br>', $parts);
    }

    protected function decodeLogPayload(string $payload): array
    {
        $decoded = json_decode($payload, true);
        return is_array($decoded) ? $decoded : [];
    }

    protected function shortenLogText(string $text, int $limit): string
    {
        $text = trim($text);
        if (mb_strlen($text) <= $limit) {
            return $text;
        }

        return mb_substr($text, 0, $limit - 3) . '...';
    }

    protected function findThreadById(array $threads, string $threadId): ?array
    {
        foreach ($threads as $thread) {
            if (is_array($thread) && (string) ($thread['id'] ?? '') === $threadId) {
                return $thread;
            }
        }

        return null;
    }

    protected function findIssueById(array $issues, string $issueId): ?array
    {
        foreach ($issues as $issue) {
            if (is_array($issue) && (string) ($issue['id'] ?? '') === $issueId) {
                return $issue;
            }
        }

        return null;
    }

    protected function extractOrderId(array $messages): ?string
    {
        foreach ($messages as $message) {
            if (!is_array($message)) {
                continue;
            }

            $orderId = $this->normalizeOptionalId($message['relatesTo']['order']['id'] ?? null);
            if ($orderId !== '') {
                return $orderId;
            }
        }

        return null;
    }

    protected function extractOfferId(array $messages): ?string
    {
        foreach ($messages as $message) {
            if (!is_array($message)) {
                continue;
            }

            $offerId = $this->normalizeOptionalId($message['relatesTo']['offer']['id'] ?? null);
            if ($offerId !== '') {
                return $offerId;
            }
        }

        return null;
    }

    protected function normalizeOptionalId($value): string
    {
        if (!is_scalar($value)) {
            return '';
        }

        $value = trim((string) $value);
        if ($value === '' || mb_strtolower($value) === 'null') {
            return '';
        }

        return $value;
    }

    protected function decodeAllegroText(string $text): string
    {
        return html_entity_decode($text, ENT_QUOTES | ENT_HTML5, 'UTF-8');
    }

    protected function formatAllegroDate(string $date): string
    {
        if ($date === '') {
            return '';
        }

        $timestamp = strtotime($date);
        if (!$timestamp) {
            return $date;
        }

        return date('Y-m-d H:i', $timestamp);
    }

    protected function getAdminMessagesUrl(array $params = []): string
    {
        if (!isset($params['thread_pages'])) {
            $threadPages = $this->getCurrentThreadPageCount();
            if ($threadPages > 1) {
                $params['thread_pages'] = $threadPages;
            }
        }

        return $this->context->link->getAdminLink('AdminAllegroAutoresponderMessages', true, [], $params);
    }

    protected function getReturnsAdminUrl(array $params = []): string
    {
        if (!isset($params['return_status'])) {
            $params['return_status'] = $this->getCurrentReturnStatusFilter();
        }
        if (!isset($params['return_date_range'])) {
            $params['return_date_range'] = $this->getCurrentReturnDateRangeFilter();
        }
        if (!isset($params['return_query'])) {
            $params['return_query'] = trim((string) Tools::getValue('return_query'));
        }
        if (!isset($params['return_pages'])) {
            $returnPages = $this->getCurrentReturnPageCount();
            if ($returnPages > 1) {
                $params['return_pages'] = $returnPages;
            }
        }

        $params = array_filter($params, function ($value): bool {
            return $value !== null && $value !== false && $value !== '';
        });

        return $this->context->link->getAdminLink('AdminAllegroAutoresponderReturns', true, [], $params);
    }

    protected function getIssuesAdminUrl(string $issueType, array $params = []): string
    {
        $normalizedType = mb_strtoupper($issueType);
        if ($normalizedType === 'CLAIM') {
            $controller = 'AdminAllegroAutoresponderComplaints';
        } elseif ($normalizedType === 'DISPUTE') {
            $controller = 'AdminAllegroAutoresponderDisputes';
        } else {
            $currentController = (string) Tools::getValue('controller');
            $controller = $currentController === 'AdminAllegroAutoresponderDisputes'
                ? 'AdminAllegroAutoresponderDisputes'
                : 'AdminAllegroAutoresponderComplaints';
        }

        if (!isset($params['status_filter'])) {
            $statusFilter = $this->getCurrentIssueStatusFilter();
            if ($statusFilter !== 'all') {
                $params['status_filter'] = $statusFilter;
            }
        }
        if (!isset($params['issue_kind'])) {
            $issueKind = $this->getCurrentIssueKindFilter($normalizedType !== '' ? $normalizedType : 'CLAIM');
            if ($issueKind !== 'CLAIM') {
                $params['issue_kind'] = $issueKind;
            }
        }
        if (!isset($params['issue_pages'])) {
            $issuePages = $this->getCurrentIssuePageCount();
            if ($issuePages > 1) {
                $params['issue_pages'] = $issuePages;
            }
        }

        return $this->context->link->getAdminLink($controller, true, [], $params);
    }

    protected function getEditedRule(): ?array
    {
        $idRule = (int) Tools::getValue('edit_rule');
        if ($idRule <= 0) {
            return null;
        }

        $rule = Db::getInstance()->getRow('SELECT * FROM `' . _DB_PREFIX_ . 'allegro_ar_rule` WHERE id_rule=' . (int) $idRule);
        return is_array($rule) ? $rule : null;
    }

    protected function getRuleMatchTypeOptions(): array
    {
        return [
            'contains' => 'Zawiera jedno ze słów lub zdań z listy',
            'exact' => 'Jest dokładnie równe tej treści',
            'regex' => 'Pasuje do zaawansowanego wzorca (regex)',
        ];
    }

    protected function getOauthCallbackUrl(): string
    {
        return $this->context->link->getModuleLink($this->name, 'oauth');
    }

    protected function getAuthorizationUrl(): string
    {
        return '';
    }

    protected function hasAllegroAuthBackend(): bool
    {
        return (new TokenManager())->hasAuthBackend();
    }

    protected function getConnectedAccount(): ?array
    {
        $account = Db::getInstance()->getRow('SELECT allegro_user_id, login, expires_at, scope, active, date_upd FROM `' . _DB_PREFIX_ . 'allegro_ar_account` ORDER BY id_account ASC');
        return is_array($account) ? $account : null;
    }
}

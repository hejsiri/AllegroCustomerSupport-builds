# Release Automation

Mechanizm aktualizacji działa jak w `CARGO_STOCK_MANAGER`:

- źródła modułu są w prywatnym repo,
- gotowe ZIP-y i podpisany manifest `latest.json` są w publicznym repo buildów,
- moduł pobiera manifest, weryfikuje podpis RSA i SHA-256 paczki, a dopiero potem instaluje aktualizację.

## Repozytoria

- źródła: `git@github.com:hejsiri/AllegroCustomerSupport.git`
- buildy: `git@github.com:hejsiri/AllegroCustomerSupport-builds.git`

## Konfiguracja

Klucz publiczny używany przez moduł jest w:

`keys/update_public.pem`

Prywatny klucz podpisu jest lokalny i ignorowany przez git:

`config/update_private.pem`

## Release

```bash
bash scripts/release_build.sh
```

Skrypt:

- buduje ZIP z aktualnego `HEAD`,
- usuwa z paczki lokalną konfigurację release,
- liczy SHA-256,
- podpisuje manifest prywatnym kluczem,
- aktualizuje `latest.json` w repo buildów,
- wypycha publiczne buildy na GitHub.

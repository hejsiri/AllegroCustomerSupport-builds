<?php

declare(strict_types=1);

$root = dirname(__DIR__);
require_once __DIR__ . '/license_generator_lib.php';

function aarLicenseUsage(): string
{
    return implode(PHP_EOL, [
        'Usage:',
        '  php scripts/generate_license.php --module=allegrocustomerservice --domain=example.com --expires=2027-12-31 --customer="Client" --output=license.php',
        '',
        'Options:',
        '  --module       Technical PrestaShop module name, e.g. allegrocustomerservice or cargostockmanager.',
        '  --domain       Licensed domain. Plain domains also cover subdomains; use *.example.com for wildcard.',
        '  --expires      Expiry date in YYYY-MM-DD format.',
        '  --customer     Optional customer name saved in the signed payload.',
        '  --private-key  Path to RSA private key. Defaults to LICENSE_PRIVATE_KEY, config/license_private.pem,',
        '                 config/update_private.pem, or the local CargoStockManager tools key when present.',
        '  --output       Output file. Use - to print to STDOUT. Default: license.php in current directory.',
        '  --key-only     Print or save only the license key instead of a PHP license.php file.',
        '  --help         Show this help.',
        '',
    ]);
}

$options = getopt('', [
    'module:',
    'domain:',
    'expires:',
    'customer::',
    'private-key::',
    'output::',
    'key-only',
    'help',
]);

if (isset($options['help'])) {
    fwrite(STDOUT, aarLicenseUsage());
    exit(0);
}

$module = trim((string) ($options['module'] ?? 'allegrocustomerservice'));
$domain = trim((string) ($options['domain'] ?? ''));
$expires = trim((string) ($options['expires'] ?? ''));
$customer = trim((string) ($options['customer'] ?? ''));
$privateKey = trim((string) ($options['private-key'] ?? ''));
$output = trim((string) ($options['output'] ?? 'license.php'));
$keyOnly = array_key_exists('key-only', $options);

if ($privateKey === '') {
    $privateKey = aarLicenseDefaultPrivateKey($root);
}

if ($domain === '' || $expires === '' || $module === '') {
    fwrite(STDERR, aarLicenseUsage());
    exit(1);
}

try {
    $licenseKey = aarLicenseBuildKey($privateKey, $module, $domain, $expires, $customer);
    $contents = $keyOnly ? $licenseKey . PHP_EOL : aarLicenseBuildPhp($licenseKey);

    if ($output === '-') {
        fwrite(STDOUT, $contents);
    } else {
        $outputDir = dirname($output);
        if ($outputDir !== '.' && !is_dir($outputDir) && !mkdir($outputDir, 0775, true) && !is_dir($outputDir)) {
            throw new RuntimeException('Could not create output directory: ' . $outputDir);
        }
        if (file_put_contents($output, $contents) === false) {
            throw new RuntimeException('Could not write output file: ' . $output);
        }

        fwrite(STDOUT, 'License written: ' . $output . PHP_EOL);
    }
} catch (Throwable $e) {
    fwrite(STDERR, $e->getMessage() . PHP_EOL);
    exit(1);
}

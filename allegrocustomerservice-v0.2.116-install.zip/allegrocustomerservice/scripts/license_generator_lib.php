<?php

declare(strict_types=1);

function aarLicenseBase64UrlEncode(string $value): string
{
    return rtrim(strtr(base64_encode($value), '+/', '-_'), '=');
}

function aarLicenseBuildKey(string $privateKeyPath, string $module, string $domain, string $expires, string $customer = ''): string
{
    $privateKeyPath = trim($privateKeyPath);
    $module = trim($module);
    $domain = trim($domain);
    $expires = trim($expires);
    $customer = trim($customer);

    if ($module === '' || $domain === '' || $expires === '') {
        throw new InvalidArgumentException('module, domain and expires are required.');
    }

    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $expires)) {
        throw new InvalidArgumentException('expires must use YYYY-MM-DD format.');
    }

    if ($privateKeyPath === '' || !is_file($privateKeyPath)) {
        throw new RuntimeException('Private key not found. Pass --private-key or set LICENSE_PRIVATE_KEY.');
    }

    $payload = [
        'module' => $module,
        'domain' => $domain,
        'expires_at' => $expires,
        'issued_at' => gmdate('c'),
    ];

    if ($customer !== '') {
        $payload['customer'] = $customer;
    }

    $payloadJson = json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    if (!is_string($payloadJson) || $payloadJson === '') {
        throw new RuntimeException('Could not encode license payload.');
    }

    $payloadEncoded = aarLicenseBase64UrlEncode($payloadJson);
    $privateKey = (string) file_get_contents($privateKeyPath);
    if (!openssl_sign($payloadEncoded, $signature, $privateKey, OPENSSL_ALGO_SHA256)) {
        throw new RuntimeException('Could not sign license payload.');
    }

    return $payloadEncoded . '.' . aarLicenseBase64UrlEncode($signature);
}

function aarLicenseBuildPhp(string $licenseKey): string
{
    return "<?php\n\nreturn [\n    'key' => '" . addslashes($licenseKey) . "',\n];\n";
}

function aarLicenseDefaultPrivateKey(string $root): string
{
    $envPath = trim((string) getenv('LICENSE_PRIVATE_KEY'));
    $candidates = [
        $envPath,
        rtrim($root, '/') . '/config/license_private.pem',
        rtrim($root, '/') . '/config/update_private.pem',
        '/Users/paweltucki/Sites/localhost/CARGO_STOCK_MANAGER/cargostockmanager-tools/keys/license_private.pem',
    ];

    foreach ($candidates as $candidate) {
        if ($candidate !== '' && is_file($candidate)) {
            return $candidate;
        }
    }

    return '';
}

function aarLicenseDecodePayload(string $licenseKey): array
{
    $parts = explode('.', trim($licenseKey), 2);
    if (count($parts) !== 2) {
        return [];
    }

    $payload = strtr($parts[0], '-_', '+/');
    $remainder = strlen($payload) % 4;
    if ($remainder > 0) {
        $payload .= str_repeat('=', 4 - $remainder);
    }

    $json = base64_decode($payload, true);
    if (!is_string($json) || $json === '') {
        return [];
    }

    $decoded = json_decode($json, true);

    return is_array($decoded) ? $decoded : [];
}

<?php

if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_2_1_121($module)
{
    return Configuration::updateValue('AAR_PRESTINO_BUILD', 35);
}
